# EcoConect

Plataforma web de acompanhamento terapêutico e de conexão com a rede de apoio e o SUS para pessoas neurodivergentes, famílias, profissionais e instituições.
Projeto da equipe **FynkTech** (UPX II · ADS · UniFacens · 2026).

## Requisitos

- Windows 10/11 (ou Linux/macOS)
- **Java JDK 17 ou superior** ([adoptium.net](https://adoptium.net)): no Windows, o setup oferece instalar pelo `winget`
- **MySQL 8** em execução, ou **Docker Desktop**: sem MySQL, o MySQL 8 sobe automaticamente no Docker
- Internet **só na primeira execução**, para o Maven baixar as bibliotecas

## Instalar e iniciar

1. Execute **`start.bat`** (no Linux/macOS: `./start.sh`).
2. Na primeira vez, o setup roda sozinho. Ele verifica o Java, baixa o Maven se for preciso e pede **uma vez** a senha do MySQL, que fica salva em `ecoconnect.properties`. Depois compila, roda os testes automatizados e cria o banco `ecoconnect` com as migrations.
3. Quando aparecer **"EcoConect em execução"**, o navegador abre em **http://localhost:8080/app/**.

Nas próximas vezes, basta executar `start.bat` de novo.

## Acessar

| Conta | E-mail | Senha |
|---|---|---|
| Administrador inicial | `admin@ecoconnect.com` | `Admin1234` (é obrigatório trocar no primeiro acesso) |
| Contas de demonstração (fictícias) | `ana.ribeiro@demo.ecoconect.local` (profissional), `mariana.alves@demo.ecoconect.local` (família), `lucas.martins@demo.ecoconect.local` (pessoa acompanhada), `roberta.lima@demo.ecoconect.local` (instituição) | `EcoDemo2026` |

As contas de demonstração e os dados fictícios só são criados em um banco vazio. Para começar sem eles, defina `ECO_DADOS_DEMO=false` em `ecoconnect.properties` **antes** da primeira inicialização.

## Encerrar e outros comandos

| Comando | O que faz |
|---|---|
| `stop.bat` / `./stop.sh` | encerra o sistema |
| `restart.bat` / `./restart.sh` | reinicia |
| `healthcheck.bat` / `./healthcheck.sh` | verifica Java, MySQL, API e banco. Com `-Completo` (`--completo` no Linux), roda também o teste ponta a ponta |
| `setup.bat` / `./setup.sh` | refaz a instalação (compilação e testes) |
| `console.bat` / `./console.sh` | abre o Console Java, que usa o mesmo banco |

Os registros ficam em `logs/ecoconect-api.log`. A documentação técnica está em [`docs/`](docs/) e a das rotas da API em http://localhost:8080/swagger-ui.html.
