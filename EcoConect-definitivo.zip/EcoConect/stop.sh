#!/usr/bin/env bash
# EcoConect - stop (Linux/macOS)
exec "$(dirname "$0")/scripts/ecoconect.sh" stop "$@"
