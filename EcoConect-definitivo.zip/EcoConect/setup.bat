@echo off
rem EcoConect - setup (Windows). Detalhes em scripts\ecoconect.ps1
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\ecoconect.ps1" setup %*
set CODIGO=%ERRORLEVEL%
if not "%ECO_SEM_PAUSA%"=="1" pause
exit /b %CODIGO%
