#!/usr/bin/env bash
# EcoConect - console (Linux/macOS)
exec "$(dirname "$0")/scripts/ecoconect.sh" console "$@"
