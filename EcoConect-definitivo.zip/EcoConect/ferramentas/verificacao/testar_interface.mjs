// Testes das funções puras da interface (formatação de datas, rótulos) - executar com: node testar_interface.mjs
import assert from 'node:assert/strict';
const caminho = new URL('../../ecoconnect-api-jpa/src/main/resources/static/app/js/ui.js', import.meta.url);
const ui = await import(caminho);
let ok = 0;
const teste = (nome, fn) => { fn(); ok++; console.log('  OK    ' + nome); };
teste('data no formato brasileiro', () => assert.equal(ui.dataBR('2026-11-10'), '10/11/2026'));
teste('data e hora com "às"', () => assert.equal(ui.dataHoraBR('2026-11-10T14:05:00'), '10/11/2026 às 14:05'));
teste('data ISO para os filtros', () => assert.equal(ui.isoData(new Date(2026, 0, 5)), '2026-01-05'));
teste('rótulo de mês do gráfico', () => assert.equal(ui.mesRotulo('2026-03'), 'mar/26'));
teste('dia da semana por extenso', () => assert.equal(ui.dataExtensa('2026-11-09'), 'segunda, 9 de nov'));
teste('valores booleanos vindos do MySQL', () => { assert.equal(ui.sim(1), true); assert.equal(ui.sim(0), false); assert.equal(ui.sim(true), true); });
teste('datas vazias não quebram a tela', () => { assert.equal(ui.dataBR(null), ''); assert.equal(ui.dataHoraBR(''), ''); });
teste('todas as situações de agendamento têm rótulo', () => {
  for (const s of ['SOLICITADO', 'EM_ANALISE', 'CONFIRMADO', 'RECUSADO', 'CANCELADO', 'AUSENTE', 'REALIZADO']) assert.ok(ui.ROTULOS.agendamento[s], s);
});
teste('todos os perfis têm rótulo', () => {
  for (const p of ['ADMINISTRADOR', 'PROFISSIONAL', 'RESPONSAVEL', 'ADMIN_INSTITUCIONAL', 'PESSOA_ACOMPANHADA']) assert.ok(ui.ROTULOS.perfil[p], p);
});
console.log(`Testes da interface: ${ok}, falhas: 0`);
