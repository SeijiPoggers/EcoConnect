#!/usr/bin/env python3
"""
Contrato front-end x back-end: toda chamada api()/baixar() do front-end precisa corresponder
a uma rota existente nos controllers Java, com o mesmo método HTTP.
Uso: python3 verificar_contrato.py <pasta ecoconnect-api-jpa>  (gera rotas-frontend.txt para a matriz de permissões)
"""
import os, re, sys
raiz = sys.argv[1] if len(sys.argv) > 1 else '.'
java = os.path.join(raiz, 'src/main/java')
js = os.path.join(raiz, 'src/main/resources/static/app/js')

def normalizar(p):
    p = p.split('?')[0]
    p = re.sub(r'\$\{[^}]*\}', '{}', p)
    p = re.sub(r'\{[^}/]*\}', '{}', p)
    return p.rstrip('/') or '/'

# ------------------------------------------------------------- rotas do back-end
rotas = set()
for d, _, fs in os.walk(java):
    for f in fs:
        if not f.endswith('Controller.java'):
            continue
        t = open(os.path.join(d, f), encoding='utf-8').read()
        if '@RestController' not in t:
            continue
        m = re.search(r'@RequestMapping\(\s*(?:value\s*=\s*)?"([^"]*)"', t)
        prefixo = m.group(1) if m else ''
        for m in re.finditer(r'@(Get|Post|Put|Patch|Delete)Mapping(?:\(\s*(?:value\s*=\s*)?(?:"([^"]*)")?[^)]*\))?', t):
            rotas.add((m.group(1).upper(), normalizar(prefixo + (m.group(2) or ''))))
        if 'extends CrudController' in t or 'extends LeituraController' in t:
            rotas.add(('GET', normalizar(prefixo))); rotas.add(('GET', normalizar(prefixo + '/{id}')))
        if 'extends CrudController' in t:
            for met, suf in (('POST', ''), ('PUT', '/{id}'), ('DELETE', '/{id}')):
                rotas.add((met, normalizar(prefixo + suf)))

# ------------------------------------------------------------- chamadas do front-end
def fim_da_chamada(texto, abre):
    nivel = 0
    for i in range(abre, len(texto)):
        c = texto[i]
        if c == '(':
            nivel += 1
        elif c == ')':
            nivel -= 1
            if nivel == 0:
                return i
    return len(texto)

chamadas, erros = [], []
for d, _, fs in os.walk(js):
    for f in fs:
        if not f.endswith('.js'):
            continue
        t = open(os.path.join(d, f), encoding='utf-8').read()
        for m in re.finditer(r'\b(api|baixar)\(\s*([`\'"])(/api/[^`\'"]*)\2', t):
            trecho = t[m.start(): fim_da_chamada(t, t.index('(', m.start())) + 1]
            met = re.search(r"metodo:\s*'(\w+)'", trecho)
            metodo = met.group(1) if met and m.group(1) == 'api' else 'GET'
            caminho = normalizar(m.group(3))
            chamadas.append((f, metodo, caminho))
            if (metodo, caminho) not in rotas:
                erros.append(f"{f}: {metodo} {caminho} não existe no back-end")

print(f"Rotas no back-end: {len(rotas)} | chamadas no front-end: {len(chamadas)} ({len({(c[1], c[2]) for c in chamadas})} distintas)")
with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'rotas-frontend.txt'), 'w') as saida:
    for met, cam in sorted({(c[1], c[2]) for c in chamadas}):
        saida.write(f"{met} {cam.replace('{}', '1')}\n")
for e in erros:
    print('ERRO  ', e)
print(f"Resultado: {len(erros)} erro(s)")
sys.exit(1 if erros else 0)
