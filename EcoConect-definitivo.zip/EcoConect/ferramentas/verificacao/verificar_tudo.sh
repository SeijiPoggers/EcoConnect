#!/usr/bin/env bash
# Executa todas as verificações que não dependem do MySQL nem do Maven (usadas durante o desenvolvimento).
set -uo pipefail
RAIZ="$(cd "$(dirname "$0")/../.." && pwd)"
falhas=0
etapa() { echo; echo "### $1"; }
etapa "Sintaxe do JavaScript"; for f in $(find "$RAIZ/ecoconnect-api-jpa/src/main/resources/static" -name '*.js'); do node --check "$f" || falhas=$((falhas+1)); done; echo "arquivos verificados: $(find "$RAIZ/ecoconnect-api-jpa/src/main/resources/static" -name '*.js' | wc -l)"
etapa "Funções da interface"; node "$RAIZ/ferramentas/verificacao/testar_interface.mjs" || falhas=$((falhas+1))
etapa "Back-end x migrations x SQL x beans"; python3 "$RAIZ/ferramentas/verificacao/verificar_backend.py" "$RAIZ/ecoconnect-api-jpa" || falhas=$((falhas+1))
etapa "Contrato front-end x API"; python3 "$RAIZ/ferramentas/verificacao/verificar_contrato.py" "$RAIZ/ecoconnect-api-jpa" || falhas=$((falhas+1))
etapa "Sintaxe dos scripts .sh"; for f in "$RAIZ"/*.sh "$RAIZ"/scripts/*.sh; do bash -n "$f" || falhas=$((falhas+1)); done; echo ok
echo; echo "Etapas com falha: $falhas"; exit $falhas
