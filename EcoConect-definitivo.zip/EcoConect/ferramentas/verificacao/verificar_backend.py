#!/usr/bin/env python3
"""
Verificações estáticas do back-end EcoConect (não substituem a execução real, mas pegam
os erros que só apareceriam com o sistema rodando):
  1. Entidades JPA x migrations: toda @Column/@Table precisa existir no esquema criado pelas migrations.
  2. Repositórios: as propriedades dos métodos derivados (findByX...) precisam existir na entidade.
  3. SQL escrito à mão (JdbcTemplate): tabelas e colunas citadas (alias.coluna, INSERT, UPDATE SET)
     precisam existir no esquema.
  4. Beans do Spring: o grafo de dependências não pode ter ciclos (o Spring Boot 3 recusa ciclos).
Uso: python3 verificar_backend.py <pasta ecoconnect-api-jpa>
"""
import os, re, sys
from collections import defaultdict

raiz = sys.argv[1] if len(sys.argv) > 1 else '.'
src = os.path.join(raiz, 'src/main/java')
mig = os.path.join(raiz, 'src/main/resources/db/migration')
erros, avisos = [], []

# ---------------------------------------------------------------- esquema a partir das migrations
esquema = defaultdict(set)
def versao(n):
    m = re.match(r'V(\d+)__', n)
    return int(m.group(1)) if m else 0
for nome in sorted(os.listdir(mig), key=versao):
    sql = open(os.path.join(mig, nome), encoding='utf-8').read()
    sql = re.sub(r'--[^\n]*', '', sql)
    for m in re.finditer(r'CREATE TABLE(?: IF NOT EXISTS)?\s+`?(\w+)`?\s*\((.*?)\)\s*(?:ENGINE|;)', sql, re.S | re.I):
        tabela, corpo = m.group(1), m.group(2)
        for linha in corpo.split('\n'):
            l = linha.strip()
            c = re.match(r'`?(\w+)`?\s+(?:int|bigint|smallint|tinyint|varchar|char|text|date|datetime|decimal|enum|json|timestamp)', l, re.I)
            if c and c.group(1).upper() not in ('PRIMARY', 'KEY', 'UNIQUE', 'CONSTRAINT'):
                esquema[tabela].add(c.group(1))
    for m in re.finditer(r'ALTER TABLE\s+`?(\w+)`?\s+ADD COLUMN\s+`?(\w+)`?', sql, re.I):
        esquema[m.group(1)].add(m.group(2))
print(f"Esquema: {len(esquema)} tabelas, {sum(len(v) for v in esquema.values())} colunas")

# ---------------------------------------------------------------- leitura das classes
arquivos = {}
for d, _, fs in os.walk(src):
    for f in fs:
        if f.endswith('.java'):
            arquivos[f[:-5]] = open(os.path.join(d, f), encoding='utf-8').read()

def campos(texto):
    return re.findall(r'^\s*private\s+[\w<>, ]+\s+(\w+)\s*;', texto, re.M)

entidades = {}
for nome, t in arquivos.items():
    if '@Entity' not in t:
        continue
    tab = re.search(r'@Table\(name\s*=\s*"(\w+)"', t)
    tabela = tab.group(1) if tab else nome.lower()
    entidades[nome] = (tabela, campos(t))
    if tabela not in esquema:
        erros.append(f"[entidade] {nome}: tabela '{tabela}' não existe nas migrations")
        continue
    for col in re.findall(r'@Column\(name\s*=\s*"(\w+)"', t):
        if col not in esquema[tabela]:
            erros.append(f"[entidade] {nome}: coluna '{col}' não existe em {tabela}")
print(f"Entidades verificadas: {len(entidades)}")

# ---------------------------------------------------------------- repositórios (métodos derivados)
PALAVRAS = ['IgnoreCase', 'IsNotNull', 'IsNull', 'NotNull', 'Null', 'NotIn', 'In', 'Not', 'True', 'False', 'Containing',
            'StartingWith', 'EndingWith', 'Between', 'LessThanEqual', 'LessThan', 'GreaterThanEqual', 'GreaterThan',
            'After', 'Before', 'Like', 'Is', 'Equals']
total_metodos = 0
for nome, t in arquivos.items():
    m = re.search(r'interface\s+\w+\s+extends\s+JpaRepository<\s*(\w+)\s*,', t)
    if not m:
        continue
    ent = m.group(1)
    if ent not in entidades:
        continue
    props = set(entidades[ent][1])
    for met in re.findall(r'\b(?:find|exists|count|delete|read|get)\w*?By(\w+)\s*\(', t):
        total_metodos += 1
        corpo = re.split(r'OrderBy', met)
        partes = re.split(r'And|Or', corpo[0])
        if len(corpo) > 1:
            partes += re.split(r'(?<=[a-z])(?=Asc$|Desc$)', corpo[1])
        for p in partes:
            p = re.sub(r'(Asc|Desc)$', '', p)
            for k in PALAVRAS:
                if p.endswith(k) and len(p) > len(k):
                    p = p[:-len(k)]
                    break
            if not p:
                continue
            prop = p[0].lower() + p[1:]
            if prop not in props:
                erros.append(f"[repositório] {nome}.{met}: '{prop}' não é campo de {ent}")
print(f"Métodos derivados verificados: {total_metodos}")

# ---------------------------------------------------------------- SQL escrito à mão
def sql_dos_textos(t):
    t = re.sub(r'Consultas\.(?:dt|d)\(\s*"([^"]*)"\s*\)', lambda m: '"' + m.group(1) + '"', t)
    blocos, atual = [], []
    for m in re.finditer(r'"((?:[^"\\]|\\.)*)"|([;{}])', t):
        if m.group(2):
            if atual:
                blocos.append(' '.join(atual)); atual = []
            continue
        atual.append(m.group(1))
    if atual:
        blocos.append(' '.join(atual))
    return [b for b in blocos if re.search(r'\b(SELECT|INSERT INTO|UPDATE|DELETE FROM)\b', b)]

RESERVADAS = {'ON', 'WHERE', 'JOIN', 'LEFT', 'RIGHT', 'INNER', 'GROUP', 'ORDER', 'LIMIT', 'AND', 'OR', 'SET', 'VALUES', 'AS', 'UNION',
              'SELECT', 'HAVING', 'USING'}
consultas = 0
for nome, t in arquivos.items():
    if 'JdbcTemplate' not in t and 'Consultas' not in t and 'db.executar' not in t:
        continue
    for sql in sql_dos_textos(t):
        consultas += 1
        aliases = {}
        for m in re.finditer(r'(?<!KEY )\b(?:FROM|JOIN|UPDATE|INTO)\s+`?([a-z_]+)`?(?:\s+(?:AS\s+)?([a-z][a-z0-9_]*))?', sql, re.I):
            tabela, alias = m.group(1), m.group(2)
            if tabela.upper() in RESERVADAS or tabela == 'DUAL':
                continue
            if tabela not in esquema:
                if tabela not in ('flyway_schema_history',):
                    erros.append(f"[sql] {nome}: tabela '{tabela}' não existe -> {sql[:90]}")
                continue
            aliases[tabela] = tabela
            if alias and alias.upper() not in RESERVADAS:
                aliases[alias] = tabela
        for m in re.finditer(r'\b([a-z][a-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)\b', sql):
            a, col = m.group(1), m.group(2)
            if a in aliases and col not in esquema[aliases[a]]:
                erros.append(f"[sql] {nome}: coluna '{a}.{col}' não existe em {aliases[a]}")
        for m in re.finditer(r'INSERT (?:IGNORE )?INTO\s+(\w+)\s*\(([^)]*)\)', sql, re.I):
            tab = m.group(1)
            for col in [c.strip(' `') for c in m.group(2).split(',')]:
                if tab in esquema and col not in esquema[tab]:
                    erros.append(f"[sql] {nome}: INSERT em {tab}: coluna '{col}' não existe")
        for m in re.finditer(r'(?<!KEY )UPDATE\s+(\w+)\s+SET\s+(.*?)(?:\bWHERE\b|$)', sql, re.I | re.S):
            tab = m.group(1)
            for col in re.findall(r'(?:^|,)\s*(\w+)\s*=', m.group(2)):
                if tab in esquema and col not in esquema[tab]:
                    erros.append(f"[sql] {nome}: UPDATE em {tab}: coluna '{col}' não existe")
print(f"Trechos de SQL verificados: {consultas}")

# ---------------------------------------------------------------- grafo de beans
ANOT = ('@Service', '@Component', '@Configuration', '@RestController', '@ControllerAdvice', '@RestControllerAdvice')
beans = {n for n, t in arquivos.items() if any(a in t for a in ANOT)}
grafo = {}
for n in beans:
    t = arquivos[n]
    deps = set()
    for m in re.finditer(r'public\s+' + n + r'\s*\(([^)]*)\)', t):
        deps |= set(re.findall(r'\b([A-Z]\w+)\s+\w+\s*(?:,|$)', m.group(1)))
    for m in re.finditer(r'@Autowired[^;{]*?void\s+\w+\(\s*([A-Z]\w+)\s+\w+\)', t, re.S):
        deps.add(m.group(1))
    grafo[n] = {d for d in deps if d in beans and d != n}
ciclos = []
def visitar(n, caminho, vistos):
    for d in grafo.get(n, ()):
        if d in caminho:
            ciclos.append(caminho[caminho.index(d):] + [d])
        elif d not in vistos:
            vistos.add(d)
            visitar(d, caminho + [d], vistos)
for b in sorted(grafo):
    visitar(b, [b], {b})
for c in {' -> '.join(c) for c in ciclos}:
    erros.append(f"[beans] ciclo de dependência: {c}")
print(f"Beans analisados: {len(grafo)}")

print()
for a in avisos:
    print('AVISO ', a)
for e in sorted(set(erros)):
    print('ERRO  ', e)
print(f"\nResultado: {len(set(erros))} erro(s)")
sys.exit(1 if erros else 0)
