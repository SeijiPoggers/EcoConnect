import java.net.CookieManager;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Teste ponta a ponta do EcoConect em execução (API + banco + regras de permissão), sem bibliotecas externas.
 * Uso:  java ferramentas/teste/TesteFimAFim.java http://127.0.0.1:8080
 *
 * Usa as contas FICTÍCIAS de demonstração (*@demo.ecoconect.local). Se o banco não tiver os dados de
 * demonstração, executa só as verificações que não gravam nada. Os registros criados pelo teste têm
 * o prefixo [TESTE] (um agendamento cancelado, uma sessão, uma solicitação recusada e mensagens).
 * Variáveis opcionais: ECO_TESTE_ADMIN_EMAIL e ECO_TESTE_ADMIN_SENHA para testar também a administração.
 */
public class TesteFimAFim {

    static final String SENHA_DEMO = "EcoDemo2026";
    static String base;
    static int sucesso = 0;
    static final List<String> falhas = new ArrayList<>();

    record Resposta(int status, String corpo, String tipo) {
    }

    static final class Sessao {
        final String nome;
        final HttpClient http = HttpClient.newBuilder().cookieHandler(new CookieManager()).connectTimeout(Duration.ofSeconds(10)).build();
        String token;

        Sessao(String nome) {
            this.nome = nome;
        }

        Resposta enviar(String metodo, String caminho, String json, boolean protecaoCsrf) {
            try {
                HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(base + caminho)).timeout(Duration.ofSeconds(90))
                        .header("Accept", "application/json");
                if (protecaoCsrf) b.header("X-Requested-With", "EcoConect");
                if (token != null) b.header("Authorization", "Bearer " + token);
                if (json != null) b.header("Content-Type", "application/json").method(metodo, HttpRequest.BodyPublishers.ofString(json));
                else b.method(metodo, HttpRequest.BodyPublishers.noBody());
                HttpResponse<String> r = http.send(b.build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
                return new Resposta(r.statusCode(), r.body(), r.headers().firstValue("Content-Type").orElse(""));
            } catch (Exception e) {
                return new Resposta(-1, e.toString(), "");
            }
        }

        Resposta get(String c) { return enviar("GET", c, null, true); }

        Resposta post(String c, String json) { return enviar("POST", c, json, true); }

        boolean entrar(String email, String senha) {
            Resposta r = post("/api/auth/login", "{\"email\":\"" + email + "\",\"senha\":\"" + senha + "\"}");
            verificar(nome + ": login", r.status == 200, r);
            return r.status == 200;
        }
    }

    public static void main(String[] args) {
        base = args.length > 0 ? args[0].replaceAll("/$", "") : "http://127.0.0.1:8080";
        boolean forcar = List.of(args).contains("--forcar");
        System.out.println("EcoConect - teste ponta a ponta em " + base);

        Sessao anonimo = new Sessao("anônimo");
        Resposta saude = anonimo.get("/api/saude");
        verificar("saúde da API e do banco", saude.status == 200 && saude.corpo.contains("\"status\":\"UP\""), saude);
        verificar("aplicação web publicada", anonimo.get("/app/").status == 200, null);
        verificar("página inicial publicada", anonimo.get("/").status == 200, null);
        verificar("catálogos públicos", anonimo.get("/api/rede/catalogos").corpo.contains("tiposServico"), null);
        Resposta semLogin = anonimo.get("/api/app/painel");
        verificar("rota protegida sem login responde 401", semLogin.status == 401, semLogin);
        Resposta errado = anonimo.post("/api/auth/login", "{\"email\":\"ninguem@demo.ecoconect.local\",\"senha\":\"errada123\"}");
        verificar("login com senha errada responde 401", errado.status == 401, errado);

        String adminEmail = System.getenv("ECO_TESTE_ADMIN_EMAIL");
        String adminSenha = System.getenv("ECO_TESTE_ADMIN_SENHA");
        if (adminEmail != null && adminSenha != null) {
            Sessao admin = new Sessao("administrador");
            if (admin.entrar(adminEmail, adminSenha)) {
                Resposta me = admin.get("/api/auth/me");
                if (me.corpo.contains("\"exigeTrocaSenha\":true")) {
                    verificar("administrador com troca de senha pendente é bloqueado nas demais rotas", admin.get("/api/admin/usuarios").status == 403, null);
                } else {
                    verificar("administrador lista usuários", admin.get("/api/admin/usuarios").status == 200, null);
                    verificar("administrador consulta a auditoria", admin.get("/api/admin/auditoria").corpo.contains("\"itens\""), null);
                    verificar("painel do administrador", admin.get("/api/app/painel").corpo.contains("\"cartoes\""), null);
                }
            }
        }

        boolean demonstracao = saude.corpo.contains("\"demonstracao\":true");
        if (!demonstracao && !forcar) {
            System.out.println("\nSem dados de demonstração: os testes que gravam registros foram pulados (use ECO_DADOS_DEMO=true num banco de teste).");
            terminar();
            return;
        }

        // ------------------------------------------------------------ profissional
        Sessao ana = new Sessao("profissional");
        if (!ana.entrar("ana.ribeiro@demo.ecoconect.local", SENHA_DEMO)) { terminar(); return; }
        verificar("perfil do profissional", ana.get("/api/auth/me").corpo.contains("\"perfil\":\"PROFISSIONAL\""), null);
        Resposta semCsrf = ana.enviar("POST", "/api/app/conversas", "{}", false);
        verificar("gravação sem o cabeçalho anti-CSRF é recusada (403)", semCsrf.status == 403, semCsrf);
        Resposta pessoas = ana.get("/api/app/pessoas");
        Long theo = id(pessoas.corpo, "idCrianca", "Theo Alves");
        Long lucas = id(pessoas.corpo, "idCrianca", "Lucas Martins");
        verificar("profissional vê as pessoas que acompanha", theo != null && lucas != null, pessoas);
        verificar("profissional não vê pessoa fora do seu escopo", !pessoas.corpo.contains("Helena Costa"), pessoas);
        Resposta injecao = ana.get("/api/app/pessoas?texto=" + URLEncoder.encode("' OR 1=1 -- ", StandardCharsets.UTF_8));
        verificar("busca com tentativa de SQL injection não vaza dados", injecao.status == 200 && injecao.corpo.trim().equals("[]"), injecao);
        verificar("trajetória terapêutica", ana.get("/api/app/pessoas/" + theo + "/trajetoria").corpo.contains("\"tipo\":\"SESSAO\""), null);
        verificar("painel do profissional", ana.get("/api/app/painel").corpo.contains("proximasSessoes"), null);

        long variacao = (System.currentTimeMillis() / 60000) % 400;
        LocalDateTime futuro = LocalDate.now().plusDays(60 + variacao).atTime(7, 0);
        String novo = "{\"idCrianca\":" + theo + ",\"inicio\":\"" + futuro + ":00\",\"fim\":\"" + futuro.plusMinutes(50)
                + ":00\",\"observacao\":\"[TESTE] agendamento automático\",\"confirmar\":true}";
        Resposta ag = ana.post("/api/app/agenda", novo);
        Long idAg = num(ag.corpo, "idAgendamento");
        verificar("agendamento confirmado pela equipe", ag.status == 200 && ag.corpo.contains("\"status\":\"CONFIRMADO\""), ag);
        Resposta conflito = ana.post("/api/app/agenda", novo);
        verificar("conflito de horário é recusado (422)", conflito.status == 422, conflito);
        Resposta cancel = ana.post("/api/app/agenda/" + idAg + "/acao", "{\"acao\":\"CANCELAR\",\"motivo\":\"[TESTE] cancelamento automático\"}");
        verificar("cancelamento com histórico", cancel.status == 200 && cancel.corpo.contains("\"statusNovo\":\"CANCELADO\""), cancel);

        LocalDateTime passado = LocalDate.now().minusDays(45 + variacao).atTime(7, 0);
        Resposta sessao = ana.post("/api/app/sessoes", "{\"idCrianca\":" + theo + ",\"inicio\":\"" + passado + ":00\",\"fim\":\"" + passado.plusMinutes(50)
                + ":00\",\"tipoAtendimento\":\"[TESTE] Sessão de verificação\",\"evolucaoObservada\":\"<script>alert(1)</script> texto\","
                + "\"observacoesGerais\":\"[TESTE] anotação interna\",\"atividades\":[],\"idsProfissionais\":[]}");
        Long idSessao = num(sessao.corpo, "idAtendimento");
        verificar("registro de sessão", sessao.status == 200 && idSessao != null, sessao);
        verificar("texto é guardado como dado (a interface o exibe como texto)", sessao.corpo.contains("<script>alert(1)</script>"), null);
        Resposta csv = ana.get("/api/relatorios/sessoes?de=" + LocalDate.now().minusYears(2) + "&ate=" + LocalDate.now());
        verificar("relatório CSV de sessões", csv.status == 200 && csv.tipo.startsWith("text/csv") && csv.corpo.contains("Tipo de atendimento"), csv);
        Resposta fhir = ana.get("/api/fhir/Patient/" + theo);
        verificar("FHIR Patient mínimo (sem CPF)", fhir.status == 200 && fhir.corpo.contains("\"resourceType\":\"Patient\"") && !fhir.corpo.contains("cpf\""), fhir);
        verificar("recomendações explicadas", ana.get("/api/rede/recomendacoes?idCrianca=" + theo).corpo.contains("\"motivos\""), null);
        verificar("estabelecimentos do SUS", ana.get("/api/sus/estabelecimentos?uf=SP&municipio=Sorocaba").corpo.contains("CAPS"), null);

        // ------------------------------------------------------------ API original com token (cliente externo)
        Sessao cliente = new Sessao("cliente da API");
        Resposta tk = cliente.post("/api/auth/token", "{\"email\":\"ana.ribeiro@demo.ecoconect.local\",\"senha\":\"" + SENHA_DEMO + "\"}");
        cliente.token = str(tk.corpo, "token");
        verificar("token para clientes de API", cliente.token != null, tk);
        verificar("API original com token e escopo", cliente.get("/api/criancas/" + theo).status == 200, null);

        // ------------------------------------------------------------ família
        Sessao mariana = new Sessao("responsável");
        if (mariana.entrar("mariana.alves@demo.ecoconect.local", SENHA_DEMO)) {
            Resposta lista = mariana.get("/api/app/pessoas");
            verificar("família vê somente a sua pessoa", lista.corpo.contains("Theo Alves") && !lista.corpo.contains("Lucas Martins"), lista);
            verificar("família não abre pessoa de outra família (403)", mariana.get("/api/app/pessoas/" + lucas).status == 403, null);
            Resposta s = mariana.get("/api/app/sessoes/" + idSessao);
            verificar("família vê a sessão sem as anotações internas", s.status == 200 && !s.corpo.contains("observacoesGerais"), s);
            verificar("família não vê o histórico de alterações (403)", mariana.get("/api/app/pessoas/" + theo + "/historico-alteracoes").status == 403, null);
            verificar("família não acessa a administração (403)", mariana.get("/api/admin/usuarios").status == 403, null);
            verificar("família não exporta relatórios gerenciais (403)", mariana.get("/api/relatorios/sessoes").status == 403, null);
            verificar("família não lê o FHIR Patient (403)", mariana.get("/api/fhir/Patient/" + theo).status == 403, null);
            verificar("exportação dos dados do titular (LGPD)", mariana.get("/api/app/privacidade/exportacao").corpo.contains("pessoasAcompanhadas"), null);
            Long equo = num(mariana.get("/api/rede/instituicoes?texto=Passo").corpo, "idInstituicao");
            String pedido = "{\"idInstituicao\":" + equo + ",\"idCrianca\":" + theo + ",\"mensagem\":\"[TESTE] solicitação automática\"}";
            Resposta sol = mariana.post("/api/app/solicitacoes", pedido);
            Long idSol = num(sol.corpo, "idSolicitacao");
            Long idConversa = num(sol.corpo, "idConversa");
            verificar("solicitação de atendimento enviada", sol.status == 200 && idSol != null, sol);
            verificar("solicitação duplicada em andamento é recusada (422)", mariana.post("/api/app/solicitacoes", pedido).status == 422, null);
            Resposta msg = mariana.post("/api/app/conversas/" + idConversa + "/mensagens", "{\"conteudo\":\"[TESTE] mensagem automática\"}");
            verificar("mensagem enviada na conversa da solicitação", msg.status == 200 && msg.corpo.contains("[TESTE] mensagem automática"), msg);

            // -------------------------------------------------------- instituição
            Sessao roberta = new Sessao("instituição");
            if (roberta.entrar("roberta.lima@demo.ecoconect.local", SENHA_DEMO)) {
                verificar("instituição recebe a solicitação", roberta.get("/api/app/solicitacoes").corpo.contains("[TESTE] solicitação automática"), null);
                verificar("instituição recebe a mensagem (contador)", !roberta.get("/api/app/contadores").corpo.contains("\"mensagens\":0"), null);
                Resposta semMotivo = roberta.post("/api/app/solicitacoes/" + idSol + "/resposta", "{\"situacao\":\"RECUSADA\"}");
                verificar("recusa sem motivo é bloqueada (422)", semMotivo.status == 422, semMotivo);
                Resposta resp = roberta.post("/api/app/solicitacoes/" + idSol + "/resposta",
                        "{\"situacao\":\"RECUSADA\",\"resposta\":\"[TESTE] recusa automática do teste\"}");
                verificar("instituição responde a solicitação", resp.status == 200 && resp.corpo.contains("\"situacao\":\"RECUSADA\""), resp);
                verificar("instituição não vê sessões (403)", roberta.get("/api/app/sessoes/" + idSessao).status == 403, null);
                Resposta perfil = roberta.get("/api/app/pessoas/" + theo);
                verificar("instituição vê só perfil e necessidades (sem CPF e sem responsáveis)",
                        perfil.status == 200 && !perfil.corpo.contains("\"cpf\"") && !perfil.corpo.contains("\"responsaveis\""), perfil);
                verificar("instituição não usa a API original de prontuário (403)", roberta.get("/api/criancas/" + theo).status == 403, null);
            }
            verificar("família é notificada da resposta", mariana.get("/api/app/notificacoes").corpo.contains("Solicitação recusada"), null);
            Resposta sair = mariana.post("/api/auth/logout", null);
            verificar("logout encerra a sessão", sair.status == 200 && mariana.get("/api/app/painel").status == 401, sair);
        }

        // ------------------------------------------------------------ pessoa acompanhada
        Sessao pessoa = new Sessao("pessoa acompanhada");
        if (pessoa.entrar("lucas.martins@demo.ecoconect.local", SENHA_DEMO)) {
            Resposta lista = pessoa.get("/api/app/pessoas");
            verificar("pessoa acompanhada vê somente o próprio cadastro", lista.corpo.contains("Lucas Martins") && !lista.corpo.contains("Theo Alves"), lista);
            verificar("agenda da pessoa acompanhada", pessoa.get("/api/app/agenda").status == 200, null);
            verificar("preferências de acessibilidade", pessoa.get("/api/app/preferencias").corpo.contains("baixoEstimulo"), null);
        }
        terminar();
    }

    static void verificar(String nome, boolean condicao, Resposta r) {
        if (condicao) {
            sucesso++;
            System.out.println("  OK     " + nome);
        } else {
            String det = r == null ? "" : " (HTTP " + r.status + ": " + resumo(r.corpo) + ")";
            falhas.add(nome + det);
            System.out.println("  FALHA  " + nome + det);
        }
    }

    static void terminar() {
        System.out.println("\nVerificações: " + (sucesso + falhas.size()) + " | sucesso: " + sucesso + " | falhas: " + falhas.size());
        System.exit(falhas.isEmpty() ? 0 : 1);
    }

    static String resumo(String s) {
        if (s == null) return "";
        String t = s.replaceAll("\\s+", " ");
        return t.length() > 220 ? t.substring(0, 220) + "..." : t;
    }

    static Long num(String json, String chave) {
        Matcher m = Pattern.compile("\"" + chave + "\"\\s*:\\s*(\\d+)").matcher(json == null ? "" : json);
        return m.find() ? Long.valueOf(m.group(1)) : null;
    }

    static String str(String json, String chave) {
        Matcher m = Pattern.compile("\"" + chave + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(json == null ? "" : json);
        return m.find() ? m.group(1) : null;
    }

    /** id do objeto cuja lista começa por {"<chave>":N,"nomeCompleto":"<nome>". */
    static Long id(String json, String chave, String nome) {
        Matcher m = Pattern.compile("\"" + chave + "\"\\s*:\\s*(\\d+)\\s*,\\s*\"nomeCompleto\"\\s*:\\s*\"" + Pattern.quote(nome) + "\"").matcher(json == null ? "" : json);
        return m.find() ? Long.valueOf(m.group(1)) : null;
    }
}
