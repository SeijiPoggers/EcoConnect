#!/usr/bin/env bash
# EcoConect - automação da instalação local (Linux/macOS).
# Uso: scripts/ecoconect.sh <setup|start|stop|restart|health|console> [--completo] [--sem-navegador]
set -euo pipefail
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
API="$RAIZ/ecoconnect-api-jpa"
CONSOLE_DIR="$RAIZ/EcoConect-Console"
FERRAMENTAS="$RAIZ/.ferramentas"
EXECUCAO="$RAIZ/.execucao"
LOGS="$RAIZ/logs"
CONFIG="$RAIZ/ecoconnect.properties"
EXEMPLO="$RAIZ/ecoconnect.properties.exemplo"
JAR="$API/target/ecoconnect-api.jar"
PIDF="$EXECUCAO/api.pid"
cd "$RAIZ"
MAVEN_VERSAO="3.9.9"
COMANDO="${1:-start}"; shift || true
COMPLETO=0; SEM_NAVEGADOR="${ECO_SEM_NAVEGADOR:-0}"
for a in "$@"; do case "$a" in --completo) COMPLETO=1 ;; --sem-navegador) SEM_NAVEGADOR=1 ;; esac; done

passo() { printf '\n\033[36m==> %s\033[0m\n' "$1"; }
ok() { printf '    \033[32m[ok]\033[0m %s\n' "$1"; }
aviso() { printf '    \033[33m[atenção]\033[0m %s\n' "$1"; }
falhar() { printf '\n\033[31m[ERRO]\033[0m %s\n' "$1" >&2; exit 1; }

cfg() { # cfg CHAVE PADRAO  (variável de ambiente > ecoconnect.properties > padrão)
  local v="${!1:-}"
  if [ -z "$v" ] && [ -f "$CONFIG" ]; then v="$(grep -E "^[[:space:]]*$1[[:space:]]*=" "$CONFIG" | tail -n1 | cut -d= -f2- | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"; fi
  printf '%s' "${v:-$2}"
}

definir_cfg() {
  local tmp; tmp="$(mktemp)"
  if grep -qE "^[[:space:]]*$1[[:space:]]*=" "$CONFIG"; then
    awk -v k="$1" -v v="$2" 'BEGIN{FS=OFS="="} $1 ~ "^[[:space:]]*"k"[[:space:]]*$" {print k"="v; next} {print}' "$CONFIG" > "$tmp"
  else cat "$CONFIG" > "$tmp"; printf '%s=%s\n' "$1" "$2" >> "$tmp"; fi
  mv "$tmp" "$CONFIG"; chmod 600 "$CONFIG"
}

porta_aberta() { (exec 3<>"/dev/tcp/$1/$2") >/dev/null 2>&1; }

java_bin() {
  if [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/java" ]; then echo "$JAVA_HOME/bin/java"; elif command -v java >/dev/null 2>&1; then command -v java; fi
}

garantir_java() {
  local j; j="$(java_bin)"
  [ -n "$j" ] || falhar "Java 17 ou superior não encontrado. Instale o JDK 17 (https://adoptium.net) e execute de novo."
  local v; v="$("$j" -version 2>&1 | sed -n 's/.*version "\([0-9]*\).*/\1/p' | head -n1)"
  [ "${v:-0}" -ge 17 ] || falhar "Encontrado Java ${v:-?}. O EcoConect precisa do Java 17 ou superior."
  ok "Java $v ($j)" >&2
  echo "$j"
}

garantir_maven() {
  if command -v mvn >/dev/null 2>&1; then ok "Maven do sistema ($(command -v mvn))" >&2; command -v mvn; return; fi
  local local_mvn="$FERRAMENTAS/apache-maven-$MAVEN_VERSAO/bin/mvn"
  if [ -x "$local_mvn" ]; then ok "Maven $MAVEN_VERSAO (pasta .ferramentas)" >&2; echo "$local_mvn"; return; fi
  passo "Baixando o Apache Maven $MAVEN_VERSAO (somente na primeira vez)" >&2
  mkdir -p "$FERRAMENTAS"
  local url="https://archive.apache.org/dist/maven/maven-3/$MAVEN_VERSAO/binaries/apache-maven-$MAVEN_VERSAO-bin.tar.gz"
  local arq="$FERRAMENTAS/maven.tar.gz"
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL "$url" -o "$arq" && curl -fsSL "$url.sha512" -o "$arq.sha512" || falhar "Não foi possível baixar o Maven ($url). Verifique a internet ou instale o Maven."
  elif command -v wget >/dev/null 2>&1; then
    wget -q "$url" -O "$arq" && wget -q "$url.sha512" -O "$arq.sha512" || falhar "Não foi possível baixar o Maven ($url)."
  else falhar "Instale o curl, o wget ou o Maven."; fi
  local esperado obtido; esperado="$(cut -d' ' -f1 "$arq.sha512")"; obtido="$(sha512sum "$arq" | cut -d' ' -f1)"
  [ "$esperado" = "$obtido" ] || { rm -f "$arq"; falhar "O arquivo do Maven não confere com a assinatura SHA-512."; }
  tar -xzf "$arq" -C "$FERRAMENTAS" && rm -f "$arq" "$arq.sha512"
  ok "Maven $MAVEN_VERSAO instalado em .ferramentas" >&2
  echo "$local_mvn"
}

garantir_config() {
  if [ ! -f "$CONFIG" ]; then cp "$EXEMPLO" "$CONFIG"; chmod 600 "$CONFIG"; ok "Arquivo ecoconnect.properties criado a partir do exemplo."; fi
  local s; s="$(cfg DB_PASSWORD '')"
  if [ "$s" = "COLOQUE_SUA_SENHA_DO_MYSQL_AQUI" ]; then
    if [ -t 0 ]; then
      echo; echo "Informe a senha do usuário root do seu MySQL (ou a que deseja usar no MySQL do Docker). Fica salva só neste computador."
      read -r -s -p "Senha do MySQL: " s; echo
      case "$s" in *\\*) falhar "A senha não pode conter o caractere \\.";; esac
      definir_cfg DB_PASSWORD "$s"; ok "Senha salva em ecoconnect.properties."
    else falhar "Defina DB_PASSWORD em ecoconnect.properties."; fi
  fi
}

garantir_mysql() {
  local h p; h="$(cfg DB_HOST localhost)"; p="$(cfg DB_PORT 3306)"
  if porta_aberta "$h" "$p"; then ok "MySQL respondendo em $h:$p"; return; fi
  if command -v systemctl >/dev/null 2>&1; then
    for s in mysql mysqld mariadb; do systemctl start "$s" >/dev/null 2>&1 && sleep 3 && break || true; done
    if porta_aberta "$h" "$p"; then ok "MySQL iniciado ($h:$p)"; return; fi
  fi
  if command -v docker >/dev/null 2>&1 && { [ "$h" = "localhost" ] || [ "$h" = "127.0.0.1" ]; }; then
    aviso "MySQL local não encontrado. Subindo o MySQL 8 no Docker (docker-compose.yml)..."
    (cd "$RAIZ" && DB_PASSWORD="$(cfg DB_PASSWORD '')" DB_NAME="$(cfg DB_NAME ecoconnect)" DB_PORT="$p" docker compose up -d mysql)
    for _ in $(seq 1 60); do if porta_aberta "$h" "$p"; then sleep 8; ok "MySQL do Docker pronto."; return; fi; sleep 2; done
  fi
  falhar "O MySQL não está respondendo em $h:$p. Inicie o serviço do MySQL 8 (ou instale o Docker) e execute de novo."
}

fontes_mudaram() {
  [ -f "$JAR" ] || return 0
  [ -n "$(find "$API/src/main" "$API/pom.xml" -newer "$JAR" -type f -print -quit)" ]
}

compilar() { # compilar MVN [testes]
  passo "Compilando a API e a aplicação web (na primeira vez o Maven baixa as dependências)"
  if [ "${2:-}" = "testes" ]; then "$1" -B -q -f "$API/pom.xml" package; else "$1" -B -q -f "$API/pom.xml" package -DskipTests; fi || falhar "A compilação falhou."
  ok "API compilada (ecoconnect-api-jpa/target/ecoconnect-api.jar)."
}

saude() { local u="http://127.0.0.1:$(cfg PORT 8080)/api/saude"
  if command -v curl >/dev/null 2>&1; then curl -fsS --max-time "${1:-5}" "$u" 2>/dev/null; else wget -qO- --timeout="${1:-5}" "$u" 2>/dev/null; fi; }

pid_atual() { [ -f "$PIDF" ] && kill -0 "$(cat "$PIDF")" 2>/dev/null && cat "$PIDF"; }

cmd_setup() {
  passo "Verificando o Java"; garantir_java >/dev/null
  passo "Verificando o Maven"; local mvn; mvn="$(garantir_maven)"
  passo "Preparando a configuração"; garantir_config
  passo "Verificando o MySQL"; garantir_mysql
  compilar "$mvn" testes
  passo "Preparando o Console Java"
  if "$mvn" -B -q -f "$CONSOLE_DIR/pom.xml" compile; then ok "Console compilado."; else aviso "O Console não compilou; a aplicação web funciona mesmo assim."; fi
  mkdir -p "$LOGS" "$EXECUCAO"
  echo; echo "Setup concluído. Para iniciar: ./start.sh"
}

cmd_start() {
  local java; java="$(garantir_java)"
  [ -f "$CONFIG" ] || { echo "Primeira execução: rodando o setup."; cmd_setup; }
  local porta; porta="$(cfg PORT 8080)"
  if pid_atual >/dev/null && saude 2 | grep -q '"status":"UP"'; then ok "O EcoConect já está em execução."; abrir; return; fi
  porta_aberta 127.0.0.1 "$porta" && falhar "A porta $porta já está em uso. Feche o outro programa ou mude PORT em ecoconnect.properties."
  passo "Verificando o MySQL"; garantir_mysql
  if fontes_mudaram; then compilar "$(garantir_maven)"; fi
  mkdir -p "$LOGS" "$EXECUCAO"
  passo "Iniciando o EcoConect"
  (cd "$API" && nohup "$java" -Dfile.encoding=UTF-8 -jar "$JAR" > "$LOGS/ecoconect-api.log" 2>&1 & echo $! > "$PIDF")
  echo "    processo $(cat "$PIDF"); registros em logs/ecoconect-api.log"
  for _ in $(seq 1 90); do
    sleep 2
    if ! kill -0 "$(cat "$PIDF")" 2>/dev/null; then
      echo; echo "O EcoConect parou durante a inicialização. Últimas linhas do registro:"; tail -n 40 "$LOGS/ecoconect-api.log" | sed 's/^/    /'
      rm -f "$PIDF"; falhar "Corrija o problema indicado acima e tente de novo."
    fi
    local s; s="$(saude 2 || true)"
    if printf '%s' "$s" | grep -q '"status":"UP"'; then
      echo; ok "Banco de dados conectado."
      echo "EcoConect em execução: http://localhost:$porta/app/"
      echo "  Documentação da API: http://localhost:$porta/swagger-ui.html"
      echo "  Administrador inicial: $(cfg ADMIN_EMAIL '') (troque a senha no primeiro acesso)"
      printf '%s' "$s" | grep -q '"demonstracao":true' && echo "  Contas fictícias: *@demo.ecoconect.local, senha EcoDemo2026"
      echo "  Para encerrar: ./stop.sh"
      abrir; return
    fi
    printf '.'
  done
  falhar "O EcoConect não respondeu em 3 minutos. Veja logs/ecoconect-api.log."
}

abrir() {
  [ "$SEM_NAVEGADOR" = "1" ] && return
  local u="http://localhost:$(cfg PORT 8080)/app/"
  if command -v xdg-open >/dev/null 2>&1; then xdg-open "$u" >/dev/null 2>&1 || true; elif command -v open >/dev/null 2>&1; then open "$u" || true; fi
}

cmd_stop() {
  local p; p="$(pid_atual || true)"
  if [ -n "$p" ]; then kill "$p" 2>/dev/null || true; for _ in $(seq 1 15); do kill -0 "$p" 2>/dev/null || break; sleep 1; done; kill -9 "$p" 2>/dev/null || true; rm -f "$PIDF"; ok "EcoConect encerrado."
  else rm -f "$PIDF"; echo "O EcoConect não estava em execução."; fi
}

cmd_health() {
  passo "Verificação de saúde"
  local j; j="$(java_bin)"; [ -n "$j" ] && ok "Java encontrado ($j)" || aviso "Java não encontrado."
  if porta_aberta "$(cfg DB_HOST localhost)" "$(cfg DB_PORT 3306)"; then ok "MySQL em $(cfg DB_HOST localhost):$(cfg DB_PORT 3306)"; else aviso "MySQL não responde em $(cfg DB_HOST localhost):$(cfg DB_PORT 3306)"; fi
  local s; s="$(saude 5 || true)"
  [ -n "$s" ] || falhar "A API não responde em http://127.0.0.1:$(cfg PORT 8080). Execute ./start.sh."
  ok "API: $s"
  if [ "$COMPLETO" = "1" ]; then
    passo "Teste ponta a ponta"
    "$(garantir_java)" -Dstdout.encoding=UTF-8 "$RAIZ/ferramentas/teste/TesteFimAFim.java" "http://127.0.0.1:$(cfg PORT 8080)" || falhar "O teste ponta a ponta encontrou falhas."
  fi
  echo; echo "Tudo certo."
}

cmd_console() { garantir_java >/dev/null; local mvn; mvn="$(garantir_maven)"; garantir_config; "$mvn" -B -q -f "$CONSOLE_DIR/pom.xml" compile exec:java; }

case "$COMANDO" in
  setup) cmd_setup ;; start) cmd_start ;; stop) cmd_stop ;; restart) cmd_stop; sleep 2; cmd_start ;;
  health) cmd_health ;; console) cmd_console ;;
  *) echo "Uso: $0 <setup|start|stop|restart|health|console> [--completo]"; exit 2 ;;
esac
