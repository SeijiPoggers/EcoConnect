﻿<#
  EcoConect - automação da instalação local no Windows.
  Uso: ecoconect.ps1 <setup|start|stop|restart|health|console> [-Completo]
  Chamado pelos arquivos setup.bat, start.bat, stop.bat, restart.bat, healthcheck.bat e console.bat.
#>
param(
    [Parameter(Position = 0)][ValidateSet('setup', 'start', 'stop', 'restart', 'health', 'console')][string]$Comando = 'start',
    [switch]$Completo,
    [switch]$SemNavegador
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Raiz = Split-Path -Parent $PSScriptRoot
$Api = Join-Path $Raiz 'ecoconnect-api-jpa'
$ConsoleDir = Join-Path $Raiz 'EcoConect-Console'
$Ferramentas = Join-Path $Raiz '.ferramentas'
$Execucao = Join-Path $Raiz '.execucao'
$Logs = Join-Path $Raiz 'logs'
$Config = Join-Path $Raiz 'ecoconnect.properties'
$Exemplo = Join-Path $Raiz 'ecoconnect.properties.exemplo'
$Jar = Join-Path $Api 'target\ecoconnect-api.jar'
$ArquivoPid = Join-Path $Execucao 'api.pid'
$MavenVersao = '3.9.9'

function Escrever([string]$texto, [string]$cor = 'Gray') { Write-Host $texto -ForegroundColor $cor }
function Passo([string]$texto) { Write-Host ''; Write-Host "==> $texto" -ForegroundColor Cyan }
function Ok([string]$texto) { Write-Host "    [ok] $texto" -ForegroundColor Green }
function Aviso([string]$texto) { Write-Host "    [atenção] $texto" -ForegroundColor Yellow }
function Falhar([string]$texto) { Write-Host ''; Write-Host "[ERRO] $texto" -ForegroundColor Red; exit 1 }

# ------------------------------------------------------------------ configuração
function Ler-Config {
    $c = @{}
    if (Test-Path $Config) {
        foreach ($linha in Get-Content $Config -Encoding UTF8) {
            $l = $linha.Trim()
            if ($l -eq '' -or $l.StartsWith('#')) { continue }
            $i = $l.IndexOf('=')
            if ($i -gt 0) { $c[$l.Substring(0, $i).Trim()] = $l.Substring($i + 1).Trim() }
        }
    }
    foreach ($k in @('DB_HOST', 'DB_PORT', 'DB_NAME', 'DB_USER', 'DB_PASSWORD', 'PORT')) {
        $v = [Environment]::GetEnvironmentVariable($k)
        if ($v) { $c[$k] = $v }
    }
    if (-not $c['DB_HOST']) { $c['DB_HOST'] = 'localhost' }
    if (-not $c['DB_PORT']) { $c['DB_PORT'] = '3306' }
    if (-not $c['DB_NAME']) { $c['DB_NAME'] = 'ecoconnect' }
    if (-not $c['DB_USER']) { $c['DB_USER'] = 'root' }
    if (-not $c['PORT']) { $c['PORT'] = '8080' }
    return $c
}

function Definir-Config([string]$chave, [string]$valor) {
    $linhas = Get-Content $Config -Encoding UTF8
    $achou = $false
    $novas = @(foreach ($linha in $linhas) {
        if ($linha -match "^\s*$([regex]::Escape($chave))\s*=") { $achou = $true; "$chave=$valor" } else { $linha }
    })
    if (-not $achou) { $novas += "$chave=$valor" }
    [System.IO.File]::WriteAllLines($Config, $novas, (New-Object System.Text.UTF8Encoding($false)))
}

function Garantir-Config {
    if (-not (Test-Path $Config)) {
        Copy-Item $Exemplo $Config
        Ok 'Arquivo ecoconnect.properties criado a partir do exemplo.'
    }
    $c = Ler-Config
    if (-not $c['DB_PASSWORD'] -or $c['DB_PASSWORD'] -eq 'COLOQUE_SUA_SENHA_DO_MYSQL_AQUI') {
        Escrever ''
        Escrever 'Informe a senha do usuário root do seu MySQL (ou a senha que deseja usar no MySQL do Docker).' 'White'
        Escrever 'Ela fica salva só neste computador, em ecoconnect.properties. Deixe vazio se o MySQL não tiver senha.' 'DarkGray'
        $segura = Read-Host -AsSecureString 'Senha do MySQL'
        $senha = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($segura))
        if ($senha.Contains('\')) { Falhar 'A senha não pode conter o caractere \ (limitação do arquivo de configuração).' }
        Definir-Config 'DB_PASSWORD' $senha
        Ok 'Senha salva em ecoconnect.properties.'
    }
}

# ------------------------------------------------------------------ Java e Maven
function Caminho-Java {
    if ($env:JAVA_HOME -and (Test-Path (Join-Path $env:JAVA_HOME 'bin\java.exe'))) { return (Join-Path $env:JAVA_HOME 'bin\java.exe') }
    $cmd = Get-Command java -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

function Versao-Java([string]$java) {
    $anterior = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { $saida = (& $java -version 2>&1 | Out-String) } finally { $ErrorActionPreference = $anterior }
    if ($saida -match 'version "(\d+)(\.(\d+))?') {
        $maior = [int]$Matches[1]
        if ($maior -eq 1 -and $Matches[3]) { $maior = [int]$Matches[3] }
        return $maior
    }
    return 0
}

function Garantir-Java {
    $java = Caminho-Java
    if (-not $java) {
        $winget = Get-Command winget -ErrorAction SilentlyContinue
        if ($winget) {
            $r = Read-Host 'O Java 17 (JDK) não foi encontrado. Instalar agora com o winget (Eclipse Temurin 17)? [S/n]'
            if ($r -eq '' -or $r -match '^[sS]') {
                & winget install --id EclipseAdoptium.Temurin.17.JDK -e --accept-source-agreements --accept-package-agreements
                Falhar 'Java instalado. Feche esta janela e execute o setup.bat de novo (o Windows precisa recarregar o PATH).'
            }
        }
        Falhar 'Java 17 ou superior não encontrado. Instale o JDK 17 (https://adoptium.net) e execute de novo.'
    }
    $v = Versao-Java $java
    if ($v -lt 17) { Falhar "Encontrado Java $v em $java. O EcoConect precisa do Java 17 ou superior." }
    Ok "Java $v ($java)"
    return $java
}

function Garantir-Maven {
    $mvn = Get-Command mvn -ErrorAction SilentlyContinue
    if ($mvn) { Ok "Maven do sistema ($($mvn.Source))"; return $mvn.Source }
    $local = Join-Path $Ferramentas "apache-maven-$MavenVersao\bin\mvn.cmd"
    if (Test-Path $local) { Ok "Maven $MavenVersao (pasta .ferramentas)"; return $local }
    Passo "Baixando o Apache Maven $MavenVersao (somente na primeira vez)"
    New-Item -ItemType Directory -Force -Path $Ferramentas | Out-Null
    $url = "https://archive.apache.org/dist/maven/maven-3/$MavenVersao/binaries/apache-maven-$MavenVersao-bin.zip"
    $zip = Join-Path $Ferramentas 'maven.zip'
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
        $esperado = ((Invoke-WebRequest -Uri "$url.sha512" -UseBasicParsing).Content -split '\s+')[0].Trim().ToLower()
    } catch { Falhar "Não foi possível baixar o Maven ($url). Verifique a internet ou instale o Maven e coloque-o no PATH." }
    $obtido = (Get-FileHash -Algorithm SHA512 $zip).Hash.ToLower()
    if ($esperado -and $obtido -ne $esperado) { Remove-Item $zip -Force; Falhar 'O arquivo do Maven baixado não confere com a assinatura SHA-512. Tente de novo.' }
    Expand-Archive -Path $zip -DestinationPath $Ferramentas -Force
    Remove-Item $zip -Force
    Ok "Maven $MavenVersao instalado em .ferramentas"
    return $local
}

# ------------------------------------------------------------------ rede e MySQL
function Porta-Aberta([string]$servidor, [int]$porta, [int]$espera = 1500) {
    $tcp = New-Object System.Net.Sockets.TcpClient
    try { return $tcp.ConnectAsync($servidor, $porta).Wait($espera) -and $tcp.Connected } catch { return $false } finally { $tcp.Dispose() }
}

function Garantir-MySQL($c) {
    $servidor = $c['DB_HOST']; $porta = [int]$c['DB_PORT']
    if (Porta-Aberta $servidor $porta) { Ok "MySQL respondendo em ${servidor}:$porta"; return }
    if ($servidor -in @('localhost', '127.0.0.1')) {
        $servicos = Get-Service -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'MySQL*' -or $_.DisplayName -like 'MySQL*' }
        foreach ($s in $servicos) {
            if ($s.Status -ne 'Running') {
                Aviso "Iniciando o serviço $($s.Name)..."
                try { Start-Service $s.Name; Start-Sleep -Seconds 3 } catch { Aviso "Não foi possível iniciar $($s.Name) (talvez seja preciso executar como administrador)." }
            }
        }
        if (Porta-Aberta $servidor $porta) { Ok "MySQL iniciado em ${servidor}:$porta"; return }
        $docker = Get-Command docker -ErrorAction SilentlyContinue
        if ($docker) {
            Aviso 'MySQL local não encontrado. Subindo o MySQL 8 no Docker (docker-compose.yml)...'
            $env:DB_PASSWORD = $c['DB_PASSWORD']; $env:DB_NAME = $c['DB_NAME']; $env:DB_PORT = "$porta"
            Push-Location $Raiz
            try { & docker compose up -d mysql } finally { Pop-Location }
            for ($i = 0; $i -lt 60; $i++) { if (Porta-Aberta $servidor $porta) { Start-Sleep -Seconds 8; Ok 'MySQL do Docker pronto.'; return }; Start-Sleep -Seconds 2 }
        }
    }
    Falhar ("O MySQL não está respondendo em ${servidor}:$porta.`n" +
        "  - Se o MySQL está instalado: abra 'Serviços' do Windows e inicie o serviço MySQL80 (ou execute este script como administrador).`n" +
        "  - Se não está instalado: instale o MySQL 8 Community ou o Docker Desktop e execute de novo.")
}

# ------------------------------------------------------------------ compilação
function Fontes-Mudaram {
    if (-not (Test-Path $Jar)) { return $true }
    $dataJar = (Get-Item $Jar).LastWriteTimeUtc
    $maisRecente = Get-ChildItem -Path (Join-Path $Api 'src\main'), (Join-Path $Api 'pom.xml') -Recurse -File | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1
    return ($maisRecente -and $maisRecente.LastWriteTimeUtc -gt $dataJar)
}

function Compilar([string]$mvn, [switch]$ComTestes) {
    Passo 'Compilando a API e a aplicação web (na primeira vez o Maven baixa as dependências)'
    $argumentos = @('-B', '-q', '-f', (Join-Path $Api 'pom.xml'), 'package')
    if (-not $ComTestes) { $argumentos += '-DskipTests' }
    & $mvn @argumentos
    if ($LASTEXITCODE -ne 0) { Falhar 'A compilação falhou. Veja as mensagens acima.' }
    Ok 'API compilada (ecoconnect-api-jpa\target\ecoconnect-api.jar).'
}

# ------------------------------------------------------------------ comandos
function Cmd-Setup {
    Passo 'Verificando o Java'
    Garantir-Java | Out-Null
    Passo 'Verificando o Maven'
    $mvn = Garantir-Maven
    Passo 'Preparando a configuração'
    Garantir-Config
    $c = Ler-Config
    Passo 'Verificando o MySQL'
    Garantir-MySQL $c
    Compilar $mvn -ComTestes
    Passo 'Preparando o Console Java'
    & $mvn -B -q -f (Join-Path $ConsoleDir 'pom.xml') compile
    if ($LASTEXITCODE -ne 0) { Aviso 'O Console não compilou; a aplicação web funciona mesmo assim.' } else { Ok 'Console compilado.' }
    New-Item -ItemType Directory -Force -Path $Logs, $Execucao | Out-Null
    Escrever ''
    Escrever 'Setup concluído. Para iniciar, execute start.bat.' 'Green'
}

function Pid-Atual {
    if (-not (Test-Path $ArquivoPid)) { return $null }
    $id = (Get-Content $ArquivoPid -ErrorAction SilentlyContinue | Select-Object -First 1)
    if ($id -and (Get-Process -Id $id -ErrorAction SilentlyContinue)) { return [int]$id }
    return $null
}

function Saude($c, [int]$espera = 5) {
    try { return Invoke-RestMethod -Uri "http://127.0.0.1:$($c['PORT'])/api/saude" -TimeoutSec $espera } catch { return $null }
}

function Cmd-Start {
    $java = Garantir-Java
    if (-not (Test-Path $Config)) { Escrever 'Primeira execução: rodando o setup.' 'Yellow'; Cmd-Setup }
    $c = Ler-Config
    $existente = Pid-Atual
    if ($existente) {
        $s = Saude $c
        if ($s -and $s.status -eq 'UP') { Ok "O EcoConect já está em execução (processo $existente)."; Abrir-Navegador $c; return }
    }
    if (Porta-Aberta '127.0.0.1' ([int]$c['PORT'])) { Falhar "A porta $($c['PORT']) já está em uso por outro programa. Feche-o ou mude PORT em ecoconnect.properties." }
    Passo 'Verificando o MySQL'
    Garantir-MySQL $c
    if (Fontes-Mudaram) { $mvn = Garantir-Maven; Compilar $mvn }
    New-Item -ItemType Directory -Force -Path $Logs, $Execucao | Out-Null
    Passo 'Iniciando o EcoConect'
    $log = Join-Path $Logs 'ecoconect-api.log'
    $logErro = Join-Path $Logs 'ecoconect-api-erros.log'
    $p = Start-Process -FilePath $java -ArgumentList @('-Dfile.encoding=UTF-8', '-jar', $Jar) -WorkingDirectory $Api -WindowStyle Hidden `
        -RedirectStandardOutput $log -RedirectStandardError $logErro -PassThru
    Set-Content -Path $ArquivoPid -Value $p.Id
    Escrever "    processo $($p.Id); registros em logs\ecoconect-api.log" 'DarkGray'
    for ($i = 0; $i -lt 90; $i++) {
        Start-Sleep -Seconds 2
        if ($p.HasExited) {
            Escrever ''; Escrever 'O EcoConect parou durante a inicialização. Últimas linhas do registro:' 'Red'
            Get-Content $log -Tail 40 -ErrorAction SilentlyContinue | ForEach-Object { Escrever "    $_" 'DarkGray' }
            Remove-Item $ArquivoPid -ErrorAction SilentlyContinue
            Falhar 'Corrija o problema indicado acima (senha do MySQL em ecoconnect.properties, porta ocupada...) e tente de novo.'
        }
        $s = Saude $c 2
        if ($s -and $s.status -eq 'UP') {
            Ok "Banco de dados conectado (versão das migrations: $($s.versaoBanco))."
            Escrever ''
            Escrever "EcoConect em execução: http://localhost:$($c['PORT'])/" 'Green'
            Escrever "  Aplicação: http://localhost:$($c['PORT'])/app/" 'Green'
            Escrever "  Documentação da API: http://localhost:$($c['PORT'])/swagger-ui.html" 'DarkGray'
            if ($c['ADMIN_EMAIL']) { Escrever "  Administrador inicial: $($c['ADMIN_EMAIL']) (troque a senha no primeiro acesso)" 'DarkGray' }
            if ($s.demonstracao) { Escrever '  Contas fictícias de demonstração: *@demo.ecoconect.local, senha EcoDemo2026' 'DarkGray' }
            Escrever '  Para encerrar: stop.bat' 'DarkGray'
            Abrir-Navegador $c
            return
        }
        Write-Host -NoNewline '.'
    }
    Falhar 'O EcoConect não respondeu em 3 minutos. Veja logs\ecoconect-api.log.'
}

function Abrir-Navegador($c) {
    if (-not $SemNavegador -and -not $env:ECO_SEM_NAVEGADOR) { Start-Process "http://localhost:$($c['PORT'])/app/" }
}

function Cmd-Stop {
    $c = Ler-Config
    $id = Pid-Atual
    $parou = $false
    if ($id) { Stop-Process -Id $id -Force -ErrorAction SilentlyContinue; $parou = $true }
    try {
        $conexoes = Get-NetTCPConnection -LocalPort ([int]$c['PORT']) -State Listen -ErrorAction SilentlyContinue
        foreach ($cx in $conexoes) {
            $proc = Get-Process -Id $cx.OwningProcess -ErrorAction SilentlyContinue
            if ($proc -and $proc.ProcessName -like 'java*') { Stop-Process -Id $proc.Id -Force; $parou = $true }
        }
    } catch { }
    Remove-Item $ArquivoPid -ErrorAction SilentlyContinue
    if ($parou) { Ok 'EcoConect encerrado.' } else { Escrever 'O EcoConect não estava em execução.' 'Yellow' }
}

function Cmd-Health {
    $c = Ler-Config
    Passo 'Verificação de saúde'
    $java = Caminho-Java
    if ($java) { Ok "Java $(Versao-Java $java)" } else { Aviso 'Java não encontrado.' }
    if (Porta-Aberta $c['DB_HOST'] ([int]$c['DB_PORT'])) { Ok "MySQL em $($c['DB_HOST']):$($c['DB_PORT'])" } else { Aviso "MySQL não responde em $($c['DB_HOST']):$($c['DB_PORT'])" }
    $s = Saude $c
    if (-not $s) { Falhar "A API não responde em http://127.0.0.1:$($c['PORT']). Execute start.bat." }
    Ok "API: $($s.status) | banco: $($s.banco) | migrations: $($s.versaoBanco) | dados de demonstração: $($s.demonstracao)"
    try {
        $r = Invoke-WebRequest -Uri "http://127.0.0.1:$($c['PORT'])/app/" -UseBasicParsing -TimeoutSec 5
        if ($r.StatusCode -eq 200) { Ok 'Aplicação web disponível em /app/' }
    } catch { Aviso 'A aplicação web não respondeu.' }
    if ($Completo) {
        Passo 'Teste ponta a ponta (cria registros de teste identificados com o prefixo [TESTE])'
        $java = Garantir-Java
        & $java '-Dstdout.encoding=UTF-8' (Join-Path $Raiz 'ferramentas\teste\TesteFimAFim.java') "http://127.0.0.1:$($c['PORT'])" "$($c['ADMIN_EMAIL'])"
        if ($LASTEXITCODE -ne 0) { Falhar 'O teste ponta a ponta encontrou falhas (veja acima).' }
    }
    Escrever ''; Escrever 'Tudo certo.' 'Green'
}

function Cmd-Console {
    Garantir-Java | Out-Null
    $mvn = Garantir-Maven
    Garantir-Config
    & $mvn -B -q -f (Join-Path $ConsoleDir 'pom.xml') compile exec:java
}

switch ($Comando) {
    'setup' { Cmd-Setup }
    'start' { Cmd-Start }
    'stop' { Cmd-Stop }
    'restart' { Cmd-Stop; Start-Sleep -Seconds 2; Cmd-Start }
    'health' { Cmd-Health }
    'console' { Cmd-Console }
}
