#!/usr/bin/env bash
# EcoConect - start (Linux/macOS)
exec "$(dirname "$0")/scripts/ecoconect.sh" start "$@"
