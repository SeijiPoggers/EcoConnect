@echo off
rem EcoConect - healthcheck (Windows). Detalhes em scripts\ecoconect.ps1
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\ecoconect.ps1" health %*
set CODIGO=%ERRORLEVEL%
if not "%ECO_SEM_PAUSA%"=="1" pause
exit /b %CODIGO%
