# EcoConnect: API + Console + MySQL

A API e o Console **não conversam diretamente**. Os dois usam o mesmo banco MySQL, e é isso que os conecta:

```
API (Spring Boot, porta 8080) ──┐
                                ├──► MySQL: banco ecoconnect
Console (Java, terminal)     ───┘
```

O que um grava, o outro enxerga. O arquivo `ecoconnect.properties` configura os dois.

## Antes de começar

Você precisa de JDK 17 ou superior, MySQL 8, MySQL Workbench e NetBeans.

## 1. Configure a senha

Abra `ecoconnect.properties` e troque `COLOQUE_SUA_SENHA_DO_MYSQL_AQUI` pela senha do seu MySQL.

## 2. Crie o banco

> **Cuidado:** o script apaga as tabelas do banco `ecoconnect`, se ele já existir. Faça backup se houver dados que queira manter.

No Workbench: *File → Open SQL Script* → `ecoconnect-api-jpa/database/EcoConnect_backup_final.sql` → executar (raio ⚡).

O script só cria as 32 tabelas: ele não tem nenhum registro.

## 3. Rode a API primeiro

No NetBeans: *File → Open Project* → `ecoconnect-api-jpa`. Clique com o botão direito no projeto → *Run*. Espere aparecer `Started EcoConnectApiApplication`. Se o Windows perguntar sobre o firewall, não libere em redes públicas: para usar em `localhost`, nenhuma liberação é necessária.

Ela precisa ser a primeira porque, com o banco vazio, cria os perfis ADMINISTRADOR, PROFISSIONAL e RESPONSAVEL e o administrador de teste. Se você cadastrar um perfil pelo Console antes, esses perfis não serão criados. Nesse caso, execute o script do passo 2 de novo e reinicie a API.

## 4. Rode o Console

Com a API ainda rodando, abra `EcoConect-Console` no NetBeans, clique com o botão direito no projeto → *Run*. Se pedir a classe principal, escolha `br.com.ecoconect.main.Main`. No menu, escolha **12**: deve aparecer `Conectado a MySQL 8...`.

## 5. Teste a conexão entre os dois

**Do Console para a API**

1. No Console, escolha `1` (Usuários) e depois `3` (Cadastrar). Preencha estes campos e aperte ENTER nos demais:
   - `id_perfil`: `2`
   - `nome_completo`: `Teste Console`
   - `email`: `console@teste.com`
   - senha: `Teste1234`
   - `status`: `ATIVO`

   Em `Confirmar cadastro?`, responda `s`.
2. Abra `http://localhost:8080/swagger-ui.html` e execute `POST /api/auth/login`:
   ```json
   { "email": "console@teste.com", "senha": "Teste1234" }
   ```
   A resposta deve ser **200** com os dados do usuário.

**Da API para o Console**

1. No Swagger, execute `POST /api/criancas`:
   ```json
   { "nomeCompleto": "Crianca Teste", "dataNascimento": "2020-05-10", "situacaoEcocura": "ATIVA" }
   ```
2. No Console, escolha `2` (Crianças) e depois `1` (Listar). A criança deve aparecer.

## Diferenças entre os dois caminhos

A API aplica as regras de negócio e grava a auditoria. O Console grava direto nas tabelas e respeita só as restrições do banco. Por isso, um registro feito pelo Console não aparece na auditoria e pode não seguir regras como a coerência entre perfil e cadastro.

## Problemas comuns

| Mensagem | O que fazer |
|---|---|
| `Access denied for user` | Corrija a senha em `ecoconnect.properties` |
| `Communications link failure` | Ligue o serviço do MySQL e confira host e porta |
| `Unknown database 'ecoconnect'` | Execute o passo 2 |
| `Port 8080 was already in use` | Feche a outra API aberta ou defina a variável `PORT=8081` |
| Login responde `Conta pendente de ativação` | O usuário foi criado sem `status` ATIVO |

Variáveis de ambiente, se existirem, têm prioridade sobre `ecoconnect.properties`.
