#!/usr/bin/env bash
# EcoConect - restart (Linux/macOS)
exec "$(dirname "$0")/scripts/ecoconect.sh" restart "$@"
