#!/usr/bin/env bash
# EcoConect - setup (Linux/macOS)
exec "$(dirname "$0")/scripts/ecoconect.sh" setup "$@"
