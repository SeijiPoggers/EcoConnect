#!/usr/bin/env bash
# EcoConect - healthcheck (Linux/macOS)
exec "$(dirname "$0")/scripts/ecoconect.sh" health "$@"
