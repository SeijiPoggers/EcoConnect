package br.com.ecoconect.dao;

import br.com.ecoconect.model.*;import java.sql.*;import java.util.*;import java.util.stream.*;
public final class CrudDao {
 private static String quote(String s){return "`"+s+"`";}
 private static String where(List<String> pk){return pk.stream().map(s->quote(s)+"=?").collect(Collectors.joining(" AND "));}
 public List<Map<String,Object>> list(Connection con,TableInfo t,int limit) throws SQLException {
  String sql="SELECT * FROM "+quote(t.name())+" LIMIT "+Math.min(100,Math.max(1,limit));
  try(Statement st=con.createStatement();ResultSet rs=st.executeQuery(sql)){return rows(rs);}
 }
 public List<Map<String,Object>> lookup(Connection con,TableInfo t,Map<String,Object> keys) throws SQLException {
  if(t.primaryKeys().isEmpty())throw new SQLException("Tabela sem chave primaria");
  String sql="SELECT * FROM "+quote(t.name())+" WHERE "+where(t.primaryKeys());
  try(PreparedStatement st=con.prepareStatement(sql)){bind(st,t.primaryKeys(),keys,1);try(ResultSet rs=st.executeQuery()){return rows(rs);}}
 }
 public int insert(Connection con,TableInfo t,Map<String,Object> values) throws SQLException {
  if(values.isEmpty())throw new SQLException("Nenhum campo informado");
  String cols=values.keySet().stream().map(CrudDao::quote).collect(Collectors.joining(","));
  String params=values.keySet().stream().map(s->"?").collect(Collectors.joining(","));
  try(PreparedStatement st=con.prepareStatement("INSERT INTO "+quote(t.name())+" ("+cols+") VALUES ("+params+")")){bind(st,new ArrayList<>(values.keySet()),values,1);return st.executeUpdate();}
 }
 public int update(Connection con,TableInfo t,Map<String,Object> keys,Map<String,Object> values) throws SQLException {
  if(values.isEmpty())return 0;
  String sets=values.keySet().stream().map(s->quote(s)+"=?").collect(Collectors.joining(","));
  try(PreparedStatement st=con.prepareStatement("UPDATE "+quote(t.name())+" SET "+sets+" WHERE "+where(t.primaryKeys()))){int next=bind(st,new ArrayList<>(values.keySet()),values,1);bind(st,t.primaryKeys(),keys,next);return st.executeUpdate();}
 }
 public int delete(Connection con,TableInfo t,Map<String,Object> keys) throws SQLException {
  try(PreparedStatement st=con.prepareStatement("DELETE FROM "+quote(t.name())+" WHERE "+where(t.primaryKeys()))){bind(st,t.primaryKeys(),keys,1);return st.executeUpdate();}
 }
 private int bind(PreparedStatement st,List<String> cols,Map<String,Object> vals,int i) throws SQLException {for(String c:cols)st.setObject(i++,vals.get(c));return i;}
 private List<Map<String,Object>> rows(ResultSet rs)throws SQLException {List<Map<String,Object>> all=new ArrayList<>();ResultSetMetaData m=rs.getMetaData();while(rs.next()){Map<String,Object> row=new LinkedHashMap<>();for(int i=1;i<=m.getColumnCount();i++){Object value=rs.getObject(i);if(value instanceof byte[] bytes)value="["+bytes.length+" bytes]";row.put(m.getColumnLabel(i),value);}all.add(row);}return all;}
}