package br.com.ecoconect.config;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.util.Properties;

/**
 * Conexao com o mesmo banco usado pela API.
 * Ordem de prioridade: variavel ECO_DB_*, variavel DB_*, ecoconnect.properties, valor padrao.
 */
public final class Database {
 private static final Properties FILE=loadFile();
 private Database() {}

 public static Connection open() throws SQLException {
  String host=setting("HOST","localhost");
  String port=setting("PORT","3306");
  String db=setting("NAME","ecoconnect");
  String user=setting("USER","root");
  String password=setting("PASSWORD",null);
  if(password==null) throw new SQLException("Senha do MySQL nao configurada. Preencha DB_PASSWORD no arquivo ecoconnect.properties (pode ficar vazia para MySQL sem senha).");
  if(!host.matches("[a-zA-Z0-9.:-]+") || !port.matches("[0-9]{1,5}") || !db.matches("[a-zA-Z0-9_]+")) throw new SQLException("Configuracao de host, porta ou banco invalida.");
  return DriverManager.getConnection("jdbc:mysql://"+host+":"+port+"/"+db+"?allowPublicKeyRetrieval=true&useUnicode=true&characterEncoding=UTF-8&connectionTimeZone=LOCAL&connectTimeout=5000",user,password);
 }

 /** Valor de configuracao compartilhado com a API (ECO_X, X ou ecoconnect.properties). */
 public static String config(String name,String fallback){
  String value=System.getenv("ECO_"+name);
  if(value==null)value=System.getenv(name);
  if(value==null)value=FILE.getProperty(name);
  return value==null||value.isBlank()?fallback:value.trim();
 }

 private static String setting(String name,String fallback){
  String value=System.getenv("ECO_DB_"+name);
  if(value==null)value=System.getenv("DB_"+name);
  if(value==null)value=FILE.getProperty("DB_"+name);
  return value==null?fallback:value;
 }

 /** Le o arquivo da pasta acima do projeto e depois o da pasta atual, que tem prioridade. */
 private static Properties loadFile(){
  Properties props=new Properties();
  for(Path path:new Path[]{Path.of("..","ecoconnect.properties"),Path.of("ecoconnect.properties")}){
   if(!Files.isRegularFile(path))continue;
   try(Reader reader=Files.newBufferedReader(path,StandardCharsets.UTF_8)){props.load(reader);}
   catch(IOException e){System.out.println("Aviso: nao foi possivel ler "+path+": "+e.getMessage());}
  }
  return props;
 }
}
