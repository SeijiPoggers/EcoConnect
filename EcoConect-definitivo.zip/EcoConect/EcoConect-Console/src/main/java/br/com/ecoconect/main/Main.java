package br.com.ecoconect.main;

import br.com.ecoconect.view.ConsoleView;
public final class Main {public static void main(String[] args){new ConsoleView().run();}}