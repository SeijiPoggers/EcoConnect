package br.com.ecoconect.view;

import br.com.ecoconect.model.*;import br.com.ecoconect.service.*;import br.com.ecoconect.util.Input;import java.sql.*;import java.util.*;import org.mindrot.jbcrypt.BCrypt;
public final class ConsoleView {
 private final Input input=new Input();private final RecordService service=new RecordService();
 private static final List<String> FEATURED=List.of("usuario","crianca","responsavel","profissional","agendamento","atendimento","atividade","diagnostico","objetivo","relatorio_atendimento");
 public void run(){System.out.println("=== ECOCONECT | Console MySQL ===");while(true){try {
  System.out.println("\n1 Usuarios | 2 Criancas | 3 Responsaveis | 4 Profissionais | 5 Agendamentos");
  System.out.println("6 Atendimentos | 7 Atividades | 8 Diagnosticos | 9 Objetivos | 10 Relatorios");
  System.out.println("11 Outras tabelas | 12 Testar conexao | 13 Situacao da API EcoConect | 0 Sair");
  int choice=input.integer("Opcao: ");if(choice==0){System.out.println("Ate logo!");return;}
  if(choice==12){service.test();continue;}
  if(choice==13){situacaoApi();continue;}
  if(choice==11){otherTables();continue;}
  if(choice>=1&&choice<=10){tableMenu(FEATURED.get(choice-1));continue;}
  System.out.println("Opcao invalida.");
 }catch(SQLException e){System.out.println("Erro MySQL: "+e.getMessage());}catch(IllegalArgumentException e){System.out.println("Entrada invalida: "+e.getMessage());}catch(NoSuchElementException e){System.out.println("Entrada encerrada.");return;}}}
 /** Integracao com o ecossistema: consulta a saude da API (mesmo banco, mesma configuracao). */
 private void situacaoApi(){
  String porta=br.com.ecoconect.config.Database.config("PORT","8080");
  try{
   java.net.http.HttpClient c=java.net.http.HttpClient.newBuilder().connectTimeout(java.time.Duration.ofSeconds(3)).build();
   java.net.http.HttpResponse<String> r=c.send(java.net.http.HttpRequest.newBuilder(java.net.URI.create("http://127.0.0.1:"+porta+"/api/saude")).timeout(java.time.Duration.ofSeconds(5)).GET().build(),java.net.http.HttpResponse.BodyHandlers.ofString());
   System.out.println("API EcoConect (HTTP "+r.statusCode()+"): "+r.body());
  }catch(Exception e){System.out.println("A API nao respondeu em http://127.0.0.1:"+porta+" ("+e.getClass().getSimpleName()+"). Inicie com start.bat ou start.sh.");}
 }
 private void otherTables()throws SQLException {System.out.println("Tabelas disponiveis:");for(int i=0;i<Catalog.TABLES.size();i++)System.out.printf("%2d - %s%n",i+1,Catalog.TABLES.get(i));int n=input.integer("Numero da tabela (0 volta): ");if(n>=1&&n<=Catalog.TABLES.size())tableMenu(Catalog.TABLES.get(n-1));}
 private void tableMenu(String name)throws SQLException {TableInfo t=service.inspect(name);while(true){
  boolean readonly=Catalog.READ_ONLY.contains(name);
  System.out.println("\n===== "+name.toUpperCase(Locale.ROOT)+" =====");
  System.out.println("1 Listar | 2 Buscar por chave | 3 Cadastrar | 4 Atualizar | 5 Excluir | 0 Voltar");
  if(readonly)System.out.println("AVISO: tabela protegida, somente consulta nesta versao.");
  int n=input.integer("Opcao: ");if(n==0)return;
  try{switch(n){case 1 -> printRows(service.list(t));case 2 -> printRows(service.lookup(t,keys(t)));
   case 3 -> {if(!readonly){Map<String,Object> vals=fields(t,false);if(input.yes("Confirmar cadastro?")){service.insert(t,vals);System.out.println("Registro cadastrado.");}}else System.out.println("Operacao protegida.");}
   case 4 -> {if(!readonly){Map<String,Object> key=keys(t);printRows(service.lookup(t,key));Map<String,Object> vals=fields(t,true);if(!vals.isEmpty()&&input.yes("Confirmar alteracao?"))System.out.println("Registros atualizados: "+service.update(t,key,vals));}else System.out.println("Operacao protegida.");}
   case 5 -> {if(readonly||Catalog.NO_DELETE.contains(name)){System.out.println("Exclusao bloqueada para proteger integridade/historico.");break;}Map<String,Object> key=keys(t);printRows(service.lookup(t,key));if(input.yes("CONFIRMA excluir este registro permanentemente?"))System.out.println("Registros excluidos: "+service.delete(t,key));}
   default -> System.out.println("Opcao invalida.");}
  }catch(SQLException e){System.out.println("Erro SQL: "+e.getMessage());}catch(IllegalArgumentException e){System.out.println("Dados invalidos: "+e.getMessage());}
 }}
 private Map<String,Object> keys(TableInfo t){Map<String,Object> vals=new LinkedHashMap<>();if(t.primaryKeys().isEmpty())throw new IllegalArgumentException("Sem chave primaria");for(String key:t.primaryKeys()){ColumnInfo c=t.column(key);vals.put(key,ask(c,true));}return vals;}
 private Map<String,Object> fields(TableInfo t,boolean update){Map<String,Object> vals=new LinkedHashMap<>();
  System.out.println("ENTER: "+(update?"manter valor atual":"usar padrao quando permitido")+" | NULL: gravar nulo");
  for(ColumnInfo c:t.columns()){
   if(c.autoIncrement()||c.generated()||t.primaryKeys().contains(c.name())&&update)continue;
   if(c.name().equals("senha_hash")){String password=input.line("senha (ENTER para "+(update?"manter":"ignorar")+"): ");if(!password.isBlank()){if(password.length()<8)throw new IllegalArgumentException("Senha deve ter pelo menos 8 caracteres");vals.put(c.name(),BCrypt.hashpw(password,BCrypt.gensalt(12)));}else if(!update)throw new IllegalArgumentException("Senha obrigatoria");continue;}
   String value=input.line(input.hint(c)+": ");
   if(value.isEmpty()){if(!update&&!c.nullable()&&c.defaultValue()==null) {System.out.println("Campo obrigatorio. Preencha-o.");value=required(c);}else continue;}
   vals.put(c.name(),input.parse(c,value));
  }return vals;}
 private String required(ColumnInfo c){while(true){String s=input.line(input.hint(c)+": ");if(!s.isEmpty())return s;System.out.println("Valor obrigatorio.");}}
 private Object ask(ColumnInfo c,boolean required){while(true){String s=input.line(input.hint(c)+": ");if(s.isBlank()){System.out.println("Informe a chave.");continue;}return input.parse(c,s);}}
 private void printRows(List<Map<String,Object>> rows){if(rows.isEmpty()){System.out.println("Nenhum registro encontrado.");return;}for(Map<String,Object> row:rows){System.out.println("------------------------------");for(var entry:row.entrySet()){
  String k=entry.getKey();if(k.equals("senha_hash")||k.equals("cpf")||k.equals("valores_anteriores")||k.equals("valores_novos")||k.equals("conteudo")||k.equals("observacoes_gerais")){System.out.println(k+": [DADO PROTEGIDO]");continue;}
  String v=String.valueOf(entry.getValue());System.out.println(k+": "+(v.length()>160?v.substring(0,160)+"...":v));
 }}System.out.println("Total exibido: "+rows.size()+" (maximo 30)");}
}