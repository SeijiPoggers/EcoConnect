package br.com.ecoconect.util;

import java.sql.*;import java.time.*;import java.util.*;import br.com.ecoconect.model.ColumnInfo;
public final class Input {
 private final Scanner scanner=new Scanner(System.in);
 public String line(String question){System.out.print(question);if(!scanner.hasNextLine())throw new NoSuchElementException("Entrada encerrada");return scanner.nextLine().trim();}
 public int integer(String question){while(true){try{return Integer.parseInt(line(question));}catch(NumberFormatException e){System.out.println("Digite um numero inteiro valido.");}}}
 public boolean yes(String question){return line(question+" [s/N]: ").equalsIgnoreCase("s");}
 public Object parse(ColumnInfo col,String text){
  if(text.equalsIgnoreCase("NULL")){if(!col.nullable())throw new IllegalArgumentException("Campo obrigatorio");return null;}
  if(!col.options().isEmpty()&&!col.options().contains(text))throw new IllegalArgumentException("Opcoes permitidas: "+col.options());
  try {switch(col.sqlType()) {
   case Types.INTEGER,Types.SMALLINT,Types.TINYINT,Types.BIGINT: return Long.parseLong(text);
   case Types.DECIMAL,Types.NUMERIC,Types.DOUBLE,Types.FLOAT,Types.REAL: return new java.math.BigDecimal(text);
   case Types.DATE: return java.sql.Date.valueOf(LocalDate.parse(text));
   case Types.TIMESTAMP,Types.TIMESTAMP_WITH_TIMEZONE: return Timestamp.valueOf(LocalDateTime.parse(text.replace(' ','T')));
   case Types.TIME: return Time.valueOf(LocalTime.parse(text));
   case Types.BIT,Types.BOOLEAN: if(!text.equals("0")&&!text.equals("1"))throw new IllegalArgumentException("Informe 0 ou 1");return text.equals("1");
   default: if(col.size()>0 && text.length()>col.size() && (col.sqlType()==Types.VARCHAR||col.sqlType()==Types.CHAR))throw new IllegalArgumentException("Maximo de "+col.size()+" caracteres");return text;
  }}catch(java.time.format.DateTimeParseException|NumberFormatException ex){throw new IllegalArgumentException("Formato invalido para "+col.name()+" ("+col.typeName()+")");}
 }
 public String hint(ColumnInfo c){String h=c.name()+" ["+c.typeName()+"]";if(!c.options().isEmpty())h+=" "+c.options();if(c.nullable())h+=" (NULL permitido)";if(c.defaultValue()!=null)h+=" (padrao: "+c.defaultValue()+")";return h;}
}