package br.com.ecoconect.service;

import br.com.ecoconect.model.*;
import java.sql.*;import java.util.*;
public final class Catalog {
 public static final List<String> TABLES=List.of("agendamento","agendamento_profissional","atendimento","atendimento_atividade","atendimento_profissional","atividade","auditoria","avaliacao_indicador","comunicado","comunicado_destinatario","condicao_saude","consentimento","conversa","conversa_participante","crianca","crianca_condicao","crianca_diagnostico","crianca_instituicao","crianca_profissional","crianca_responsavel","crianca_usuario","diagnostico","documento","especialidade","estabelecimento_sus","fila_espera","historico_agendamento","historico_saude","indicador","instituicao","instituicao_membro","instituicao_servico","mensagem","notificacao","objetivo","objetivo_indicador","perfil","perfil_necessidades","preferencia_interface","profissional","profissional_especialidade","registro_sessao","relatorio_atendimento","responsavel","solicitacao_atendimento","solicitacao_titular","usuario");
 public static final Set<String> READ_ONLY=Set.of("auditoria","historico_agendamento","historico_saude","avaliacao_indicador","consentimento","documento","relatorio_atendimento","atendimento","atendimento_atividade","atendimento_profissional","notificacao","comunicado_destinatario","crianca_diagnostico","crianca_condicao","conversa","conversa_participante","mensagem","registro_sessao","solicitacao_atendimento","solicitacao_titular","crianca_usuario","preferencia_interface");
 public static final Set<String> NO_DELETE=Set.of("usuario","crianca","responsavel","profissional","agendamento","fila_espera","objetivo","comunicado","crianca_responsavel","instituicao","instituicao_membro","instituicao_servico","crianca_profissional","crianca_instituicao","perfil_necessidades");
 private Catalog(){}
 public static TableInfo inspect(Connection con,String table) throws SQLException {
  if(!TABLES.contains(table))throw new SQLException("Tabela nao autorizada: "+table);
  DatabaseMetaData md=con.getMetaData(); List<ColumnInfo> cols=new ArrayList<>(); List<String> pk=new ArrayList<>(); Map<String,TableInfo.ForeignKey> fk=new LinkedHashMap<>();
  try(ResultSet r=md.getColumns(con.getCatalog(),null,table,null)) {while(r.next()) {
   String type=r.getString("TYPE_NAME");String name=r.getString("COLUMN_NAME");
   List<String> opts=new ArrayList<>(); if(type!=null && type.toLowerCase(Locale.ROOT).startsWith("enum(")){
    java.util.regex.Matcher m=java.util.regex.Pattern.compile("'((?:[^']|'')*)'").matcher(type);
    while(m.find())opts.add(m.group(1).replace("''","'"));
   }
   cols.add(new ColumnInfo(name,r.getInt("DATA_TYPE"),type,r.getInt("NULLABLE")!=DatabaseMetaData.columnNoNulls,"YES".equalsIgnoreCase(r.getString("IS_AUTOINCREMENT")),"YES".equalsIgnoreCase(r.getString("IS_GENERATEDCOLUMN")),r.getString("COLUMN_DEF"),r.getInt("COLUMN_SIZE"),opts));
  }}
  TreeMap<Short,String> sorted=new TreeMap<>();try(ResultSet r=md.getPrimaryKeys(con.getCatalog(),null,table)){while(r.next())sorted.put(r.getShort("KEY_SEQ"),r.getString("COLUMN_NAME"));}pk.addAll(sorted.values());
  try(ResultSet r=md.getImportedKeys(con.getCatalog(),null,table)){while(r.next())fk.put(r.getString("FKCOLUMN_NAME"),new TableInfo.ForeignKey(r.getString("PKTABLE_NAME"),r.getString("PKCOLUMN_NAME")));}
  Map<String,List<String>> enumOptions=new HashMap<>();
  try(Statement st=con.createStatement();ResultSet er=st.executeQuery("SHOW COLUMNS FROM `"+table+"`")){
   while(er.next()){String type=er.getString("Type");if(type!=null&&type.toLowerCase(Locale.ROOT).startsWith("enum(")){
    List<String> options=new ArrayList<>();java.util.regex.Matcher m=java.util.regex.Pattern.compile("'((?:[^']|'')*)'").matcher(type);while(m.find())options.add(m.group(1).replace("''","'"));enumOptions.put(er.getString("Field"),options);
   }}
  }
  if(!enumOptions.isEmpty()){List<ColumnInfo> replaced=new ArrayList<>();for(ColumnInfo c:cols)replaced.add(new ColumnInfo(c.name(),c.sqlType(),c.typeName(),c.nullable(),c.autoIncrement(),c.generated(),c.defaultValue(),c.size(),enumOptions.getOrDefault(c.name(),c.options())));cols=replaced;}
  if(cols.isEmpty())throw new SQLException("Tabela nao encontrada no banco: "+table);
  return new TableInfo(table,cols,pk,fk);
 }
}