package br.com.ecoconect.model;

import java.util.*;
public record TableInfo(String name, List<ColumnInfo> columns, List<String> primaryKeys, Map<String,ForeignKey> foreignKeys) {
 public record ForeignKey(String table,String column) {}
 public ColumnInfo column(String name){return columns.stream().filter(c->c.name().equals(name)).findFirst().orElseThrow();}
}