package br.com.ecoconect.model;

import java.util.List;
public record ColumnInfo(String name, int sqlType, String typeName, boolean nullable, boolean autoIncrement, boolean generated, String defaultValue, int size, List<String> options) {}