package br.com.ecoconect.service;

import br.com.ecoconect.config.Database;import br.com.ecoconect.dao.CrudDao;import br.com.ecoconect.model.*;import java.sql.*;import java.util.*;
public final class RecordService {
 private final CrudDao dao=new CrudDao();
 public TableInfo inspect(String table)throws SQLException {try(Connection c=Database.open()){return Catalog.inspect(c,table);}}
 public List<Map<String,Object>> list(TableInfo t)throws SQLException {try(Connection c=Database.open()){return dao.list(c,t,30);}}
 public List<Map<String,Object>> lookup(TableInfo t,Map<String,Object> keys)throws SQLException {try(Connection c=Database.open()){return dao.lookup(c,t,keys);}}
 public void insert(TableInfo t,Map<String,Object> values)throws SQLException {try(Connection c=Database.open()){dao.insert(c,t,values);}}
 public int update(TableInfo t,Map<String,Object> keys,Map<String,Object> values)throws SQLException {try(Connection c=Database.open()){return dao.update(c,t,keys,values);}}
 public int delete(TableInfo t,Map<String,Object> keys)throws SQLException {try(Connection c=Database.open()){return dao.delete(c,t,keys);}}
 public void test()throws SQLException {try(Connection c=Database.open()){System.out.println("Conectado a "+c.getMetaData().getDatabaseProductName()+" "+c.getMetaData().getDatabaseProductVersion());}}
}