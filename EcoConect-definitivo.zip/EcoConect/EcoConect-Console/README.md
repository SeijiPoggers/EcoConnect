> **Versão definitiva:** o Console agora lista também as tabelas novas (instituições, mensagens, solicitações, perfil de necessidades...). A opção **13** consulta a situação da API EcoConect. Execute pelo `console.bat` / `./console.sh` da pasta principal. O banco é criado pelas migrations da API, por isso não é preciso rodar o script SQL. As tabelas de sessões de login ficam fora do Console por segurança.

# EcoConect — Console Java / MySQL

Projeto acadêmico Java 17 + Maven + MySQL Connector/J. CRUD orientado pelo **metadado real** das 32 tabelas do backup, sem alterar o esquema. Os módulos mais sensíveis ficam somente para consulta.

## Requisitos
- Java JDK 17+, Apache NetBeans com Maven, MySQL 8.0 e MySQL Workbench opcional.
- O backup `EcoConnect_backup_final.sql` está incluído para facilitar a restauração.

## 1. Restaurar o banco (CUIDADO)
O arquivo SQL possui `DROP TABLE IF EXISTS`: **use uma instância de testes, nunca seu banco de produção**. No MySQL Workbench, File > Open SQL Script > selecione `EcoConnect_backup_final.sql` > execute o script. Ele cria e seleciona o banco `ecoconnect`. O dump não inclui registros de exemplo.

## 2. Configurar conexão
Preencha `DB_PASSWORD` no arquivo `ecoconnect.properties`, na pasta acima deste projeto. É o mesmo arquivo usado pela API (veja `LEIA-ME.md`).

Variáveis de ambiente têm prioridade sobre o arquivo, nesta ordem: `ECO_DB_*` e depois `DB_*` (`HOST`, `PORT`, `NAME`, `USER`, `PASSWORD`).

## 3. Abrir e executar no NetBeans
File > Open Project > selecione a pasta `EcoConect-Console` (contém `pom.xml`). Aguarde baixar as dependências Maven. Clique com botão direito no projeto > Run, ou execute a classe `br.com.ecoconect.main.Main`. Alternativa: terminal na pasta do projeto, `mvn clean compile exec:java`.

## 4. Teste demonstrativo
1. Escolha 12 e confirme a conexão.
2. Escolha 11, selecione `perfil` e liste os perfis. Eles são criados pela API ao subir, portanto rode a API antes e não cadastre perfis pelo Console em um banco vazio.
3. Escolha 1 e cadastre um usuário com `id_perfil` válido. Digite uma senha (não um hash) no campo de senha; o console armazena BCrypt.
4. Escolha 2 e cadastre uma criança, preenchendo data de atualização e situação válida.
5. Liste, busque por chave, atualize e consulte novamente.
6. Para testar DELETE, utilize uma tabela de catálogo sem dependentes, como `atividade`, e confirme a exclusão.
7. Teste chave inexistente, data inválida e FK inexistente. A aplicação deve apresentar mensagem e continuar.

Verificação no Workbench: `SELECT * FROM ecoconnect.perfil;`, `SELECT * FROM ecoconnect.crianca;`.

## Limites e cuidados
- Não foi possível testar uma conexão real com o MySQL do seu computador neste ambiente.
- O programa foi estruturado para operar via JDBC e usa metadados (`DatabaseMetaData`) para descobrir tipos, chaves e ENUMs. Verifique a apresentação de ENUMs na versão do driver instalada.
- Tabelas sensíveis e de histórico são apenas consultáveis; exclusões de entidades centrais são bloqueadas. O programa **não implementa autenticação ou controle de permissões**, portanto é apenas um protótipo acadêmico local. Não use com dados reais de crianças, saúde ou usuários.
- CPF, senha e alguns campos sensíveis são ocultados na listagem, mas outros campos ainda podem conter informações pessoais. Use dados fictícios.
- Não implementa todos os fluxos de negócio (como confirmação de agendamentos, relatórios e consentimento) e não substitui uma aplicação de produção.
- Não há criação automática de dados, pois o backup original está vazio. A ordem das FKs deve ser respeitada.
- Campos `NULL` são tratados com a palavra `NULL`; ENTER omite o campo no cadastro ou mantém o valor na atualização.
- Em caso de falha de conexão: verifique serviço MySQL, porta, credenciais, nome do banco e variáveis de ambiente. Em caso de FK: cadastre primeiro o registro pai. Em caso de `CHECK`: confira datas/status.
