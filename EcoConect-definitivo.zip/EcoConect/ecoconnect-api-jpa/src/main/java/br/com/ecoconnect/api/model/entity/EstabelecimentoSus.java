package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/** Tabela `estabelecimento_sus` (migration V2/V3). Gerada no mesmo padrão das entidades originais. */
@Entity
@Table(name = "estabelecimento_sus")
public class EstabelecimentoSus implements Entidade<String> {

    @Id
    @Column(name = "codigo_cnes", nullable = false)
    private String codigoCnes;

    @Size(max = 200)
    @Column(name = "nome", nullable = false, length = 200)
    private String nome;

    @Size(max = 200)
    @Column(name = "razao_social", length = 200)
    private String razaoSocial;

    @Size(max = 20)
    @Column(name = "categoria", nullable = false, length = 20)
    private String categoria;

    @Column(name = "codigo_tipo_unidade")
    private Integer codigoTipoUnidade;

    @Size(max = 6)
    @Column(name = "codigo_municipio", nullable = false, length = 6)
    private String codigoMunicipio;

    @Size(max = 80)
    @Column(name = "municipio", length = 80)
    private String municipio;

    @Size(max = 2)
    @Column(name = "uf", length = 2)
    private String uf;

    @Size(max = 150)
    @Column(name = "logradouro", length = 150)
    private String logradouro;

    @Size(max = 20)
    @Column(name = "numero", length = 20)
    private String numero;

    @Size(max = 80)
    @Column(name = "bairro", length = 80)
    private String bairro;

    @Size(max = 8)
    @Column(name = "cep", length = 8)
    private String cep;

    @Size(max = 30)
    @Column(name = "telefone", length = 30)
    private String telefone;

    @Size(max = 150)
    @Column(name = "email", length = 150)
    private String email;

    @Column(name = "latitude", precision = 9, scale = 6)
    private BigDecimal latitude;

    @Column(name = "longitude", precision = 9, scale = 6)
    private BigDecimal longitude;

    @Size(max = 20)
    @Column(name = "fonte", nullable = false, length = 20)
    private String fonte;

    @Column(name = "data_importacao")
    private LocalDateTime dataImportacao;

    @PrePersist
    void aoInserir() {
        if (dataImportacao == null) dataImportacao = LocalDateTime.now();
    }

    @PreUpdate
    void aoAtualizar() {
        dataImportacao = LocalDateTime.now();
    }

    @Override
    public String chave() {
        return codigoCnes;
    }

    @Override
    public void definirChave(String id) {
        this.codigoCnes = id;
    }

    public String getCodigoCnes() {
        return codigoCnes;
    }

    public void setCodigoCnes(String codigoCnes) {
        this.codigoCnes = codigoCnes;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public Integer getCodigoTipoUnidade() {
        return codigoTipoUnidade;
    }

    public void setCodigoTipoUnidade(Integer codigoTipoUnidade) {
        this.codigoTipoUnidade = codigoTipoUnidade;
    }

    public String getCodigoMunicipio() {
        return codigoMunicipio;
    }

    public void setCodigoMunicipio(String codigoMunicipio) {
        this.codigoMunicipio = codigoMunicipio;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }

    public String getFonte() {
        return fonte;
    }

    public void setFonte(String fonte) {
        this.fonte = fonte;
    }

    public LocalDateTime getDataImportacao() {
        return dataImportacao;
    }

    public void setDataImportacao(LocalDateTime dataImportacao) {
        this.dataImportacao = dataImportacao;
    }
}
