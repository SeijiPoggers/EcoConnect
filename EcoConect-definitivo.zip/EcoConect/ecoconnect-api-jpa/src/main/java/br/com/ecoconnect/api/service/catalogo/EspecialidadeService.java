package br.com.ecoconnect.api.service.catalogo;

import br.com.ecoconnect.api.model.entity.Especialidade;
import br.com.ecoconnect.api.repository.EspecialidadeRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;

/** Especialidades profissionais (catálogo). Exclusão física: o banco bloqueia se estiver em uso. */
@Service
public class EspecialidadeService extends CrudService<Especialidade, Integer> {

    public EspecialidadeService(EspecialidadeRepository repository, AuditoriaService auditoria) {
        super(repository, auditoria, "especialidade");
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.FISICA;
    }
}
