package br.com.ecoconnect.api.controller.catalogo;

import br.com.ecoconnect.api.controller.base.CrudController;
import br.com.ecoconnect.api.model.entity.CondicaoSaude;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.catalogo.CondicaoSaudeService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Condições de saúde reutilizáveis (catálogo). DELETE apenas desativa (ativo = 0). */
@RestController
@RequestMapping("/api/condicoes-saude")
public class CondicaoSaudeController extends CrudController<CondicaoSaude, Long> {

    private final CondicaoSaudeService service;

    public CondicaoSaudeController(CondicaoSaudeService service) {
        this.service = service;
    }

    @Override
    protected CrudService<CondicaoSaude, Long> service() {
        return service;
    }
}
