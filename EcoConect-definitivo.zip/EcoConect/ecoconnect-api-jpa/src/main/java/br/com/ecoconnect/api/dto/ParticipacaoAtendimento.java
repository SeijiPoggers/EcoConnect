package br.com.ecoconnect.api.dto;

import jakarta.validation.constraints.Size;

/** No POST, idProfissional é obrigatório; no PUT ele vem da URL. */
public record ParticipacaoAtendimento(
        Long idProfissional,
        @Size(max = 80) String funcaoNoAtendimento) {
}
