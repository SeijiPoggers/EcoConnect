package br.com.ecoconnect.api.service.saude;

import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.CondicaoSaude;
import br.com.ecoconnect.api.model.entity.CriancaCondicao;
import br.com.ecoconnect.api.repository.CondicaoSaudeRepository;
import br.com.ecoconnect.api.repository.CriancaCondicaoRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.Verificacoes;
import org.springframework.stereotype.Service;

/** CRIANCA_CONDICAO: condições de saúde da criança, com período, origem e validação. */
@Service
public class CriancaCondicaoService extends RegistroSaudeService<CriancaCondicao> {

    private final CondicaoSaudeRepository condicaoRepository;

    public CriancaCondicaoService(CriancaCondicaoRepository repository, AuditoriaService auditoria,
                                  Verificacoes verificacoes, CondicaoSaudeRepository condicaoRepository) {
        super(repository, auditoria, "crianca_condicao", verificacoes);
        this.condicaoRepository = condicaoRepository;
    }

    @Override
    protected void validarEspecifico(CriancaCondicao cc) {
        CondicaoSaude c = condicaoRepository.findById(cc.getIdCondicaoSaude())
                .orElseThrow(() -> new NaoEncontradoException("condicao_saude", cc.getIdCondicaoSaude()));
        if (!Boolean.TRUE.equals(c.getAtivo()) && cc.getIdCriancaCondicao() == null) {
            throw new RegraNegocioException("A condição " + c.getNome() + " está inativa no catálogo.");
        }
        if (cc.getDataInicio() != null && cc.getDataFim() != null && cc.getDataFim().isBefore(cc.getDataInicio())) {
            throw new RegraNegocioException("A data de fim não pode ser antes da data de início.");
        }
    }
}
