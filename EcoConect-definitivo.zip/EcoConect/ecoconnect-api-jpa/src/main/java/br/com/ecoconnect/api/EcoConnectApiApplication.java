package br.com.ecoconnect.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * EcoConnect API - ponte entre o front-end e o banco MySQL "ecoconnect".
 *
 * Front-end  --HTTP/JSON-->  Controllers  -->  Services (regras)  -->  Repositories (Spring Data JPA)  -->  MySQL
 */
@SpringBootApplication
public class EcoConnectApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(EcoConnectApiApplication.class, args);
    }
}
