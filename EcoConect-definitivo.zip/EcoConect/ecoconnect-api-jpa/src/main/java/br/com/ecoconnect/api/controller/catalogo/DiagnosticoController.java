package br.com.ecoconnect.api.controller.catalogo;

import br.com.ecoconnect.api.controller.base.CrudController;
import br.com.ecoconnect.api.model.entity.Diagnostico;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.catalogo.DiagnosticoService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Diagnósticos reutilizáveis (catálogo). DELETE apenas desativa (ativo = 0). */
@RestController
@RequestMapping("/api/diagnosticos")
public class DiagnosticoController extends CrudController<Diagnostico, Long> {

    private final DiagnosticoService service;

    public DiagnosticoController(DiagnosticoService service) {
        this.service = service;
    }

    @Override
    protected CrudService<Diagnostico, Long> service() {
        return service;
    }
}
