package br.com.ecoconnect.api.model.entity;

import java.io.Serializable;
import java.util.Objects;

/** Chave primária composta de `objetivo_indicador`: (id_objetivo, id_indicador). */
public class ObjetivoIndicadorId implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long idObjetivo;
    private Long idIndicador;

    public ObjetivoIndicadorId() {
    }

    public ObjetivoIndicadorId(Long idObjetivo, Long idIndicador) {
        this.idObjetivo = idObjetivo;
        this.idIndicador = idIndicador;
    }

    public Long getIdObjetivo() {
        return idObjetivo;
    }

    public void setIdObjetivo(Long idObjetivo) {
        this.idObjetivo = idObjetivo;
    }

    public Long getIdIndicador() {
        return idIndicador;
    }

    public void setIdIndicador(Long idIndicador) {
        this.idIndicador = idIndicador;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ObjetivoIndicadorId outro)) return false;
        return Objects.equals(idObjetivo, outro.idObjetivo) && Objects.equals(idIndicador, outro.idIndicador);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idObjetivo, idIndicador);
    }

    @Override
    public String toString() {
        return "idObjetivo=" + idObjetivo + ","
                + "idIndicador=" + idIndicador;
    }
}
