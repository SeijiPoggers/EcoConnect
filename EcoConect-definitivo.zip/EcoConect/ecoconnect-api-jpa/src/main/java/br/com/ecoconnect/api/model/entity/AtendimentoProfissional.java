package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;

/**
 * Tabela `atendimento_profissional` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 */
@Entity
@Table(name = "atendimento_profissional")
@IdClass(AtendimentoProfissionalId.class)
public class AtendimentoProfissional {

    @Id
    @Column(name = "id_atendimento", nullable = false)
    private Long idAtendimento;

    @Id
    @Column(name = "id_profissional", nullable = false)
    private Long idProfissional;

    @Size(max = 80)
    @Column(name = "funcao_no_atendimento", length = 80)
    private String funcaoNoAtendimento;

    @PrePersist
    void aoInserir() {
        // sem valores padrão a preencher
    }

    public Long getIdAtendimento() {
        return idAtendimento;
    }

    public void setIdAtendimento(Long idAtendimento) {
        this.idAtendimento = idAtendimento;
    }

    public Long getIdProfissional() {
        return idProfissional;
    }

    public void setIdProfissional(Long idProfissional) {
        this.idProfissional = idProfissional;
    }

    public String getFuncaoNoAtendimento() {
        return funcaoNoAtendimento;
    }

    public void setFuncaoNoAtendimento(String funcaoNoAtendimento) {
        this.funcaoNoAtendimento = funcaoNoAtendimento;
    }
}
