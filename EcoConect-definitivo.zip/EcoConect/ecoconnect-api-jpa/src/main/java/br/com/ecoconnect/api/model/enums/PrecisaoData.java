package br.com.ecoconnect.api.model.enums;

/** Precisão de uma data histórica. Valores idênticos ao ENUM do MySQL. */
public enum PrecisaoData {
    DIA, MES, ANO, DESCONHECIDA
}
