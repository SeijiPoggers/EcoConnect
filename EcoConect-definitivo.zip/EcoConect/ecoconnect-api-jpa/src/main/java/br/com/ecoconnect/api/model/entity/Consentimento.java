package br.com.ecoconnect.api.model.entity;

import br.com.ecoconnect.api.model.enums.BaseLegal;
import br.com.ecoconnect.api.model.enums.SituacaoAutorizacao;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Tabela `consentimento` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 * CHECK consentimento_chk_1: ((situacao_autorizacao <> 'REVOGADA') or (data_revogacao is not null))
 * CHECK consentimento_chk_2: ((base_legal_avaliada = 'NAO_AVALIADA') or ((id_usuario_avaliacao_base is not null) and (data_avaliacao_base is not null)))
 */
@Entity
@Table(name = "consentimento")
public class Consentimento implements Entidade<Long>, PertenceACrianca {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_consentimento", nullable = false)
    private Long idConsentimento;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_crianca", nullable = false)
    private Long idCrianca;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_responsavel", nullable = false)
    private Long idResponsavel;

    @NotBlank(message = "campo obrigatório")
    @Size(max = 200)
    @Column(name = "finalidade", nullable = false, length = 200)
    private String finalidade;

    @NotBlank(message = "campo obrigatório")
    @Size(max = 30)
    @Column(name = "versao_termo", nullable = false, length = 30)
    private String versaoTermo;

    @Enumerated(EnumType.STRING)
    @Column(name = "situacao_autorizacao", nullable = false)
    private SituacaoAutorizacao situacaoAutorizacao;

    @NotNull(message = "campo obrigatório")
    @Column(name = "data_autorizacao", nullable = false)
    private LocalDateTime dataAutorizacao;

    @Column(name = "data_revogacao")
    private LocalDateTime dataRevogacao;

    @Column(name = "data_validade")
    private LocalDate dataValidade;

    @Column(name = "id_documento")
    private Long idDocumento;

    @Enumerated(EnumType.STRING)
    @Column(name = "base_legal_avaliada", nullable = false)
    private BaseLegal baseLegalAvaliada;

    @Column(name = "id_usuario_avaliacao_base")
    private Long idUsuarioAvaliacaoBase;

    @Column(name = "data_avaliacao_base")
    private LocalDateTime dataAvaliacaoBase;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_usuario_registro", nullable = false)
    private Long idUsuarioRegistro;

    @Column(name = "data_registro", nullable = false)
    private LocalDateTime dataRegistro;

    @PrePersist
    void aoInserir() {
        if (situacaoAutorizacao == null) {
            situacaoAutorizacao = SituacaoAutorizacao.REGISTRADA;
        }
        if (baseLegalAvaliada == null) {
            baseLegalAvaliada = BaseLegal.NAO_AVALIADA;
        }
        if (dataRegistro == null) {
            dataRegistro = LocalDateTime.now();
        }
    }

    public Long getIdConsentimento() {
        return idConsentimento;
    }

    public void setIdConsentimento(Long idConsentimento) {
        this.idConsentimento = idConsentimento;
    }

    public Long getIdCrianca() {
        return idCrianca;
    }

    public void setIdCrianca(Long idCrianca) {
        this.idCrianca = idCrianca;
    }

    public Long getIdResponsavel() {
        return idResponsavel;
    }

    public void setIdResponsavel(Long idResponsavel) {
        this.idResponsavel = idResponsavel;
    }

    public String getFinalidade() {
        return finalidade;
    }

    public void setFinalidade(String finalidade) {
        this.finalidade = finalidade;
    }

    public String getVersaoTermo() {
        return versaoTermo;
    }

    public void setVersaoTermo(String versaoTermo) {
        this.versaoTermo = versaoTermo;
    }

    public SituacaoAutorizacao getSituacaoAutorizacao() {
        return situacaoAutorizacao;
    }

    public void setSituacaoAutorizacao(SituacaoAutorizacao situacaoAutorizacao) {
        this.situacaoAutorizacao = situacaoAutorizacao;
    }

    public LocalDateTime getDataAutorizacao() {
        return dataAutorizacao;
    }

    public void setDataAutorizacao(LocalDateTime dataAutorizacao) {
        this.dataAutorizacao = dataAutorizacao;
    }

    public LocalDateTime getDataRevogacao() {
        return dataRevogacao;
    }

    public void setDataRevogacao(LocalDateTime dataRevogacao) {
        this.dataRevogacao = dataRevogacao;
    }

    public LocalDate getDataValidade() {
        return dataValidade;
    }

    public void setDataValidade(LocalDate dataValidade) {
        this.dataValidade = dataValidade;
    }

    public Long getIdDocumento() {
        return idDocumento;
    }

    public void setIdDocumento(Long idDocumento) {
        this.idDocumento = idDocumento;
    }

    public BaseLegal getBaseLegalAvaliada() {
        return baseLegalAvaliada;
    }

    public void setBaseLegalAvaliada(BaseLegal baseLegalAvaliada) {
        this.baseLegalAvaliada = baseLegalAvaliada;
    }

    public Long getIdUsuarioAvaliacaoBase() {
        return idUsuarioAvaliacaoBase;
    }

    public void setIdUsuarioAvaliacaoBase(Long idUsuarioAvaliacaoBase) {
        this.idUsuarioAvaliacaoBase = idUsuarioAvaliacaoBase;
    }

    public LocalDateTime getDataAvaliacaoBase() {
        return dataAvaliacaoBase;
    }

    public void setDataAvaliacaoBase(LocalDateTime dataAvaliacaoBase) {
        this.dataAvaliacaoBase = dataAvaliacaoBase;
    }

    public Long getIdUsuarioRegistro() {
        return idUsuarioRegistro;
    }

    public void setIdUsuarioRegistro(Long idUsuarioRegistro) {
        this.idUsuarioRegistro = idUsuarioRegistro;
    }

    public LocalDateTime getDataRegistro() {
        return dataRegistro;
    }

    public void setDataRegistro(LocalDateTime dataRegistro) {
        this.dataRegistro = dataRegistro;
    }

    @Override
    public Long chave() {
        return idConsentimento;
    }

    @Override
    public void definirChave(Long id) {
        this.idConsentimento = id;
    }
}
