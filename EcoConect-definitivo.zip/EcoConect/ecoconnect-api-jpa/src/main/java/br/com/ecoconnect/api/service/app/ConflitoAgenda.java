package br.com.ecoconnect.api.service.app;

import br.com.ecoconnect.api.dominio.ConflitoHorario;
import br.com.ecoconnect.api.exception.ConflitoException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Component;

/**
 * Evita conflitos de horário entre agendamentos CONFIRMADOS: a mesma pessoa, ou o mesmo
 * profissional designado, não pode ter dois atendimentos sobrepostos.
 */
@Component
public class ConflitoAgenda {

    private static final String SOBREPOE = " AND a.status = 'CONFIRMADO' AND a.id_agendamento <> ? AND a.data_hora_inicio < ? "
            + "AND COALESCE(a.data_hora_fim, DATE_ADD(a.data_hora_inicio, INTERVAL 50 MINUTE)) > ?";

    private final Consultas consultas;

    public ConflitoAgenda(Consultas consultas) {
        this.consultas = consultas;
    }

    /** Verifica a pessoa e todos os profissionais já designados para o agendamento. */
    public void verificar(Long idAgendamento, Long idCrianca, LocalDateTime inicio, LocalDateTime fim) {
        if (inicio == null) return;
        LocalDateTime fimEfetivo = ConflitoHorario.fimEfetivo(inicio, fim);
        long id = idAgendamento == null ? 0 : idAgendamento;
        List<Map<String, Object>> daPessoa = consultas.lista("SELECT a.id_agendamento AS id, "
                + Consultas.dt("a.data_hora_inicio") + " AS inicio FROM agendamento a WHERE a.id_crianca = ?" + SOBREPOE,
                idCrianca, id, fimEfetivo, inicio);
        if (!daPessoa.isEmpty()) {
            throw new ConflitoException("Conflito de horário: esta pessoa já tem o atendimento " + daPessoa.get(0).get("id")
                    + " confirmado em " + texto(daPessoa.get(0).get("inicio")) + ".");
        }
        if (idAgendamento != null) {
            for (Long idProfissional : consultas.ids("SELECT id_profissional FROM agendamento_profissional WHERE id_agendamento = ?",
                    idAgendamento)) {
                verificarProfissional(idAgendamento, idProfissional, inicio, fim);
            }
        }
    }

    public void verificarProfissional(Long idAgendamento, Long idProfissional, LocalDateTime inicio, LocalDateTime fim) {
        if (inicio == null || idProfissional == null) return;
        LocalDateTime fimEfetivo = ConflitoHorario.fimEfetivo(inicio, fim);
        long id = idAgendamento == null ? 0 : idAgendamento;
        List<Map<String, Object>> r = consultas.lista("SELECT a.id_agendamento AS id, " + Consultas.dt("a.data_hora_inicio")
                + " AS inicio, u.nome_completo AS profissional FROM agendamento a "
                + "JOIN agendamento_profissional ap ON ap.id_agendamento = a.id_agendamento "
                + "JOIN profissional p ON p.id_profissional = ap.id_profissional JOIN usuario u ON u.id_usuario = p.id_usuario "
                + "WHERE ap.id_profissional = ?" + SOBREPOE, idProfissional, id, fimEfetivo, inicio);
        if (!r.isEmpty()) {
            throw new ConflitoException("Conflito de horário: " + r.get(0).get("profissional") + " já tem o atendimento "
                    + r.get(0).get("id") + " confirmado em " + texto(r.get(0).get("inicio")) + ".");
        }
    }

    private static String texto(Object isoDataHora) {
        String s = String.valueOf(isoDataHora);
        // aaaa-mm-ddThh:mm:ss -> dd/mm/aaaa às hh:mm
        if (s.length() >= 16) return s.substring(8, 10) + "/" + s.substring(5, 7) + "/" + s.substring(0, 4) + " às " + s.substring(11, 16);
        return s;
    }
}
