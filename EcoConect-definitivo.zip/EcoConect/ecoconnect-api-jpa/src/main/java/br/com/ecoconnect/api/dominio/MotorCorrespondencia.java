package br.com.ecoconnect.api.dominio;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.text.Normalizer;

/**
 * Motor de correspondência entre o perfil de necessidades e as instituições.
 *
 * Regras transparentes e explicáveis (sem aprendizado de máquina): cada critério
 * soma pontos e gera um motivo em linguagem simples. O resultado é uma ORIENTAÇÃO
 * de busca: não é diagnóstico, nem garantia de adequação clínica.
 */
public final class MotorCorrespondencia {

    public static final String AVISO = "As recomendações comparam o perfil informado com os dados que cada instituição "
            + "cadastrou. Elas ajudam a encontrar opções, mas não são diagnóstico nem garantem que o serviço é o mais "
            + "adequado. Converse com a instituição e com os profissionais que acompanham a pessoa.";

    /** Perfil usado na busca. Campos nulos/vazios não são considerados. */
    public record Perfil(Integer idade, Set<String> condicoes, String municipio, String uf, boolean somenteGratuito,
                         String modalidadePreferida, Set<String> acessibilidade, String comunicacaoPreferida,
                         Set<String> sensorial, Set<String> tiposServico) {
    }

    /** Dados da instituição relevantes para a comparação. */
    public record Candidata(long id, String nome, String municipio, String uf, Integer idadeMinima, Integer idadeMaxima,
                            Set<String> condicoes, Set<String> modalidades, Set<String> acessibilidade,
                            boolean gratuito, boolean atendePeloSus, Integer vagas, boolean verificada,
                            boolean aceitaSolicitacoes, Set<String> tiposServico) {
    }

    public record Resultado(long idInstituicao, String nome, int pontuacao, List<String> motivos, List<String> atencao) {
    }

    private MotorCorrespondencia() {
    }

    public static List<Resultado> recomendar(Perfil perfil, List<Candidata> candidatas, int limite) {
        List<Resultado> r = new ArrayList<>();
        for (Candidata c : candidatas) {
            Resultado res = avaliar(perfil, c);
            if (res != null) r.add(res);
        }
        r.sort(Comparator.comparingInt(Resultado::pontuacao).reversed().thenComparing(Resultado::nome));
        return r.size() > limite ? r.subList(0, limite) : r;
    }

    /** null = excluída por critério eliminatório (fora da faixa etária ou não gratuita quando exigido). */
    public static Resultado avaliar(Perfil p, Candidata c) {
        List<String> motivos = new ArrayList<>();
        List<String> atencao = new ArrayList<>();
        int pontos = 0;

        // Faixa etária (eliminatória quando a instituição informa a faixa e a idade é conhecida)
        if (p.idade() != null && (c.idadeMinima() != null || c.idadeMaxima() != null)) {
            boolean dentro = (c.idadeMinima() == null || p.idade() >= c.idadeMinima())
                    && (c.idadeMaxima() == null || p.idade() <= c.idadeMaxima());
            if (!dentro) return null;
            pontos += 20;
            motivos.add("Atende a faixa etária (" + faixa(c) + ").");
        } else if (p.idade() != null) {
            atencao.add("A instituição não informou a faixa etária atendida.");
        }

        // Gratuidade (eliminatória quando o perfil pede somente serviços gratuitos)
        if (p.somenteGratuito()) {
            if (!c.gratuito() && !c.atendePeloSus()) return null;
            pontos += 10;
            motivos.add(c.atendePeloSus() ? "Atendimento pelo SUS, sem custo." : "Oferece atendimento gratuito.");
        } else if (c.gratuito() || c.atendePeloSus()) {
            pontos += 4;
            motivos.add(c.atendePeloSus() ? "Atende pelo SUS." : "Tem atendimento gratuito.");
        }

        // Condições atendidas
        if (!vazio(p.condicoes())) {
            List<String> comuns = p.condicoes().stream().filter(c.condicoes()::contains).toList();
            if (!comuns.isEmpty()) {
                pontos += 30;
                motivos.add("Atende " + rotulos(comuns, Codigos.CONDICOES) + ".");
            } else if (vazio(c.condicoes())) {
                atencao.add("A instituição não informou quais condições atende.");
            } else {
                atencao.add("A instituição não cita as condições informadas no perfil.");
            }
        }

        // Localização
        if (temTexto(p.municipio()) && mesmo(p.municipio(), c.municipio()) && (!temTexto(p.uf()) || mesmo(p.uf(), c.uf()))) {
            pontos += 15;
            motivos.add("Fica em " + c.municipio() + "/" + c.uf() + ", o mesmo município informado.");
        } else if (temTexto(p.uf()) && mesmo(p.uf(), c.uf())) {
            pontos += 5;
            motivos.add("Fica no mesmo estado (" + c.uf() + ").");
        }

        // Tipo de serviço desejado
        if (!vazio(p.tiposServico())) {
            List<String> comuns = p.tiposServico().stream().filter(c.tiposServico()::contains).toList();
            if (!comuns.isEmpty()) {
                pontos += 10;
                motivos.add("Oferece o serviço procurado (" + String.join(", ", comuns.stream().map(MotorCorrespondencia::legivel).toList()) + ").");
            }
        }

        // Modalidade
        if (temTexto(p.modalidadePreferida()) && !"SEM_PREFERENCIA".equals(p.modalidadePreferida())
                && c.modalidades().contains(p.modalidadePreferida())) {
            pontos += 5;
            motivos.add("Tem atendimento " + Codigos.rotulo(Codigos.MODALIDADES, p.modalidadePreferida()).toLowerCase(Locale.ROOT) + ".");
        }

        // Acessibilidade declarada
        if (!vazio(p.acessibilidade())) {
            List<String> comuns = p.acessibilidade().stream().filter(c.acessibilidade()::contains).toList();
            if (!comuns.isEmpty()) {
                pontos += Math.min(10, 4 * comuns.size());
                motivos.add("Oferece " + rotulos(comuns, Codigos.ACESSIBILIDADE).toLowerCase(Locale.ROOT) + ".");
            }
        }

        // Comunicação preferida por escrito
        if ("ESCRITA".equals(p.comunicacaoPreferida()) && c.acessibilidade().contains("COMUNICACAO_ESCRITA")
                && (vazio(p.acessibilidade()) || !p.acessibilidade().contains("COMUNICACAO_ESCRITA"))) {
            pontos += 5;
            motivos.add("Aceita contato por mensagem escrita, como preferido no perfil.");
        }
        if ("COMUNICACAO_ALTERNATIVA".equals(p.comunicacaoPreferida()) && c.acessibilidade().contains("COMUNICACAO_ALTERNATIVA")
                && (vazio(p.acessibilidade()) || !p.acessibilidade().contains("COMUNICACAO_ALTERNATIVA"))) {
            pontos += 5;
            motivos.add("Trabalha com comunicação alternativa, como indicado no perfil.");
        }

        // Sensibilidades sensoriais x ambiente
        if (!vazio(p.sensorial()) && !p.sensorial().equals(Set.of("BUSCA_ESTIMULO_SENSORIAL"))
                && (c.acessibilidade().contains("BAIXO_ESTIMULO") || c.acessibilidade().contains("SALA_SENSORIAL"))
                && (vazio(p.acessibilidade()) || (!p.acessibilidade().contains("BAIXO_ESTIMULO") && !p.acessibilidade().contains("SALA_SENSORIAL")))) {
            pontos += 5;
            motivos.add("Tem ambiente preparado para sensibilidades sensoriais.");
        }

        // Disponibilidade
        if (c.vagas() != null) {
            if (c.vagas() > 0) {
                pontos += 5;
                motivos.add("Informou " + c.vagas() + (c.vagas() == 1 ? " vaga disponível." : " vagas disponíveis."));
            } else {
                atencao.add("Sem vagas no momento: é possível pedir para entrar na lista de espera.");
            }
        }
        if (!c.aceitaSolicitacoes()) {
            atencao.add("A instituição não está recebendo solicitações pela plataforma no momento.");
        }
        if (c.verificada()) {
            pontos += 3;
            motivos.add("Cadastro conferido pela equipe EcoConect.");
        } else {
            atencao.add("Cadastro ainda não conferido pela equipe EcoConect.");
        }

        return new Resultado(c.id(), c.nome(), Math.min(100, pontos), motivos, atencao);
    }

    public static int idade(java.time.LocalDate nascimento, java.time.LocalDate hoje) {
        return nascimento == null ? -1 : java.time.Period.between(nascimento, hoje).getYears();
    }

    private static String faixa(Candidata c) {
        if (c.idadeMinima() != null && c.idadeMaxima() != null) return c.idadeMinima() + " a " + c.idadeMaxima() + " anos";
        if (c.idadeMinima() != null) return "a partir de " + c.idadeMinima() + " anos";
        return "até " + c.idadeMaxima() + " anos";
    }

    private static String rotulos(List<String> codigos, java.util.Map<String, String> voc) {
        List<String> r = codigos.stream().map(x -> Codigos.rotulo(voc, x)).toList();
        if (r.size() == 1) return r.get(0);
        return String.join(", ", r.subList(0, r.size() - 1)) + " e " + r.get(r.size() - 1);
    }

    private static String legivel(String codigo) {
        String s = codigo.replace('_', ' ').toLowerCase(Locale.ROOT);
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private static boolean vazio(Set<String> s) {
        return s == null || s.isEmpty();
    }

    private static boolean temTexto(String s) {
        return s != null && !s.isBlank();
    }

    static boolean mesmo(String a, String b) {
        return a != null && b != null && semAcento(a).equalsIgnoreCase(semAcento(b));
    }

    public static String semAcento(String s) {
        return Normalizer.normalize(s.trim(), Normalizer.Form.NFD).replaceAll("\\p{M}", "");
    }
}
