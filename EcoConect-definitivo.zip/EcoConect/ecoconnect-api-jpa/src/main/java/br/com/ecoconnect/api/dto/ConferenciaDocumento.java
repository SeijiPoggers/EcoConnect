package br.com.ecoconnect.api.dto;

import br.com.ecoconnect.api.model.enums.SituacaoConferencia;
import jakarta.validation.constraints.NotNull;

/** Conferência do documento pela equipe: CONFERIDO ou REJEITADO. */
public record ConferenciaDocumento(
        @NotNull(message = "campo obrigatório") SituacaoConferencia situacaoValidacao,
        @NotNull(message = "campo obrigatório") Long idUsuario) {
}
