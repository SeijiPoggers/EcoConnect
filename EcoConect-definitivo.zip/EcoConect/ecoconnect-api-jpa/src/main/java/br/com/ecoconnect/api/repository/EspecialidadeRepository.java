package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.Especialidade;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `especialidade` (Spring Data JPA). */
public interface EspecialidadeRepository extends JpaRepository<Especialidade, Integer> {
}
