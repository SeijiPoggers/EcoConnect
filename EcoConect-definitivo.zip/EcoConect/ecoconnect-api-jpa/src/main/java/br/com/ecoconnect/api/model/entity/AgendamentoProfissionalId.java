package br.com.ecoconnect.api.model.entity;

import java.io.Serializable;
import java.util.Objects;

/** Chave primária composta de `agendamento_profissional`: (id_agendamento, id_profissional). */
public class AgendamentoProfissionalId implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long idAgendamento;
    private Long idProfissional;

    public AgendamentoProfissionalId() {
    }

    public AgendamentoProfissionalId(Long idAgendamento, Long idProfissional) {
        this.idAgendamento = idAgendamento;
        this.idProfissional = idProfissional;
    }

    public Long getIdAgendamento() {
        return idAgendamento;
    }

    public void setIdAgendamento(Long idAgendamento) {
        this.idAgendamento = idAgendamento;
    }

    public Long getIdProfissional() {
        return idProfissional;
    }

    public void setIdProfissional(Long idProfissional) {
        this.idProfissional = idProfissional;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AgendamentoProfissionalId outro)) return false;
        return Objects.equals(idAgendamento, outro.idAgendamento) && Objects.equals(idProfissional, outro.idProfissional);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAgendamento, idProfissional);
    }

    @Override
    public String toString() {
        return "idAgendamento=" + idAgendamento + ","
                + "idProfissional=" + idProfissional;
    }
}
