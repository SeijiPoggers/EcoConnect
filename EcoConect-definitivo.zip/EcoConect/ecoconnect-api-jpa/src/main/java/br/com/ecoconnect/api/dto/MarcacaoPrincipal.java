package br.com.ecoconnect.api.dto;

import jakarta.validation.constraints.NotNull;

public record MarcacaoPrincipal(@NotNull(message = "campo obrigatório") Boolean principal) {
}
