package br.com.ecoconnect.api.model.entity;

import br.com.ecoconnect.api.model.enums.SituacaoObjetivo;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Tabela `objetivo` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 * CHECK chk_obj_data: ((data_prevista_fim is null) or (data_prevista_fim >= data_inicio))
 */
@Entity
@Table(name = "objetivo")
public class Objetivo implements Entidade<Long>, PertenceACrianca {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_objetivo", nullable = false)
    private Long idObjetivo;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_crianca", nullable = false)
    private Long idCrianca;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_profissional_definidor", nullable = false)
    private Long idProfissionalDefinidor;

    @NotBlank(message = "campo obrigatório")
    @Size(max = 150)
    @Column(name = "titulo", nullable = false, length = 150)
    private String titulo;

    @Column(name = "descricao", columnDefinition = "text")
    private String descricao;

    @NotNull(message = "campo obrigatório")
    @Column(name = "data_inicio", nullable = false)
    private LocalDate dataInicio;

    @Column(name = "data_prevista_fim")
    private LocalDate dataPrevistaFim;

    @Column(name = "data_encerramento")
    private LocalDate dataEncerramento;

    @Enumerated(EnumType.STRING)
    @Column(name = "situacao", nullable = false)
    private SituacaoObjetivo situacao;

    @Column(name = "data_cadastro", nullable = false)
    private LocalDateTime dataCadastro;

    @PrePersist
    void aoInserir() {
        if (situacao == null) {
            situacao = SituacaoObjetivo.EM_ANDAMENTO;
        }
        if (dataCadastro == null) {
            dataCadastro = LocalDateTime.now();
        }
    }

    public Long getIdObjetivo() {
        return idObjetivo;
    }

    public void setIdObjetivo(Long idObjetivo) {
        this.idObjetivo = idObjetivo;
    }

    public Long getIdCrianca() {
        return idCrianca;
    }

    public void setIdCrianca(Long idCrianca) {
        this.idCrianca = idCrianca;
    }

    public Long getIdProfissionalDefinidor() {
        return idProfissionalDefinidor;
    }

    public void setIdProfissionalDefinidor(Long idProfissionalDefinidor) {
        this.idProfissionalDefinidor = idProfissionalDefinidor;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public LocalDate getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(LocalDate dataInicio) {
        this.dataInicio = dataInicio;
    }

    public LocalDate getDataPrevistaFim() {
        return dataPrevistaFim;
    }

    public void setDataPrevistaFim(LocalDate dataPrevistaFim) {
        this.dataPrevistaFim = dataPrevistaFim;
    }

    public LocalDate getDataEncerramento() {
        return dataEncerramento;
    }

    public void setDataEncerramento(LocalDate dataEncerramento) {
        this.dataEncerramento = dataEncerramento;
    }

    public SituacaoObjetivo getSituacao() {
        return situacao;
    }

    public void setSituacao(SituacaoObjetivo situacao) {
        this.situacao = situacao;
    }

    public LocalDateTime getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(LocalDateTime dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    @Override
    public Long chave() {
        return idObjetivo;
    }

    @Override
    public void definirChave(Long id) {
        this.idObjetivo = id;
    }
}
