package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.Mensagem;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MensagemRepository extends JpaRepository<Mensagem, Long> {

    List<Mensagem> findByIdConversaOrderByDataEnvioAsc(Long idConversa);

}
