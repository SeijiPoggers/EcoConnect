package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.Diagnostico;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `diagnostico` (Spring Data JPA). */
public interface DiagnosticoRepository extends JpaRepository<Diagnostico, Long> {
}
