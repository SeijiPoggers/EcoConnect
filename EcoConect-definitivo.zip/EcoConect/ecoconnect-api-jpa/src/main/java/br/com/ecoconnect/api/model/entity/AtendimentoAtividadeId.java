package br.com.ecoconnect.api.model.entity;

import java.io.Serializable;
import java.util.Objects;

/** Chave primária composta de `atendimento_atividade`: (id_atendimento, id_atividade). */
public class AtendimentoAtividadeId implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long idAtendimento;
    private Integer idAtividade;

    public AtendimentoAtividadeId() {
    }

    public AtendimentoAtividadeId(Long idAtendimento, Integer idAtividade) {
        this.idAtendimento = idAtendimento;
        this.idAtividade = idAtividade;
    }

    public Long getIdAtendimento() {
        return idAtendimento;
    }

    public void setIdAtendimento(Long idAtendimento) {
        this.idAtendimento = idAtendimento;
    }

    public Integer getIdAtividade() {
        return idAtividade;
    }

    public void setIdAtividade(Integer idAtividade) {
        this.idAtividade = idAtividade;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AtendimentoAtividadeId outro)) return false;
        return Objects.equals(idAtendimento, outro.idAtendimento) && Objects.equals(idAtividade, outro.idAtividade);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAtendimento, idAtividade);
    }

    @Override
    public String toString() {
        return "idAtendimento=" + idAtendimento + ","
                + "idAtividade=" + idAtividade;
    }
}
