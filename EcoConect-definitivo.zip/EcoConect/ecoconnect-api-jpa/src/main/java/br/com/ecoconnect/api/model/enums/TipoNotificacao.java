package br.com.ecoconnect.api.model.enums;

/** Tipo de notificação. Valores idênticos ao ENUM do MySQL. */
public enum TipoNotificacao {
    AGENDAMENTO, RELATORIO_LIBERADO, COMUNICADO, FILA_ESPERA, OUTRO,
    /** V2: nova mensagem em uma conversa. */
    MENSAGEM,
    /** V2: solicitação de atendimento enviada a uma instituição ou respondida por ela. */
    SOLICITACAO
}
