package br.com.ecoconnect.api.service.catalogo;

import br.com.ecoconnect.api.model.entity.CondicaoSaude;
import br.com.ecoconnect.api.repository.CondicaoSaudeRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;

/** Condições de saúde reutilizáveis (catálogo). DELETE apenas desativa (ativo = 0). */
@Service
public class CondicaoSaudeService extends CrudService<CondicaoSaude, Long> {

    public CondicaoSaudeService(CondicaoSaudeRepository repository, AuditoriaService auditoria) {
        super(repository, auditoria, "condicao_saude");
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.LOGICA;
    }

    @Override
    protected void aplicarExclusaoLogica(CondicaoSaude e) {
        e.setAtivo(false);
    }
}
