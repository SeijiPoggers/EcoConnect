package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;

/** Tabela `perfil_necessidades` (migration V2/V3). Gerada no mesmo padrão das entidades originais. */
@Entity
@Table(name = "perfil_necessidades")
public class PerfilNecessidades implements Entidade<Long>, PertenceACrianca {

    @Id
    @Column(name = "id_crianca", nullable = false)
    private Long idCrianca;

    @Size(max = 255)
    @Column(name = "condicoes_informadas", length = 255)
    private String condicoesInformadas;

    @Size(max = 500)
    @Column(name = "necessidades_acompanhamento", length = 500)
    private String necessidadesAcompanhamento;

    @Size(max = 255)
    @Column(name = "preferencias_sensoriais", length = 255)
    private String preferenciasSensoriais;

    @Size(max = 500)
    @Column(name = "observacoes_sensoriais", length = 500)
    private String observacoesSensoriais;

    @Size(max = 30)
    @Column(name = "comunicacao_preferida", length = 30)
    private String comunicacaoPreferida;

    @Size(max = 255)
    @Column(name = "necessidades_acessibilidade", length = 255)
    private String necessidadesAcessibilidade;

    @Column(name = "observacoes_acompanhamento", columnDefinition = "TEXT")
    private String observacoesAcompanhamento;

    @Size(max = 80)
    @Column(name = "municipio", length = 80)
    private String municipio;

    @Size(max = 2)
    @Column(name = "uf", length = 2)
    private String uf;

    @Column(name = "somente_gratuito")
    private Boolean somenteGratuito;

    @Size(max = 20)
    @Column(name = "modalidade_preferida", length = 20)
    private String modalidadePreferida;

    @Column(name = "id_usuario_atualizacao", nullable = false)
    private Long idUsuarioAtualizacao;

    @Column(name = "data_atualizacao")
    private LocalDateTime dataAtualizacao;

    @PrePersist
    void aoInserir() {
        if (comunicacaoPreferida == null) comunicacaoPreferida = "SEM_PREFERENCIA";
        if (somenteGratuito == null) somenteGratuito = Boolean.FALSE;
        if (modalidadePreferida == null) modalidadePreferida = "SEM_PREFERENCIA";
        if (dataAtualizacao == null) dataAtualizacao = LocalDateTime.now();
    }

    @PreUpdate
    void aoAtualizar() {
        dataAtualizacao = LocalDateTime.now();
    }

    @Override
    public Long chave() {
        return idCrianca;
    }

    @Override
    public void definirChave(Long id) {
        this.idCrianca = id;
    }

    public Long getIdCrianca() {
        return idCrianca;
    }

    public void setIdCrianca(Long idCrianca) {
        this.idCrianca = idCrianca;
    }

    public String getCondicoesInformadas() {
        return condicoesInformadas;
    }

    public void setCondicoesInformadas(String condicoesInformadas) {
        this.condicoesInformadas = condicoesInformadas;
    }

    public String getNecessidadesAcompanhamento() {
        return necessidadesAcompanhamento;
    }

    public void setNecessidadesAcompanhamento(String necessidadesAcompanhamento) {
        this.necessidadesAcompanhamento = necessidadesAcompanhamento;
    }

    public String getPreferenciasSensoriais() {
        return preferenciasSensoriais;
    }

    public void setPreferenciasSensoriais(String preferenciasSensoriais) {
        this.preferenciasSensoriais = preferenciasSensoriais;
    }

    public String getObservacoesSensoriais() {
        return observacoesSensoriais;
    }

    public void setObservacoesSensoriais(String observacoesSensoriais) {
        this.observacoesSensoriais = observacoesSensoriais;
    }

    public String getComunicacaoPreferida() {
        return comunicacaoPreferida;
    }

    public void setComunicacaoPreferida(String comunicacaoPreferida) {
        this.comunicacaoPreferida = comunicacaoPreferida;
    }

    public String getNecessidadesAcessibilidade() {
        return necessidadesAcessibilidade;
    }

    public void setNecessidadesAcessibilidade(String necessidadesAcessibilidade) {
        this.necessidadesAcessibilidade = necessidadesAcessibilidade;
    }

    public String getObservacoesAcompanhamento() {
        return observacoesAcompanhamento;
    }

    public void setObservacoesAcompanhamento(String observacoesAcompanhamento) {
        this.observacoesAcompanhamento = observacoesAcompanhamento;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public Boolean getSomenteGratuito() {
        return somenteGratuito;
    }

    public void setSomenteGratuito(Boolean somenteGratuito) {
        this.somenteGratuito = somenteGratuito;
    }

    public String getModalidadePreferida() {
        return modalidadePreferida;
    }

    public void setModalidadePreferida(String modalidadePreferida) {
        this.modalidadePreferida = modalidadePreferida;
    }

    public Long getIdUsuarioAtualizacao() {
        return idUsuarioAtualizacao;
    }

    public void setIdUsuarioAtualizacao(Long idUsuarioAtualizacao) {
        this.idUsuarioAtualizacao = idUsuarioAtualizacao;
    }

    public LocalDateTime getDataAtualizacao() {
        return dataAtualizacao;
    }

    public void setDataAtualizacao(LocalDateTime dataAtualizacao) {
        this.dataAtualizacao = dataAtualizacao;
    }
}
