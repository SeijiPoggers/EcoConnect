package br.com.ecoconnect.api.service.app;

import br.com.ecoconnect.api.dominio.EscritorCsv;
import br.com.ecoconnect.api.exception.NaoAutorizadoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.seguranca.ContextoAtual;
import br.com.ecoconnect.api.seguranca.ContextoUsuario;
import br.com.ecoconnect.api.seguranca.EscopoAcesso;
import br.com.ecoconnect.api.service.AuditoriaService;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Relatórios exportados em CSV (abrem no Excel/LibreOffice), sempre gerados a partir dos dados
 * gravados e restritos ao escopo de quem pede. Toda exportação fica registrada na auditoria.
 */
@Service
public class RelatorioService {

    public record Arquivo(String nome, byte[] conteudo) {
    }

    private final Consultas consultas;
    private final EscopoAcesso escopo;
    private final AuditoriaService auditoria;

    public RelatorioService(Consultas consultas, EscopoAcesso escopo, AuditoriaService auditoria) {
        this.consultas = consultas;
        this.escopo = escopo;
        this.auditoria = auditoria;
    }

    /** Tipos disponíveis para o perfil (usado pela tela de relatórios). */
    public List<Map<String, Object>> disponiveis() {
        ContextoUsuario ctx = ContextoAtual.exigir();
        List<Map<String, Object>> r = new ArrayList<>();
        if (ctx.equipe()) {
            r.add(tipo("sessoes", "Sessões realizadas", "Data, pessoa, tipo de atendimento, profissionais, atividades e evolução registrada.", true));
            r.add(tipo("agendamentos", "Agendamentos", "Todos os agendamentos do período e a situação de cada um.", true));
            r.add(tipo("historico-pessoa", "Histórico de acompanhamento de uma pessoa", "Linha do tempo completa de uma pessoa (escolha a pessoa).", false));
        }
        r.add(tipo("solicitacoes", "Solicitações a instituições", "Solicitações de atendimento e as respostas das instituições.", true));
        if (ctx.administrador() || ctx.adminInstitucional()) {
            r.add(tipo("instituicoes", "Atividade das instituições", "Solicitações por situação, pessoas vinculadas e vagas.", false));
        }
        if (ctx.administrador()) {
            r.add(tipo("indicadores", "Indicadores administrativos (por mês)", "Cadastros, sessões, agendamentos e solicitações por mês.", true));
        }
        return r;
    }

    private static Map<String, Object> tipo(String codigo, String nome, String descricao, boolean periodo) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("codigo", codigo);
        m.put("nome", nome);
        m.put("descricao", descricao);
        m.put("usaPeriodo", periodo);
        return m;
    }

    @Transactional(readOnly = true)
    public Arquivo gerar(String tipo, LocalDate de, LocalDate ate, Long idCrianca) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        LocalDate inicio = de == null ? LocalDate.now().minusMonths(3) : de;
        LocalDate fim = ate == null ? LocalDate.now() : ate;
        if (fim.isBefore(inicio)) throw new RegraNegocioException("A data final deve ser depois da inicial.");
        if (inicio.plusYears(5).isBefore(fim)) throw new RegraNegocioException("Período máximo: 5 anos.");
        Arquivo a = switch (tipo == null ? "" : tipo) {
            case "sessoes" -> sessoes(ctx, inicio, fim, idCrianca);
            case "agendamentos" -> agendamentos(ctx, inicio, fim, idCrianca);
            case "historico-pessoa" -> historico(ctx, idCrianca);
            case "solicitacoes" -> solicitacoes(ctx, inicio, fim);
            case "instituicoes" -> instituicoes(ctx);
            case "indicadores" -> indicadores(ctx, inicio, fim);
            default -> throw new RegraNegocioException("Relatório desconhecido: " + tipo);
        };
        Map<String, Object> det = new LinkedHashMap<>();
        det.put("relatorio", tipo);
        det.put("de", inicio.toString());
        det.put("ate", fim.toString());
        if (idCrianca != null) det.put("idCrianca", idCrianca);
        auditoria.registrarDados(AcaoAuditoria.CONSULTA, "relatorio", tipo, idCrianca, null, det);
        return a;
    }

    private void exigirEquipe(ContextoUsuario ctx) {
        if (!ctx.equipe()) throw new NaoAutorizadoException(403, "Este relatório é da equipe de acompanhamento.");
    }

    /** Cláusula de escopo sobre agendamento a (administrador: tudo). */
    private String escopoAgendamento(List<Object> args) {
        if (escopo.irrestrito()) return "";
        List<Long> ids = new ArrayList<>(escopo.criancas());
        args.addAll(ids);
        return " AND a.id_crianca IN (" + Consultas.marcadores(ids) + ")";
    }

    private Arquivo sessoes(ContextoUsuario ctx, LocalDate de, LocalDate ate, Long idCrianca) {
        exigirEquipe(ctx);
        List<Object> args = new ArrayList<>(List.of(de.atStartOfDay(), ate.plusDays(1).atStartOfDay()));
        String sql = "SELECT " + Consultas.dt("t.data_hora_inicio_real") + " AS inicio, c.nome_completo AS pessoa, rs.tipo_atendimento AS tipo, "
                + "(SELECT GROUP_CONCAT(u.nome_completo SEPARATOR ', ') FROM atendimento_profissional tp JOIN profissional p "
                + " ON p.id_profissional = tp.id_profissional JOIN usuario u ON u.id_usuario = p.id_usuario WHERE tp.id_atendimento = t.id_atendimento) AS profissionais, "
                + "(SELECT GROUP_CONCAT(at.nome SEPARATOR ', ') FROM atendimento_atividade aa JOIN atividade at ON at.id_atividade = aa.id_atividade "
                + " WHERE aa.id_atendimento = t.id_atendimento) AS atividades, rs.objetivos_trabalhados AS objetivos, rs.evolucao_observada AS evolucao, "
                + "rs.dificuldades_observadas AS dificuldades, rs.recomendacoes, rs.proximos_passos AS proximos, ur.nome_completo AS registradoPor "
                + "FROM atendimento t JOIN agendamento a ON a.id_agendamento = t.id_agendamento JOIN crianca c ON c.id_crianca = a.id_crianca "
                + "LEFT JOIN registro_sessao rs ON rs.id_atendimento = t.id_atendimento JOIN usuario ur ON ur.id_usuario = t.id_usuario_registro "
                + "WHERE t.data_hora_inicio_real >= ? AND t.data_hora_inicio_real < ?" + escopoAgendamento(args);
        if (idCrianca != null) {
            escopo.exigirCrianca(idCrianca);
            sql += " AND a.id_crianca = ?";
            args.add(idCrianca);
        }
        EscritorCsv csv = new EscritorCsv().linha("Data e hora", "Pessoa", "Tipo de atendimento", "Profissionais", "Atividades",
                "Objetivos trabalhados", "Evolução observada", "Dificuldades observadas", "Recomendações", "Próximos passos", "Registrado por");
        for (Map<String, Object> l : consultas.lista(sql + " ORDER BY t.data_hora_inicio_real", args.toArray())) {
            csv.linha(l.get("inicio"), l.get("pessoa"), l.get("tipo"), l.get("profissionais"), l.get("atividades"), l.get("objetivos"),
                    l.get("evolucao"), l.get("dificuldades"), l.get("recomendacoes"), l.get("proximos"), l.get("registradoPor"));
        }
        return new Arquivo("sessoes_" + de + "_" + ate + ".csv", csv.bytes());
    }

    private Arquivo agendamentos(ContextoUsuario ctx, LocalDate de, LocalDate ate, Long idCrianca) {
        exigirEquipe(ctx);
        List<Object> args = new ArrayList<>(List.of(de.atStartOfDay(), ate.plusDays(1).atStartOfDay()));
        String sql = "SELECT " + Consultas.dt("COALESCE(a.data_hora_inicio, a.data_hora_inicio_solicitada)") + " AS inicio, c.nome_completo AS pessoa, "
                + "a.status, (SELECT GROUP_CONCAT(u.nome_completo SEPARATOR ', ') FROM agendamento_profissional ap JOIN profissional p "
                + " ON p.id_profissional = ap.id_profissional JOIN usuario u ON u.id_usuario = p.id_usuario WHERE ap.id_agendamento = a.id_agendamento) AS profissionais, "
                + "us.nome_completo AS solicitante, " + Consultas.dt("a.data_solicitacao") + " AS solicitadoEm, a.observacao_solicitacao AS observacao "
                + "FROM agendamento a JOIN crianca c ON c.id_crianca = a.id_crianca JOIN usuario us ON us.id_usuario = a.id_usuario_solicitante "
                + "WHERE COALESCE(a.data_hora_inicio, a.data_hora_inicio_solicitada) >= ? AND COALESCE(a.data_hora_inicio, a.data_hora_inicio_solicitada) < ?"
                + escopoAgendamento(args);
        if (idCrianca != null) {
            escopo.exigirCrianca(idCrianca);
            sql += " AND a.id_crianca = ?";
            args.add(idCrianca);
        }
        EscritorCsv csv = new EscritorCsv().linha("Data e hora", "Pessoa", "Situação", "Profissionais", "Solicitado por", "Solicitado em", "Observação");
        for (Map<String, Object> l : consultas.lista(sql + " ORDER BY inicio", args.toArray())) {
            csv.linha(l.get("inicio"), l.get("pessoa"), l.get("status"), l.get("profissionais"), l.get("solicitante"), l.get("solicitadoEm"),
                    l.get("observacao"));
        }
        return new Arquivo("agendamentos_" + de + "_" + ate + ".csv", csv.bytes());
    }

    private Arquivo historico(ContextoUsuario ctx, Long idCrianca) {
        exigirEquipe(ctx);
        if (idCrianca == null) throw new RegraNegocioException("Escolha a pessoa.");
        escopo.exigirCrianca(idCrianca);
        String nome = String.valueOf(consultas.um("SELECT nome_completo AS n FROM crianca WHERE id_crianca = ?", idCrianca).get("n"));
        EscritorCsv csv = new EscritorCsv().linha("Data", "Tipo de registro", "Título / situação", "Detalhes", "Responsável pelo registro");
        for (Map<String, Object> l : consultas.lista("SELECT " + Consultas.dt("COALESCE(a.data_hora_inicio, a.data_hora_inicio_solicitada)")
                + " AS data, 'Agendamento' AS tipo, a.status AS titulo, a.observacao_solicitacao AS detalhes, us.nome_completo AS autor "
                + "FROM agendamento a JOIN usuario us ON us.id_usuario = a.id_usuario_solicitante WHERE a.id_crianca = ? "
                + "UNION ALL SELECT " + Consultas.dt("t.data_hora_inicio_real") + ", 'Sessão', COALESCE(rs.tipo_atendimento, 'Sessão'), "
                + "CONCAT_WS(' | ', rs.objetivos_trabalhados, rs.evolucao_observada, rs.proximos_passos), u.nome_completo "
                + "FROM atendimento t JOIN agendamento a ON a.id_agendamento = t.id_agendamento LEFT JOIN registro_sessao rs ON rs.id_atendimento = t.id_atendimento "
                + "JOIN usuario u ON u.id_usuario = t.id_usuario_registro WHERE a.id_crianca = ? "
                + "UNION ALL SELECT " + Consultas.dt("h.data_evento") + ", 'Histórico de saúde', h.titulo, h.descricao, u.nome_completo "
                + "FROM historico_saude h JOIN usuario u ON u.id_usuario = h.id_usuario_registro WHERE h.id_crianca = ? AND h.situacao_registro = 'ATIVO' "
                + "UNION ALL SELECT " + Consultas.dt("av.data_avaliacao") + ", 'Avaliação de indicador', CONCAT(o.titulo, ' - ', i.nome), "
                + "COALESCE(av.valor_qualitativo, CAST(av.valor_numerico AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci), u.nome_completo FROM avaliacao_indicador av "
                + "JOIN objetivo o ON o.id_objetivo = av.id_objetivo JOIN indicador i ON i.id_indicador = av.id_indicador "
                + "JOIN profissional p ON p.id_profissional = av.id_profissional_avaliador JOIN usuario u ON u.id_usuario = p.id_usuario "
                + "WHERE o.id_crianca = ? AND av.situacao = 'VIGENTE' ORDER BY data", idCrianca, idCrianca, idCrianca, idCrianca)) {
            csv.linha(l.get("data"), l.get("tipo"), l.get("titulo"), l.get("detalhes"), l.get("autor"));
        }
        return new Arquivo("historico_" + nome.replaceAll("[^A-Za-z0-9]+", "_") + ".csv", csv.bytes());
    }

    private Arquivo solicitacoes(ContextoUsuario ctx, LocalDate de, LocalDate ate) {
        List<Object> args = new ArrayList<>(List.of(de.atStartOfDay(), ate.plusDays(1).atStartOfDay()));
        String filtro;
        if (ctx.administrador()) {
            filtro = "";
        } else if (ctx.adminInstitucional()) {
            List<Long> inst = new ArrayList<>(ctx.instituicoes());
            filtro = " AND s.id_instituicao IN (" + Consultas.marcadores(inst) + ")";
            args.addAll(inst);
        } else if (ctx.profissional()) {
            List<Long> pessoas = new ArrayList<>(escopo.criancas());
            filtro = " AND (s.id_usuario_solicitante = ? OR s.id_crianca IN (" + Consultas.marcadores(pessoas) + "))";
            args.add(ctx.idUsuario());
            args.addAll(pessoas);
        } else {
            throw new NaoAutorizadoException(403, "Relatório indisponível para o seu perfil.");
        }
        EscritorCsv csv = new EscritorCsv().linha("Enviada em", "Instituição", "Serviço", "Pessoa", "Solicitante", "Situação", "Resposta",
                "Respondida em");
        for (Map<String, Object> l : consultas.lista("SELECT " + Consultas.dt("s.data_criacao") + " AS data, i.nome AS instituicao, sv.nome AS servico, "
                + "c.nome_completo AS pessoa, us.nome_completo AS solicitante, s.situacao, s.resposta, " + Consultas.dt("s.data_resposta")
                + " AS respondida FROM solicitacao_atendimento s JOIN instituicao i ON i.id_instituicao = s.id_instituicao "
                + "LEFT JOIN instituicao_servico sv ON sv.id_servico = s.id_servico LEFT JOIN crianca c ON c.id_crianca = s.id_crianca "
                + "JOIN usuario us ON us.id_usuario = s.id_usuario_solicitante WHERE s.data_criacao >= ? AND s.data_criacao < ?" + filtro
                + " ORDER BY s.data_criacao", args.toArray())) {
            csv.linha(l.get("data"), l.get("instituicao"), l.get("servico"), l.get("pessoa"), l.get("solicitante"),
                    SolicitacaoService.rotulo(String.valueOf(l.get("situacao"))), l.get("resposta"), l.get("respondida"));
        }
        return new Arquivo("solicitacoes_" + de + "_" + ate + ".csv", csv.bytes());
    }

    private Arquivo instituicoes(ContextoUsuario ctx) {
        List<Object> args = new ArrayList<>();
        String filtro = "";
        if (ctx.adminInstitucional()) {
            List<Long> inst = new ArrayList<>(ctx.instituicoes());
            filtro = " WHERE i.id_instituicao IN (" + Consultas.marcadores(inst) + ")";
            args.addAll(inst);
        } else if (!ctx.administrador()) {
            throw new NaoAutorizadoException(403, "Relatório disponível para administradores.");
        }
        EscritorCsv csv = new EscritorCsv().linha("Instituição", "Tipo", "Município", "UF", "Ativa", "Verificada", "Vagas informadas",
                "Solicitações recebidas", "Pendentes", "Aceitas", "Recusadas", "Pessoas vinculadas");
        for (Map<String, Object> l : consultas.lista("SELECT i.nome, i.tipo, i.municipio, i.uf, i.ativa, i.verificada, i.vagas_disponiveis AS vagas, "
                + "(SELECT COUNT(*) FROM solicitacao_atendimento s WHERE s.id_instituicao = i.id_instituicao) AS recebidas, "
                + "(SELECT COUNT(*) FROM solicitacao_atendimento s WHERE s.id_instituicao = i.id_instituicao AND s.situacao IN ('ENVIADA','EM_ANALISE')) AS pendentes, "
                + "(SELECT COUNT(*) FROM solicitacao_atendimento s WHERE s.id_instituicao = i.id_instituicao AND s.situacao IN ('ACEITA','CONCLUIDA')) AS aceitas, "
                + "(SELECT COUNT(*) FROM solicitacao_atendimento s WHERE s.id_instituicao = i.id_instituicao AND s.situacao = 'RECUSADA') AS recusadas, "
                + "(SELECT COUNT(*) FROM crianca_instituicao ci WHERE ci.id_instituicao = i.id_instituicao AND ci.status = 'ATIVO') AS vinculos "
                + "FROM instituicao i" + filtro + " ORDER BY i.nome", args.toArray())) {
            csv.linha(l.get("nome"), RedeService.TIPOS_INSTITUICAO.getOrDefault(String.valueOf(l.get("tipo")), String.valueOf(l.get("tipo"))),
                    l.get("municipio"), l.get("uf"), RedeService.bool(l.get("ativa")), RedeService.bool(l.get("verificada")), l.get("vagas"),
                    l.get("recebidas"), l.get("pendentes"), l.get("aceitas"), l.get("recusadas"), l.get("vinculos"));
        }
        return new Arquivo("instituicoes.csv", csv.bytes());
    }

    private Arquivo indicadores(ContextoUsuario ctx, LocalDate de, LocalDate ate) {
        if (!ctx.administrador()) throw new NaoAutorizadoException(403, "Relatório disponível para administradores.");
        Object a = de.withDayOfMonth(1).atStartOfDay();
        Object b = ate.plusDays(1).atStartOfDay();
        Map<String, long[]> meses = new java.util.TreeMap<>();
        acumular(meses, 0, "SELECT DATE_FORMAT(data_cadastro, '%Y-%m') AS mes, COUNT(*) AS total FROM crianca WHERE data_cadastro >= ? AND data_cadastro < ? GROUP BY mes", a, b);
        acumular(meses, 1, "SELECT DATE_FORMAT(data_hora_inicio_real, '%Y-%m') AS mes, COUNT(*) AS total FROM atendimento WHERE data_hora_inicio_real >= ? AND data_hora_inicio_real < ? GROUP BY mes", a, b);
        acumular(meses, 2, "SELECT DATE_FORMAT(data_solicitacao, '%Y-%m') AS mes, COUNT(*) AS total FROM agendamento WHERE data_solicitacao >= ? AND data_solicitacao < ? GROUP BY mes", a, b);
        acumular(meses, 3, "SELECT DATE_FORMAT(data_solicitacao, '%Y-%m') AS mes, COUNT(*) AS total FROM agendamento WHERE status IN ('CANCELADO','AUSENTE') AND data_solicitacao >= ? AND data_solicitacao < ? GROUP BY mes", a, b);
        acumular(meses, 4, "SELECT DATE_FORMAT(data_criacao, '%Y-%m') AS mes, COUNT(*) AS total FROM solicitacao_atendimento WHERE data_criacao >= ? AND data_criacao < ? GROUP BY mes", a, b);
        acumular(meses, 5, "SELECT DATE_FORMAT(data_criacao, '%Y-%m') AS mes, COUNT(*) AS total FROM solicitacao_atendimento WHERE situacao IN ('ACEITA','CONCLUIDA') AND data_criacao >= ? AND data_criacao < ? GROUP BY mes", a, b);
        acumular(meses, 6, "SELECT DATE_FORMAT(data_cadastro, '%Y-%m') AS mes, COUNT(*) AS total FROM usuario WHERE data_cadastro >= ? AND data_cadastro < ? GROUP BY mes", a, b);
        EscritorCsv csv = new EscritorCsv().linha("Mês", "Pessoas cadastradas", "Sessões realizadas", "Agendamentos solicitados",
                "Agendamentos cancelados ou com ausência", "Solicitações a instituições", "Solicitações aceitas", "Novos usuários");
        for (Map.Entry<String, long[]> e : meses.entrySet()) {
            long[] v = e.getValue();
            csv.linha(e.getKey(), v[0], v[1], v[2], v[3], v[4], v[5], v[6]);
        }
        return new Arquivo("indicadores_" + de + "_" + ate + ".csv", csv.bytes());
    }

    private void acumular(Map<String, long[]> meses, int coluna, String sql, Object... args) {
        for (Map<String, Object> l : consultas.lista(sql, args)) {
            meses.computeIfAbsent(String.valueOf(l.get("mes")), k -> new long[7])[coluna] = ((Number) l.get("total")).longValue();
        }
    }
}
