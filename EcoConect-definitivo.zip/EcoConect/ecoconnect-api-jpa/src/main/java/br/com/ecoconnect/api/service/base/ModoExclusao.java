package br.com.ecoconnect.api.service.base;

/**
 * Como o DELETE da API se comporta em cada tabela (regra C.2 da modelagem):
 * FISICA   - apaga a linha (só catálogos e vínculos sem dados de saúde; o banco bloqueia se houver uso)
 * LOGICA   - marca como inativo/removido/cancelado, preservando o histórico
 * PROIBIDA - não há exclusão (dados de saúde, histórico, relatórios, auditoria)
 */
public enum ModoExclusao {
    FISICA, LOGICA, PROIBIDA
}
