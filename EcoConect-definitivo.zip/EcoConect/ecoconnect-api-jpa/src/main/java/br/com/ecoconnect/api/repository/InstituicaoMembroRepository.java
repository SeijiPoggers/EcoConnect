package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.InstituicaoMembro;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InstituicaoMembroRepository extends JpaRepository<InstituicaoMembro, Long> {

    List<InstituicaoMembro> findByIdUsuarioAndAtivoTrue(Long idUsuario);
    List<InstituicaoMembro> findByIdInstituicaoAndAtivoTrue(Long idInstituicao);
    List<InstituicaoMembro> findByIdInstituicao(Long idInstituicao);
    Optional<InstituicaoMembro> findByIdInstituicaoAndIdUsuario(Long idInstituicao, Long idUsuario);
    boolean existsByIdInstituicaoAndIdUsuarioAndAtivoTrue(Long idInstituicao, Long idUsuario);

}
