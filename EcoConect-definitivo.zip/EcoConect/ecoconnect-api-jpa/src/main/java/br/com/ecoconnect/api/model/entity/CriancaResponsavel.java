package br.com.ecoconnect.api.model.entity;

import br.com.ecoconnect.api.model.enums.StatusVinculo;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;

/**
 * Tabela `crianca_responsavel` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 */
@Entity
@Table(name = "crianca_responsavel")
public class CriancaResponsavel implements Entidade<Long>, PertenceACrianca {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_crianca_responsavel", nullable = false)
    private Long idCriancaResponsavel;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_crianca", nullable = false)
    private Long idCrianca;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_responsavel", nullable = false)
    private Long idResponsavel;

    @NotBlank(message = "campo obrigatório")
    @Size(max = 50)
    @Column(name = "parentesco", nullable = false, length = 50)
    private String parentesco;

    @Column(name = "responsavel_principal", nullable = false)
    private Boolean responsavelPrincipal;

    @Column(name = "pode_consultar_dados", nullable = false)
    private Boolean podeConsultarDados;

    @Column(name = "pode_solicitar_agendamento", nullable = false)
    private Boolean podeSolicitarAgendamento;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private StatusVinculo status;

    @Column(name = "data_inicio", nullable = false)
    private LocalDate dataInicio;

    @Column(name = "data_fim")
    private LocalDate dataFim;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_usuario_cadastro", nullable = false)
    private Long idUsuarioCadastro;

    @PrePersist
    void aoInserir() {
        if (responsavelPrincipal == null) {
            responsavelPrincipal = Boolean.FALSE;
        }
        if (podeConsultarDados == null) {
            podeConsultarDados = Boolean.TRUE;
        }
        if (podeSolicitarAgendamento == null) {
            podeSolicitarAgendamento = Boolean.TRUE;
        }
        if (status == null) {
            status = StatusVinculo.ATIVO;
        }
    }

    public Long getIdCriancaResponsavel() {
        return idCriancaResponsavel;
    }

    public void setIdCriancaResponsavel(Long idCriancaResponsavel) {
        this.idCriancaResponsavel = idCriancaResponsavel;
    }

    public Long getIdCrianca() {
        return idCrianca;
    }

    public void setIdCrianca(Long idCrianca) {
        this.idCrianca = idCrianca;
    }

    public Long getIdResponsavel() {
        return idResponsavel;
    }

    public void setIdResponsavel(Long idResponsavel) {
        this.idResponsavel = idResponsavel;
    }

    public String getParentesco() {
        return parentesco;
    }

    public void setParentesco(String parentesco) {
        this.parentesco = parentesco;
    }

    public Boolean getResponsavelPrincipal() {
        return responsavelPrincipal;
    }

    public void setResponsavelPrincipal(Boolean responsavelPrincipal) {
        this.responsavelPrincipal = responsavelPrincipal;
    }

    public Boolean getPodeConsultarDados() {
        return podeConsultarDados;
    }

    public void setPodeConsultarDados(Boolean podeConsultarDados) {
        this.podeConsultarDados = podeConsultarDados;
    }

    public Boolean getPodeSolicitarAgendamento() {
        return podeSolicitarAgendamento;
    }

    public void setPodeSolicitarAgendamento(Boolean podeSolicitarAgendamento) {
        this.podeSolicitarAgendamento = podeSolicitarAgendamento;
    }

    public StatusVinculo getStatus() {
        return status;
    }

    public void setStatus(StatusVinculo status) {
        this.status = status;
    }

    public LocalDate getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(LocalDate dataInicio) {
        this.dataInicio = dataInicio;
    }

    public LocalDate getDataFim() {
        return dataFim;
    }

    public void setDataFim(LocalDate dataFim) {
        this.dataFim = dataFim;
    }

    public Long getIdUsuarioCadastro() {
        return idUsuarioCadastro;
    }

    public void setIdUsuarioCadastro(Long idUsuarioCadastro) {
        this.idUsuarioCadastro = idUsuarioCadastro;
    }

    @Override
    public Long chave() {
        return idCriancaResponsavel;
    }

    @Override
    public void definirChave(Long id) {
        this.idCriancaResponsavel = id;
    }
}
