package br.com.ecoconnect.api.dto;

import org.springframework.data.domain.Page;

import java.util.List;

/** Resposta paginada das listagens: ?page=0&size=20&sort=campo,desc */
public record Pagina<T>(
        List<T> conteudo,
        int pagina,
        int tamanho,
        long totalElementos,
        int totalPaginas) {

    public static <T> Pagina<T> de(Page<T> page) {
        return new Pagina<>(page.getContent(), page.getNumber(), page.getSize(),
                page.getTotalElements(), page.getTotalPages());
    }
}
