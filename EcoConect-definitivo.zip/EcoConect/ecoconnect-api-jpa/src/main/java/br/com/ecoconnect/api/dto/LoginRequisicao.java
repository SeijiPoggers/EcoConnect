package br.com.ecoconnect.api.dto;

import jakarta.validation.constraints.NotBlank;

public record LoginRequisicao(
        @NotBlank(message = "campo obrigatório") String email,
        @NotBlank(message = "campo obrigatório") String senha) {
}
