package br.com.ecoconnect.api.model.entity;

import br.com.ecoconnect.api.model.enums.OrigemInformacao;
import br.com.ecoconnect.api.model.enums.PrecisaoData;
import br.com.ecoconnect.api.model.enums.SituacaoRegistro;
import br.com.ecoconnect.api.model.enums.SituacaoValidacao;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Tabela `historico_saude` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 * CHECK historico_saude_chk_1: ((data_evento_fim is null) or (data_evento_fim >= data_evento))
 * CHECK historico_saude_chk_2: ((situacao_validacao <> 'VALIDADO') or ((id_usuario_validacao is not null) and (data_validacao is not null)))
 */
@Entity
@Table(name = "historico_saude")
public class HistoricoSaude implements Entidade<Long>, RegistroDeSaude {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_historico_saude", nullable = false)
    private Long idHistoricoSaude;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_crianca", nullable = false)
    private Long idCrianca;

    @NotBlank(message = "campo obrigatório")
    @Size(max = 50)
    @Column(name = "tipo_evento", nullable = false, length = 50)
    private String tipoEvento;

    @NotBlank(message = "campo obrigatório")
    @Size(max = 150)
    @Column(name = "titulo", nullable = false, length = 150)
    private String titulo;

    @Column(name = "descricao", columnDefinition = "text")
    private String descricao;

    @NotNull(message = "campo obrigatório")
    @Column(name = "data_evento", nullable = false)
    private LocalDate dataEvento;

    @Column(name = "data_evento_fim")
    private LocalDate dataEventoFim;

    @Enumerated(EnumType.STRING)
    @Column(name = "precisao_data", nullable = false)
    private PrecisaoData precisaoData;

    @Size(max = 150)
    @Column(name = "instituicao_origem", length = 150)
    private String instituicaoOrigem;

    @Column(name = "id_crianca_diagnostico")
    private Long idCriancaDiagnostico;

    @Column(name = "id_documento")
    private Long idDocumento;

    @NotNull(message = "campo obrigatório")
    @Enumerated(EnumType.STRING)
    @Column(name = "origem_informacao", nullable = false)
    private OrigemInformacao origemInformacao;

    @Enumerated(EnumType.STRING)
    @Column(name = "situacao_validacao", nullable = false)
    private SituacaoValidacao situacaoValidacao;

    @Enumerated(EnumType.STRING)
    @Column(name = "situacao_registro", nullable = false)
    private SituacaoRegistro situacaoRegistro;

    @Column(name = "id_historico_saude_substituido")
    private Long idHistoricoSaudeSubstituido;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_usuario_registro", nullable = false)
    private Long idUsuarioRegistro;

    @Column(name = "data_registro", nullable = false)
    private LocalDateTime dataRegistro;

    @Column(name = "id_usuario_validacao")
    private Long idUsuarioValidacao;

    @Column(name = "data_validacao")
    private LocalDateTime dataValidacao;

    @PrePersist
    void aoInserir() {
        if (precisaoData == null) {
            precisaoData = PrecisaoData.DIA;
        }
        if (situacaoValidacao == null) {
            situacaoValidacao = SituacaoValidacao.DECLARADO;
        }
        if (situacaoRegistro == null) {
            situacaoRegistro = SituacaoRegistro.ATIVO;
        }
        if (dataRegistro == null) {
            dataRegistro = LocalDateTime.now();
        }
    }

    public Long getIdHistoricoSaude() {
        return idHistoricoSaude;
    }

    public void setIdHistoricoSaude(Long idHistoricoSaude) {
        this.idHistoricoSaude = idHistoricoSaude;
    }

    public Long getIdCrianca() {
        return idCrianca;
    }

    public void setIdCrianca(Long idCrianca) {
        this.idCrianca = idCrianca;
    }

    public String getTipoEvento() {
        return tipoEvento;
    }

    public void setTipoEvento(String tipoEvento) {
        this.tipoEvento = tipoEvento;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public LocalDate getDataEvento() {
        return dataEvento;
    }

    public void setDataEvento(LocalDate dataEvento) {
        this.dataEvento = dataEvento;
    }

    public LocalDate getDataEventoFim() {
        return dataEventoFim;
    }

    public void setDataEventoFim(LocalDate dataEventoFim) {
        this.dataEventoFim = dataEventoFim;
    }

    public PrecisaoData getPrecisaoData() {
        return precisaoData;
    }

    public void setPrecisaoData(PrecisaoData precisaoData) {
        this.precisaoData = precisaoData;
    }

    public String getInstituicaoOrigem() {
        return instituicaoOrigem;
    }

    public void setInstituicaoOrigem(String instituicaoOrigem) {
        this.instituicaoOrigem = instituicaoOrigem;
    }

    public Long getIdCriancaDiagnostico() {
        return idCriancaDiagnostico;
    }

    public void setIdCriancaDiagnostico(Long idCriancaDiagnostico) {
        this.idCriancaDiagnostico = idCriancaDiagnostico;
    }

    public Long getIdDocumento() {
        return idDocumento;
    }

    public void setIdDocumento(Long idDocumento) {
        this.idDocumento = idDocumento;
    }

    public OrigemInformacao getOrigemInformacao() {
        return origemInformacao;
    }

    public void setOrigemInformacao(OrigemInformacao origemInformacao) {
        this.origemInformacao = origemInformacao;
    }

    public SituacaoValidacao getSituacaoValidacao() {
        return situacaoValidacao;
    }

    public void setSituacaoValidacao(SituacaoValidacao situacaoValidacao) {
        this.situacaoValidacao = situacaoValidacao;
    }

    public SituacaoRegistro getSituacaoRegistro() {
        return situacaoRegistro;
    }

    public void setSituacaoRegistro(SituacaoRegistro situacaoRegistro) {
        this.situacaoRegistro = situacaoRegistro;
    }

    public Long getIdHistoricoSaudeSubstituido() {
        return idHistoricoSaudeSubstituido;
    }

    public void setIdHistoricoSaudeSubstituido(Long idHistoricoSaudeSubstituido) {
        this.idHistoricoSaudeSubstituido = idHistoricoSaudeSubstituido;
    }

    public Long getIdUsuarioRegistro() {
        return idUsuarioRegistro;
    }

    public void setIdUsuarioRegistro(Long idUsuarioRegistro) {
        this.idUsuarioRegistro = idUsuarioRegistro;
    }

    public LocalDateTime getDataRegistro() {
        return dataRegistro;
    }

    public void setDataRegistro(LocalDateTime dataRegistro) {
        this.dataRegistro = dataRegistro;
    }

    public Long getIdUsuarioValidacao() {
        return idUsuarioValidacao;
    }

    public void setIdUsuarioValidacao(Long idUsuarioValidacao) {
        this.idUsuarioValidacao = idUsuarioValidacao;
    }

    public LocalDateTime getDataValidacao() {
        return dataValidacao;
    }

    public void setDataValidacao(LocalDateTime dataValidacao) {
        this.dataValidacao = dataValidacao;
    }

    @Override
    public Long chave() {
        return idHistoricoSaude;
    }

    @Override
    public void definirChave(Long id) {
        this.idHistoricoSaude = id;
    }
}
