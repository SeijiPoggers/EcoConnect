package br.com.ecoconnect.api.model.enums;

/** Situação de uma avaliação de indicador. Valores idênticos ao ENUM do MySQL. */
public enum SituacaoAvaliacao {
    VIGENTE, SUBSTITUIDA
}
