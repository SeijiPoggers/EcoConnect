package br.com.ecoconnect.api.controller.app;

import br.com.ecoconnect.api.service.UsuarioAtual;
import br.com.ecoconnect.api.service.app.CadastroService;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/** Saúde do sistema (usada pelos scripts de inicialização) e cadastro público de famílias. */
@RestController
public class SistemaController {

    private final JdbcTemplate jdbc;
    private final CadastroService cadastro;
    private final UsuarioAtual usuarioAtual;

    public SistemaController(JdbcTemplate jdbc, CadastroService cadastro, UsuarioAtual usuarioAtual) {
        this.jdbc = jdbc;
        this.cadastro = cadastro;
        this.usuarioAtual = usuarioAtual;
    }

    @GetMapping("/api/saude")
    public ResponseEntity<Map<String, Object>> saude() {
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("aplicacao", "EcoConect");
        r.put("versao", "1.0.0");
        r.put("horario", LocalDateTime.now().withNano(0).toString());
        boolean banco;
        try {
            jdbc.queryForObject("SELECT 1", Integer.class);
            banco = true;
        } catch (RuntimeException e) {
            banco = false;
        }
        r.put("banco", banco ? "UP" : "DOWN");
        if (banco) {
            try {
                List<String> v = jdbc.queryForList("SELECT version FROM flyway_schema_history WHERE success = 1 AND version IS NOT NULL "
                        + "ORDER BY installed_rank DESC LIMIT 1", String.class);
                r.put("versaoBanco", v.isEmpty() ? null : v.get(0));
            } catch (RuntimeException e) {
                r.put("versaoBanco", null);
            }
            try {
                Integer n = jdbc.queryForObject("SELECT COUNT(*) FROM registro_demonstracao", Integer.class);
                r.put("demonstracao", n != null && n > 0);
            } catch (RuntimeException e) {
                r.put("demonstracao", false);
            }
        }
        r.put("status", banco ? "UP" : "DOWN");
        return ResponseEntity.status(banco ? 200 : 503).body(r);
    }

    @PostMapping("/api/auth/cadastro")
    public Map<String, Object> cadastrar(@RequestBody CadastroService.NovoCadastro dados) {
        return cadastro.cadastrar(dados, usuarioAtual.ip());
    }
}
