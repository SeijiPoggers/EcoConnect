package br.com.ecoconnect.api.seguranca;

import br.com.ecoconnect.api.exception.NaoAutorizadoException;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Map;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.HandlerMapping;

/**
 * Escopo nas sub-rotas da API original cujo identificador fica no caminho
 * (/agendamentos/{idAgendamento}/profissionais, /atendimentos/{idAtendimento}/..., /objetivos/{idObjetivo}/indicadores)
 * e no relatório do responsável (/responsaveis/{id}/relatorios: só o próprio).
 */
@Component
public class EscopoInterceptor implements HandlerInterceptor {

    private final EscopoAcesso escopo;

    public EscopoInterceptor(EscopoAcesso escopo) {
        this.escopo = escopo;
    }

    @Override
    public boolean preHandle(HttpServletRequest req, HttpServletResponse resp, Object handler) {
        ContextoUsuario c = ContextoAtual.obter();
        if (c == null || c.administrador()) return true;
        Object attr = req.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
        if (!(attr instanceof Map<?, ?> vars)) return true;
        Long idAgendamento = numero(vars.get("idAgendamento"));
        if (idAgendamento != null) exigir(escopo.criancaDoAgendamento(idAgendamento), "agendamento", idAgendamento);
        Long idAtendimento = numero(vars.get("idAtendimento"));
        if (idAtendimento != null) exigir(escopo.criancaDoAtendimento(idAtendimento), "atendimento", idAtendimento);
        Long idObjetivo = numero(vars.get("idObjetivo"));
        if (idObjetivo != null) exigir(escopo.criancaDoObjetivo(idObjetivo), "objetivo", idObjetivo);
        String uri = req.getRequestURI();
        if (c.responsavel() && uri.matches(".*/api/responsaveis/\\d+/relatorios/?")) {
            Long id = numero(vars.get("id"));
            if (id == null || !id.equals(c.idResponsavel())) {
                throw new NaoAutorizadoException(403, "Você só pode consultar os seus próprios relatórios.");
            }
        }
        return true;
    }

    private void exigir(Long idCrianca, String tabela, Long id) {
        if (idCrianca == null) throw new NaoEncontradoException(tabela, id);
        escopo.exigirCrianca(idCrianca);
    }

    private static Long numero(Object v) {
        if (v == null) return null;
        try {
            return Long.valueOf(v.toString());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
