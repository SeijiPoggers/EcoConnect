package br.com.ecoconnect.api.service.saude;

import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Consentimento;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.BaseLegal;
import br.com.ecoconnect.api.model.enums.SituacaoAutorizacao;
import br.com.ecoconnect.api.model.enums.StatusVinculo;
import br.com.ecoconnect.api.repository.ConsentimentoRepository;
import br.com.ecoconnect.api.repository.CriancaResponsavelRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.Verificacoes;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

/**
 * CONSENTIMENTO: autorização do responsável, finalidade, versão do termo e avaliação da base legal
 * (três conceitos separados, ajuste E.2-5). Não é editado nem excluído: é revogado ou expira.
 */
@Service
public class ConsentimentoService extends CrudService<Consentimento, Long> {

    private final CriancaResponsavelRepository vinculoRepository;
    private final Verificacoes verificacoes;

    public ConsentimentoService(ConsentimentoRepository repository, AuditoriaService auditoria,
                                CriancaResponsavelRepository vinculoRepository, Verificacoes verificacoes) {
        super(repository, auditoria, "consentimento");
        this.vinculoRepository = vinculoRepository;
        this.verificacoes = verificacoes;
    }

    @Override
    protected void antesDeCriar(Consentimento c) {
        verificacoes.crianca(c.getIdCrianca());
        verificacoes.responsavel(c.getIdResponsavel());
        if (!vinculoRepository.existsByIdCriancaAndIdResponsavelAndStatus(c.getIdCrianca(), c.getIdResponsavel(), StatusVinculo.ATIVO)) {
            throw new RegraNegocioException("Só um responsável com vínculo ATIVO pode autorizar pela criança.");
        }
        verificacoes.documentoDaCrianca(c.getIdDocumento(), c.getIdCrianca());
        verificacoes.usuarioAtivo(c.getIdUsuarioRegistro(), "Quem registra o consentimento");
        if (c.getDataValidade() != null && c.getDataValidade().isBefore(c.getDataAutorizacao().toLocalDate())) {
            throw new RegraNegocioException("A validade não pode ser antes da data de autorização.");
        }
        c.setSituacaoAutorizacao(SituacaoAutorizacao.REGISTRADA);
        c.setDataRevogacao(null);
        if (c.getBaseLegalAvaliada() == null || c.getBaseLegalAvaliada() == BaseLegal.NAO_AVALIADA) {
            c.setBaseLegalAvaliada(BaseLegal.NAO_AVALIADA);
            c.setIdUsuarioAvaliacaoBase(null);
            c.setDataAvaliacaoBase(null);
        } else {
            verificacoes.usuarioDaEquipe(c.getIdUsuarioAvaliacaoBase(), "Quem avalia a base legal");
            if (c.getDataAvaliacaoBase() == null) c.setDataAvaliacaoBase(LocalDateTime.now());
        }
    }

    @Transactional
    public Consentimento revogar(Long id) {
        return mudarSituacao(id, SituacaoAutorizacao.REVOGADA);
    }

    @Transactional
    public Consentimento expirar(Long id) {
        return mudarSituacao(id, SituacaoAutorizacao.EXPIRADA);
    }

    @Transactional
    public Consentimento avaliarBaseLegal(Long id, BaseLegal base, Long idUsuario) {
        Consentimento c = buscar(id);
        if (base == BaseLegal.NAO_AVALIADA) throw new RegraNegocioException("Informe a base legal avaliada.");
        verificacoes.usuarioDaEquipe(idUsuario, "Quem avalia a base legal");
        String antes = auditoria.json(c);
        c.setBaseLegalAvaliada(base);
        c.setIdUsuarioAvaliacaoBase(idUsuario);
        c.setDataAvaliacaoBase(LocalDateTime.now());
        return salvarAlteracao(c, antes, AcaoAuditoria.VALIDACAO);
    }

    private Consentimento mudarSituacao(Long id, SituacaoAutorizacao nova) {
        Consentimento c = buscar(id);
        if (c.getSituacaoAutorizacao() != SituacaoAutorizacao.REGISTRADA) {
            throw new RegraNegocioException("O consentimento já está " + c.getSituacaoAutorizacao() + ".");
        }
        String antes = auditoria.json(c);
        c.setSituacaoAutorizacao(nova);
        if (nova == SituacaoAutorizacao.REVOGADA) c.setDataRevogacao(LocalDateTime.now());
        return salvarAlteracao(c, antes, AcaoAuditoria.ATUALIZACAO);
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.PROIBIDA;
    }
}
