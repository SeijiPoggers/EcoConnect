package br.com.ecoconnect.api.dto;

import br.com.ecoconnect.api.model.enums.SituacaoValidacao;
import jakarta.validation.constraints.NotNull;

/** Validação de informação de saúde: EM_VALIDACAO, VALIDADO ou REJEITADO, por alguém da equipe. */
public record ValidacaoRequisicao(
        @NotNull(message = "campo obrigatório") SituacaoValidacao situacaoValidacao,
        @NotNull(message = "campo obrigatório") Long idUsuarioValidacao) {
}
