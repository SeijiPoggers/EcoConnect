package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

/**
 * Tabela `agendamento_profissional` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 */
@Entity
@Table(name = "agendamento_profissional")
@IdClass(AgendamentoProfissionalId.class)
public class AgendamentoProfissional {

    @Id
    @Column(name = "id_agendamento", nullable = false)
    private Long idAgendamento;

    @Id
    @Column(name = "id_profissional", nullable = false)
    private Long idProfissional;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_usuario_designacao", nullable = false)
    private Long idUsuarioDesignacao;

    @Column(name = "data_designacao", nullable = false)
    private LocalDateTime dataDesignacao;

    @PrePersist
    void aoInserir() {
        if (dataDesignacao == null) {
            dataDesignacao = LocalDateTime.now();
        }
    }

    public Long getIdAgendamento() {
        return idAgendamento;
    }

    public void setIdAgendamento(Long idAgendamento) {
        this.idAgendamento = idAgendamento;
    }

    public Long getIdProfissional() {
        return idProfissional;
    }

    public void setIdProfissional(Long idProfissional) {
        this.idProfissional = idProfissional;
    }

    public Long getIdUsuarioDesignacao() {
        return idUsuarioDesignacao;
    }

    public void setIdUsuarioDesignacao(Long idUsuarioDesignacao) {
        this.idUsuarioDesignacao = idUsuarioDesignacao;
    }

    public LocalDateTime getDataDesignacao() {
        return dataDesignacao;
    }

    public void setDataDesignacao(LocalDateTime dataDesignacao) {
        this.dataDesignacao = dataDesignacao;
    }
}
