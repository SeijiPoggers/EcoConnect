package br.com.ecoconnect.api.service.app;

import br.com.ecoconnect.api.dominio.Codigos;
import br.com.ecoconnect.api.dominio.MotorCorrespondencia;
import br.com.ecoconnect.api.dominio.Papeis;
import br.com.ecoconnect.api.exception.ConflitoException;
import br.com.ecoconnect.api.exception.NaoAutorizadoException;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Instituicao;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.repository.InstituicaoRepository;
import br.com.ecoconnect.api.seguranca.ContextoAtual;
import br.com.ecoconnect.api.seguranca.ContextoUsuario;
import br.com.ecoconnect.api.seguranca.EscopoAcesso;
import br.com.ecoconnect.api.service.AuditoriaService;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Frente B - rede de apoio: catálogo de instituições (públicas, filantrópicas, privadas, ONGs...),
 * serviços oferecidos, vagas, membros, vínculos com pessoas acompanhadas e recomendações explicadas.
 * As recomendações não são diagnóstico nem garantia de adequação clínica (MotorCorrespondencia.AVISO).
 */
@Service
public class RedeService {

    public static final Map<String, String> TIPOS_INSTITUICAO = mapa("PUBLICA", "Pública", "FILANTROPICA", "Filantrópica",
            "PRIVADA", "Privada", "ONG", "ONG", "ASSOCIACAO", "Associação", "CLINICA_ESCOLA", "Clínica-escola");
    public static final Map<String, String> TIPOS_SERVICO = mapa("AVALIACAO_DIAGNOSTICA", "Avaliação diagnóstica",
            "PSICOLOGIA", "Psicologia", "FONOAUDIOLOGIA", "Fonoaudiologia", "TERAPIA_OCUPACIONAL", "Terapia ocupacional",
            "FISIOTERAPIA", "Fisioterapia", "PSICOPEDAGOGIA", "Psicopedagogia", "EQUOTERAPIA", "Equoterapia",
            "NEUROPEDIATRIA", "Neuropediatria", "PSIQUIATRIA", "Psiquiatria", "GRUPO_DE_APOIO", "Grupo de apoio",
            "ORIENTACAO_FAMILIAR", "Orientação familiar", "APOIO_ESCOLAR", "Apoio escolar", "OUTRO", "Outro");
    public static final Map<String, String> COMUNICACAO = mapa("ESCRITA", "Por escrito (mensagens)", "FALADA", "Falada",
            "VISUAL", "Com apoio visual", "COMUNICACAO_ALTERNATIVA", "Comunicação alternativa (CAA)",
            "SEM_PREFERENCIA", "Sem preferência");

    private final InstituicaoRepository instituicaoRepository;
    private final Consultas consultas;
    private final EscopoAcesso escopo;
    private final AuditoriaService auditoria;

    public RedeService(InstituicaoRepository instituicaoRepository, Consultas consultas, EscopoAcesso escopo,
                       AuditoriaService auditoria) {
        this.instituicaoRepository = instituicaoRepository;
        this.consultas = consultas;
        this.escopo = escopo;
        this.auditoria = auditoria;
    }

    // ============================================================== catálogos

    public Map<String, Object> catalogos() {
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("condicoes", Codigos.CONDICOES);
        r.put("acessibilidade", Codigos.ACESSIBILIDADE);
        r.put("sensorial", Codigos.SENSORIAL);
        r.put("modalidades", Codigos.MODALIDADES);
        r.put("comunicacao", COMUNICACAO);
        r.put("tiposInstituicao", TIPOS_INSTITUICAO);
        r.put("tiposServico", TIPOS_SERVICO);
        r.put("categoriasSus", SusService.CATEGORIAS);
        r.put("avisoRecomendacoes", MotorCorrespondencia.AVISO);
        return r;
    }

    // ============================================================== busca

    public record FiltroBusca(String texto, String uf, String municipio, String condicao, String tipoServico,
                              Boolean gratuito, Boolean sus, Integer idade, String modalidade, String acessibilidade,
                              Boolean comVagas, String tipo) {
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> buscar(FiltroBusca f) {
        ContextoAtual.exigir();
        StringBuilder sql = new StringBuilder(resumoSql()).append(" WHERE i.ativa = 1");
        List<Object> args = new ArrayList<>();
        if (vazio(f.texto()) == null) {
            // sem texto
        } else {
            sql.append(" AND (LOWER(i.nome) LIKE ? OR LOWER(i.descricao) LIKE ? OR LOWER(i.bairro) LIKE ?)");
            String t = "%" + f.texto().trim().toLowerCase(Locale.ROOT) + "%";
            args.add(t);
            args.add(t);
            args.add(t);
        }
        if (vazio(f.uf()) != null) {
            sql.append(" AND i.uf = ?");
            args.add(f.uf().trim().toUpperCase(Locale.ROOT));
        }
        if (vazio(f.municipio()) != null) {
            sql.append(" AND LOWER(i.municipio) = ?");
            args.add(f.municipio().trim().toLowerCase(Locale.ROOT));
        }
        if (vazio(f.tipo()) != null) {
            sql.append(" AND i.tipo = ?");
            args.add(validar(f.tipo(), TIPOS_INSTITUICAO, "tipo de instituição"));
        }
        if (vazio(f.condicao()) != null) {
            sql.append(" AND FIND_IN_SET(?, i.condicoes_atendidas) > 0");
            args.add(validar(f.condicao(), Codigos.CONDICOES, "condição"));
        }
        if (vazio(f.modalidade()) != null) {
            sql.append(" AND FIND_IN_SET(?, i.modalidades) > 0");
            args.add(validar(f.modalidade(), Codigos.MODALIDADES, "modalidade"));
        }
        if (vazio(f.acessibilidade()) != null) {
            sql.append(" AND FIND_IN_SET(?, i.recursos_acessibilidade) > 0");
            args.add(validar(f.acessibilidade(), Codigos.ACESSIBILIDADE, "recurso de acessibilidade"));
        }
        if (vazio(f.tipoServico()) != null) {
            sql.append(" AND EXISTS (SELECT 1 FROM instituicao_servico s2 WHERE s2.id_instituicao = i.id_instituicao "
                    + "AND s2.ativo = 1 AND s2.tipo_servico = ?)");
            args.add(validar(f.tipoServico(), TIPOS_SERVICO, "tipo de serviço"));
        }
        if (Boolean.TRUE.equals(f.gratuito())) {
            sql.append(" AND (i.atendimento_gratuito = 1 OR i.atende_pelo_sus = 1 OR EXISTS (SELECT 1 FROM instituicao_servico s3 "
                    + "WHERE s3.id_instituicao = i.id_instituicao AND s3.ativo = 1 AND s3.gratuito = 1))");
        }
        if (Boolean.TRUE.equals(f.sus())) sql.append(" AND i.atende_pelo_sus = 1");
        if (f.idade() != null) {
            sql.append(" AND (i.idade_minima IS NULL OR i.idade_minima <= ?) AND (i.idade_maxima IS NULL OR i.idade_maxima >= ?)");
            args.add(f.idade());
            args.add(f.idade());
        }
        if (Boolean.TRUE.equals(f.comVagas())) {
            sql.append(" AND i.aceita_solicitacoes = 1 AND (i.vagas_disponiveis IS NULL OR i.vagas_disponiveis > 0)");
        }
        sql.append(" ORDER BY i.verificada DESC, i.nome LIMIT 200");
        List<Map<String, Object>> linhas = consultas.lista(sql.toString(), args.toArray());
        linhas.forEach(this::rotular);
        return linhas;
    }

    private static String resumoSql() {
        return "SELECT i.id_instituicao AS idInstituicao, i.nome, i.tipo, i.descricao, i.municipio, i.uf, i.bairro, "
                + "i.telefone, i.email, i.site, i.idade_minima AS idadeMinima, i.idade_maxima AS idadeMaxima, "
                + "i.condicoes_atendidas AS condicoes, i.modalidades, i.recursos_acessibilidade AS acessibilidade, "
                + "i.atendimento_gratuito AS gratuito, i.atende_pelo_sus AS atendePeloSus, i.vagas_disponiveis AS vagas, "
                + "i.aceita_solicitacoes AS aceitaSolicitacoes, i.verificada, i.dados_demonstracao AS demonstracao, "
                + "(SELECT GROUP_CONCAT(DISTINCT s.tipo_servico ORDER BY s.tipo_servico SEPARATOR ',') FROM instituicao_servico s "
                + " WHERE s.id_instituicao = i.id_instituicao AND s.ativo = 1) AS tiposServico "
                + "FROM instituicao i";
    }

    /** Acrescenta os rótulos legíveis das listas de códigos. */
    private void rotular(Map<String, Object> l) {
        l.put("tipoRotulo", TIPOS_INSTITUICAO.getOrDefault(String.valueOf(l.get("tipo")), String.valueOf(l.get("tipo"))));
        l.put("condicoesRotulos", rotulos(l.get("condicoes"), Codigos.CONDICOES));
        l.put("modalidadesRotulos", rotulos(l.get("modalidades"), Codigos.MODALIDADES));
        l.put("acessibilidadeRotulos", rotulos(l.get("acessibilidade"), Codigos.ACESSIBILIDADE));
        l.put("servicosRotulos", rotulos(l.get("tiposServico"), TIPOS_SERVICO));
    }

    private static List<String> rotulos(Object codigos, Map<String, String> vocabulario) {
        List<String> r = new ArrayList<>();
        for (String c : Codigos.lista(codigos == null ? null : codigos.toString())) r.add(Codigos.rotulo(vocabulario, c));
        return r;
    }

    // ============================================================== detalhe

    @Transactional(readOnly = true)
    public Map<String, Object> detalhe(Long idInstituicao) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        Map<String, Object> r = consultas.um(resumoSql() + " WHERE i.id_instituicao = ?", idInstituicao);
        if (r == null) throw new NaoEncontradoException("instituicao", idInstituicao);
        boolean gestor = gestor(ctx, idInstituicao);
        if (!gestor && !Boolean.TRUE.equals(bool(consultas.um("SELECT ativa FROM instituicao WHERE id_instituicao = ?",
                idInstituicao).get("ativa")))) {
            throw new NaoEncontradoException("instituicao", idInstituicao);
        }
        rotular(r);
        Instituicao i = instituicaoRepository.findById(idInstituicao).orElseThrow();
        r.put("logradouro", i.getLogradouro());
        r.put("numero", i.getNumero());
        r.put("cep", i.getCep());
        r.put("codigoCnes", i.getCodigoCnes());
        r.put("ativa", i.getAtiva());
        r.put("dataAtualizacao", i.getDataAtualizacao());
        r.put("servicos", consultas.lista("SELECT id_servico AS idServico, nome, tipo_servico AS tipoServico, descricao, gratuito, ativo "
                + "FROM instituicao_servico WHERE id_instituicao = ?" + (gestor ? "" : " AND ativo = 1") + " ORDER BY ativo DESC, nome",
                idInstituicao));
        for (Map<String, Object> s : listaDe(r.get("servicos"))) {
            s.put("tipoRotulo", Codigos.rotulo(TIPOS_SERVICO, String.valueOf(s.get("tipoServico"))));
        }
        r.put("gestor", gestor);
        if (gestor) {
            r.put("cnpj", i.getCnpj());
            r.put("latitude", i.getLatitude());
            r.put("longitude", i.getLongitude());
            r.put("membros", consultas.lista("SELECT m.id_membro AS idMembro, m.id_usuario AS idUsuario, u.nome_completo AS nome, "
                    + "u.email, m.papel, m.ativo FROM instituicao_membro m JOIN usuario u ON u.id_usuario = m.id_usuario "
                    + "WHERE m.id_instituicao = ? ORDER BY m.ativo DESC, u.nome_completo", idInstituicao));
        }
        r.put("podeSolicitar", ctx.familia() || ctx.equipe());
        return r;
    }

    // ============================================================== cadastro e gestão

    @Transactional
    public Map<String, Object> criar(Instituicao dados) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (!ctx.administrador()) throw new NaoAutorizadoException(403, "Somente o administrador cadastra novas instituições.");
        Instituicao i = new Instituicao();
        copiar(dados, i, true);
        if (i.getCnpj() != null && instituicaoRepository.existsByCnpj(i.getCnpj())) {
            throw new ConflitoException("Já existe uma instituição com este CNPJ.");
        }
        i.setAtiva(Boolean.TRUE);
        i.setDadosDemonstracao(Boolean.FALSE);
        Instituicao salva = instituicaoRepository.saveAndFlush(i);
        auditoria.registrar(AcaoAuditoria.CRIACAO, "instituicao", salva, null, salva);
        return detalhe(salva.getIdInstituicao());
    }

    @Transactional
    public Map<String, Object> alterar(Long idInstituicao, Instituicao dados) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        escopo.exigirGestaoInstituicao(idInstituicao);
        Instituicao i = instituicaoRepository.findById(idInstituicao)
                .orElseThrow(() -> new NaoEncontradoException("instituicao", idInstituicao));
        String antes = auditoria.json(i);
        copiar(dados, i, ctx.administrador());
        if (i.getCnpj() != null && instituicaoRepository.existsByCnpjAndIdInstituicaoNot(i.getCnpj(), idInstituicao)) {
            throw new ConflitoException("Já existe outra instituição com este CNPJ.");
        }
        if (ctx.administrador() && dados.getAtiva() != null) i.setAtiva(dados.getAtiva());
        i.setDataAtualizacao(LocalDateTime.now());
        Instituicao salva = instituicaoRepository.saveAndFlush(i);
        auditoria.registrar(AcaoAuditoria.ATUALIZACAO, "instituicao", salva, antes, salva);
        return detalhe(idInstituicao);
    }

    /** Copia e valida os campos editáveis. "verificada" só é alterada pelo administrador geral. */
    private void copiar(Instituicao d, Instituicao i, boolean administrador) {
        String nome = PessoasService.texto(d.getNome(), 150);
        if (nome == null) throw new RegraNegocioException("Informe o nome da instituição.");
        i.setNome(nome);
        i.setTipo(validar(d.getTipo(), TIPOS_INSTITUICAO, "tipo de instituição"));
        if (i.getTipo() == null) throw new RegraNegocioException("Informe o tipo da instituição.");
        String cnpj = d.getCnpj() == null ? null : d.getCnpj().replaceAll("\\D", "");
        if (cnpj != null && cnpj.isEmpty()) cnpj = null;
        if (cnpj != null && cnpj.length() != 14) throw new RegraNegocioException("O CNPJ deve ter 14 dígitos.");
        i.setCnpj(cnpj);
        String cnes = d.getCodigoCnes() == null ? null : d.getCodigoCnes().replaceAll("\\D", "");
        if (cnes != null && cnes.isEmpty()) cnes = null;
        if (cnes != null && cnes.length() != 7) throw new RegraNegocioException("O código CNES tem 7 dígitos.");
        i.setCodigoCnes(cnes);
        i.setDescricao(PessoasService.texto(d.getDescricao(), 5000));
        i.setEmail(PessoasService.texto(d.getEmail(), 150));
        if (i.getEmail() != null && !i.getEmail().matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) {
            throw new RegraNegocioException("E-mail da instituição inválido.");
        }
        i.setTelefone(PessoasService.texto(d.getTelefone(), 20));
        String site = PessoasService.texto(d.getSite(), 200);
        if (site != null && !site.matches("(?i)^https?://\\S+$")) throw new RegraNegocioException("O site deve começar com http:// ou https://.");
        i.setSite(site);
        i.setLogradouro(PessoasService.texto(d.getLogradouro(), 150));
        i.setNumero(PessoasService.texto(d.getNumero(), 20));
        i.setBairro(PessoasService.texto(d.getBairro(), 80));
        String municipio = PessoasService.texto(d.getMunicipio(), 80);
        String uf = d.getUf() == null ? null : d.getUf().trim().toUpperCase(Locale.ROOT);
        if (municipio == null || uf == null || !uf.matches("[A-Z]{2}")) {
            throw new RegraNegocioException("Informe o município e a UF (duas letras) da instituição.");
        }
        i.setMunicipio(municipio);
        i.setUf(uf);
        String cep = d.getCep() == null ? null : d.getCep().replaceAll("\\D", "");
        if (cep != null && cep.isEmpty()) cep = null;
        if (cep != null && cep.length() != 8) throw new RegraNegocioException("O CEP deve ter 8 dígitos.");
        i.setCep(cep);
        i.setLatitude(coordenada(d.getLatitude(), 90, "latitude"));
        i.setLongitude(coordenada(d.getLongitude(), 180, "longitude"));
        Integer min = d.getIdadeMinima();
        Integer max = d.getIdadeMaxima();
        if ((min != null && (min < 0 || min > 120)) || (max != null && (max < 0 || max > 120))) {
            throw new RegraNegocioException("Faixa etária inválida (0 a 120 anos).");
        }
        if (min != null && max != null && max < min) throw new RegraNegocioException("A idade máxima deve ser maior ou igual à mínima.");
        i.setIdadeMinima(min);
        i.setIdadeMaxima(max);
        i.setCondicoesAtendidas(Codigos.normalizar(d.getCondicoesAtendidas(), Codigos.CONDICOES, "condições atendidas"));
        i.setModalidades(Codigos.normalizar(d.getModalidades(), Codigos.MODALIDADES, "modalidades"));
        i.setRecursosAcessibilidade(Codigos.normalizar(d.getRecursosAcessibilidade(), Codigos.ACESSIBILIDADE, "acessibilidade"));
        i.setAtendimentoGratuito(Boolean.TRUE.equals(d.getAtendimentoGratuito()));
        i.setAtendePeloSus(Boolean.TRUE.equals(d.getAtendePeloSus()));
        if (d.getVagasDisponiveis() != null && (d.getVagasDisponiveis() < 0 || d.getVagasDisponiveis() > 65000)) {
            throw new RegraNegocioException("Número de vagas inválido.");
        }
        i.setVagasDisponiveis(d.getVagasDisponiveis());
        i.setAceitaSolicitacoes(d.getAceitaSolicitacoes() == null || d.getAceitaSolicitacoes());
        if (administrador) i.setVerificada(Boolean.TRUE.equals(d.getVerificada()));
        else if (i.getVerificada() == null) i.setVerificada(Boolean.FALSE);
    }

    private static BigDecimal coordenada(BigDecimal v, int limite, String campo) {
        if (v == null) return null;
        if (v.abs().compareTo(BigDecimal.valueOf(limite)) > 0) throw new RegraNegocioException("Valor de " + campo + " inválido.");
        return v;
    }

    public record DadosServico(String nome, String tipoServico, String descricao, Boolean gratuito, Boolean ativo) {
    }

    @Transactional
    public Map<String, Object> salvarServico(Long idInstituicao, Long idServico, DadosServico d) {
        escopo.exigirGestaoInstituicao(idInstituicao);
        String nome = PessoasService.texto(d.nome(), 120);
        if (nome == null) throw new RegraNegocioException("Informe o nome do serviço.");
        String tipo = validar(d.tipoServico(), TIPOS_SERVICO, "tipo de serviço");
        if (tipo == null) throw new RegraNegocioException("Informe o tipo de serviço.");
        String descricao = PessoasService.texto(d.descricao(), 500);
        boolean gratuito = Boolean.TRUE.equals(d.gratuito());
        if (idServico == null) {
            long id = consultas.inserir("INSERT INTO instituicao_servico (id_instituicao, nome, tipo_servico, descricao, gratuito, ativo) "
                    + "VALUES (?, ?, ?, ?, ?, 1)", idInstituicao, nome, tipo, descricao, gratuito);
            Map<String, Object> novo = servico(idInstituicao, id);
            auditoria.registrarDados(AcaoAuditoria.CRIACAO, "instituicao_servico", id, null, null, novo);
            return novo;
        }
        Map<String, Object> antes = servico(idInstituicao, idServico);
        boolean ativo = d.ativo() == null || d.ativo();
        consultas.executar("UPDATE instituicao_servico SET nome = ?, tipo_servico = ?, descricao = ?, gratuito = ?, ativo = ? "
                + "WHERE id_servico = ? AND id_instituicao = ?", nome, tipo, descricao, gratuito, ativo, idServico, idInstituicao);
        Map<String, Object> depois = servico(idInstituicao, idServico);
        auditoria.registrarDados(ativo ? AcaoAuditoria.ATUALIZACAO : AcaoAuditoria.EXCLUSAO_LOGICA, "instituicao_servico",
                idServico, null, antes, depois);
        return depois;
    }

    private Map<String, Object> servico(Long idInstituicao, Long idServico) {
        Map<String, Object> s = consultas.um("SELECT id_servico AS idServico, id_instituicao AS idInstituicao, nome, "
                + "tipo_servico AS tipoServico, descricao, gratuito, ativo FROM instituicao_servico "
                + "WHERE id_servico = ? AND id_instituicao = ?", idServico, idInstituicao);
        if (s == null) throw new NaoEncontradoException("instituicao_servico", idServico);
        return s;
    }

    public record DadosVagas(Integer vagasDisponiveis, Boolean aceitaSolicitacoes) {
    }

    @Transactional
    public Map<String, Object> atualizarVagas(Long idInstituicao, DadosVagas d) {
        escopo.exigirGestaoInstituicao(idInstituicao);
        if (d.vagasDisponiveis() != null && (d.vagasDisponiveis() < 0 || d.vagasDisponiveis() > 65000)) {
            throw new RegraNegocioException("Número de vagas inválido.");
        }
        Instituicao i = instituicaoRepository.findById(idInstituicao)
                .orElseThrow(() -> new NaoEncontradoException("instituicao", idInstituicao));
        String antes = auditoria.json(i);
        i.setVagasDisponiveis(d.vagasDisponiveis());
        if (d.aceitaSolicitacoes() != null) i.setAceitaSolicitacoes(d.aceitaSolicitacoes());
        i.setDataAtualizacao(LocalDateTime.now());
        Instituicao salva = instituicaoRepository.saveAndFlush(i);
        auditoria.registrar(AcaoAuditoria.ATUALIZACAO, "instituicao", salva, antes, salva);
        return detalhe(idInstituicao);
    }

    public record NovoMembro(String email, String papel) {
    }

    @Transactional
    public Map<String, Object> adicionarMembro(Long idInstituicao, NovoMembro d) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (!ctx.administrador()) throw new NaoAutorizadoException(403, "Somente o administrador vincula membros às instituições.");
        exigirInstituicao(idInstituicao);
        String email = d.email() == null ? "" : d.email().trim().toLowerCase(Locale.ROOT);
        Map<String, Object> u = consultas.um("SELECT u.id_usuario AS id, p.nome AS perfil FROM usuario u "
                + "JOIN perfil p ON p.id_perfil = u.id_perfil WHERE u.email = ?", email);
        if (u == null) throw new RegraNegocioException("Não há usuário com o e-mail " + email + ". Cadastre-o em Administração > Usuários.");
        String perfil = String.valueOf(u.get("perfil"));
        String papel = Papeis.ADMIN_INSTITUCIONAL.equals(perfil) ? Papeis.ADMIN_INSTITUCIONAL
                : Papeis.PROFISSIONAL.equals(perfil) ? Papeis.PROFISSIONAL : null;
        if (papel == null) throw new RegraNegocioException("Somente usuários com perfil ADMIN_INSTITUCIONAL ou PROFISSIONAL podem ser membros.");
        Long idUsuario = ((Number) u.get("id")).longValue();
        Map<String, Object> existente = consultas.um("SELECT id_membro AS id FROM instituicao_membro WHERE id_instituicao = ? AND id_usuario = ?",
                idInstituicao, idUsuario);
        long id;
        if (existente != null) {
            id = ((Number) existente.get("id")).longValue();
            consultas.executar("UPDATE instituicao_membro SET ativo = 1, papel = ? WHERE id_membro = ?", papel, id);
        } else {
            id = consultas.inserir("INSERT INTO instituicao_membro (id_instituicao, id_usuario, papel, ativo) VALUES (?, ?, ?, 1)",
                    idInstituicao, idUsuario, papel);
        }
        auditoria.registrarDados(AcaoAuditoria.CRIACAO, "instituicao_membro", id, null, null,
                Map.of("idInstituicao", idInstituicao, "idUsuario", idUsuario, "papel", papel));
        return detalhe(idInstituicao);
    }

    @Transactional
    public Map<String, Object> removerMembro(Long idInstituicao, Long idMembro) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (!ctx.administrador()) throw new NaoAutorizadoException(403, "Somente o administrador altera os membros das instituições.");
        int n = consultas.executar("UPDATE instituicao_membro SET ativo = 0 WHERE id_membro = ? AND id_instituicao = ?", idMembro, idInstituicao);
        if (n == 0) throw new NaoEncontradoException("instituicao_membro", idMembro);
        auditoria.registrarDados(AcaoAuditoria.EXCLUSAO_LOGICA, "instituicao_membro", idMembro, null, null, Map.of("ativo", false));
        return detalhe(idInstituicao);
    }

    // ============================================================== painel institucional

    @Transactional(readOnly = true)
    public Map<String, Object> painel(Long idInstituicao) {
        escopo.exigirGestaoInstituicao(idInstituicao);
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("instituicao", detalhe(idInstituicao));
        r.put("solicitacoesPorSituacao", consultas.lista("SELECT situacao, COUNT(*) AS total FROM solicitacao_atendimento "
                + "WHERE id_instituicao = ? GROUP BY situacao", idInstituicao));
        r.put("pendentes", consultas.numero("SELECT COUNT(*) FROM solicitacao_atendimento WHERE id_instituicao = ? "
                + "AND situacao IN ('ENVIADA','EM_ANALISE')", idInstituicao));
        r.put("vinculosAtivos", consultas.numero("SELECT COUNT(*) FROM crianca_instituicao WHERE id_instituicao = ? AND status = 'ATIVO'",
                idInstituicao));
        r.put("profissionais", consultas.lista("SELECT u.nome_completo AS nome, m.papel FROM instituicao_membro m "
                + "JOIN usuario u ON u.id_usuario = m.id_usuario WHERE m.id_instituicao = ? AND m.ativo = 1 ORDER BY u.nome_completo",
                idInstituicao));
        r.put("pessoasVinculadas", vinculosDaInstituicao(idInstituicao));
        return r;
    }

    // ============================================================== vínculos pessoa x instituição

    /** Pessoas vinculadas à instituição: a instituição vê somente nome, idade, condições e preferências informadas. */
    @Transactional(readOnly = true)
    public List<Map<String, Object>> vinculosDaInstituicao(Long idInstituicao) {
        escopo.exigirGestaoInstituicao(idInstituicao);
        return consultas.lista("SELECT ci.id_crianca_instituicao AS idVinculo, ci.id_crianca AS idCrianca, c.nome_completo AS nome, "
                + "TIMESTAMPDIFF(YEAR, c.data_nascimento, CURDATE()) AS idade, pn.condicoes_informadas AS condicoes, "
                + "pn.comunicacao_preferida AS comunicacaoPreferida, ci.origem, ci.status, " + Consultas.d("ci.data_inicio") + " AS dataInicio, "
                + Consultas.d("ci.data_fim") + " AS dataFim FROM crianca_instituicao ci JOIN crianca c ON c.id_crianca = ci.id_crianca "
                + "LEFT JOIN perfil_necessidades pn ON pn.id_crianca = ci.id_crianca WHERE ci.id_instituicao = ? "
                + "ORDER BY ci.status, c.nome_completo", idInstituicao);
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> vinculosDaPessoa(Long idCrianca) {
        escopo.exigirCrianca(idCrianca);
        return consultas.lista("SELECT ci.id_crianca_instituicao AS idVinculo, ci.id_instituicao AS idInstituicao, i.nome, i.tipo, "
                + "i.municipio, i.uf, i.telefone, ci.origem, ci.status, " + Consultas.d("ci.data_inicio") + " AS dataInicio, "
                + Consultas.d("ci.data_fim") + " AS dataFim, ci.observacao FROM crianca_instituicao ci "
                + "JOIN instituicao i ON i.id_instituicao = ci.id_instituicao WHERE ci.id_crianca = ? ORDER BY ci.status, i.nome", idCrianca);
    }

    public record NovoVinculo(Long idInstituicao, String observacao) {
    }

    /** Vínculo feito pela equipe, pelo responsável principal ou pela própria instituição (se a pessoa já a procurou). */
    @Transactional
    public List<Map<String, Object>> vincular(Long idCrianca, NovoVinculo d) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (d.idInstituicao() == null) throw new RegraNegocioException("Informe a instituição.");
        exigirInstituicao(d.idInstituicao());
        if (ctx.adminInstitucional()) {
            escopo.exigirGestaoInstituicao(d.idInstituicao());
            escopo.exigirCrianca(idCrianca);
        } else {
            escopo.exigirAcompanhamento(idCrianca);
            if (!ctx.equipe() && !ctx.responsavel()) {
                throw new NaoAutorizadoException(403, "Somente a equipe ou o responsável registram este vínculo.");
            }
        }
        criarVinculo(idCrianca, d.idInstituicao(), "CADASTRO", null, PessoasService.texto(d.observacao(), 300), ctx.idUsuario());
        return vinculosDaPessoa(idCrianca);
    }

    /** Cria (ou reativa) o vínculo; usado também pela aceitação de uma solicitação. */
    @Transactional
    public void criarVinculo(Long idCrianca, Long idInstituicao, String origem, Long idSolicitacao, String observacao, Long idUsuario) {
        Map<String, Object> existente = consultas.um("SELECT id_crianca_instituicao AS id, status FROM crianca_instituicao "
                + "WHERE id_crianca = ? AND id_instituicao = ?", idCrianca, idInstituicao);
        if (existente != null) {
            if ("ATIVO".equals(existente.get("status"))) return;
            consultas.executar("UPDATE crianca_instituicao SET status = 'ATIVO', data_inicio = ?, data_fim = NULL, origem = ?, "
                    + "id_solicitacao = ?, observacao = ? WHERE id_crianca_instituicao = ?", LocalDate.now(), origem, idSolicitacao,
                    observacao, existente.get("id"));
            auditoria.registrarDados(AcaoAuditoria.ATUALIZACAO, "crianca_instituicao", existente.get("id"), idCrianca, existente,
                    Map.of("status", "ATIVO", "origem", origem));
            return;
        }
        long id = consultas.inserir("INSERT INTO crianca_instituicao (id_crianca, id_instituicao, origem, id_solicitacao, status, "
                + "data_inicio, observacao, id_usuario_cadastro) VALUES (?, ?, ?, ?, 'ATIVO', ?, ?, ?)", idCrianca, idInstituicao, origem,
                idSolicitacao, LocalDate.now(), observacao, idUsuario);
        auditoria.registrarDados(AcaoAuditoria.CRIACAO, "crianca_instituicao", id, idCrianca, null,
                Map.of("idCrianca", idCrianca, "idInstituicao", idInstituicao, "origem", origem));
    }

    @Transactional
    public List<Map<String, Object>> encerrarVinculo(Long idCrianca, Long idVinculo) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        Map<String, Object> v = consultas.um("SELECT id_instituicao AS idInstituicao, status FROM crianca_instituicao "
                + "WHERE id_crianca_instituicao = ? AND id_crianca = ?", idVinculo, idCrianca);
        if (v == null) throw new NaoEncontradoException("crianca_instituicao", idVinculo);
        Long idInstituicao = ((Number) v.get("idInstituicao")).longValue();
        if (ctx.adminInstitucional()) escopo.exigirGestaoInstituicao(idInstituicao);
        else escopo.exigirAcompanhamento(idCrianca);
        if (!ctx.equipe() && !ctx.responsavel() && !ctx.adminInstitucional()) {
            throw new NaoAutorizadoException(403, "Sem permissão para encerrar este vínculo.");
        }
        consultas.executar("UPDATE crianca_instituicao SET status = 'ENCERRADO', data_fim = ? WHERE id_crianca_instituicao = ?",
                LocalDate.now(), idVinculo);
        auditoria.registrarDados(AcaoAuditoria.EXCLUSAO_LOGICA, "crianca_instituicao", idVinculo, idCrianca, v, Map.of("status", "ENCERRADO"));
        return ctx.adminInstitucional() ? vinculosDaInstituicao(idInstituicao) : vinculosDaPessoa(idCrianca);
    }

    // ============================================================== recomendações

    public record PedidoRecomendacao(Long idCrianca, Integer idade, String condicoes, String uf, String municipio,
                                     Boolean somenteGratuito, String modalidade, String acessibilidade, String tiposServico,
                                     Integer limite) {
    }

    /**
     * Recomenda instituições a partir do perfil de necessidades da pessoa (idCrianca) ou de critérios informados.
     * Cada resultado traz os motivos (por que foi recomendada) e os pontos de atenção.
     */
    @Transactional(readOnly = true)
    public Map<String, Object> recomendar(PedidoRecomendacao p) {
        ContextoAtual.exigir();
        Integer idade = p.idade();
        Set<String> condicoes = Codigos.lista(p.condicoes());
        String uf = vazio(p.uf());
        String municipio = vazio(p.municipio());
        boolean gratuito = Boolean.TRUE.equals(p.somenteGratuito());
        String modalidade = vazio(p.modalidade());
        Set<String> acess = Codigos.lista(p.acessibilidade());
        String comunicacao = null;
        Set<String> sensorial = Set.of();
        String pessoa = null;
        if (p.idCrianca() != null) {
            escopo.exigirCrianca(p.idCrianca());
            Map<String, Object> c = consultas.um("SELECT c.nome_completo AS nome, c.data_nascimento AS nascimento, "
                    + "pn.condicoes_informadas AS condicoes, pn.municipio, pn.uf, pn.somente_gratuito AS gratuito, "
                    + "pn.modalidade_preferida AS modalidade, pn.necessidades_acessibilidade AS acess, "
                    + "pn.comunicacao_preferida AS comunicacao, pn.preferencias_sensoriais AS sensorial "
                    + "FROM crianca c LEFT JOIN perfil_necessidades pn ON pn.id_crianca = c.id_crianca WHERE c.id_crianca = ?", p.idCrianca());
            if (c == null) throw new NaoEncontradoException("crianca", p.idCrianca());
            pessoa = String.valueOf(c.get("nome"));
            if (c.get("nascimento") instanceof java.sql.Date d) idade = MotorCorrespondencia.idade(d.toLocalDate(), LocalDate.now());
            else if (c.get("nascimento") instanceof LocalDate d) idade = MotorCorrespondencia.idade(d, LocalDate.now());
            if (condicoes.isEmpty()) condicoes = Codigos.lista(str(c.get("condicoes")));
            if (municipio == null) municipio = vazio(str(c.get("municipio")));
            if (uf == null) uf = vazio(str(c.get("uf")));
            if (p.somenteGratuito() == null) gratuito = Boolean.TRUE.equals(bool(c.get("gratuito")));
            if (modalidade == null && !"SEM_PREFERENCIA".equals(str(c.get("modalidade")))) modalidade = vazio(str(c.get("modalidade")));
            if (acess.isEmpty()) acess = Codigos.lista(str(c.get("acess")));
            comunicacao = str(c.get("comunicacao"));
            sensorial = Codigos.lista(str(c.get("sensorial")));
        }
        Set<String> tipos = Codigos.lista(p.tiposServico());
        MotorCorrespondencia.Perfil perfil = new MotorCorrespondencia.Perfil(idade, condicoes, municipio, uf, gratuito, modalidade,
                acess, comunicacao, sensorial, tipos);
        List<MotorCorrespondencia.Candidata> candidatas = new ArrayList<>();
        Map<Long, Map<String, Object>> resumo = new LinkedHashMap<>();
        for (Map<String, Object> l : consultas.lista(resumoSql() + " WHERE i.ativa = 1")) {
            long id = ((Number) l.get("idInstituicao")).longValue();
            rotular(l);
            resumo.put(id, l);
            candidatas.add(new MotorCorrespondencia.Candidata(id, str(l.get("nome")), str(l.get("municipio")), str(l.get("uf")),
                    inteiro(l.get("idadeMinima")), inteiro(l.get("idadeMaxima")), Codigos.lista(str(l.get("condicoes"))),
                    Codigos.lista(str(l.get("modalidades"))), Codigos.lista(str(l.get("acessibilidade"))),
                    Boolean.TRUE.equals(bool(l.get("gratuito"))), Boolean.TRUE.equals(bool(l.get("atendePeloSus"))),
                    inteiro(l.get("vagas")), Boolean.TRUE.equals(bool(l.get("verificada"))),
                    Boolean.TRUE.equals(bool(l.get("aceitaSolicitacoes"))), Codigos.lista(str(l.get("tiposServico")))));
        }
        int limite = p.limite() == null ? 10 : Math.max(1, Math.min(30, p.limite()));
        List<Map<String, Object>> itens = new ArrayList<>();
        for (MotorCorrespondencia.Resultado res : MotorCorrespondencia.recomendar(perfil, candidatas, limite)) {
            Map<String, Object> m = new LinkedHashMap<>(resumo.get(res.idInstituicao()));
            m.put("pontuacao", res.pontuacao());
            m.put("motivos", res.motivos());
            m.put("atencao", res.atencao());
            itens.add(m);
        }
        Map<String, Object> criterios = new LinkedHashMap<>();
        criterios.put("pessoa", pessoa);
        criterios.put("idade", idade);
        criterios.put("condicoes", rotulos(String.join(",", condicoes), Codigos.CONDICOES));
        criterios.put("local", municipio == null ? uf : municipio + (uf == null ? "" : "/" + uf));
        criterios.put("somenteGratuito", gratuito);
        criterios.put("modalidade", modalidade == null ? null : Codigos.rotulo(Codigos.MODALIDADES, modalidade));
        criterios.put("acessibilidade", rotulos(String.join(",", acess), Codigos.ACESSIBILIDADE));
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("criterios", criterios);
        r.put("recomendacoes", itens);
        r.put("aviso", MotorCorrespondencia.AVISO);
        return r;
    }

    // ============================================================== auxiliares

    private void exigirInstituicao(Long id) {
        if (id == null || !instituicaoRepository.existsById(id)) throw new NaoEncontradoException("instituicao", id);
    }

    private static boolean gestor(ContextoUsuario ctx, Long idInstituicao) {
        return ctx.administrador() || (ctx.adminInstitucional() && ctx.instituicoes().contains(idInstituicao));
    }

    static String validar(String codigo, Map<String, String> vocabulario, String campo) {
        if (codigo == null || codigo.isBlank()) return null;
        String c = codigo.trim().toUpperCase(Locale.ROOT);
        if (!vocabulario.containsKey(c)) {
            throw new RegraNegocioException("Valor inválido para " + campo + ": " + codigo + ". Aceitos: "
                    + String.join(", ", vocabulario.keySet()));
        }
        return c;
    }

    static String vazio(String s) {
        return s == null || s.isBlank() ? null : s.trim();
    }

    static String str(Object o) {
        return o == null ? null : o.toString();
    }

    static Integer inteiro(Object o) {
        return o instanceof Number n ? n.intValue() : null;
    }

    /** MySQL devolve TINYINT(1) como Boolean ou Integer, conforme o driver: normaliza. */
    static Boolean bool(Object o) {
        if (o == null) return null;
        if (o instanceof Boolean b) return b;
        if (o instanceof Number n) return n.intValue() != 0;
        return "true".equalsIgnoreCase(o.toString()) || "1".equals(o.toString());
    }

    @SuppressWarnings("unchecked")
    static List<Map<String, Object>> listaDe(Object o) {
        return o instanceof List<?> l ? (List<Map<String, Object>>) l : List.of();
    }

    private static Map<String, String> mapa(String... pares) {
        Map<String, String> m = new LinkedHashMap<>();
        for (int i = 0; i < pares.length; i += 2) m.put(pares[i], pares[i + 1]);
        return java.util.Collections.unmodifiableMap(m);
    }

    static Set<String> conjunto(String... itens) {
        return new LinkedHashSet<>(List.of(itens));
    }
}
