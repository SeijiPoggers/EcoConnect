package br.com.ecoconnect.api.exception;

/** Registro não existe (HTTP 404). */
public class NaoEncontradoException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public NaoEncontradoException(String tabela, Object id) {
        super("Registro não encontrado em " + tabela + " (id " + id + ").");
    }

    public NaoEncontradoException(String mensagem) {
        super(mensagem);
    }
}
