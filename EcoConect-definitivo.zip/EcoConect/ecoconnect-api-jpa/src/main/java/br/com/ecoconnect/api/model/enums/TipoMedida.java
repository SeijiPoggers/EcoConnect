package br.com.ecoconnect.api.model.enums;

/** Tipo de medida do indicador. Valores idênticos ao ENUM do MySQL. */
public enum TipoMedida {
    NUMERICA, QUALITATIVA
}
