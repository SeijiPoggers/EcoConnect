package br.com.ecoconnect.api.model.enums;

/** Situação da conta do usuário. Valores idênticos ao ENUM do MySQL. */
public enum StatusUsuario {
    PENDENTE_ATIVACAO, ATIVO, BLOQUEADO, INATIVO
}
