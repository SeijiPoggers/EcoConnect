package br.com.ecoconnect.api.dto;

import jakarta.validation.constraints.NotNull;

public record DestinatarioComunicado(@NotNull(message = "campo obrigatório") Long idResponsavel) {
}
