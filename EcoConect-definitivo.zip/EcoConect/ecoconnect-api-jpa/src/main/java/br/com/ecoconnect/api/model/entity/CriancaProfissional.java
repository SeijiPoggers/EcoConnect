package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.time.LocalDateTime;

/** Tabela `crianca_profissional` (migration V2/V3). Gerada no mesmo padrão das entidades originais. */
@Entity
@Table(name = "crianca_profissional")
public class CriancaProfissional implements Entidade<Long>, PertenceACrianca {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_crianca_profissional", nullable = false)
    private Long idCriancaProfissional;

    @Column(name = "id_crianca", nullable = false)
    private Long idCrianca;

    @Column(name = "id_profissional", nullable = false)
    private Long idProfissional;

    @Size(max = 80)
    @Column(name = "funcao", length = 80)
    private String funcao;

    @Size(max = 10)
    @Column(name = "status", length = 10)
    private String status;

    @Column(name = "data_inicio")
    private LocalDate dataInicio;

    @Column(name = "data_fim")
    private LocalDate dataFim;

    @Column(name = "id_usuario_cadastro", nullable = false)
    private Long idUsuarioCadastro;

    @Column(name = "data_cadastro")
    private LocalDateTime dataCadastro;

    @PrePersist
    void aoInserir() {
        if (status == null) status = "ATIVO";
        if (dataInicio == null) dataInicio = LocalDate.now();
        if (dataCadastro == null) dataCadastro = LocalDateTime.now();
    }

    @Override
    public Long chave() {
        return idCriancaProfissional;
    }

    @Override
    public void definirChave(Long id) {
        this.idCriancaProfissional = id;
    }

    public Long getIdCriancaProfissional() {
        return idCriancaProfissional;
    }

    public void setIdCriancaProfissional(Long idCriancaProfissional) {
        this.idCriancaProfissional = idCriancaProfissional;
    }

    public Long getIdCrianca() {
        return idCrianca;
    }

    public void setIdCrianca(Long idCrianca) {
        this.idCrianca = idCrianca;
    }

    public Long getIdProfissional() {
        return idProfissional;
    }

    public void setIdProfissional(Long idProfissional) {
        this.idProfissional = idProfissional;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDate getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(LocalDate dataInicio) {
        this.dataInicio = dataInicio;
    }

    public LocalDate getDataFim() {
        return dataFim;
    }

    public void setDataFim(LocalDate dataFim) {
        this.dataFim = dataFim;
    }

    public Long getIdUsuarioCadastro() {
        return idUsuarioCadastro;
    }

    public void setIdUsuarioCadastro(Long idUsuarioCadastro) {
        this.idUsuarioCadastro = idUsuarioCadastro;
    }

    public LocalDateTime getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(LocalDateTime dataCadastro) {
        this.dataCadastro = dataCadastro;
    }
}
