package br.com.ecoconnect.api.model.entity;

/**
 * Entidade com chave primária simples. chave()/definirChave() dão acesso
 * genérico ao id (cada tabela tem um nome próprio: id_crianca, id_usuario...).
 * Os nomes não seguem o padrão getX/setX de propósito, para não aparecerem no JSON.
 */
public interface Entidade<ID> {

    ID chave();

    void definirChave(ID id);
}
