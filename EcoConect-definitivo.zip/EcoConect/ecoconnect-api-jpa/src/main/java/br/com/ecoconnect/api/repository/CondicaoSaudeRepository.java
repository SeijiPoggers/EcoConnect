package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.CondicaoSaude;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `condicao_saude` (Spring Data JPA). */
public interface CondicaoSaudeRepository extends JpaRepository<CondicaoSaude, Long> {
}
