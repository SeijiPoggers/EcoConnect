package br.com.ecoconnect.api.config;

import br.com.ecoconnect.api.model.entity.Perfil;
import br.com.ecoconnect.api.model.entity.Usuario;
import br.com.ecoconnect.api.model.enums.StatusUsuario;
import br.com.ecoconnect.api.repository.PerfilRepository;
import br.com.ecoconnect.api.repository.UsuarioRepository;
import br.com.ecoconnect.api.service.Verificacoes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Ao subir: cria os 3 perfis-base se a tabela PERFIL estiver vazia e, se configurado,
 * o primeiro administrador. Só INSERE dados; nunca altera a estrutura do banco.
 */
@Component
@Order(10)
public class DadosIniciais implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DadosIniciais.class);

    private final PerfilRepository perfilRepository;
    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${ecoconnect.dados-iniciais.perfis:true}")
    private boolean criarPerfis;

    @Value("${ecoconnect.dados-iniciais.admin-email:}")
    private String adminEmail;

    @Value("${ecoconnect.dados-iniciais.admin-senha:}")
    private String adminSenha;

    public DadosIniciais(PerfilRepository perfilRepository, UsuarioRepository usuarioRepository,
                         PasswordEncoder passwordEncoder) {
        this.perfilRepository = perfilRepository;
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public void run(String... args) {
        if (criarPerfis && perfilRepository.count() == 0) {
            perfil(Verificacoes.ADMINISTRADOR, "Gestão do sistema e da equipe");
            perfil(Verificacoes.PROFISSIONAL, "Profissional da equipe Ecocura");
            perfil(Verificacoes.RESPONSAVEL, "Responsável por uma ou mais crianças");
            log.info("Perfis ADMINISTRADOR, PROFISSIONAL e RESPONSAVEL criados.");
        }
        if (!adminEmail.isBlank() && !adminSenha.isBlank() && usuarioRepository.count() == 0) {
            Perfil admin = perfilRepository.findByNome(Verificacoes.ADMINISTRADOR).orElse(null);
            if (admin == null) {
                log.warn("Perfil ADMINISTRADOR não existe: administrador inicial não criado.");
                return;
            }
            Usuario u = new Usuario();
            u.setIdPerfil(admin.getIdPerfil());
            u.setNomeCompleto("Administrador");
            u.setEmail(adminEmail.trim().toLowerCase());
            u.setSenhaHash(passwordEncoder.encode(adminSenha));
            u.setStatus(StatusUsuario.ATIVO);
            u.setExigeTrocaSenha(Boolean.TRUE);
            usuarioRepository.save(u);
            log.info("Administrador inicial criado: {} (a senha deverá ser trocada no primeiro acesso)", u.getEmail());
        }
    }

    private void perfil(String nome, String descricao) {
        Perfil p = new Perfil();
        p.setNome(nome);
        p.setDescricao(descricao);
        perfilRepository.save(p);
    }
}
