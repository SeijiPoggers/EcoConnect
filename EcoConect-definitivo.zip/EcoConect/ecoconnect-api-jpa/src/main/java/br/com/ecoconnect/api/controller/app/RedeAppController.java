package br.com.ecoconnect.api.controller.app;

import br.com.ecoconnect.api.model.entity.Instituicao;
import br.com.ecoconnect.api.service.app.ProfissionaisAppService;
import br.com.ecoconnect.api.service.app.PessoasService;
import br.com.ecoconnect.api.service.app.RedeService;
import br.com.ecoconnect.api.service.app.SolicitacaoService;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** Rede de apoio (instituições, serviços, vagas, recomendações), solicitações de atendimento e profissionais. */
@RestController
public class RedeAppController {

    private final RedeService rede;
    private final SolicitacaoService solicitacoes;
    private final ProfissionaisAppService profissionais;
    private final PessoasService pessoas;

    public RedeAppController(RedeService rede, SolicitacaoService solicitacoes, ProfissionaisAppService profissionais, PessoasService pessoas) {
        this.rede = rede;
        this.solicitacoes = solicitacoes;
        this.profissionais = profissionais;
        this.pessoas = pessoas;
    }

    // ---------------------------------------------------------------- rede de apoio

    @GetMapping("/api/rede/catalogos")
    public Map<String, Object> catalogos() {
        return rede.catalogos();
    }

    @GetMapping("/api/rede/instituicoes")
    public List<Map<String, Object>> buscar(@RequestParam(name = "texto", required = false) String texto,
                                            @RequestParam(name = "uf", required = false) String uf,
                                            @RequestParam(name = "municipio", required = false) String municipio,
                                            @RequestParam(name = "condicao", required = false) String condicao,
                                            @RequestParam(name = "tipoServico", required = false) String tipoServico,
                                            @RequestParam(name = "gratuito", required = false) Boolean gratuito,
                                            @RequestParam(name = "sus", required = false) Boolean sus,
                                            @RequestParam(name = "idade", required = false) Integer idade,
                                            @RequestParam(name = "modalidade", required = false) String modalidade,
                                            @RequestParam(name = "acessibilidade", required = false) String acessibilidade,
                                            @RequestParam(name = "comVagas", required = false) Boolean comVagas,
                                            @RequestParam(name = "tipo", required = false) String tipo) {
        return rede.buscar(new RedeService.FiltroBusca(texto, uf, municipio, condicao, tipoServico, gratuito, sus, idade, modalidade,
                acessibilidade, comVagas, tipo));
    }

    @PostMapping("/api/rede/instituicoes")
    public Map<String, Object> criar(@RequestBody Instituicao dados) {
        return rede.criar(dados);
    }

    @GetMapping("/api/rede/instituicoes/{id}")
    public Map<String, Object> detalhe(@PathVariable("id") Long id) {
        return rede.detalhe(id);
    }

    @PutMapping("/api/rede/instituicoes/{id}")
    public Map<String, Object> alterar(@PathVariable("id") Long id, @RequestBody Instituicao dados) {
        return rede.alterar(id, dados);
    }

    @PostMapping("/api/rede/instituicoes/{id}/servicos")
    public Map<String, Object> novoServico(@PathVariable("id") Long id, @RequestBody RedeService.DadosServico dados) {
        return rede.salvarServico(id, null, dados);
    }

    @PutMapping("/api/rede/instituicoes/{id}/servicos/{idServico}")
    public Map<String, Object> alterarServico(@PathVariable("id") Long id, @PathVariable("idServico") Long idServico,
                                              @RequestBody RedeService.DadosServico dados) {
        return rede.salvarServico(id, idServico, dados);
    }

    @PatchMapping("/api/rede/instituicoes/{id}/vagas")
    public Map<String, Object> vagas(@PathVariable("id") Long id, @RequestBody RedeService.DadosVagas dados) {
        return rede.atualizarVagas(id, dados);
    }

    @PostMapping("/api/rede/instituicoes/{id}/membros")
    public Map<String, Object> adicionarMembro(@PathVariable("id") Long id, @RequestBody RedeService.NovoMembro dados) {
        return rede.adicionarMembro(id, dados);
    }

    @DeleteMapping("/api/rede/instituicoes/{id}/membros/{idMembro}")
    public Map<String, Object> removerMembro(@PathVariable("id") Long id, @PathVariable("idMembro") Long idMembro) {
        return rede.removerMembro(id, idMembro);
    }

    @GetMapping("/api/rede/instituicoes/{id}/painel")
    public Map<String, Object> painel(@PathVariable("id") Long id) {
        return rede.painel(id);
    }

    @DeleteMapping("/api/rede/instituicoes/{id}/vinculos/{idVinculo}")
    public List<Map<String, Object>> encerrarVinculo(@PathVariable("id") Long id, @PathVariable("idVinculo") Long idVinculo,
                                                     @RequestParam(name = "idCrianca") Long idCrianca) {
        return rede.encerrarVinculo(idCrianca, idVinculo);
    }

    @GetMapping("/api/rede/recomendacoes")
    public Map<String, Object> recomendacoes(@RequestParam(name = "idCrianca", required = false) Long idCrianca,
                                             @RequestParam(name = "idade", required = false) Integer idade,
                                             @RequestParam(name = "condicoes", required = false) String condicoes,
                                             @RequestParam(name = "uf", required = false) String uf,
                                             @RequestParam(name = "municipio", required = false) String municipio,
                                             @RequestParam(name = "somenteGratuito", required = false) Boolean somenteGratuito,
                                             @RequestParam(name = "modalidade", required = false) String modalidade,
                                             @RequestParam(name = "acessibilidade", required = false) String acessibilidade,
                                             @RequestParam(name = "tiposServico", required = false) String tiposServico,
                                             @RequestParam(name = "limite", required = false) Integer limite) {
        return rede.recomendar(new RedeService.PedidoRecomendacao(idCrianca, idade, condicoes, uf, municipio, somenteGratuito, modalidade,
                acessibilidade, tiposServico, limite));
    }

    // ---------------------------------------------------------------- solicitações de atendimento

    @GetMapping("/api/app/solicitacoes")
    public List<Map<String, Object>> solicitacoes(@RequestParam(name = "situacao", required = false) String situacao,
                                                  @RequestParam(name = "idInstituicao", required = false) Long idInstituicao) {
        return solicitacoes.listar(situacao, idInstituicao);
    }

    @PostMapping("/api/app/solicitacoes")
    public Map<String, Object> solicitar(@RequestBody SolicitacaoService.NovaSolicitacao dados) {
        return solicitacoes.criar(dados);
    }

    @GetMapping("/api/app/solicitacoes/{id}")
    public Map<String, Object> solicitacao(@PathVariable("id") Long id) {
        return solicitacoes.detalhe(id);
    }

    @PostMapping("/api/app/solicitacoes/{id}/resposta")
    public Map<String, Object> responder(@PathVariable("id") Long id, @RequestBody SolicitacaoService.Resposta dados) {
        return solicitacoes.responder(id, dados);
    }

    @PostMapping("/api/app/solicitacoes/{id}/cancelamento")
    public Map<String, Object> cancelar(@PathVariable("id") Long id) {
        return solicitacoes.cancelar(id);
    }

    // ---------------------------------------------------------------- profissionais

    @GetMapping("/api/app/profissionais")
    public List<Map<String, Object>> profissionais(@RequestParam(name = "texto", required = false) String texto) {
        return profissionais.listar(texto);
    }

    /** Diretório simples (nome e especialidade) usado para autorizar e designar profissionais. */
    @GetMapping("/api/app/diretorio-profissionais")
    public List<Map<String, Object>> diretorio(@RequestParam(name = "texto", required = false) String texto) {
        return pessoas.profissionais(texto);
    }

    @GetMapping("/api/app/profissionais/{id}")
    public Map<String, Object> profissional(@PathVariable("id") Long id) {
        return profissionais.detalhe(id);
    }

    @PutMapping("/api/app/profissionais/{id}")
    public Map<String, Object> alterarProfissional(@PathVariable("id") Long id, @RequestBody ProfissionaisAppService.AlteracaoProfissional dados) {
        return profissionais.alterar(id, dados);
    }

    @PostMapping("/api/app/profissionais/{id}/especialidades")
    public Map<String, Object> adicionarEspecialidade(@PathVariable("id") Long id,
                                                      @RequestBody ProfissionaisAppService.NovaEspecialidade dados) {
        return profissionais.adicionarEspecialidade(id, dados);
    }

    @DeleteMapping("/api/app/profissionais/{id}/especialidades/{idEspecialidade}")
    public Map<String, Object> removerEspecialidade(@PathVariable("id") Long id, @PathVariable("idEspecialidade") Integer idEspecialidade) {
        return profissionais.removerEspecialidade(id, idEspecialidade);
    }
}
