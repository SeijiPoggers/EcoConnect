package br.com.ecoconnect.api.controller.pessoa;

import br.com.ecoconnect.api.controller.base.CrudController;
import br.com.ecoconnect.api.model.entity.Profissional;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.pessoa.ProfissionalService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Profissionais. As especialidades ficam em /api/profissionais/{id}/especialidades. */
@RestController
@RequestMapping("/api/profissionais")
public class ProfissionalController extends CrudController<Profissional, Long> {

    private final ProfissionalService service;

    public ProfissionalController(ProfissionalService service) {
        this.service = service;
    }

    @Override
    protected CrudService<Profissional, Long> service() {
        return service;
    }
}
