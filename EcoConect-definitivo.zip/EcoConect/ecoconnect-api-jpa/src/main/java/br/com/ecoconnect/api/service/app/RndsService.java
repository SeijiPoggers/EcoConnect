package br.com.ecoconnect.api.service.app;

import br.com.ecoconnect.api.exception.NaoAutorizadoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.seguranca.ContextoAtual;
import br.com.ecoconnect.api.seguranca.ContextoUsuario;
import br.com.ecoconnect.api.service.AuditoriaService;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Adaptador da Rede Nacional de Dados em Saúde (RNDS).
 *
 * A RNDS só aceita sistemas credenciados pelo Ministério da Saúde, com certificado digital ICP-Brasil
 * do estabelecimento (autenticação mútua TLS) e modelos de informação homologados. Sem essas
 * credenciais, NENHUMA chamada é feita e a situação informa claramente que a integração está desligada.
 * Com credenciais configuradas, o administrador pode testar a autenticação (obtenção do token de acesso).
 * O envio de dados clínicos não é feito nesta versão: depende do modelo homologado no credenciamento.
 */
@Service
public class RndsService {

    @Value("${ecoconnect.rnds.habilitada:false}")
    private boolean habilitada;
    @Value("${ecoconnect.rnds.url-autenticacao:}")
    private String urlAutenticacao;
    @Value("${ecoconnect.rnds.url-servicos:}")
    private String urlServicos;
    @Value("${ecoconnect.rnds.certificado:}")
    private String certificado;
    @Value("${ecoconnect.rnds.senha-certificado:}")
    private String senhaCertificado;
    @Value("${ecoconnect.rnds.cnes-solicitante:}")
    private String cnesSolicitante;

    private final AuditoriaService auditoria;
    private volatile Map<String, Object> ultimoTeste;

    public RndsService(AuditoriaService auditoria) {
        this.auditoria = auditoria;
    }

    public boolean configurada() {
        return habilitada && !urlAutenticacao.isBlank() && !urlServicos.isBlank() && !certificado.isBlank()
                && Files.isRegularFile(Path.of(certificado)) && !cnesSolicitante.isBlank();
    }

    public Map<String, Object> situacao() {
        ContextoAtual.exigir();
        Map<String, Object> r = new LinkedHashMap<>();
        boolean ok = configurada();
        r.put("habilitada", habilitada);
        r.put("configurada", ok);
        r.put("ambiente", urlServicos.contains("hmg") ? "HOMOLOGACAO" : urlServicos.isBlank() ? null : "PRODUCAO");
        r.put("situacao", ok ? "Credenciais configuradas. Use \"Testar autenticação\" para validar o certificado."
                : "Integração desligada: este ambiente local não possui credenciamento na RNDS. Nenhum dado é enviado.");
        r.put("requisitos", List.of(
                "Credenciamento do estabelecimento de saúde no Portal de Serviços do DATASUS.",
                "Certificado digital ICP-Brasil (e-CNPJ) do estabelecimento, em arquivo .pfx/.p12.",
                "Modelo de informação homologado para o tipo de dado a ser enviado.",
                "Configuração em ecoconnect.properties: RNDS_HABILITADA, RNDS_URL_AUTENTICACAO, RNDS_URL_SERVICOS, "
                        + "RNDS_CERTIFICADO, RNDS_SENHA_CERTIFICADO e RNDS_CNES."));
        r.put("ultimoTeste", ultimoTeste);
        return r;
    }

    /** Pede um token de acesso ao serviço de autenticação da RNDS usando o certificado (mTLS). */
    public Map<String, Object> testarAutenticacao() {
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (!ctx.administrador()) throw new NaoAutorizadoException(403, "Somente o administrador testa a integração.");
        if (!configurada()) {
            throw new RegraNegocioException("A integração com a RNDS não está configurada neste ambiente. "
                    + "Sem credenciamento e certificado, nenhuma chamada é feita.");
        }
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("dataHora", LocalDateTime.now().withNano(0).toString());
        try {
            KeyStore ks = KeyStore.getInstance("PKCS12");
            try (InputStream in = Files.newInputStream(Path.of(certificado))) {
                ks.load(in, senhaCertificado.toCharArray());
            }
            KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            kmf.init(ks, senhaCertificado.toCharArray());
            SSLContext ssl = SSLContext.getInstance("TLS");
            ssl.init(kmf.getKeyManagers(), null, null);
            HttpClient cliente = HttpClient.newBuilder().sslContext(ssl).connectTimeout(Duration.ofSeconds(15)).build();
            HttpResponse<String> resp = cliente.send(HttpRequest.newBuilder(URI.create(urlAutenticacao))
                    .timeout(Duration.ofSeconds(30)).GET().build(), HttpResponse.BodyHandlers.ofString());
            boolean token = resp.statusCode() == 200 && resp.body() != null && resp.body().contains("access_token");
            r.put("sucesso", token);
            r.put("statusHttp", resp.statusCode());
            r.put("mensagem", token ? "Autenticação aceita: a RNDS emitiu um token de acesso (o token não é guardado)."
                    : "A RNDS respondeu sem token. Verifique o credenciamento e o certificado.");
        } catch (Exception e) {
            r.put("sucesso", false);
            r.put("mensagem", "Falha ao autenticar: " + e.getClass().getSimpleName() + (e.getMessage() == null ? "" : " - " + e.getMessage()));
        }
        ultimoTeste = r;
        auditoria.registrarDados(AcaoAuditoria.CONSULTA, "rnds", "autenticacao", null, null, r);
        return r;
    }
}
