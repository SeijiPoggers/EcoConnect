package br.com.ecoconnect.api.seguranca;

import br.com.ecoconnect.api.dto.ConferenciaDocumento;
import br.com.ecoconnect.api.dto.MudancaStatusAgendamento;
import br.com.ecoconnect.api.model.entity.Auditoria;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.core.MethodParameter;
import org.springframework.core.ResolvableType;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.RequestBodyAdviceAdapter;

/**
 * Impede que alguém grave em nome de outra pessoa: nos JSON recebidos, os campos que indicam
 * QUEM está agindo (idUsuarioSolicitante, idUsuarioRegistro, idUsuarioValidacao...) recebem
 * sempre o id do usuário autenticado, qualquer que seja o valor enviado pelo cliente.
 * Campos como Responsavel.idUsuario (a conta vinculada) não são alterados.
 */
@ControllerAdvice
public class AutorDaRequisicaoAdvice extends RequestBodyAdviceAdapter {

    static final Set<String> CAMPOS_DO_AUTOR = Set.of("idUsuarioSolicitante", "idUsuarioRegistro", "idUsuarioUpload",
            "idUsuarioCadastro", "idUsuarioDesignacao", "idUsuarioCriador", "idUsuarioAnalise", "idUsuarioValidacao",
            "idUsuarioAvaliacaoBase", "idUsuarioConfirmacao", "idUsuarioResposta", "idUsuarioAutor", "idUsuarioAtualizacao");
    /** Em entidades, só substituídos quando o cliente os envia (nas criações o serviço os mantém vazios). Em DTOs (records), sempre. */
    static final Set<String> SOMENTE_SE_ENVIADOS = Set.of("idUsuarioValidacao", "idUsuarioAnalise", "idUsuarioConfirmacao",
            "idUsuarioAvaliacaoBase", "idUsuarioResposta", "idUsuarioAtualizacao");
    /** Classes em que "idUsuario" significa o autor da ação. */
    static final Set<Class<?>> ID_USUARIO_E_AUTOR = Set.of(MudancaStatusAgendamento.class, ConferenciaDocumento.class,
            Auditoria.class);

    private final ObjectMapper mapper;
    private final Map<Class<?>, Set<String>> cache = new ConcurrentHashMap<>();

    public AutorDaRequisicaoAdvice(ObjectMapper mapper) {
        this.mapper = mapper;
    }

    @Override
    public boolean supports(MethodParameter p, Type tipo, Class<? extends HttpMessageConverter<?>> conversor) {
        return true;
    }

    @Override
    public HttpInputMessage beforeBodyRead(HttpInputMessage msg, MethodParameter p, Type tipo,
                                           Class<? extends HttpMessageConverter<?>> conversor) throws IOException {
        ContextoUsuario ctx = ContextoAtual.obter();
        Class<?> alvo = classe(tipo);
        if (alvo == null) alvo = ResolvableType.forMethodParameter(p).resolve();
        if (ctx == null || alvo == null) return msg;
        Set<String> campos = cache.computeIfAbsent(alvo, AutorDaRequisicaoAdvice::camposDoAutor);
        if (campos.isEmpty()) return msg;
        byte[] corpo = msg.getBody().readAllBytes();
        byte[] novo = corpo;
        if (corpo.length > 0) {
            JsonNode no = mapper.readTree(new ByteArrayInputStream(corpo));
            if (no instanceof ObjectNode obj) {
                for (String campo : campos) {
                    if (!alvo.isRecord() && SOMENTE_SE_ENVIADOS.contains(campo) && !obj.has(campo)) continue;
                    obj.put(campo, ctx.idUsuario());
                }
                novo = mapper.writeValueAsBytes(obj);
            }
        }
        final byte[] fim = novo;
        final HttpHeaders cab = msg.getHeaders();
        return new HttpInputMessage() {
            @Override
            public InputStream getBody() {
                return new ByteArrayInputStream(fim);
            }

            @Override
            public HttpHeaders getHeaders() {
                return cab;
            }
        };
    }

    static Set<String> camposDoAutor(Class<?> alvo) {
        Set<String> r = new HashSet<>();
        for (Class<?> c = alvo; c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                if (CAMPOS_DO_AUTOR.contains(f.getName())) r.add(f.getName());
                if ("idUsuario".equals(f.getName()) && ID_USUARIO_E_AUTOR.contains(alvo)) r.add("idUsuario");
            }
        }
        return Set.copyOf(r);
    }

    private static Class<?> classe(Type t) {
        if (t instanceof Class<?> c) return c;
        if (t instanceof ParameterizedType pt && pt.getRawType() instanceof Class<?> c) return c;
        return null;
    }
}
