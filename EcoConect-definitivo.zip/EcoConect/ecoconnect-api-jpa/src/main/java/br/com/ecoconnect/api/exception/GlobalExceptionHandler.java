package br.com.ecoconnect.api.exception;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import jakarta.validation.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.transaction.CannotCreateTransactionException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

/** Converte qualquer erro em JSON padronizado (ErroResposta) com o status HTTP correto. */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(NaoEncontradoException.class)
    public ResponseEntity<ErroResposta> naoEncontrado(NaoEncontradoException e) {
        return resposta(404, "Não encontrado", e.getMessage());
    }

    @ExceptionHandler(RegraNegocioException.class)
    public ResponseEntity<ErroResposta> regra(RegraNegocioException e) {
        return resposta(422, "Regra de negócio", e.getMessage());
    }

    @ExceptionHandler(ConflitoException.class)
    public ResponseEntity<ErroResposta> conflito(ConflitoException e) {
        return resposta(409, "Conflito", e.getMessage());
    }

    @ExceptionHandler(NaoAutorizadoException.class)
    public ResponseEntity<ErroResposta> naoAutorizado(NaoAutorizadoException e) {
        String rotulo = switch (e.getStatus()) {
            case 401 -> "Não autorizado";
            case 429 -> "Muitas tentativas";
            default -> "Acesso negado";
        };
        return resposta(e.getStatus(), rotulo, e.getMessage());
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ErroResposta> argumento(IllegalArgumentException e) {
        return resposta(400, "Dados inválidos", e.getMessage());
    }

    @ExceptionHandler(RequisicaoInvalidaException.class)
    public ResponseEntity<ErroResposta> invalida(RequisicaoInvalidaException e) {
        return resposta(400, "Requisição inválida", e.getMessage());
    }

    /** Falhas de @Valid nos campos do JSON. */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErroResposta> validacao(MethodArgumentNotValidException e) {
        Map<String, String> campos = new LinkedHashMap<>();
        for (FieldError f : e.getBindingResult().getFieldErrors()) {
            campos.putIfAbsent(f.getField(), f.getDefaultMessage());
        }
        return ResponseEntity.status(400).body(new ErroResposta(LocalDateTime.now(), 400,
                "Dados inválidos", "Verifique os campos informados.", campos));
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ErroResposta> validacaoEntidade(ConstraintViolationException e) {
        Map<String, String> campos = new LinkedHashMap<>();
        e.getConstraintViolations().forEach(v -> campos.putIfAbsent(v.getPropertyPath().toString(), v.getMessage()));
        return ResponseEntity.status(400).body(new ErroResposta(LocalDateTime.now(), 400,
                "Dados inválidos", "Verifique os campos informados.", campos));
    }

    /** JSON mal formado ou valor de ENUM inexistente. */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ErroResposta> jsonInvalido(HttpMessageNotReadableException e) {
        Throwable causa = e.getCause();
        if (causa instanceof InvalidFormatException f && f.getTargetType() != null && f.getTargetType().isEnum()) {
            String campo = f.getPath().isEmpty() ? "?" : f.getPath().get(f.getPath().size() - 1).getFieldName();
            return resposta(400, "Valor inválido", "Valor '" + f.getValue() + "' inválido para " + campo
                    + ". Aceitos: " + Arrays.toString(f.getTargetType().getEnumConstants()));
        }
        if (causa instanceof InvalidFormatException f) {
            String campo = f.getPath().isEmpty() ? "?" : f.getPath().get(f.getPath().size() - 1).getFieldName();
            return resposta(400, "Valor inválido", "Valor '" + f.getValue() + "' inválido para " + campo
                    + ". Datas: aaaa-mm-dd; data e hora: aaaa-mm-ddThh:mm:ss.");
        }
        return resposta(400, "JSON inválido", "O corpo da requisição não é um JSON válido.");
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ErroResposta> tipoParametro(MethodArgumentTypeMismatchException e) {
        return resposta(400, "Parâmetro inválido", "Valor '" + e.getValue() + "' inválido para " + e.getName() + ".");
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ErroResposta> metodo(HttpRequestMethodNotSupportedException e) {
        return resposta(405, "Operação não permitida",
                "Método " + e.getMethod() + " não é permitido neste endereço. "
                        + "Dados de saúde, histórico e auditoria não são excluídos nem sobrescritos.");
    }

    @ExceptionHandler(NoResourceFoundException.class)
    public ResponseEntity<ErroResposta> rota(NoResourceFoundException e) {
        return resposta(404, "Endereço não encontrado", "Não existe o endereço /" + e.getResourcePath() + ".");
    }

    @ExceptionHandler({CannotCreateTransactionException.class, DataAccessResourceFailureException.class})
    public ResponseEntity<ErroResposta> semBanco(Exception e) {
        log.error("Sem conexão com o MySQL", e);
        return resposta(503, "Banco indisponível",
                "Não foi possível conectar ao MySQL. Verifique se ele está ligado e as configurações de acesso.");
    }

    /** Demais erros: se a causa for do MySQL, traduz; senão, 500. */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErroResposta> geral(Exception e) {
        SQLException sql = causaSql(e);
        if (sql != null) {
            int status = MensagensBanco.status(sql);
            if (status == 500) log.error("Erro SQL", e);
            return resposta(status, "Erro do banco de dados", MensagensBanco.traduzir(sql));
        }
        Throwable t = e;
        while (t != null) {
            if (t instanceof ConstraintViolationException cv) {
                return validacaoEntidade(cv);
            }
            t = t.getCause();
        }
        log.error("Erro inesperado", e);
        return resposta(500, "Erro interno", "Erro inesperado. Veja o log da API.");
    }

    private static SQLException causaSql(Throwable e) {
        SQLException encontrada = null;
        Throwable t = e;
        while (t != null) {
            if (t instanceof SQLException s) encontrada = s;
            if (t.getCause() == t) break;
            t = t.getCause();
        }
        return encontrada;
    }

    private static ResponseEntity<ErroResposta> resposta(int status, String erro, String mensagem) {
        return ResponseEntity.status(status).body(ErroResposta.de(status, erro, mensagem));
    }
}
