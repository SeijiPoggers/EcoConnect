package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.Crianca;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `crianca` (Spring Data JPA). */
public interface CriancaRepository extends JpaRepository<Crianca, Long> {
}
