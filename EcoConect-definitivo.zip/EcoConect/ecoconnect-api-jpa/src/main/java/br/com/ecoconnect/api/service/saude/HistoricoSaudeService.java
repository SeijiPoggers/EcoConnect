package br.com.ecoconnect.api.service.saude;

import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.HistoricoSaude;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.SituacaoRegistro;
import br.com.ecoconnect.api.repository.CriancaDiagnosticoRepository;
import br.com.ecoconnect.api.repository.HistoricoSaudeRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.Verificacoes;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;

/**
 * HISTORICO_SAUDE: linha do tempo de eventos de saúde (também anteriores ao ingresso).
 * Não é sobrescrito: a correção é feita por SUBSTITUIÇÃO (novo registro aponta o antigo,
 * que vira SUBSTITUIDO). DELETE = REMOVIDO_LOGICAMENTE.
 */
@Service
public class HistoricoSaudeService extends RegistroSaudeService<HistoricoSaude> {

    private final CriancaDiagnosticoRepository criancaDiagnosticoRepository;

    public HistoricoSaudeService(HistoricoSaudeRepository repository, AuditoriaService auditoria,
                                 Verificacoes verificacoes, CriancaDiagnosticoRepository criancaDiagnosticoRepository) {
        super(repository, auditoria, "historico_saude", verificacoes);
        this.criancaDiagnosticoRepository = criancaDiagnosticoRepository;
    }

    @Override
    protected void antesDeCriar(HistoricoSaude h) {
        super.antesDeCriar(h);
        h.setSituacaoRegistro(SituacaoRegistro.ATIVO);
        h.setIdHistoricoSaudeSubstituido(null);
    }

    @Override
    protected void validarEspecifico(HistoricoSaude h) {
        // FK composta (id_crianca_diagnostico, id_crianca): o diagnóstico citado precisa ser da mesma criança
        if (h.getIdCriancaDiagnostico() != null && !criancaDiagnosticoRepository
                .existsByIdCriancaDiagnosticoAndIdCrianca(h.getIdCriancaDiagnostico(), h.getIdCrianca())) {
            throw new RegraNegocioException("O diagnóstico " + h.getIdCriancaDiagnostico()
                    + " não existe ou não é da criança " + h.getIdCrianca() + ".");
        }
        if (h.getDataEventoFim() != null && h.getDataEventoFim().isBefore(h.getDataEvento())) {
            throw new RegraNegocioException("A data de fim do evento não pode ser antes da data do evento.");
        }
    }

    @Override
    protected void validarAtualizacao(HistoricoSaude atual, HistoricoSaude dados) {
        throw new RegraNegocioException("Histórico de saúde não é sobrescrito. Use POST /api/historicos-saude/"
                + atual.getIdHistoricoSaude() + "/substituicao para corrigir.");
    }

    @Override
    protected Set<String> camposProtegidosExtras() {
        return Set.of("situacaoRegistro", "idHistoricoSaudeSubstituido");
    }

    /** Cria a nova versão e marca a anterior como SUBSTITUIDO. */
    @Transactional
    public HistoricoSaude substituir(Long id, HistoricoSaude nova) {
        HistoricoSaude antiga = buscar(id);
        if (antiga.getSituacaoRegistro() != SituacaoRegistro.ATIVO) {
            throw new RegraNegocioException("Só registros ATIVOS podem ser substituídos (este está " + antiga.getSituacaoRegistro() + ").");
        }
        nova.setIdCrianca(antiga.getIdCrianca());
        HistoricoSaude criada = criar(nova);
        criada.setIdHistoricoSaudeSubstituido(antiga.getIdHistoricoSaude());
        criada = repository.saveAndFlush(criada);

        String antes = auditoria.json(antiga);
        antiga.setSituacaoRegistro(SituacaoRegistro.SUBSTITUIDO);
        salvarAlteracao(antiga, antes, AcaoAuditoria.ATUALIZACAO);
        return criada;
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.LOGICA;
    }

    @Override
    protected void aplicarExclusaoLogica(HistoricoSaude h) {
        h.setSituacaoRegistro(SituacaoRegistro.REMOVIDO_LOGICAMENTE);
    }
}
