package br.com.ecoconnect.api.service.agenda;

import br.com.ecoconnect.api.service.app.ConflitoAgenda;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.ecoconnect.api.exception.ConflitoException;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Agendamento;
import br.com.ecoconnect.api.model.entity.AgendamentoProfissional;
import br.com.ecoconnect.api.model.entity.AgendamentoProfissionalId;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.StatusAgendamento;
import br.com.ecoconnect.api.repository.AgendamentoProfissionalRepository;
import br.com.ecoconnect.api.repository.AgendamentoRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.Verificacoes;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.EnumSet;
import java.util.List;

/** AGENDAMENTO_PROFISSIONAL: profissionais previstos para um agendamento, com quem designou e quando. */
@Service
public class AgendamentoProfissionalService {

    private static final String TABELA = "agendamento_profissional";

    private final AgendamentoProfissionalRepository repository;

    private ConflitoAgenda conflitoAgenda;

    @Autowired(required = false)
    public void setConflitoAgenda(ConflitoAgenda conflitoAgenda) {
        this.conflitoAgenda = conflitoAgenda;
    }
    private final AgendamentoRepository agendamentoRepository;
    private final Verificacoes verificacoes;
    private final AuditoriaService auditoria;

    public AgendamentoProfissionalService(AgendamentoProfissionalRepository repository,
                                          AgendamentoRepository agendamentoRepository,
                                          Verificacoes verificacoes, AuditoriaService auditoria) {
        this.repository = repository;
        this.agendamentoRepository = agendamentoRepository;
        this.verificacoes = verificacoes;
        this.auditoria = auditoria;
    }

    @Transactional(readOnly = true)
    public List<AgendamentoProfissional> listar(Long idAgendamento) {
        agendamento(idAgendamento);
        return repository.findByIdAgendamento(idAgendamento);
    }

    @Transactional
    public AgendamentoProfissional designar(Long idAgendamento, Long idProfissional, Long idUsuarioDesignacao) {
        Agendamento ag = agendamento(idAgendamento);
        exigirEmAberto(ag);
        if (conflitoAgenda != null && ag.getStatus() == StatusAgendamento.CONFIRMADO) {
            conflitoAgenda.verificarProfissional(idAgendamento, idProfissional, ag.getDataHoraInicio(), ag.getDataHoraFim());
        }
        verificacoes.profissionalAtivo(idProfissional);
        verificacoes.usuarioDaEquipe(idUsuarioDesignacao, "Quem designa o profissional");
        AgendamentoProfissionalId id = new AgendamentoProfissionalId(idAgendamento, idProfissional);
        if (repository.existsById(id)) throw new ConflitoException("Profissional já designado para este agendamento.");
        AgendamentoProfissional ap = new AgendamentoProfissional();
        ap.setIdAgendamento(idAgendamento);
        ap.setIdProfissional(idProfissional);
        ap.setIdUsuarioDesignacao(idUsuarioDesignacao);
        AgendamentoProfissional salvo = repository.saveAndFlush(ap);
        auditoria.registrar(AcaoAuditoria.CRIACAO, TABELA, salvo, null, salvo);
        return salvo;
    }

    @Transactional
    public void remover(Long idAgendamento, Long idProfissional) {
        exigirEmAberto(agendamento(idAgendamento));
        AgendamentoProfissionalId id = new AgendamentoProfissionalId(idAgendamento, idProfissional);
        AgendamentoProfissional ap = repository.findById(id).orElseThrow(() -> new NaoEncontradoException(TABELA, id));
        String antes = auditoria.json(ap);
        repository.delete(ap);
        repository.flush();
        auditoria.registrar(AcaoAuditoria.ATUALIZACAO, TABELA, ap, antes, null);
    }

    private Agendamento agendamento(Long id) {
        return agendamentoRepository.findById(id).orElseThrow(() -> new NaoEncontradoException("agendamento", id));
    }

    private static void exigirEmAberto(Agendamento a) {
        if (!EnumSet.of(StatusAgendamento.SOLICITADO, StatusAgendamento.EM_ANALISE, StatusAgendamento.CONFIRMADO)
                .contains(a.getStatus())) {
            throw new RegraNegocioException("A equipe só pode ser alterada em agendamentos SOLICITADO, EM_ANALISE ou CONFIRMADO.");
        }
    }
}
