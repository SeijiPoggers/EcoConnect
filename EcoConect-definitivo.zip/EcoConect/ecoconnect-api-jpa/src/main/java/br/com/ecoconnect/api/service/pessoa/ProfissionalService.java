package br.com.ecoconnect.api.service.pessoa;

import br.com.ecoconnect.api.exception.ConflitoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Profissional;
import br.com.ecoconnect.api.model.entity.Usuario;
import br.com.ecoconnect.api.repository.ProfissionalRepository;
import br.com.ecoconnect.api.repository.ResponsavelRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.Verificacoes;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;

import java.util.Set;

/** PROFISSIONAL: cadastro complementar (1:1) de um usuário com perfil PROFISSIONAL. DELETE desativa. */
@Service
public class ProfissionalService extends CrudService<Profissional, Long> {

    private final ProfissionalRepository profissionalRepository;
    private final ResponsavelRepository responsavelRepository;
    private final Verificacoes verificacoes;

    public ProfissionalService(ProfissionalRepository repository, AuditoriaService auditoria,
                               ResponsavelRepository responsavelRepository, Verificacoes verificacoes) {
        super(repository, auditoria, "profissional");
        this.profissionalRepository = repository;
        this.responsavelRepository = responsavelRepository;
        this.verificacoes = verificacoes;
    }

    /** RI-02: perfil PROFISSIONAL e sem cadastro de responsável. */
    @Override
    protected void antesDeCriar(Profissional p) {
        Usuario u = verificacoes.usuario(p.getIdUsuario());
        if (!Verificacoes.PROFISSIONAL.equals(verificacoes.perfilDe(u))) {
            throw new RegraNegocioException("O usuário " + u.getIdUsuario() + " não tem perfil PROFISSIONAL.");
        }
        if (profissionalRepository.existsByIdUsuario(u.getIdUsuario())) {
            throw new ConflitoException("O usuário " + u.getIdUsuario() + " já tem cadastro de profissional.");
        }
        if (responsavelRepository.existsByIdUsuario(u.getIdUsuario())) {
            throw new RegraNegocioException("Um usuário não pode ser profissional e responsável ao mesmo tempo.");
        }
    }

    @Override
    protected Set<String> camposProtegidos() {
        return Set.of("idUsuario");
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.LOGICA;
    }

    @Override
    protected void aplicarExclusaoLogica(Profissional p) {
        p.setAtivo(false);
    }
}
