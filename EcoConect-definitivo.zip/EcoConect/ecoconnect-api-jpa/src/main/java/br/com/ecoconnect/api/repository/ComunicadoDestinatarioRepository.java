package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.ComunicadoDestinatario;
import br.com.ecoconnect.api.model.entity.ComunicadoDestinatarioId;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `comunicado_destinatario` (Spring Data JPA). */
public interface ComunicadoDestinatarioRepository extends JpaRepository<ComunicadoDestinatario, ComunicadoDestinatarioId> {

    List<ComunicadoDestinatario> findByIdComunicado(Long idComunicado);
}
