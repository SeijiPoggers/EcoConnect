package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.Objetivo;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `objetivo` (Spring Data JPA). */
public interface ObjetivoRepository extends JpaRepository<Objetivo, Long> {
}
