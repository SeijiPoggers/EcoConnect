package br.com.ecoconnect.api.service.catalogo;

import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Perfil;
import br.com.ecoconnect.api.repository.PerfilRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.Verificacoes;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;

import java.util.Set;

/**
 * PERFIL: ADMINISTRADOR, PROFISSIONAL e RESPONSAVEL.
 * Os três perfis-base não podem ser renomeados nem excluídos, porque as regras da API dependem deles.
 */
@Service
public class PerfilService extends CrudService<Perfil, Integer> {

    private static final Set<String> BASE = Set.of(Verificacoes.ADMINISTRADOR, Verificacoes.PROFISSIONAL, Verificacoes.RESPONSAVEL);

    public PerfilService(PerfilRepository repository, AuditoriaService auditoria) {
        super(repository, auditoria, "perfil");
    }

    @Override
    protected void antesDeCriar(Perfil p) {
        p.setNome(p.getNome().trim().toUpperCase());
    }

    @Override
    protected void validarAtualizacao(Perfil atual, Perfil dados) {
        if (BASE.contains(atual.getNome()) && !atual.getNome().equalsIgnoreCase(dados.getNome().trim())) {
            throw new RegraNegocioException("O perfil " + atual.getNome() + " é usado pelas regras do sistema e não pode ser renomeado.");
        }
        dados.setNome(dados.getNome().trim().toUpperCase());
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.FISICA;
    }

    @Override
    protected void validarExclusaoFisica(Perfil p) {
        if (BASE.contains(p.getNome())) {
            throw new RegraNegocioException("O perfil " + p.getNome() + " é usado pelas regras do sistema e não pode ser excluído.");
        }
    }
}
