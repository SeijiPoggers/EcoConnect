package br.com.ecoconnect.api.service.app;

import br.com.ecoconnect.api.dominio.LeitorCnes;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.seguranca.ContextoAtual;
import br.com.ecoconnect.api.service.AuditoriaService;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Integração com o SUS pelos dados abertos do CNES (Cadastro Nacional de Estabelecimentos de Saúde):
 * busca de UBS, CAPS e CER por município, orientação em linguagem simples sobre os caminhos de
 * atendimento e importação do arquivo oficial do DATASUS (feita pelo administrador, sem internet).
 */
@Service
public class SusService {

    public static final Map<String, String> CATEGORIAS = Map.of(
            "UBS", "Unidade Básica de Saúde (UBS)",
            "CAPS", "Centro de Atenção Psicossocial (CAPS)",
            "CAPS_INFANTIL", "CAPS Infantojuvenil (CAPSi)",
            "CAPS_AD", "CAPS Álcool e Drogas (CAPS AD)",
            "CER", "Centro Especializado em Reabilitação (CER)",
            "POLICLINICA", "Policlínica / ambulatório de especialidades",
            "HOSPITAL", "Hospital",
            "OUTRO", "Outro estabelecimento");

    /** Categorias guardadas na importação (as demais são ignoradas para manter o catálogo enxuto). */
    private static final Set<String> IMPORTADAS = Set.of("UBS", "CAPS", "CAPS_INFANTIL", "CAPS_AD", "CER", "POLICLINICA");
    private static final int LOTE = 500;

    private final Consultas consultas;
    private final JdbcTemplate jdbc;
    private final AuditoriaService auditoria;

    public SusService(Consultas consultas, JdbcTemplate jdbc, AuditoriaService auditoria) {
        this.consultas = consultas;
        this.jdbc = jdbc;
        this.auditoria = auditoria;
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> estabelecimentos(String uf, String municipio, String categoria, String texto) {
        ContextoAtual.exigir();
        StringBuilder sql = new StringBuilder("SELECT codigo_cnes AS codigoCnes, nome, categoria, municipio, uf, logradouro, numero, "
                + "bairro, cep, telefone, email, latitude, longitude, fonte, " + Consultas.dt("data_importacao") + " AS dataImportacao "
                + "FROM estabelecimento_sus WHERE 1 = 1");
        List<Object> args = new ArrayList<>();
        if (RedeService.vazio(uf) != null) {
            sql.append(" AND uf = ?");
            args.add(uf.trim().toUpperCase(Locale.ROOT));
        }
        if (RedeService.vazio(municipio) != null) {
            sql.append(" AND LOWER(municipio) = ?");
            args.add(municipio.trim().toLowerCase(Locale.ROOT));
        }
        if (RedeService.vazio(categoria) != null) {
            String c = categoria.trim().toUpperCase(Locale.ROOT);
            if ("CAPS_TODOS".equals(c)) {
                sql.append(" AND categoria IN ('CAPS','CAPS_INFANTIL','CAPS_AD')");
            } else {
                if (!CATEGORIAS.containsKey(c)) throw new RegraNegocioException("Categoria inválida: " + categoria);
                sql.append(" AND categoria = ?");
                args.add(c);
            }
        }
        if (RedeService.vazio(texto) != null) {
            sql.append(" AND (LOWER(nome) LIKE ? OR LOWER(bairro) LIKE ?)");
            String t = "%" + texto.trim().toLowerCase(Locale.ROOT) + "%";
            args.add(t);
            args.add(t);
        }
        sql.append(" ORDER BY FIELD(categoria,'UBS','CAPS_INFANTIL','CAPS','CER','CAPS_AD','POLICLINICA','HOSPITAL','OUTRO'), nome LIMIT 300");
        List<Map<String, Object>> r = consultas.lista(sql.toString(), args.toArray());
        for (Map<String, Object> e : r) {
            e.put("categoriaRotulo", CATEGORIAS.getOrDefault(String.valueOf(e.get("categoria")), String.valueOf(e.get("categoria"))));
            e.put("demonstracao", "DEMONSTRACAO".equals(e.get("fonte")));
        }
        return r;
    }

    @Transactional(readOnly = true)
    public Map<String, Object> estabelecimento(String codigoCnes) {
        ContextoAtual.exigir();
        Map<String, Object> e = consultas.um("SELECT codigo_cnes AS codigoCnes, nome, razao_social AS razaoSocial, categoria, "
                + "codigo_tipo_unidade AS codigoTipoUnidade, codigo_municipio AS codigoMunicipio, municipio, uf, logradouro, numero, "
                + "bairro, cep, telefone, email, latitude, longitude, fonte, " + Consultas.dt("data_importacao") + " AS dataImportacao "
                + "FROM estabelecimento_sus WHERE codigo_cnes = ?", codigoCnes);
        if (e == null) throw new NaoEncontradoException("estabelecimento_sus", codigoCnes);
        e.put("categoriaRotulo", CATEGORIAS.getOrDefault(String.valueOf(e.get("categoria")), String.valueOf(e.get("categoria"))));
        e.put("demonstracao", "DEMONSTRACAO".equals(e.get("fonte")));
        e.put("orientacao", guiaDaCategoria(String.valueOf(e.get("categoria"))));
        return e;
    }

    /** Municípios com estabelecimentos no catálogo (para o filtro da tela). */
    @Transactional(readOnly = true)
    public List<Map<String, Object>> municipios() {
        ContextoAtual.exigir();
        return consultas.lista("SELECT uf, municipio, COUNT(*) AS total FROM estabelecimento_sus WHERE municipio IS NOT NULL "
                + "GROUP BY uf, municipio ORDER BY uf, municipio");
    }

    @Transactional(readOnly = true)
    public Map<String, Object> situacaoCatalogo() {
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("porFonte", consultas.lista("SELECT fonte, COUNT(*) AS total, " + Consultas.dt("MAX(data_importacao)")
                + " AS ultimaAtualizacao FROM estabelecimento_sus GROUP BY fonte"));
        r.put("porCategoria", consultas.lista("SELECT categoria, COUNT(*) AS total FROM estabelecimento_sus GROUP BY categoria ORDER BY total DESC"));
        r.put("comoAtualizar", "Baixe a \"Base de dados CNES\" no portal de dados abertos do DATASUS (arquivo tbEstabelecimento*.csv) "
                + "ou a exportação de estabelecimentos do seu estado e importe em Administração > Catálogo do SUS.");
        return r;
    }

    // ============================================================== importação

    /**
     * Importa o arquivo do CNES. Atualiza registros existentes (mesmo código CNES) e acrescenta os novos.
     * @param ufFiltro opcional: importa apenas a UF informada (reduz o volume do arquivo nacional)
     */
    @Transactional
    public Map<String, Object> importar(InputStream arquivo, String nomeArquivo, String ufFiltro) throws IOException {
        String uf = RedeService.vazio(ufFiltro) == null ? null : ufFiltro.trim().toUpperCase(Locale.ROOT);
        List<Object[]> lote = new ArrayList<>();
        int[] contagem = new int[3]; // 0 = gravados, 1 = fora do filtro/categoria, 2 = sem município
        String sql = "INSERT INTO estabelecimento_sus (codigo_cnes, nome, razao_social, categoria, codigo_tipo_unidade, "
                + "codigo_municipio, municipio, uf, logradouro, numero, bairro, cep, telefone, email, latitude, longitude, fonte, "
                + "data_importacao) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'CNES_ARQUIVO', NOW()) "
                + "ON DUPLICATE KEY UPDATE nome = VALUES(nome), razao_social = VALUES(razao_social), categoria = VALUES(categoria), "
                + "codigo_tipo_unidade = VALUES(codigo_tipo_unidade), codigo_municipio = VALUES(codigo_municipio), "
                + "municipio = COALESCE(VALUES(municipio), municipio), uf = COALESCE(VALUES(uf), uf), logradouro = VALUES(logradouro), "
                + "numero = VALUES(numero), bairro = VALUES(bairro), cep = VALUES(cep), telefone = VALUES(telefone), "
                + "email = VALUES(email), latitude = VALUES(latitude), longitude = VALUES(longitude), fonte = 'CNES_ARQUIVO', "
                + "data_importacao = NOW()";
        LeitorCnes.Estatisticas est = LeitorCnes.ler(arquivo, e -> {
            if (!IMPORTADAS.contains(e.categoria()) || (uf != null && !uf.equals(e.uf()))) {
                contagem[1]++;
                return;
            }
            if (e.codigoMunicipio() == null || e.codigoMunicipio().isBlank()) {
                contagem[2]++;
                return;
            }
            lote.add(new Object[]{e.codigoCnes(), corte(e.nome(), 200), corte(e.razaoSocial(), 200), e.categoria(),
                    e.codigoTipoUnidade(), corte(e.codigoMunicipio(), 6), corte(e.municipio(), 80), e.uf(), corte(e.logradouro(), 150),
                    corte(e.numero(), 20), corte(e.bairro(), 80), corte(e.cep(), 8), corte(e.telefone(), 30), corte(e.email(), 150),
                    e.latitude(), e.longitude()});
            if (lote.size() >= LOTE) {
                jdbc.batchUpdate(sql, lote);
                contagem[0] += lote.size();
                lote.clear();
            }
        });
        if (!lote.isEmpty()) {
            jdbc.batchUpdate(sql, lote);
            contagem[0] += lote.size();
        }
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("arquivo", nomeArquivo);
        r.put("linhasLidas", est.linhasLidas());
        r.put("estabelecimentosGravados", contagem[0]);
        r.put("ignoradosPorCategoriaOuUf", contagem[1]);
        r.put("ignoradosSemMunicipio", contagem[2]);
        r.put("linhasInvalidas", est.linhasIgnoradas());
        r.put("avisos", est.avisos());
        auditoria.registrarDados(AcaoAuditoria.CRIACAO, "estabelecimento_sus", "importacao", null, null, r);
        return r;
    }

    private static String corte(String s, int max) {
        if (s == null) return null;
        String t = s.trim();
        if (t.isEmpty()) return null;
        return t.length() <= max ? t : t.substring(0, max);
    }

    // ============================================================== guia em linguagem simples

    public Map<String, Object> guia() {
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("introducao", "No SUS, o cuidado começa quase sempre pela Unidade Básica de Saúde (UBS) mais perto da sua casa. "
                + "É ela que acompanha a pessoa e, quando precisa, encaminha para serviços especializados. "
                + "As regras de cada serviço podem mudar de um município para outro: confirme por telefone antes de ir.");
        r.put("portas", List.of(guiaDaCategoria("UBS"), guiaDaCategoria("CAPS_INFANTIL"), guiaDaCategoria("CAPS"),
                guiaDaCategoria("CER"), guiaDaCategoria("POLICLINICA")));
        r.put("caminhos", List.of(
                caminho("Suspeito que meu filho ou minha filha pode ser autista",
                        "Agende uma consulta na UBS e conte o que você observa no dia a dia (anote exemplos).",
                        "Leve a caderneta da criança e, se tiver, relatórios da escola ou da creche.",
                        "A equipe da UBS avalia e pode encaminhar para avaliação especializada (CER, CAPSi ou ambulatório), conforme o município.",
                        "Enquanto espera, você pode procurar o CAPSi da sua região, que costuma acolher sem encaminhamento.",
                        "Guarde cópias de todos os documentos e pergunte em que etapa da fila você está."),
                caminho("A escola diz que meu filho pode ter TDAH ou dislexia",
                        "Peça à escola um relatório por escrito do que foi observado.",
                        "Leve o relatório à UBS para a primeira avaliação.",
                        "A Lei nº 14.254/2021 garante acompanhamento integral a estudantes com dislexia, TDAH ou outro transtorno de aprendizagem.",
                        "A escola pode adaptar atividades mesmo antes de um laudo; converse com a coordenação."),
                caminho("Sou adulto e acho que posso ser autista ou ter TDAH",
                        "Procure a UBS e explique as dificuldades que você percebe (estudo, trabalho, rotina, relações).",
                        "Se houver sofrimento intenso, o CAPS da sua região acolhe adultos sem encaminhamento.",
                        "Pergunte quais especialistas atendem adultos no seu município: a oferta varia bastante.",
                        "Você pode preferir contato por escrito: informe isso à equipe."),
                caminho("Alguém está em crise agora",
                        "Se houver risco imediato à vida, ligue 192 (SAMU) ou vá à UPA ou ao pronto-socorro mais próximo.",
                        "Para conversar com alguém em sofrimento emocional, o CVV atende 24 horas pelo telefone 188 (ligação gratuita).",
                        "Depois da crise, procure o CAPS ou a UBS para organizar o acompanhamento.")));
        r.put("documentos", List.of("Cartão Nacional de Saúde (Cartão SUS) ou CPF", "Documento com foto do responsável",
                "Comprovante de endereço", "Caderneta da criança (quando for criança)",
                "Relatórios, exames e laudos anteriores, se houver"));
        r.put("aviso", "Estas orientações são gerais e não substituem a avaliação de profissionais de saúde.");
        return r;
    }

    static Map<String, Object> guiaDaCategoria(String categoria) {
        return switch (categoria == null ? "" : categoria) {
            case "UBS" -> porta("UBS", "Unidade Básica de Saúde (UBS)", "Posto de saúde do bairro. É a porta de entrada do SUS.",
                    "Para a primeira conversa sobre o desenvolvimento, a atenção, a aprendizagem ou o comportamento; para pedir encaminhamentos.",
                    "Vá à UBS do seu bairro ou ligue para agendar. Não precisa de encaminhamento.");
            case "CAPS_INFANTIL" -> porta("CAPS_INFANTIL", "CAPS Infantojuvenil (CAPSi)",
                    "Serviço de saúde mental para crianças e adolescentes. Em muitos municípios acompanha crianças autistas.",
                    "Quando há sofrimento intenso ou persistente, dificuldades importantes na rotina ou crises.",
                    "Em geral, pode procurar diretamente, sem encaminhamento (acolhimento de porta aberta). Confirme o horário.");
            case "CAPS" -> porta("CAPS", "Centro de Atenção Psicossocial (CAPS)",
                    "Serviço de saúde mental para adultos com sofrimento psíquico intenso ou persistente.",
                    "Quando o sofrimento atrapalha a vida diária, há crises frequentes ou a UBS indica.",
                    "Em geral, pode procurar diretamente. Leve documentos e, se houver, relatórios anteriores.");
            case "CAPS_AD" -> porta("CAPS_AD", "CAPS Álcool e Drogas (CAPS AD)",
                    "Cuida de pessoas com problemas relacionados ao uso de álcool e outras drogas.",
                    "Quando o uso de substâncias traz prejuízo ou sofrimento.",
                    "Pode procurar diretamente ou pela UBS.");
            case "CER" -> porta("CER", "Centro Especializado em Reabilitação (CER)",
                    "Serviço de reabilitação com equipe de várias áreas (fonoaudiologia, terapia ocupacional, psicologia e outras). "
                            + "A modalidade intelectual atende pessoas com autismo e deficiência intelectual.",
                    "Para avaliação especializada e terapias de reabilitação.",
                    "Normalmente é preciso encaminhamento da UBS ou de outro serviço, que entra na fila de regulação do município.");
            case "POLICLINICA" -> porta("POLICLINICA", "Policlínica / ambulatório de especialidades",
                    "Consultas com especialistas, como neurologista ou psiquiatra infantil.",
                    "Quando a UBS encaminha para um especialista.",
                    "Somente com encaminhamento, pela regulação do município.");
            default -> porta(categoria, CATEGORIAS.getOrDefault(categoria, "Estabelecimento de saúde"),
                    "Estabelecimento de saúde do SUS.", "Conforme orientação da UBS.", "Ligue antes para confirmar como é o acesso.");
        };
    }

    private static Map<String, Object> porta(String codigo, String nome, String oQueE, String quando, String acesso) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("categoria", codigo);
        m.put("nome", nome);
        m.put("oQueE", oQueE);
        m.put("quandoProcurar", quando);
        m.put("comoAcessar", acesso);
        return m;
    }

    private static Map<String, Object> caminho(String situacao, String... passos) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("situacao", situacao);
        m.put("passos", List.of(passos));
        return m;
    }
}
