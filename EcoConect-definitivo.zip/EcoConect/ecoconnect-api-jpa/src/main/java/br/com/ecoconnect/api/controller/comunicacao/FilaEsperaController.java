package br.com.ecoconnect.api.controller.comunicacao;

import br.com.ecoconnect.api.controller.base.LeituraController;
import br.com.ecoconnect.api.dto.AnaliseFila;
import br.com.ecoconnect.api.model.entity.FilaEspera;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.comunicacao.FilaEsperaService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/** Fila de espera para ingresso no Ecocura. */
@RestController
@RequestMapping("/api/fila-espera")
public class FilaEsperaController extends LeituraController<FilaEspera, Long> {

    private final FilaEsperaService service;

    public FilaEsperaController(FilaEsperaService service) {
        this.service = service;
    }

    @Override
    protected CrudService<FilaEspera, Long> service() {
        return service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public FilaEspera solicitar(@Valid @RequestBody FilaEspera dados) {
        return service.criar(dados);
    }

    @PatchMapping("/{id}/analise")
    public FilaEspera analisar(@PathVariable Long id, @Valid @RequestBody AnaliseFila dados) {
        return service.analisar(id, dados);
    }
}
