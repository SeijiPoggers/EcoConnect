package br.com.ecoconnect.api.model.enums;

/** Para quem o comunicado é enviado. Valores idênticos ao ENUM do MySQL. */
public enum AbrangenciaComunicado {
    TODOS, GRUPO, ESPECIFICO
}
