package br.com.ecoconnect.api.model.entity;

import java.io.Serializable;
import java.util.Objects;

/** Chave primária composta de `atendimento_profissional`: (id_atendimento, id_profissional). */
public class AtendimentoProfissionalId implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long idAtendimento;
    private Long idProfissional;

    public AtendimentoProfissionalId() {
    }

    public AtendimentoProfissionalId(Long idAtendimento, Long idProfissional) {
        this.idAtendimento = idAtendimento;
        this.idProfissional = idProfissional;
    }

    public Long getIdAtendimento() {
        return idAtendimento;
    }

    public void setIdAtendimento(Long idAtendimento) {
        this.idAtendimento = idAtendimento;
    }

    public Long getIdProfissional() {
        return idProfissional;
    }

    public void setIdProfissional(Long idProfissional) {
        this.idProfissional = idProfissional;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AtendimentoProfissionalId outro)) return false;
        return Objects.equals(idAtendimento, outro.idAtendimento) && Objects.equals(idProfissional, outro.idProfissional);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAtendimento, idProfissional);
    }

    @Override
    public String toString() {
        return "idAtendimento=" + idAtendimento + ","
                + "idProfissional=" + idProfissional;
    }
}
