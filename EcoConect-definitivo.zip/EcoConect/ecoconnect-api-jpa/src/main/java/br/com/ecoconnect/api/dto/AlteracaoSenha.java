package br.com.ecoconnect.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/** senhaAtual é exigida quando o próprio usuário troca a senha; o administrador pode omiti-la. */
public record AlteracaoSenha(
        String senhaAtual,
        @NotBlank(message = "campo obrigatório") @Size(min = 8, max = 72, message = "a senha deve ter de 8 a 72 caracteres") String novaSenha) {
}
