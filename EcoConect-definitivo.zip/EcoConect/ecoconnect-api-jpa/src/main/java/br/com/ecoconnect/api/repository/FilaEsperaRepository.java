package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.FilaEspera;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `fila_espera` (Spring Data JPA). */
public interface FilaEsperaRepository extends JpaRepository<FilaEspera, Long> {
}
