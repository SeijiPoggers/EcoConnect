package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/** Tabela `instituicao` (migration V2/V3). Gerada no mesmo padrão das entidades originais. */
@Entity
@Table(name = "instituicao")
public class Instituicao implements Entidade<Long> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_instituicao", nullable = false)
    private Long idInstituicao;

    @Size(max = 150)
    @Column(name = "nome", nullable = false, length = 150)
    private String nome;

    @Size(max = 20)
    @Column(name = "tipo", nullable = false, length = 20)
    private String tipo;

    @Size(max = 14)
    @Column(name = "cnpj", length = 14)
    private String cnpj;

    @Size(max = 7)
    @Column(name = "codigo_cnes", length = 7)
    private String codigoCnes;

    @Column(name = "descricao", columnDefinition = "TEXT")
    private String descricao;

    @Size(max = 150)
    @Column(name = "email", length = 150)
    private String email;

    @Size(max = 20)
    @Column(name = "telefone", length = 20)
    private String telefone;

    @Size(max = 200)
    @Column(name = "site", length = 200)
    private String site;

    @Size(max = 150)
    @Column(name = "logradouro", length = 150)
    private String logradouro;

    @Size(max = 20)
    @Column(name = "numero", length = 20)
    private String numero;

    @Size(max = 80)
    @Column(name = "bairro", length = 80)
    private String bairro;

    @Size(max = 80)
    @Column(name = "municipio", nullable = false, length = 80)
    private String municipio;

    @Size(max = 2)
    @Column(name = "uf", nullable = false, length = 2)
    private String uf;

    @Size(max = 8)
    @Column(name = "cep", length = 8)
    private String cep;

    @Column(name = "latitude", precision = 9, scale = 6)
    private BigDecimal latitude;

    @Column(name = "longitude", precision = 9, scale = 6)
    private BigDecimal longitude;

    @Column(name = "idade_minima")
    private Integer idadeMinima;

    @Column(name = "idade_maxima")
    private Integer idadeMaxima;

    @Size(max = 255)
    @Column(name = "condicoes_atendidas", length = 255)
    private String condicoesAtendidas;

    @Size(max = 100)
    @Column(name = "modalidades", length = 100)
    private String modalidades;

    @Size(max = 255)
    @Column(name = "recursos_acessibilidade", length = 255)
    private String recursosAcessibilidade;

    @Column(name = "atendimento_gratuito")
    private Boolean atendimentoGratuito;

    @Column(name = "atende_pelo_sus")
    private Boolean atendePeloSus;

    @Column(name = "vagas_disponiveis")
    private Integer vagasDisponiveis;

    @Column(name = "aceita_solicitacoes")
    private Boolean aceitaSolicitacoes;

    @Column(name = "verificada")
    private Boolean verificada;

    @Column(name = "ativa")
    private Boolean ativa;

    @Column(name = "dados_demonstracao")
    private Boolean dadosDemonstracao;

    @Column(name = "data_cadastro")
    private LocalDateTime dataCadastro;

    @Column(name = "data_atualizacao")
    private LocalDateTime dataAtualizacao;

    @PrePersist
    void aoInserir() {
        if (atendimentoGratuito == null) atendimentoGratuito = Boolean.FALSE;
        if (atendePeloSus == null) atendePeloSus = Boolean.FALSE;
        if (aceitaSolicitacoes == null) aceitaSolicitacoes = Boolean.TRUE;
        if (verificada == null) verificada = Boolean.FALSE;
        if (ativa == null) ativa = Boolean.TRUE;
        if (dadosDemonstracao == null) dadosDemonstracao = Boolean.FALSE;
        if (dataCadastro == null) dataCadastro = LocalDateTime.now();
        if (dataAtualizacao == null) dataAtualizacao = LocalDateTime.now();
    }

    @PreUpdate
    void aoAtualizar() {
        dataAtualizacao = LocalDateTime.now();
    }

    @Override
    public Long chave() {
        return idInstituicao;
    }

    @Override
    public void definirChave(Long id) {
        this.idInstituicao = id;
    }

    public Long getIdInstituicao() {
        return idInstituicao;
    }

    public void setIdInstituicao(Long idInstituicao) {
        this.idInstituicao = idInstituicao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getCodigoCnes() {
        return codigoCnes;
    }

    public void setCodigoCnes(String codigoCnes) {
        this.codigoCnes = codigoCnes;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }

    public Integer getIdadeMinima() {
        return idadeMinima;
    }

    public void setIdadeMinima(Integer idadeMinima) {
        this.idadeMinima = idadeMinima;
    }

    public Integer getIdadeMaxima() {
        return idadeMaxima;
    }

    public void setIdadeMaxima(Integer idadeMaxima) {
        this.idadeMaxima = idadeMaxima;
    }

    public String getCondicoesAtendidas() {
        return condicoesAtendidas;
    }

    public void setCondicoesAtendidas(String condicoesAtendidas) {
        this.condicoesAtendidas = condicoesAtendidas;
    }

    public String getModalidades() {
        return modalidades;
    }

    public void setModalidades(String modalidades) {
        this.modalidades = modalidades;
    }

    public String getRecursosAcessibilidade() {
        return recursosAcessibilidade;
    }

    public void setRecursosAcessibilidade(String recursosAcessibilidade) {
        this.recursosAcessibilidade = recursosAcessibilidade;
    }

    public Boolean getAtendimentoGratuito() {
        return atendimentoGratuito;
    }

    public void setAtendimentoGratuito(Boolean atendimentoGratuito) {
        this.atendimentoGratuito = atendimentoGratuito;
    }

    public Boolean getAtendePeloSus() {
        return atendePeloSus;
    }

    public void setAtendePeloSus(Boolean atendePeloSus) {
        this.atendePeloSus = atendePeloSus;
    }

    public Integer getVagasDisponiveis() {
        return vagasDisponiveis;
    }

    public void setVagasDisponiveis(Integer vagasDisponiveis) {
        this.vagasDisponiveis = vagasDisponiveis;
    }

    public Boolean getAceitaSolicitacoes() {
        return aceitaSolicitacoes;
    }

    public void setAceitaSolicitacoes(Boolean aceitaSolicitacoes) {
        this.aceitaSolicitacoes = aceitaSolicitacoes;
    }

    public Boolean getVerificada() {
        return verificada;
    }

    public void setVerificada(Boolean verificada) {
        this.verificada = verificada;
    }

    public Boolean getAtiva() {
        return ativa;
    }

    public void setAtiva(Boolean ativa) {
        this.ativa = ativa;
    }

    public Boolean getDadosDemonstracao() {
        return dadosDemonstracao;
    }

    public void setDadosDemonstracao(Boolean dadosDemonstracao) {
        this.dadosDemonstracao = dadosDemonstracao;
    }

    public LocalDateTime getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(LocalDateTime dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    public LocalDateTime getDataAtualizacao() {
        return dataAtualizacao;
    }

    public void setDataAtualizacao(LocalDateTime dataAtualizacao) {
        this.dataAtualizacao = dataAtualizacao;
    }
}
