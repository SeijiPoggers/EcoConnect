package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.Profissional;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `profissional` (Spring Data JPA). */
public interface ProfissionalRepository extends JpaRepository<Profissional, Long> {

    Optional<Profissional> findByIdUsuario(Long idUsuario);
    boolean existsByIdUsuario(Long idUsuario);
}
