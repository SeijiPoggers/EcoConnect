package br.com.ecoconnect.api.service.saude;

import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.CriancaDiagnostico;
import br.com.ecoconnect.api.model.entity.Diagnostico;
import br.com.ecoconnect.api.repository.CriancaDiagnosticoRepository;
import br.com.ecoconnect.api.repository.DiagnosticoRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.Verificacoes;
import org.springframework.stereotype.Service;

/** CRIANCA_DIAGNOSTICO: diagnósticos da criança, com data (inclusive anterior ao ingresso), origem e validação. */
@Service
public class CriancaDiagnosticoService extends RegistroSaudeService<CriancaDiagnostico> {

    private final DiagnosticoRepository diagnosticoRepository;

    public CriancaDiagnosticoService(CriancaDiagnosticoRepository repository, AuditoriaService auditoria,
                                     Verificacoes verificacoes, DiagnosticoRepository diagnosticoRepository) {
        super(repository, auditoria, "crianca_diagnostico", verificacoes);
        this.diagnosticoRepository = diagnosticoRepository;
    }

    @Override
    protected void validarEspecifico(CriancaDiagnostico cd) {
        Diagnostico d = diagnosticoRepository.findById(cd.getIdDiagnostico())
                .orElseThrow(() -> new NaoEncontradoException("diagnostico", cd.getIdDiagnostico()));
        if (!Boolean.TRUE.equals(d.getAtivo()) && cd.getIdCriancaDiagnostico() == null) {
            throw new RegraNegocioException("O diagnóstico " + d.getNome() + " está inativo no catálogo.");
        }
        Verificacoes.naoFutura(cd.getDataDiagnostico(), "A data do diagnóstico");
    }
}
