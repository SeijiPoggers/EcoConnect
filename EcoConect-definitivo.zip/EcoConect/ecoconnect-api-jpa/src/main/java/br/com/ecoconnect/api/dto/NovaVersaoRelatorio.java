package br.com.ecoconnect.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record NovaVersaoRelatorio(
        @NotBlank(message = "campo obrigatório") @Size(max = 150) String titulo,
        @NotBlank(message = "campo obrigatório") String conteudo) {
}
