package br.com.ecoconnect.api.seguranca;

import br.com.ecoconnect.api.dominio.Papeis;
import br.com.ecoconnect.api.exception.NaoAutorizadoException;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * Escopo por registro: quais pessoas acompanhadas o usuário pode ver.
 *  - ADMINISTRADOR: todas;
 *  - PROFISSIONAL: as que acompanha (autorização em crianca_profissional, ou designação em agendamento/atendimento);
 *  - RESPONSAVEL: as de vínculo ATIVO com permissão de consulta;
 *  - PESSOA_ACOMPANHADA: somente a própria;
 *  - ADMIN_INSTITUCIONAL: as que enviaram solicitação à sua instituição ou estão vinculadas a ela (somente perfil e necessidades).
 * O resultado é calculado uma vez por requisição.
 */
@Component
public class EscopoAcesso {

    private static final String CACHE = "ecoconect.escopo.criancas";
    private final JdbcTemplate jdbc;

    public EscopoAcesso(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /** Sem restrição: administrador, ou execução interna (sem requisição HTTP autenticada). */
    public boolean irrestrito() {
        ContextoUsuario c = ContextoAtual.obter();
        return c == null || c.administrador();
    }

    public Set<Long> criancas() {
        ContextoUsuario c = ContextoAtual.obter();
        if (c == null) return Set.of();
        HttpServletRequest req = requisicao();
        if (req != null && req.getAttribute(CACHE) instanceof Set<?> s) {
            @SuppressWarnings("unchecked")
            Set<Long> cache = (Set<Long>) s;
            return cache;
        }
        Set<Long> ids = new LinkedHashSet<>(calcular(c));
        Set<Long> r = Collections.unmodifiableSet(ids);
        if (req != null) req.setAttribute(CACHE, r);
        return r;
    }

    private List<Long> calcular(ContextoUsuario c) {
        switch (c.perfil()) {
            case Papeis.ADMINISTRADOR:
                return jdbc.queryForList("SELECT id_crianca FROM crianca", Long.class);
            case Papeis.PROFISSIONAL:
                if (c.idProfissional() == null) return List.of();
                return jdbc.queryForList("SELECT id_crianca FROM crianca_profissional WHERE id_profissional = ? AND status = 'ATIVO' "
                        + "UNION SELECT a.id_crianca FROM agendamento a JOIN agendamento_profissional ap ON ap.id_agendamento = a.id_agendamento "
                        + "WHERE ap.id_profissional = ? AND a.status NOT IN ('RECUSADO','CANCELADO') "
                        + "UNION SELECT a.id_crianca FROM atendimento t JOIN agendamento a ON a.id_agendamento = t.id_agendamento "
                        + "JOIN atendimento_profissional tp ON tp.id_atendimento = t.id_atendimento WHERE tp.id_profissional = ?",
                        Long.class, c.idProfissional(), c.idProfissional(), c.idProfissional());
            case Papeis.RESPONSAVEL:
                if (c.idResponsavel() == null) return List.of();
                return jdbc.queryForList("SELECT id_crianca FROM crianca_responsavel WHERE id_responsavel = ? "
                        + "AND status = 'ATIVO' AND pode_consultar_dados = 1", Long.class, c.idResponsavel());
            case Papeis.PESSOA_ACOMPANHADA:
                return c.idCriancaPropria() == null ? List.of() : List.of(c.idCriancaPropria());
            case Papeis.ADMIN_INSTITUCIONAL:
                if (c.instituicoes().isEmpty()) return List.of();
                String marcas = String.join(",", Collections.nCopies(c.instituicoes().size(), "?"));
                Object[] args = new Object[c.instituicoes().size() * 2];
                int k = 0;
                for (Long id : c.instituicoes()) args[k++] = id;
                for (Long id : c.instituicoes()) args[k++] = id;
                return jdbc.queryForList("SELECT id_crianca FROM solicitacao_atendimento WHERE id_crianca IS NOT NULL "
                        + "AND situacao IN ('ENVIADA','EM_ANALISE','ACEITA','CONCLUIDA') AND id_instituicao IN (" + marcas + ") "
                        + "UNION SELECT id_crianca FROM crianca_instituicao WHERE status = 'ATIVO' AND id_instituicao IN (" + marcas + ")",
                        Long.class, args);
            default:
                return List.of();
        }
    }

    public boolean podeVer(Long idCrianca) {
        return idCrianca != null && (irrestrito() || criancas().contains(idCrianca));
    }

    public void exigirCrianca(Long idCrianca) {
        if (idCrianca == null || irrestrito()) return;
        if (!criancas().contains(idCrianca)) {
            throw new NaoAutorizadoException(403, "Você não tem autorização para acessar os dados desta pessoa.");
        }
    }

    /** Acesso a dados de saúde e de sessões: equipe com escopo, ou família vinculada (nunca a instituição). */
    public void exigirAcompanhamento(Long idCrianca) {
        ContextoUsuario c = ContextoAtual.exigir();
        if (c.adminInstitucional()) {
            throw new NaoAutorizadoException(403, "A instituição vê apenas o perfil e as necessidades informadas na solicitação.");
        }
        exigirCrianca(idCrianca);
    }

    /** Gestão de uma instituição: administrador geral ou administrador institucional dela. */
    public void exigirGestaoInstituicao(Long idInstituicao) {
        ContextoUsuario c = ContextoAtual.exigir();
        if (c.administrador()) return;
        if (c.adminInstitucional() && c.instituicoes().contains(idInstituicao)) return;
        throw new NaoAutorizadoException(403, "Você não administra esta instituição.");
    }

    public Long criancaDoAgendamento(Long idAgendamento) {
        return umLong("SELECT id_crianca FROM agendamento WHERE id_agendamento = ?", idAgendamento);
    }

    public Long criancaDoAtendimento(Long idAtendimento) {
        return umLong("SELECT a.id_crianca FROM atendimento t JOIN agendamento a ON a.id_agendamento = t.id_agendamento "
                + "WHERE t.id_atendimento = ?", idAtendimento);
    }

    public Long criancaDoObjetivo(Long idObjetivo) {
        return umLong("SELECT id_crianca FROM objetivo WHERE id_objetivo = ?", idObjetivo);
    }

    public Long criancaDoRelatorio(Long idRelatorio) {
        return umLong("SELECT a.id_crianca FROM relatorio_atendimento r JOIN atendimento t ON t.id_atendimento = r.id_atendimento "
                + "JOIN agendamento a ON a.id_agendamento = t.id_agendamento WHERE r.id_relatorio = ?", idRelatorio);
    }

    private Long umLong(String sql, Long id) {
        if (id == null) return null;
        List<Long> r = jdbc.queryForList(sql, Long.class, id);
        return r.isEmpty() ? null : r.get(0);
    }

    private static HttpServletRequest requisicao() {
        if (RequestContextHolder.getRequestAttributes() instanceof ServletRequestAttributes a) return a.getRequest();
        return null;
    }
}
