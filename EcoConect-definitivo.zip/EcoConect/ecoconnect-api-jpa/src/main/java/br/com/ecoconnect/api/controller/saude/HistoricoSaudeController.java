package br.com.ecoconnect.api.controller.saude;

import br.com.ecoconnect.api.controller.base.LeituraController;
import br.com.ecoconnect.api.dto.ValidacaoRequisicao;
import br.com.ecoconnect.api.model.entity.HistoricoSaude;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.saude.HistoricoSaudeService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/** Linha do tempo de saúde. Correção por substituição; DELETE = REMOVIDO_LOGICAMENTE. */
@RestController
@RequestMapping("/api/historicos-saude")
public class HistoricoSaudeController extends LeituraController<HistoricoSaude, Long> {

    private final HistoricoSaudeService service;

    public HistoricoSaudeController(HistoricoSaudeService service) {
        this.service = service;
    }

    @Override
    protected CrudService<HistoricoSaude, Long> service() {
        return service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public HistoricoSaude criar(@Valid @RequestBody HistoricoSaude dados) {
        return service.criar(dados);
    }

    /** Nova versão do registro: a anterior fica SUBSTITUIDO. */
    @PostMapping("/{id}/substituicao")
    @ResponseStatus(HttpStatus.CREATED)
    public HistoricoSaude substituir(@PathVariable Long id, @Valid @RequestBody HistoricoSaude dados) {
        return service.substituir(id, dados);
    }

    @PatchMapping("/{id}/validacao")
    public HistoricoSaude validar(@PathVariable Long id, @Valid @RequestBody ValidacaoRequisicao dados) {
        return service.validar(id, dados.situacaoValidacao(), dados.idUsuarioValidacao());
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void excluir(@PathVariable Long id) {
        service.excluir(id);
    }
}
