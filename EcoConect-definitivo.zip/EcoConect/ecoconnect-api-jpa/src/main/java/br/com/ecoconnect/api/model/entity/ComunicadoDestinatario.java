package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import java.time.LocalDateTime;

/**
 * Tabela `comunicado_destinatario` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 */
@Entity
@Table(name = "comunicado_destinatario")
@IdClass(ComunicadoDestinatarioId.class)
public class ComunicadoDestinatario {

    @Id
    @Column(name = "id_comunicado", nullable = false)
    private Long idComunicado;

    @Id
    @Column(name = "id_responsavel", nullable = false)
    private Long idResponsavel;

    @Column(name = "data_leitura")
    private LocalDateTime dataLeitura;

    @PrePersist
    void aoInserir() {
        // sem valores padrão a preencher
    }

    public Long getIdComunicado() {
        return idComunicado;
    }

    public void setIdComunicado(Long idComunicado) {
        this.idComunicado = idComunicado;
    }

    public Long getIdResponsavel() {
        return idResponsavel;
    }

    public void setIdResponsavel(Long idResponsavel) {
        this.idResponsavel = idResponsavel;
    }

    public LocalDateTime getDataLeitura() {
        return dataLeitura;
    }

    public void setDataLeitura(LocalDateTime dataLeitura) {
        this.dataLeitura = dataLeitura;
    }
}
