package br.com.ecoconnect.api.dominio;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Leitor dos arquivos de dados abertos do CNES (DATASUS).
 *
 * Aceita o arquivo de estabelecimentos da "Base de dados CNES" (tbEstabelecimentoAAAAMM.csv,
 * separado por ';', em ISO-8859-1) e também exportações de portais estaduais de dados abertos,
 * que usam nomes de coluna em minúsculas. As colunas são localizadas por apelidos; colunas
 * desconhecidas são ignoradas. Não faz nenhum acesso à internet.
 */
public final class LeitorCnes {

    public record Estabelecimento(String codigoCnes, String nome, String razaoSocial, String categoria,
                                  Integer codigoTipoUnidade, String codigoMunicipio, String municipio, String uf,
                                  String logradouro, String numero, String bairro, String cep, String telefone,
                                  String email, BigDecimal latitude, BigDecimal longitude) {
    }

    public record ResultadoLeitura(List<Estabelecimento> estabelecimentos, int linhasLidas, int linhasIgnoradas,
                                   List<String> avisos) {
    }

    private static final Map<String, String[]> APELIDOS = new HashMap<>();

    static {
        APELIDOS.put("cnes", new String[]{"CO_CNES", "CNES", "CODIGO_CNES", "COD_CNES"});
        APELIDOS.put("nome", new String[]{"NO_FANTASIA", "NOME_FANTASIA", "NOME", "FANTASIA"});
        APELIDOS.put("razao", new String[]{"NO_RAZAO_SOCIAL", "RAZAO_SOCIAL", "NOME_RAZAO_SOCIAL"});
        APELIDOS.put("tipo", new String[]{"TP_UNIDADE", "CO_TIPO_UNIDADE", "CODIGO_TIPO_UNIDADE", "TIPO_UNIDADE", "TP_UNID"});
        APELIDOS.put("tipoTexto", new String[]{"DS_TIPO_UNIDADE", "TIPO_ESTABELECIMENTO", "DESCRICAO_TIPO_UNIDADE"});
        APELIDOS.put("municipioCodigo", new String[]{"CO_MUNICIPIO_GESTOR", "CO_MUNICIPIO", "CODIGO_IBGE", "CODIGO_MUNICIPIO",
                "CODIGO_IBGE_MUNICIPIO", "CODIGO_IBGE_MUNICIPIO_GESTOR", "IBGE", "CODUFMUN"});
        APELIDOS.put("municipioNome", new String[]{"NO_MUNICIPIO", "MUNICIPIO", "NOME_MUNICIPIO"});
        APELIDOS.put("uf", new String[]{"UF", "SG_UF", "CO_SIGLA_ESTADO", "SIGLA_UF"});
        APELIDOS.put("ufCodigo", new String[]{"CO_ESTADO_GESTOR", "CO_UF", "CODIGO_UF"});
        APELIDOS.put("logradouro", new String[]{"NO_LOGRADOURO", "LOGRADOURO", "ENDERECO", "ENDERECO_ESTABELECIMENTO"});
        APELIDOS.put("numero", new String[]{"NU_ENDERECO", "NUMERO", "NUMERO_ESTABELECIMENTO"});
        APELIDOS.put("bairro", new String[]{"NO_BAIRRO", "BAIRRO", "BAIRRO_ESTABELECIMENTO"});
        APELIDOS.put("cep", new String[]{"CO_CEP", "CEP", "CODIGO_CEP_ESTABELECIMENTO"});
        APELIDOS.put("telefone", new String[]{"NU_TELEFONE", "TELEFONE", "NUMERO_TELEFONE_ESTABELECIMENTO"});
        APELIDOS.put("email", new String[]{"NO_EMAIL", "EMAIL", "ENDERECO_EMAIL_ESTABELECIMENTO"});
        APELIDOS.put("latitude", new String[]{"NU_LATITUDE", "LATITUDE", "LATITUDE_ESTABELECIMENTO_DECIMO_GRAU"});
        APELIDOS.put("longitude", new String[]{"NU_LONGITUDE", "LONGITUDE", "LONGITUDE_ESTABELECIMENTO_DECIMO_GRAU"});
    }

    /** Códigos IBGE das unidades da federação. */
    private static final Map<String, String> UF_POR_CODIGO = Map.ofEntries(
            Map.entry("11", "RO"), Map.entry("12", "AC"), Map.entry("13", "AM"), Map.entry("14", "RR"),
            Map.entry("15", "PA"), Map.entry("16", "AP"), Map.entry("17", "TO"), Map.entry("21", "MA"),
            Map.entry("22", "PI"), Map.entry("23", "CE"), Map.entry("24", "RN"), Map.entry("25", "PB"),
            Map.entry("26", "PE"), Map.entry("27", "AL"), Map.entry("28", "SE"), Map.entry("29", "BA"),
            Map.entry("31", "MG"), Map.entry("32", "ES"), Map.entry("33", "RJ"), Map.entry("35", "SP"),
            Map.entry("41", "PR"), Map.entry("42", "SC"), Map.entry("43", "RS"), Map.entry("50", "MS"),
            Map.entry("51", "MT"), Map.entry("52", "GO"), Map.entry("53", "DF"));

    private LeitorCnes() {
    }

    /** Lê o arquivo inteiro para uma lista (arquivos pequenos e testes). */
    public static ResultadoLeitura ler(InputStream entrada) throws IOException {
        List<Estabelecimento> lista = new ArrayList<>();
        Estatisticas e = ler(entrada, lista::add);
        return new ResultadoLeitura(lista, e.linhasLidas(), e.linhasIgnoradas(), e.avisos());
    }

    public record Estatisticas(int linhasLidas, int linhasIgnoradas, List<String> avisos) {
    }

    /**
     * Lê em fluxo (o arquivo nacional do CNES tem centenas de milhares de linhas) e entrega cada
     * estabelecimento válido ao consumidor. A codificação (UTF-8 ou ISO-8859-1) é detectada no início.
     */
    public static Estatisticas ler(InputStream entrada, java.util.function.Consumer<Estabelecimento> consumidor) throws IOException {
        java.io.BufferedInputStream bin = new java.io.BufferedInputStream(entrada, 1 << 16);
        bin.mark(1 << 16);
        byte[] amostra = bin.readNBytes(1 << 15);
        bin.reset();
        Charset cs = ehUtf8(amostra) ? StandardCharsets.UTF_8 : Charset.forName("ISO-8859-1");
        java.io.BufferedReader leitor = new java.io.BufferedReader(new java.io.InputStreamReader(bin, cs));
        List<String> avisos = new ArrayList<>();
        String primeira = leitor.readLine();
        if (primeira == null || primeira.isBlank()) return new Estatisticas(0, 0, List.of("Arquivo vazio."));
        if (primeira.startsWith("\uFEFF")) primeira = primeira.substring(1);
        final String cabecalho = primeira;
        char sep = cabecalho.chars().filter(ch -> ch == ';').count() >= cabecalho.chars().filter(ch -> ch == ',').count() ? ';' : ',';
        List<String> cab = campos(cabecalho, sep);
        Map<String, Integer> idx = new HashMap<>();
        for (int i = 0; i < cab.size(); i++) {
            String nome = cab.get(i).trim().toUpperCase(Locale.ROOT).replace(' ', '_');
            for (Map.Entry<String, String[]> e : APELIDOS.entrySet()) {
                for (String apelido : e.getValue()) {
                    if (apelido.equals(nome)) idx.putIfAbsent(e.getKey(), i);
                }
            }
        }
        if (!idx.containsKey("cnes") || !idx.containsKey("nome") || !idx.containsKey("municipioCodigo")) {
            throw new IllegalArgumentException("Cabeçalho não reconhecido: o arquivo precisa ter as colunas do código CNES "
                    + "(CO_CNES), do nome fantasia (NO_FANTASIA) e do código IBGE do município (CO_MUNICIPIO_GESTOR).");
        }
        int lidas = 0;
        int ignoradas = 0;
        String linha;
        while ((linha = leitor.readLine()) != null) {
            if (linha.isBlank()) continue;
            lidas++;
            Estabelecimento est = converter(campos(linha, sep), idx);
            if (est == null) {
                ignoradas++;
            } else {
                consumidor.accept(est);
            }
        }
        if (!idx.containsKey("municipioNome")) {
            avisos.add("O arquivo não traz o nome do município: a busca funcionará pelo código IBGE.");
        }
        if (!idx.containsKey("tipo")) {
            avisos.add("O arquivo não traz o tipo de unidade: a categoria foi deduzida pelo nome do estabelecimento.");
        }
        return new Estatisticas(lidas, ignoradas, avisos);
    }

    private static Estabelecimento converter(List<String> v, Map<String, Integer> idx) {
        String cnes = soDigitos(valor(v, idx, "cnes"));
        String nome = valor(v, idx, "nome");
        String codMun = soDigitos(valor(v, idx, "municipioCodigo"));
        if (cnes == null || cnes.length() > 7 || nome == null || codMun == null || codMun.length() < 6) return null;
        cnes = "0".repeat(7 - cnes.length()) + cnes;
        codMun = codMun.substring(0, 6); // o CNES usa 6 dígitos (sem o verificador)
        Integer tipo = inteiro(valor(v, idx, "tipo"));
        String uf = valor(v, idx, "uf");
        if (uf == null || uf.length() != 2) {
            String cod = soDigitos(valor(v, idx, "ufCodigo"));
            uf = UF_POR_CODIGO.getOrDefault(cod != null ? cod : codMun.substring(0, 2), null);
        }
        String cep = soDigitos(valor(v, idx, "cep"));
        return new Estabelecimento(cnes, limitar(nome, 200), limitar(valor(v, idx, "razao"), 200),
                categoria(tipo, valor(v, idx, "tipoTexto"), nome), tipo, codMun,
                limitar(valor(v, idx, "municipioNome"), 80), uf == null ? null : uf.toUpperCase(Locale.ROOT),
                limitar(valor(v, idx, "logradouro"), 150), limitar(valor(v, idx, "numero"), 20),
                limitar(valor(v, idx, "bairro"), 80), cep != null && cep.length() == 8 ? cep : null,
                limitar(valor(v, idx, "telefone"), 30), limitar(valor(v, idx, "email"), 150),
                coordenada(valor(v, idx, "latitude"), 90), coordenada(valor(v, idx, "longitude"), 180));
    }

    static boolean ehUtf8(byte[] amostra) {
        int n = amostra.length;
        // ignora um caractere multibyte possivelmente cortado no fim da amostra
        while (n > 0 && n > amostra.length - 4 && (amostra[n - 1] & 0xC0) == 0x80) n--;
        if (n > 0 && (amostra[n - 1] & 0xC0) == 0xC0) n--;
        try {
            StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(amostra, 0, n));
            return true;
        } catch (CharacterCodingException e) {
            return false;
        }
    }

    /**
     * Categoria usada na busca. TP_UNIDADE 70 = Centro de Atenção Psicossocial; 01 e 02 = posto/centro de
     * saúde (atenção básica); 04 = policlínica; 05, 07, 15 e 62 = hospitais. O CER não tem tipo próprio no
     * CNES (é uma habilitação de clínicas/centros de especialidade): ele é reconhecido pelo nome.
     */
    public static String categoria(Integer tipo, String tipoTexto, String nome) {
        String n = MotorCorrespondencia.semAcento((nome == null ? "" : nome) + " " + (tipoTexto == null ? "" : tipoTexto))
                .toUpperCase(Locale.ROOT);
        String t = " " + n.replaceAll("[^A-Z0-9]+", " ").trim() + " ";
        boolean caps = (tipo != null && tipo == 70) || t.contains(" CAPS") || n.contains("ATENCAO PSICOSSOCIAL");
        if (caps) {
            if (n.contains("INFANT") || t.contains(" CAPSIJ ") || t.contains(" CAPS IJ ") || t.contains(" CAPS I J ")
                    || t.contains(" CAPSI ")) return "CAPS_INFANTIL";
            if (t.contains(" CAPS AD") || t.contains(" CAPSAD") || n.contains("ALCOOL")) return "CAPS_AD";
            return "CAPS";
        }
        if (n.matches(".*\\bCER\\b.*") || n.contains("REABILITACAO")) return "CER";
        if (tipo != null && (tipo == 1 || tipo == 2) || n.matches(".*\\b(UBS|USF|ESF)\\b.*") || n.contains("UNIDADE BASICA")
                || n.contains("SAUDE DA FAMILIA") || n.contains("CENTRO DE SAUDE")) return "UBS";
        if (tipo != null && tipo == 4 || n.contains("POLICLINICA")) return "POLICLINICA";
        if (tipo != null && (tipo == 5 || tipo == 7 || tipo == 15 || tipo == 62) || n.contains("HOSPITAL")) return "HOSPITAL";
        return "OUTRO";
    }

    /** Divide uma linha CSV respeitando aspas. */
    static List<String> campos(String linha, char sep) {
        List<String> r = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        boolean aspas = false;
        for (int i = 0; i < linha.length(); i++) {
            char ch = linha.charAt(i);
            if (ch == '"') {
                if (aspas && i + 1 < linha.length() && linha.charAt(i + 1) == '"') {
                    sb.append('"');
                    i++;
                } else {
                    aspas = !aspas;
                }
            } else if (ch == sep && !aspas) {
                r.add(sb.toString());
                sb.setLength(0);
            } else {
                sb.append(ch);
            }
        }
        r.add(sb.toString());
        return r;
    }

    private static String valor(List<String> v, Map<String, Integer> idx, String chave) {
        Integer i = idx.get(chave);
        if (i == null || i >= v.size()) return null;
        String s = v.get(i).trim();
        return s.isEmpty() ? null : s;
    }

    private static String soDigitos(String s) {
        if (s == null) return null;
        String d = s.replaceAll("\\D", "");
        return d.isEmpty() ? null : d;
    }

    private static Integer inteiro(String s) {
        String d = soDigitos(s);
        try {
            return d == null ? null : Integer.valueOf(d);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static BigDecimal coordenada(String s, int limite) {
        if (s == null) return null;
        try {
            BigDecimal b = new BigDecimal(s.replace(',', '.'));
            if (b.abs().compareTo(BigDecimal.valueOf(limite)) > 0 || b.signum() == 0) return null;
            return b.setScale(6, java.math.RoundingMode.HALF_UP);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static String limitar(String s, int max) {
        return s == null ? null : (s.length() > max ? s.substring(0, max) : s);
    }

    public static ResultadoLeitura ler(byte[] bytes) throws IOException {
        return ler(new ByteArrayInputStream(bytes));
    }
}
