package br.com.ecoconnect.api.service.app;

import br.com.ecoconnect.api.exception.NaoAutorizadoException;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.TipoNotificacao;
import br.com.ecoconnect.api.seguranca.ContextoAtual;
import br.com.ecoconnect.api.seguranca.ContextoUsuario;
import br.com.ecoconnect.api.seguranca.EscopoAcesso;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.NotificacaoService;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Solicitação de atendimento a uma instituição de apoio. Cada solicitação abre uma conversa
 * entre quem pediu e os administradores da instituição; a resposta (aceita, recusada...) gera
 * notificação e, quando aceita, o vínculo da pessoa com a instituição.
 */
@Service
public class SolicitacaoService {

    private static final Set<String> FORMAS = Set.of("MENSAGEM_NA_PLATAFORMA", "EMAIL", "TELEFONE");
    private static final Map<String, Set<String>> TRANSICOES = Map.of(
            "ENVIADA", Set.of("EM_ANALISE", "ACEITA", "RECUSADA"),
            "EM_ANALISE", Set.of("ACEITA", "RECUSADA"),
            "ACEITA", Set.of("CONCLUIDA"));

    private final Consultas consultas;
    private final EscopoAcesso escopo;
    private final ComunicacaoService comunicacao;
    private final NotificacaoService notificacaoService;
    private final RedeService redeService;
    private final AuditoriaService auditoria;

    public SolicitacaoService(Consultas consultas, EscopoAcesso escopo, ComunicacaoService comunicacao,
                              NotificacaoService notificacaoService, RedeService redeService, AuditoriaService auditoria) {
        this.consultas = consultas;
        this.escopo = escopo;
        this.comunicacao = comunicacao;
        this.notificacaoService = notificacaoService;
        this.redeService = redeService;
        this.auditoria = auditoria;
    }

    public record NovaSolicitacao(Long idInstituicao, Long idServico, Long idCrianca, String mensagem, String formaContato) {
    }

    @Transactional
    public Map<String, Object> criar(NovaSolicitacao d) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (!ctx.familia() && !ctx.equipe()) {
            throw new NaoAutorizadoException(403, "Somente a família, a pessoa acompanhada ou a equipe enviam solicitações.");
        }
        if (d.idInstituicao() == null) throw new RegraNegocioException("Escolha a instituição.");
        Map<String, Object> inst = consultas.um("SELECT nome, ativa, aceita_solicitacoes AS aceita FROM instituicao WHERE id_instituicao = ?",
                d.idInstituicao());
        if (inst == null || !Boolean.TRUE.equals(RedeService.bool(inst.get("ativa")))) {
            throw new NaoEncontradoException("instituicao", d.idInstituicao());
        }
        if (!Boolean.TRUE.equals(RedeService.bool(inst.get("aceita")))) {
            throw new RegraNegocioException("Esta instituição não está recebendo solicitações no momento.");
        }
        if (d.idServico() != null && consultas.numero("SELECT COUNT(*) FROM instituicao_servico WHERE id_servico = ? "
                + "AND id_instituicao = ? AND ativo = 1", d.idServico(), d.idInstituicao()) == 0) {
            throw new RegraNegocioException("O serviço escolhido não pertence a esta instituição.");
        }
        if (d.idCrianca() != null) escopo.exigirAcompanhamento(d.idCrianca());
        if (ctx.familia() && d.idCrianca() == null) {
            throw new RegraNegocioException("Informe para qual pessoa é o atendimento.");
        }
        String mensagem = PessoasService.texto(d.mensagem(), 1000);
        if (mensagem == null) throw new RegraNegocioException("Escreva uma mensagem contando o que você procura.");
        String forma = d.formaContato() == null ? "MENSAGEM_NA_PLATAFORMA" : d.formaContato().trim().toUpperCase();
        if (!FORMAS.contains(forma)) throw new RegraNegocioException("Forma de contato inválida.");
        if (d.idCrianca() != null && consultas.numero("SELECT COUNT(*) FROM solicitacao_atendimento WHERE id_instituicao = ? "
                + "AND id_crianca = ? AND situacao IN ('ENVIADA','EM_ANALISE')", d.idInstituicao(), d.idCrianca()) > 0) {
            throw new RegraNegocioException("Já existe uma solicitação em andamento para esta pessoa nesta instituição.");
        }
        Set<Long> gestores = gestores(d.idInstituicao());
        String nomeInst = String.valueOf(inst.get("nome"));
        long idConversa = comunicacao.criarConversa("Solicitação de atendimento - " + nomeInst, d.idInstituicao(), d.idCrianca(),
                ctx.idUsuario(), gestores);
        long id = consultas.inserir("INSERT INTO solicitacao_atendimento (id_instituicao, id_servico, id_crianca, id_usuario_solicitante, "
                + "mensagem, forma_contato, situacao, id_conversa) VALUES (?, ?, ?, ?, ?, ?, 'ENVIADA', ?)", d.idInstituicao(), d.idServico(),
                d.idCrianca(), ctx.idUsuario(), mensagem, forma, idConversa);
        comunicacao.gravarMensagem(idConversa, ctx, mensagem);
        for (Long g : gestores) {
            notificacaoService.notificar(g, TipoNotificacao.SOLICITACAO, "Nova solicitação de atendimento",
                    ctx.nome() + " enviou uma solicitação para " + nomeInst + ".", null, null, null);
        }
        Map<String, Object> r = detalhe(id);
        auditoria.registrarDados(AcaoAuditoria.CRIACAO, "solicitacao_atendimento", id, d.idCrianca(), null, r);
        r.put("mensagemConfirmacao", gestores.isEmpty()
                ? "Solicitação registrada. A instituição ainda não tem um responsável cadastrado na plataforma; a equipe EcoConect fará o contato."
                : "Solicitação enviada. Você será avisado quando a instituição responder.");
        return r;
    }

    /** Lista conforme o perfil: instituição -> recebidas; administrador -> todas; demais -> as suas e as das pessoas que acompanha. */
    @Transactional(readOnly = true)
    public List<Map<String, Object>> listar(String situacao, Long idInstituicao) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        StringBuilder sql = new StringBuilder(selectSql()).append(" WHERE 1 = 1");
        List<Object> args = new ArrayList<>();
        if (ctx.adminInstitucional()) {
            List<Long> inst = new ArrayList<>(ctx.instituicoes());
            sql.append(" AND s.id_instituicao IN (").append(Consultas.marcadores(inst)).append(")");
            args.addAll(inst);
        } else if (!ctx.administrador()) {
            List<Long> pessoas = new ArrayList<>(escopo.criancas());
            sql.append(" AND (s.id_usuario_solicitante = ? OR s.id_crianca IN (").append(Consultas.marcadores(pessoas)).append("))");
            args.add(ctx.idUsuario());
            args.addAll(pessoas);
        }
        if (RedeService.vazio(situacao) != null) {
            sql.append(" AND s.situacao = ?");
            args.add(situacao.trim().toUpperCase());
        }
        if (idInstituicao != null) {
            sql.append(" AND s.id_instituicao = ?");
            args.add(idInstituicao);
        }
        sql.append(" ORDER BY FIELD(s.situacao,'ENVIADA','EM_ANALISE','ACEITA','CONCLUIDA','RECUSADA','CANCELADA'), s.data_criacao DESC LIMIT 300");
        return consultas.lista(sql.toString(), args.toArray());
    }

    @Transactional(readOnly = true)
    public Map<String, Object> detalhe(Long id) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        Map<String, Object> s = consultas.um(selectSql() + " WHERE s.id_solicitacao = ?", id);
        if (s == null) throw new NaoEncontradoException("solicitacao_atendimento", id);
        exigirAcesso(ctx, s);
        Long idCrianca = s.get("idCrianca") == null ? null : ((Number) s.get("idCrianca")).longValue();
        if (idCrianca != null) {
            // a instituição vê só as necessidades informadas (nunca dados de saúde ou sessões)
            s.put("necessidades", consultas.um("SELECT condicoes_informadas AS condicoes, necessidades_acompanhamento AS necessidades, "
                    + "preferencias_sensoriais AS sensorial, comunicacao_preferida AS comunicacao, "
                    + "necessidades_acessibilidade AS acessibilidade, modalidade_preferida AS modalidade, municipio, uf "
                    + "FROM perfil_necessidades WHERE id_crianca = ?", idCrianca));
        }
        boolean gestor = ctx.administrador() || (ctx.adminInstitucional()
                && ctx.instituicoes().contains(((Number) s.get("idInstituicao")).longValue()));
        s.put("podeResponder", gestor && TRANSICOES.containsKey(String.valueOf(s.get("situacao"))));
        s.put("podeCancelar", ((Number) s.get("idUsuarioSolicitante")).longValue() == ctx.idUsuario()
                && Set.of("ENVIADA", "EM_ANALISE").contains(String.valueOf(s.get("situacao"))));
        return s;
    }

    public record Resposta(String situacao, String resposta) {
    }

    @Transactional
    public Map<String, Object> responder(Long id, Resposta d) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        Map<String, Object> s = consultas.um(selectSql() + " WHERE s.id_solicitacao = ?", id);
        if (s == null) throw new NaoEncontradoException("solicitacao_atendimento", id);
        Long idInstituicao = ((Number) s.get("idInstituicao")).longValue();
        escopo.exigirGestaoInstituicao(idInstituicao);
        String atual = String.valueOf(s.get("situacao"));
        String nova = d.situacao() == null ? "" : d.situacao().trim().toUpperCase();
        if (!TRANSICOES.getOrDefault(atual, Set.of()).contains(nova)) {
            throw new RegraNegocioException("Não é possível mudar a solicitação de " + atual + " para " + nova + ".");
        }
        String texto = PessoasService.texto(d.resposta(), 1000);
        if ("RECUSADA".equals(nova) && texto == null) {
            throw new RegraNegocioException("Explique o motivo da recusa e, se possível, indique outro serviço.");
        }
        consultas.executar("UPDATE solicitacao_atendimento SET situacao = ?, resposta = COALESCE(?, resposta), id_usuario_resposta = ?, "
                + "data_resposta = ? WHERE id_solicitacao = ?", nova, texto, ctx.idUsuario(), LocalDateTime.now(), id);
        Long idCrianca = s.get("idCrianca") == null ? null : ((Number) s.get("idCrianca")).longValue();
        if ("ACEITA".equals(nova) && idCrianca != null) {
            redeService.criarVinculo(idCrianca, idInstituicao, "SOLICITACAO", id, null, ctx.idUsuario());
        }
        Object idConversa = s.get("idConversa");
        if (idConversa != null) {
            String msg = "Situação da solicitação: " + rotulo(nova) + (texto == null ? "." : ". " + texto);
            comunicacao.gravarMensagem(((Number) idConversa).longValue(), ctx, msg);
        }
        notificacaoService.notificar(((Number) s.get("idUsuarioSolicitante")).longValue(), TipoNotificacao.SOLICITACAO,
                "Solicitação " + rotulo(nova).toLowerCase(), s.get("instituicao") + " atualizou a sua solicitação: " + rotulo(nova) + ".",
                null, null, null);
        Map<String, Object> depois = detalhe(id);
        auditoria.registrarDados(AcaoAuditoria.ATUALIZACAO, "solicitacao_atendimento", id, idCrianca, s, depois);
        return depois;
    }

    @Transactional
    public Map<String, Object> cancelar(Long id) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        Map<String, Object> s = consultas.um(selectSql() + " WHERE s.id_solicitacao = ?", id);
        if (s == null) throw new NaoEncontradoException("solicitacao_atendimento", id);
        if (((Number) s.get("idUsuarioSolicitante")).longValue() != ctx.idUsuario()) {
            throw new NaoAutorizadoException(403, "Somente quem enviou pode cancelar a solicitação.");
        }
        if (!Set.of("ENVIADA", "EM_ANALISE").contains(String.valueOf(s.get("situacao")))) {
            throw new RegraNegocioException("Esta solicitação já foi respondida e não pode ser cancelada.");
        }
        consultas.executar("UPDATE solicitacao_atendimento SET situacao = 'CANCELADA' WHERE id_solicitacao = ?", id);
        for (Long g : gestores(((Number) s.get("idInstituicao")).longValue())) {
            notificacaoService.notificar(g, TipoNotificacao.SOLICITACAO, "Solicitação cancelada",
                    ctx.nome() + " cancelou a solicitação enviada para " + s.get("instituicao") + ".", null, null, null);
        }
        Map<String, Object> depois = detalhe(id);
        auditoria.registrarDados(AcaoAuditoria.ATUALIZACAO, "solicitacao_atendimento", id,
                s.get("idCrianca") == null ? null : ((Number) s.get("idCrianca")).longValue(), s, depois);
        return depois;
    }

    // ------------------------------------------------------------------

    private void exigirAcesso(ContextoUsuario ctx, Map<String, Object> s) {
        if (ctx.administrador()) return;
        long idInst = ((Number) s.get("idInstituicao")).longValue();
        if (ctx.adminInstitucional() && ctx.instituicoes().contains(idInst)) return;
        if (((Number) s.get("idUsuarioSolicitante")).longValue() == ctx.idUsuario()) return;
        Object c = s.get("idCrianca");
        if (c != null && !ctx.adminInstitucional() && escopo.podeVer(((Number) c).longValue())) return;
        throw new NaoAutorizadoException(403, "Você não tem acesso a esta solicitação.");
    }

    private Set<Long> gestores(Long idInstituicao) {
        return new LinkedHashSet<>(consultas.ids("SELECT m.id_usuario FROM instituicao_membro m JOIN usuario u ON u.id_usuario = m.id_usuario "
                + "WHERE m.id_instituicao = ? AND m.ativo = 1 AND m.papel = 'ADMIN_INSTITUCIONAL' AND u.status = 'ATIVO'", idInstituicao));
    }

    private static String selectSql() {
        return "SELECT s.id_solicitacao AS idSolicitacao, s.id_instituicao AS idInstituicao, i.nome AS instituicao, "
                + "s.id_servico AS idServico, sv.nome AS servico, s.id_crianca AS idCrianca, c.nome_completo AS pessoa, "
                + "TIMESTAMPDIFF(YEAR, c.data_nascimento, CURDATE()) AS idadePessoa, s.id_usuario_solicitante AS idUsuarioSolicitante, "
                + "us.nome_completo AS solicitante, s.mensagem, s.forma_contato AS formaContato, s.situacao, s.resposta, "
                + "ur.nome_completo AS respondidaPor, " + Consultas.dt("s.data_resposta") + " AS dataResposta, s.id_conversa AS idConversa, "
                + Consultas.dt("s.data_criacao") + " AS dataCriacao, " + Consultas.dt("s.data_atualizacao") + " AS dataAtualizacao "
                + "FROM solicitacao_atendimento s JOIN instituicao i ON i.id_instituicao = s.id_instituicao "
                + "LEFT JOIN instituicao_servico sv ON sv.id_servico = s.id_servico LEFT JOIN crianca c ON c.id_crianca = s.id_crianca "
                + "JOIN usuario us ON us.id_usuario = s.id_usuario_solicitante LEFT JOIN usuario ur ON ur.id_usuario = s.id_usuario_resposta";
    }

    static String rotulo(String situacao) {
        return switch (situacao) {
            case "ENVIADA" -> "Enviada";
            case "EM_ANALISE" -> "Em análise";
            case "ACEITA" -> "Aceita";
            case "RECUSADA" -> "Recusada";
            case "CANCELADA" -> "Cancelada";
            case "CONCLUIDA" -> "Concluída";
            default -> situacao;
        };
    }
}
