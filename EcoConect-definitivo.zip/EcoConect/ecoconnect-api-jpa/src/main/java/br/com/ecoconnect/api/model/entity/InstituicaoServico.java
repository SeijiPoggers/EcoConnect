package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;

/** Tabela `instituicao_servico` (migration V2/V3). Gerada no mesmo padrão das entidades originais. */
@Entity
@Table(name = "instituicao_servico")
public class InstituicaoServico implements Entidade<Long> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_servico", nullable = false)
    private Long idServico;

    @Column(name = "id_instituicao", nullable = false)
    private Long idInstituicao;

    @Size(max = 120)
    @Column(name = "nome", nullable = false, length = 120)
    private String nome;

    @Size(max = 30)
    @Column(name = "tipo_servico", nullable = false, length = 30)
    private String tipoServico;

    @Size(max = 500)
    @Column(name = "descricao", length = 500)
    private String descricao;

    @Column(name = "gratuito")
    private Boolean gratuito;

    @Column(name = "ativo")
    private Boolean ativo;

    @PrePersist
    void aoInserir() {
        if (gratuito == null) gratuito = Boolean.FALSE;
        if (ativo == null) ativo = Boolean.TRUE;
    }

    @Override
    public Long chave() {
        return idServico;
    }

    @Override
    public void definirChave(Long id) {
        this.idServico = id;
    }

    public Long getIdServico() {
        return idServico;
    }

    public void setIdServico(Long idServico) {
        this.idServico = idServico;
    }

    public Long getIdInstituicao() {
        return idInstituicao;
    }

    public void setIdInstituicao(Long idInstituicao) {
        this.idInstituicao = idInstituicao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipoServico() {
        return tipoServico;
    }

    public void setTipoServico(String tipoServico) {
        this.tipoServico = tipoServico;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Boolean getGratuito() {
        return gratuito;
    }

    public void setGratuito(Boolean gratuito) {
        this.gratuito = gratuito;
    }

    public Boolean getAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }
}
