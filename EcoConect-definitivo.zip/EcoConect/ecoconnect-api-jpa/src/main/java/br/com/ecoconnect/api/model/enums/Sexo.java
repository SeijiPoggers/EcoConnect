package br.com.ecoconnect.api.model.enums;

/** Sexo da criança (opcional). Valores idênticos ao ENUM do MySQL. */
public enum Sexo {
    F, M, NAO_INFORMADO
}
