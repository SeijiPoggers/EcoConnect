package br.com.ecoconnect.api.seguranca;

import br.com.ecoconnect.api.exception.NaoAutorizadoException;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/** Acesso ao usuário autenticado da requisição atual. */
public final class ContextoAtual {

    public static final String ATRIBUTO = "ecoconect.contexto";

    private ContextoAtual() {
    }

    /** Contexto da requisição, ou null fora de uma requisição HTTP ou sem login. */
    public static ContextoUsuario obter() {
        if (RequestContextHolder.getRequestAttributes() instanceof ServletRequestAttributes attrs) {
            HttpServletRequest req = attrs.getRequest();
            Object c = req.getAttribute(ATRIBUTO);
            return c instanceof ContextoUsuario ctx ? ctx : null;
        }
        return null;
    }

    /** Contexto obrigatório (as rotas protegidas já passaram pelo filtro de autenticação). */
    public static ContextoUsuario exigir() {
        ContextoUsuario c = obter();
        if (c == null) throw new NaoAutorizadoException(401, "Faça login para continuar.");
        return c;
    }
}
