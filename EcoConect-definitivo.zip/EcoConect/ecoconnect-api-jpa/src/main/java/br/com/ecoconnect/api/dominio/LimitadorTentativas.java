package br.com.ecoconnect.api.dominio;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Proteção contra tentativa e erro de senha: após N falhas na janela,
 * a chave (e-mail + IP) fica bloqueada até a janela expirar.
 */
public final class LimitadorTentativas {

    private final int maximo;
    private final Duration janela;
    private final Clock relogio;
    private final Map<String, Deque<Instant>> falhas = new ConcurrentHashMap<>();

    public LimitadorTentativas(int maximo, Duration janela, Clock relogio) {
        this.maximo = maximo;
        this.janela = janela;
        this.relogio = relogio;
    }

    public boolean bloqueado(String chave) {
        Deque<Instant> d = falhas.get(chave);
        if (d == null) return false;
        synchronized (d) {
            limpar(d);
            return d.size() >= maximo;
        }
    }

    public void registrarFalha(String chave) {
        Deque<Instant> d = falhas.computeIfAbsent(chave, k -> new ArrayDeque<>());
        synchronized (d) {
            limpar(d);
            d.addLast(relogio.instant());
        }
    }

    public void limpar(String chave) {
        falhas.remove(chave);
    }

    private void limpar(Deque<Instant> d) {
        Instant limite = relogio.instant().minus(janela);
        while (!d.isEmpty() && d.peekFirst().isBefore(limite)) d.pollFirst();
    }
}
