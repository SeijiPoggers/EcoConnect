package br.com.ecoconnect.api.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/** Dados para criar um usuário. A senha chega em texto e é gravada como hash BCrypt. */
public record UsuarioCriacao(
        @NotNull(message = "campo obrigatório") Integer idPerfil,
        @NotBlank(message = "campo obrigatório") @Size(max = 150) String nomeCompleto,
        @NotBlank(message = "campo obrigatório") @Email(message = "e-mail inválido") @Size(max = 150) String email,
        @Size(max = 20) String telefone,
        @NotBlank(message = "campo obrigatório") @Size(min = 8, max = 72, message = "a senha deve ter de 8 a 72 caracteres") String senha) {
}
