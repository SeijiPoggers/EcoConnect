package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.Conversa;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConversaRepository extends JpaRepository<Conversa, Long> {

}
