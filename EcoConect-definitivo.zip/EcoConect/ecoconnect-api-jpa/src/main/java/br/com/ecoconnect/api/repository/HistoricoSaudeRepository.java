package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.HistoricoSaude;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `historico_saude` (Spring Data JPA). */
public interface HistoricoSaudeRepository extends JpaRepository<HistoricoSaude, Long> {
}
