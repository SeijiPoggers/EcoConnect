package br.com.ecoconnect.api.dominio;

import java.time.Duration;
import java.time.LocalDateTime;

/** Sobreposição de horários na agenda (intervalos semiabertos [início, fim)). */
public final class ConflitoHorario {

    /** Duração assumida quando o agendamento não informa o fim. */
    public static final Duration DURACAO_PADRAO = Duration.ofMinutes(50);

    private ConflitoHorario() {
    }

    public static LocalDateTime fimEfetivo(LocalDateTime inicio, LocalDateTime fim) {
        return fim != null ? fim : inicio.plus(DURACAO_PADRAO);
    }

    public static boolean sobrepoe(LocalDateTime inicioA, LocalDateTime fimA, LocalDateTime inicioB, LocalDateTime fimB) {
        if (inicioA == null || inicioB == null) return false;
        LocalDateTime fa = fimEfetivo(inicioA, fimA);
        LocalDateTime fb = fimEfetivo(inicioB, fimB);
        return inicioA.isBefore(fb) && inicioB.isBefore(fa);
    }
}
