package br.com.ecoconnect.api.controller.agenda;

import br.com.ecoconnect.api.controller.base.LeituraController;
import br.com.ecoconnect.api.dto.MudancaStatusAgendamento;
import br.com.ecoconnect.api.model.entity.Agendamento;
import br.com.ecoconnect.api.model.entity.HistoricoAgendamento;
import br.com.ecoconnect.api.service.agenda.AgendamentoService;
import br.com.ecoconnect.api.service.base.CrudService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Agendamentos. Sem DELETE: cancelamento por PATCH /{id}/status. */
@RestController
@RequestMapping("/api/agendamentos")
public class AgendamentoController extends LeituraController<Agendamento, Long> {

    private final AgendamentoService service;

    public AgendamentoController(AgendamentoService service) {
        this.service = service;
    }

    @Override
    protected CrudService<Agendamento, Long> service() {
        return service;
    }

    /** Solicita um agendamento (nasce SOLICITADO). */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Agendamento solicitar(@Valid @RequestBody Agendamento dados) {
        return service.criar(dados);
    }

    /** Altera horário/observação da solicitação (enquanto SOLICITADO ou EM_ANALISE). */
    @PutMapping("/{id}")
    public Agendamento alterar(@PathVariable Long id, @Valid @RequestBody Agendamento dados) {
        return service.atualizar(id, dados);
    }

    /** {"status": "CONFIRMADO", "idUsuario": 2, "dataHoraInicio": "2026-11-10T14:00:00", "motivo": "..."} */
    @PatchMapping("/{id}/status")
    public Agendamento mudarStatus(@PathVariable Long id, @Valid @RequestBody MudancaStatusAgendamento dados) {
        return service.mudarStatus(id, dados);
    }

    /** Todas as mudanças de status/horário (HISTORICO_AGENDAMENTO). */
    @GetMapping("/{id}/historico")
    public List<HistoricoAgendamento> historico(@PathVariable Long id) {
        return service.historico(id);
    }
}
