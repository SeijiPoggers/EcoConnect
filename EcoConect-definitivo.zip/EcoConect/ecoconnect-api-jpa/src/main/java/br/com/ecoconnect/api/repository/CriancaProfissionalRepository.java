package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.CriancaProfissional;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CriancaProfissionalRepository extends JpaRepository<CriancaProfissional, Long> {

    List<CriancaProfissional> findByIdCrianca(Long idCrianca);
    Optional<CriancaProfissional> findByIdCriancaAndIdProfissional(Long idCrianca, Long idProfissional);

}
