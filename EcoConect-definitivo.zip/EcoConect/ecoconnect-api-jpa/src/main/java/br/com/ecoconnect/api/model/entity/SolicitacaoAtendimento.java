package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;

/** Tabela `solicitacao_atendimento` (migration V2/V3). Gerada no mesmo padrão das entidades originais. */
@Entity
@Table(name = "solicitacao_atendimento")
public class SolicitacaoAtendimento implements Entidade<Long>, PertenceACrianca {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_solicitacao", nullable = false)
    private Long idSolicitacao;

    @Column(name = "id_instituicao", nullable = false)
    private Long idInstituicao;

    @Column(name = "id_servico")
    private Long idServico;

    @Column(name = "id_crianca")
    private Long idCrianca;

    @Column(name = "id_usuario_solicitante", nullable = false)
    private Long idUsuarioSolicitante;

    @Size(max = 1000)
    @Column(name = "mensagem", nullable = false, length = 1000)
    private String mensagem;

    @Size(max = 30)
    @Column(name = "forma_contato", length = 30)
    private String formaContato;

    @Size(max = 20)
    @Column(name = "situacao", length = 20)
    private String situacao;

    @Size(max = 1000)
    @Column(name = "resposta", length = 1000)
    private String resposta;

    @Column(name = "id_usuario_resposta")
    private Long idUsuarioResposta;

    @Column(name = "data_resposta")
    private LocalDateTime dataResposta;

    @Column(name = "id_conversa")
    private Long idConversa;

    @Column(name = "data_criacao")
    private LocalDateTime dataCriacao;

    @Column(name = "data_atualizacao")
    private LocalDateTime dataAtualizacao;

    @PrePersist
    void aoInserir() {
        if (formaContato == null) formaContato = "MENSAGEM_NA_PLATAFORMA";
        if (situacao == null) situacao = "ENVIADA";
        if (dataCriacao == null) dataCriacao = LocalDateTime.now();
        if (dataAtualizacao == null) dataAtualizacao = LocalDateTime.now();
    }

    @PreUpdate
    void aoAtualizar() {
        dataAtualizacao = LocalDateTime.now();
    }

    @Override
    public Long chave() {
        return idSolicitacao;
    }

    @Override
    public void definirChave(Long id) {
        this.idSolicitacao = id;
    }

    public Long getIdSolicitacao() {
        return idSolicitacao;
    }

    public void setIdSolicitacao(Long idSolicitacao) {
        this.idSolicitacao = idSolicitacao;
    }

    public Long getIdInstituicao() {
        return idInstituicao;
    }

    public void setIdInstituicao(Long idInstituicao) {
        this.idInstituicao = idInstituicao;
    }

    public Long getIdServico() {
        return idServico;
    }

    public void setIdServico(Long idServico) {
        this.idServico = idServico;
    }

    public Long getIdCrianca() {
        return idCrianca;
    }

    public void setIdCrianca(Long idCrianca) {
        this.idCrianca = idCrianca;
    }

    public Long getIdUsuarioSolicitante() {
        return idUsuarioSolicitante;
    }

    public void setIdUsuarioSolicitante(Long idUsuarioSolicitante) {
        this.idUsuarioSolicitante = idUsuarioSolicitante;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public String getFormaContato() {
        return formaContato;
    }

    public void setFormaContato(String formaContato) {
        this.formaContato = formaContato;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

    public String getResposta() {
        return resposta;
    }

    public void setResposta(String resposta) {
        this.resposta = resposta;
    }

    public Long getIdUsuarioResposta() {
        return idUsuarioResposta;
    }

    public void setIdUsuarioResposta(Long idUsuarioResposta) {
        this.idUsuarioResposta = idUsuarioResposta;
    }

    public LocalDateTime getDataResposta() {
        return dataResposta;
    }

    public void setDataResposta(LocalDateTime dataResposta) {
        this.dataResposta = dataResposta;
    }

    public Long getIdConversa() {
        return idConversa;
    }

    public void setIdConversa(Long idConversa) {
        this.idConversa = idConversa;
    }

    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDateTime dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public LocalDateTime getDataAtualizacao() {
        return dataAtualizacao;
    }

    public void setDataAtualizacao(LocalDateTime dataAtualizacao) {
        this.dataAtualizacao = dataAtualizacao;
    }
}
