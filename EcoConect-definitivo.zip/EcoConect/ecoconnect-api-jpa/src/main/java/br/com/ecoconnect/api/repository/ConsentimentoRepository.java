package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.Consentimento;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `consentimento` (Spring Data JPA). */
public interface ConsentimentoRepository extends JpaRepository<Consentimento, Long> {
}
