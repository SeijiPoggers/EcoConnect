package br.com.ecoconnect.api.dto;

import br.com.ecoconnect.api.model.entity.Usuario;

/** Dados do usuário autenticado: perfil e o cadastro complementar (responsável ou profissional). */
public record LoginResposta(
        Usuario usuario,
        String perfil,
        Long idResponsavel,
        Long idProfissional) {
}
