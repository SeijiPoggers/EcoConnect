package br.com.ecoconnect.api.model.enums;

/** Base legal avaliada (LGPD). Valores idênticos ao ENUM do MySQL. */
public enum BaseLegal {
    NAO_AVALIADA, CONSENTIMENTO, TUTELA_DA_SAUDE, OBRIGACAO_LEGAL, OUTRA
}
