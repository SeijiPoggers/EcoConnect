package br.com.ecoconnect.api.service;

import br.com.ecoconnect.api.dto.Pagina;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.model.entity.Auditoria;
import br.com.ecoconnect.api.model.entity.Entidade;
import br.com.ecoconnect.api.model.entity.PertenceACrianca;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.repository.AuditoriaRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Grava a tabela AUDITORIA (somente inserção, regra RI-21).
 * Cada criação, alteração, exclusão lógica, validação e liberação feita pela API
 * gera uma linha com os valores anteriores e novos em JSON.
 */
@Service
public class AuditoriaService {

    private final AuditoriaRepository repository;
    private final ObjectMapper mapper;
    private final UsuarioAtual usuarioAtual;

    @PersistenceContext
    private EntityManager em;

    public AuditoriaService(AuditoriaRepository repository, ObjectMapper mapper, UsuarioAtual usuarioAtual) {
        this.repository = repository;
        this.mapper = mapper;
        this.usuarioAtual = usuarioAtual;
    }

    /** Fotografia do registro em JSON (a senha nunca entra: @JsonIgnore). */
    public String json(Object objeto) {
        if (objeto == null) return null;
        try {
            return mapper.writeValueAsString(objeto);
        } catch (JsonProcessingException e) {
            return null;
        }
    }

    /** Registra uma ação sobre uma entidade. antesJson pode ser null (criação). */
    @Transactional
    public void registrar(AcaoAuditoria acao, String tabela, Object entidade, String antesJson, Object depois) {
        Auditoria a = new Auditoria();
        a.setAcao(acao);
        a.setIdUsuario(usuarioAtual.id());
        a.setIdCrianca(entidade instanceof PertenceACrianca p ? p.getIdCrianca() : null);
        a.setTabelaAfetada(tabela);
        a.setIdRegistroAfetado(limitar(idDe(entidade), 64));
        a.setValoresAnteriores(antesJson);
        a.setValoresNovos(json(depois));
        a.setIpOrigem(usuarioAtual.ip());
        repository.save(a);
    }

    /** Registro sem entidade (ex.: login). */
    @Transactional
    public void registrarAcao(AcaoAuditoria acao, Long idUsuario, String tabela, String idRegistro) {
        Auditoria a = new Auditoria();
        a.setAcao(acao);
        a.setIdUsuario(idUsuario);
        a.setTabelaAfetada(tabela);
        a.setIdRegistroAfetado(limitar(idRegistro, 64));
        a.setIpOrigem(usuarioAtual.ip());
        repository.save(a);
    }

    /**
     * Registro de uma gravação feita por SQL (tabelas novas sem entidade JPA), com os valores
     * anteriores e novos em JSON. antes/depois podem ser mapas, records ou null.
     */
    @Transactional
    public void registrarDados(AcaoAuditoria acao, String tabela, Object idRegistro, Long idCrianca, Object antes, Object depois) {
        Auditoria a = new Auditoria();
        a.setAcao(acao);
        a.setIdUsuario(usuarioAtual.id());
        a.setIdCrianca(idCrianca);
        a.setTabelaAfetada(tabela);
        a.setIdRegistroAfetado(limitar(idRegistro == null ? null : String.valueOf(idRegistro), 64));
        a.setValoresAnteriores(antes instanceof String s ? s : json(antes));
        a.setValoresNovos(depois instanceof String s ? s : json(depois));
        a.setIpOrigem(usuarioAtual.ip());
        repository.save(a);
    }

    /** Inserção manual pelo front-end (ex.: LOGOUT, CONSULTA a prontuário). */
    @Transactional
    public Auditoria inserirManual(Auditoria a) {
        a.setIdAuditoria(null);
        a.setDataHora(null);
        if (a.getIdUsuario() == null) a.setIdUsuario(usuarioAtual.id());
        if (a.getIpOrigem() == null) a.setIpOrigem(usuarioAtual.ip());
        return repository.saveAndFlush(a);
    }

    @Transactional(readOnly = true)
    public Pagina<Auditoria> listar(Auditoria filtro, Pageable pageable) {
        ExampleMatcher matcher = ExampleMatcher.matching().withIgnoreNullValues()
                .withStringMatcher(ExampleMatcher.StringMatcher.EXACT);
        return Pagina.de(repository.findAll(Example.of(filtro, matcher), pageable));
    }

    @Transactional(readOnly = true)
    public Auditoria buscar(Long id) {
        return repository.findById(id).orElseThrow(() -> new NaoEncontradoException("auditoria", id));
    }

    private String idDe(Object entidade) {
        if (entidade == null) return null;
        if (entidade instanceof Entidade<?> e) return String.valueOf(e.chave());
        Object id = em.getEntityManagerFactory().getPersistenceUnitUtil().getIdentifier(entidade);
        return String.valueOf(id);
    }

    private static String limitar(String s, int max) {
        return s == null || s.length() <= max ? s : s.substring(0, max);
    }
}
