package br.com.ecoconnect.api.service.pessoa;

import br.com.ecoconnect.api.exception.ConflitoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.CriancaResponsavel;
import br.com.ecoconnect.api.model.enums.StatusVinculo;
import br.com.ecoconnect.api.repository.CriancaResponsavelRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.Verificacoes;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Set;

/**
 * CRIANCA_RESPONSAVEL: vínculo autorizado entre criança e responsável, com permissões.
 * Regras: um par só uma vez (UNIQUE); no máximo um responsável principal ATIVO por criança (E.3).
 * DELETE revoga o vínculo (status REVOGADO + data_fim).
 */
@Service
public class CriancaResponsavelService extends CrudService<CriancaResponsavel, Long> {

    private final CriancaResponsavelRepository vinculoRepository;
    private final Verificacoes verificacoes;

    public CriancaResponsavelService(CriancaResponsavelRepository repository, AuditoriaService auditoria,
                                     Verificacoes verificacoes) {
        super(repository, auditoria, "crianca_responsavel");
        this.vinculoRepository = repository;
        this.verificacoes = verificacoes;
    }

    @Override
    protected void antesDeCriar(CriancaResponsavel v) {
        verificacoes.crianca(v.getIdCrianca());
        verificacoes.responsavel(v.getIdResponsavel());
        verificacoes.usuarioDaEquipe(v.getIdUsuarioCadastro(), "Quem cadastra o vínculo");
        if (vinculoRepository.existsByIdCriancaAndIdResponsavel(v.getIdCrianca(), v.getIdResponsavel())) {
            throw new ConflitoException("Este responsável já tem vínculo com esta criança. Altere o vínculo existente.");
        }
        if (v.getDataInicio() == null) v.setDataInicio(LocalDate.now());
        if (v.getStatus() == null) v.setStatus(StatusVinculo.ATIVO);
        v.setDataFim(v.getStatus() == StatusVinculo.REVOGADO ? LocalDate.now() : null);
        if (principalAtivo(v) && vinculoRepository.existsByIdCriancaAndResponsavelPrincipalTrueAndStatus(
                v.getIdCrianca(), StatusVinculo.ATIVO)) {
            throw new RegraNegocioException("A criança já tem um responsável principal ativo.");
        }
    }

    @Override
    protected Set<String> camposProtegidos() {
        return Set.of("idCrianca", "idResponsavel", "idUsuarioCadastro");
    }

    @Override
    protected void antesDeSalvarAtualizacao(CriancaResponsavel v) {
        if (v.getDataInicio() == null) {
            throw new RegraNegocioException("Informe a data de início do vínculo.");
        }
        if (v.getStatus() == StatusVinculo.REVOGADO && v.getDataFim() == null) v.setDataFim(LocalDate.now());
        if (v.getStatus() == StatusVinculo.ATIVO) v.setDataFim(null);
        if (principalAtivo(v) && vinculoRepository
                .existsByIdCriancaAndResponsavelPrincipalTrueAndStatusAndIdCriancaResponsavelNot(
                        v.getIdCrianca(), StatusVinculo.ATIVO, v.getIdCriancaResponsavel())) {
            throw new RegraNegocioException("A criança já tem outro responsável principal ativo.");
        }
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.LOGICA;
    }

    @Override
    protected void aplicarExclusaoLogica(CriancaResponsavel v) {
        v.setStatus(StatusVinculo.REVOGADO);
        if (v.getDataFim() == null) v.setDataFim(LocalDate.now());
    }

    private static boolean principalAtivo(CriancaResponsavel v) {
        return Boolean.TRUE.equals(v.getResponsavelPrincipal()) && v.getStatus() == StatusVinculo.ATIVO;
    }
}
