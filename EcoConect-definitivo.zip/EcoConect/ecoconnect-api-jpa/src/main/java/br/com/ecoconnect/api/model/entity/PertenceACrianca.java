package br.com.ecoconnect.api.model.entity;

/** Tabelas que têm a coluna id_crianca (usada para preencher auditoria.id_crianca). */
public interface PertenceACrianca {

    Long getIdCrianca();
}
