package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.AgendamentoProfissional;
import br.com.ecoconnect.api.model.entity.AgendamentoProfissionalId;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `agendamento_profissional` (Spring Data JPA). */
public interface AgendamentoProfissionalRepository extends JpaRepository<AgendamentoProfissional, AgendamentoProfissionalId> {

    List<AgendamentoProfissional> findByIdAgendamento(Long idAgendamento);
}
