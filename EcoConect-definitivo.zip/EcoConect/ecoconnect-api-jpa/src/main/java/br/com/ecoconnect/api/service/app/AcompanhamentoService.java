package br.com.ecoconnect.api.service.app;

import br.com.ecoconnect.api.dto.MudancaStatusAgendamento;
import br.com.ecoconnect.api.exception.NaoAutorizadoException;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Agendamento;
import br.com.ecoconnect.api.model.entity.AtendimentoProfissional;
import br.com.ecoconnect.api.model.entity.Atendimento;
import br.com.ecoconnect.api.model.entity.RegistroSessao;
import br.com.ecoconnect.api.model.entity.RelatorioAtendimento;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.StatusAgendamento;
import br.com.ecoconnect.api.repository.AgendamentoRepository;
import br.com.ecoconnect.api.repository.AtendimentoRepository;
import br.com.ecoconnect.api.repository.RegistroSessaoRepository;
import br.com.ecoconnect.api.seguranca.ContextoAtual;
import br.com.ecoconnect.api.seguranca.ContextoUsuario;
import br.com.ecoconnect.api.seguranca.EscopoAcesso;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.agenda.AgendamentoProfissionalService;
import br.com.ecoconnect.api.service.agenda.AgendamentoService;
import br.com.ecoconnect.api.service.agenda.AtendimentoEquipeService;
import br.com.ecoconnect.api.service.agenda.AtendimentoService;
import br.com.ecoconnect.api.service.agenda.RelatorioAtendimentoService;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Frente A: registro de sessões e trajetória de acompanhamento.
 * A sessão é gravada pelo fluxo original (AGENDAMENTO -> REALIZADO -> ATENDIMENTO -> participantes e
 * atividades -> RELATÓRIO), com histórico e auditoria, e complementada pelo REGISTRO_SESSAO estruturado.
 * O sistema não gera diagnósticos nem conclusões clínicas: só organiza o que os profissionais registram.
 */
@Service
public class AcompanhamentoService {

    private final AgendamentoService agendamentoService;
    private final AgendamentoProfissionalService designacaoService;
    private final AtendimentoService atendimentoService;
    private final AtendimentoEquipeService equipeService;
    private final RelatorioAtendimentoService relatorioService;
    private final AgendamentoRepository agendamentoRepository;
    private final AtendimentoRepository atendimentoRepository;
    private final RegistroSessaoRepository registroRepository;
    private final EscopoAcesso escopo;
    private final AuditoriaService auditoria;
    private final Consultas consultas;

    public AcompanhamentoService(AgendamentoService agendamentoService, AgendamentoProfissionalService designacaoService,
                                 AtendimentoService atendimentoService, AtendimentoEquipeService equipeService,
                                 RelatorioAtendimentoService relatorioService, AgendamentoRepository agendamentoRepository,
                                 AtendimentoRepository atendimentoRepository, RegistroSessaoRepository registroRepository,
                                 EscopoAcesso escopo, AuditoriaService auditoria, Consultas consultas) {
        this.agendamentoService = agendamentoService;
        this.designacaoService = designacaoService;
        this.atendimentoService = atendimentoService;
        this.equipeService = equipeService;
        this.relatorioService = relatorioService;
        this.agendamentoRepository = agendamentoRepository;
        this.atendimentoRepository = atendimentoRepository;
        this.registroRepository = registroRepository;
        this.escopo = escopo;
        this.auditoria = auditoria;
        this.consultas = consultas;
    }

    // ============================================================== registro de sessão

    public record AtividadeSessao(Integer idAtividade, Integer duracaoMinutos, String observacao) {
    }

    public record RelatorioSessao(String titulo, String conteudo, Boolean liberarParaFamilia) {
    }

    public record NovaSessao(Long idCrianca, Long idAgendamento, LocalDateTime inicio, LocalDateTime fim,
                             String tipoAtendimento, List<Long> idsProfissionais, List<AtividadeSessao> atividades,
                             String objetivosTrabalhados, String evolucaoObservada, String dificuldadesObservadas,
                             String recomendacoes, String proximosPassos, String observacoesGerais,
                             RelatorioSessao relatorio) {
    }

    @Transactional
    public Map<String, Object> registrarSessao(NovaSessao s) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (!ctx.equipe()) throw new NaoAutorizadoException(403, "Somente profissionais e administradores registram sessões.");
        if (s.tipoAtendimento() == null || s.tipoAtendimento().isBlank()) throw new RegraNegocioException("Informe o tipo de atendimento.");
        if (s.inicio() == null) throw new RegraNegocioException("Informe a data e o horário de início da sessão.");
        if (s.inicio().isAfter(LocalDateTime.now().plusMinutes(5))) {
            throw new RegraNegocioException("Só é possível registrar sessões que já aconteceram. Para o futuro, use a agenda.");
        }
        Set<Long> profissionais = new LinkedHashSet<>();
        if (ctx.idProfissional() != null) profissionais.add(ctx.idProfissional());
        if (s.idsProfissionais() != null) profissionais.addAll(s.idsProfissionais());
        if (profissionais.isEmpty()) throw new RegraNegocioException("Informe ao menos um profissional que participou da sessão.");

        Agendamento ag;
        if (s.idAgendamento() == null) {
            if (s.idCrianca() == null) throw new RegraNegocioException("Informe a pessoa acompanhada.");
            escopo.exigirAcompanhamento(s.idCrianca());
            Agendamento novo = new Agendamento();
            novo.setIdCrianca(s.idCrianca());
            novo.setIdUsuarioSolicitante(ctx.idUsuario());
            novo.setDataHoraInicioSolicitada(s.inicio());
            novo.setDataHoraFimSolicitada(s.fim());
            novo.setObservacaoSolicitacao("Registrado junto com a sessão pelo profissional.");
            ag = agendamentoService.criar(novo);
            for (Long p : profissionais) designacaoService.designar(ag.getIdAgendamento(), p, ctx.idUsuario());
            agendamentoService.mudarStatus(ag.getIdAgendamento(), new MudancaStatusAgendamento(StatusAgendamento.CONFIRMADO,
                    ctx.idUsuario(), s.inicio(), s.fim(), "Confirmado no registro da sessão."));
            ag = agendamentoService.mudarStatus(ag.getIdAgendamento(), new MudancaStatusAgendamento(StatusAgendamento.REALIZADO,
                    ctx.idUsuario(), null, null, "Sessão realizada."));
        } else {
            ag = agendamentoService.buscar(s.idAgendamento());
            escopo.exigirAcompanhamento(ag.getIdCrianca());
            if (ag.getStatus() == StatusAgendamento.CONFIRMADO) {
                ag = agendamentoService.mudarStatus(ag.getIdAgendamento(), new MudancaStatusAgendamento(StatusAgendamento.REALIZADO,
                        ctx.idUsuario(), null, null, "Sessão realizada."));
            } else if (ag.getStatus() != StatusAgendamento.REALIZADO) {
                throw new RegraNegocioException("O agendamento precisa estar CONFIRMADO para registrar a sessão (situação atual: "
                        + ag.getStatus() + ").");
            }
        }

        Atendimento at = new Atendimento();
        at.setIdAgendamento(ag.getIdAgendamento());
        at.setDataHoraInicioReal(s.inicio());
        at.setDataHoraFimReal(s.fim());
        at.setObservacoesGerais(PessoasService.texto(s.observacoesGerais(), 20000));
        at.setIdUsuarioRegistro(ctx.idUsuario());
        Atendimento salvo = atendimentoService.criar(at);
        Long idAt = salvo.getIdAtendimento();

        equipeService.importarDoAgendamento(idAt);
        Set<Long> jaParticipam = new LinkedHashSet<>();
        for (AtendimentoProfissional ap : equipeService.profissionais(idAt)) jaParticipam.add(ap.getIdProfissional());
        for (Long p : profissionais) {
            if (!jaParticipam.contains(p)) equipeService.adicionarProfissional(idAt, p, null);
        }
        if (s.atividades() != null) {
            for (AtividadeSessao a : s.atividades()) {
                if (a == null || a.idAtividade() == null) continue;
                equipeService.adicionarAtividade(idAt, a.idAtividade(), a.duracaoMinutos(), a.observacao());
            }
        }

        RegistroSessao r = new RegistroSessao();
        r.setIdAtendimento(idAt);
        preencher(r, s.tipoAtendimento(), s.objetivosTrabalhados(), s.evolucaoObservada(), s.dificuldadesObservadas(),
                s.recomendacoes(), s.proximosPassos());
        r.setIdUsuarioRegistro(ctx.idUsuario());
        RegistroSessao rs = registroRepository.saveAndFlush(r);
        auditoria.registrar(AcaoAuditoria.CRIACAO, "registro_sessao", rs, null, rs);

        if (s.relatorio() != null && s.relatorio().conteudo() != null && !s.relatorio().conteudo().isBlank()) {
            RelatorioAtendimento rel = new RelatorioAtendimento();
            rel.setIdAtendimento(idAt);
            rel.setIdProfissionalAutor(ctx.idProfissional() != null ? ctx.idProfissional() : profissionais.iterator().next());
            rel.setTitulo(s.relatorio().titulo() == null || s.relatorio().titulo().isBlank()
                    ? "Relatório da sessão de " + s.inicio().toLocalDate() : PessoasService.texto(s.relatorio().titulo(), 150));
            rel.setConteudo(s.relatorio().conteudo().trim());
            RelatorioAtendimento criado = relatorioService.criar(rel);
            if (Boolean.TRUE.equals(s.relatorio().liberarParaFamilia())) {
                relatorioService.finalizar(criado.getIdRelatorio());
                relatorioService.liberar(criado.getIdRelatorio());
            }
        }
        return sessao(idAt);
    }

    public record AlteracaoSessao(String tipoAtendimento, String objetivosTrabalhados, String evolucaoObservada,
                                  String dificuldadesObservadas, String recomendacoes, String proximosPassos) {
    }

    @Transactional
    public Map<String, Object> alterarSessao(Long idAtendimento, AlteracaoSessao d) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (!ctx.equipe()) throw new NaoAutorizadoException(403, "Somente a equipe altera registros de sessão.");
        Long idCrianca = escopo.criancaDoAtendimento(idAtendimento);
        if (idCrianca == null) throw new NaoEncontradoException("atendimento", idAtendimento);
        escopo.exigirAcompanhamento(idCrianca);
        boolean participou = ctx.idProfissional() != null && consultas.contar("SELECT COUNT(*) FROM atendimento_profissional "
                + "WHERE id_atendimento = ? AND id_profissional = ?", idAtendimento, ctx.idProfissional()) > 0;
        if (!ctx.administrador() && !participou) {
            throw new NaoAutorizadoException(403, "Só quem participou da sessão (ou o administrador) pode alterar o registro.");
        }
        RegistroSessao r = registroRepository.findById(idAtendimento).orElse(null);
        String antes = auditoria.json(r);
        if (r == null) {
            r = new RegistroSessao();
            r.setIdAtendimento(idAtendimento);
            r.setIdUsuarioRegistro(ctx.idUsuario());
        } else {
            r.setIdUsuarioAtualizacao(ctx.idUsuario());
            r.setDataAtualizacao(LocalDateTime.now());
        }
        preencher(r, d.tipoAtendimento() == null ? r.getTipoAtendimento() : d.tipoAtendimento(), d.objetivosTrabalhados(),
                d.evolucaoObservada(), d.dificuldadesObservadas(), d.recomendacoes(), d.proximosPassos());
        if (r.getTipoAtendimento() == null) throw new RegraNegocioException("Informe o tipo de atendimento.");
        RegistroSessao s = registroRepository.saveAndFlush(r);
        auditoria.registrar(antes == null ? AcaoAuditoria.CRIACAO : AcaoAuditoria.ATUALIZACAO, "registro_sessao", s, antes, s);
        return sessao(idAtendimento);
    }

    private static void preencher(RegistroSessao r, String tipo, String objetivos, String evolucao, String dificuldades,
                                  String recomendacoes, String proximos) {
        r.setTipoAtendimento(PessoasService.texto(tipo, 80));
        r.setObjetivosTrabalhados(PessoasService.texto(objetivos, 20000));
        r.setEvolucaoObservada(PessoasService.texto(evolucao, 20000));
        r.setDificuldadesObservadas(PessoasService.texto(dificuldades, 20000));
        r.setRecomendacoes(PessoasService.texto(recomendacoes, 20000));
        r.setProximosPassos(PessoasService.texto(proximos, 20000));
    }

    @Transactional(readOnly = true)
    public Map<String, Object> sessao(Long idAtendimento) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        Long idCrianca = escopo.criancaDoAtendimento(idAtendimento);
        if (idCrianca == null) throw new NaoEncontradoException("atendimento", idAtendimento);
        escopo.exigirAcompanhamento(idCrianca);
        Map<String, Object> s = consultas.um("SELECT t.id_atendimento AS idAtendimento, t.id_agendamento AS idAgendamento, "
                + "a.id_crianca AS idCrianca, c.nome_completo AS pessoa, " + Consultas.dt("t.data_hora_inicio_real") + " AS inicio, "
                + Consultas.dt("t.data_hora_fim_real") + " AS fim, t.observacoes_gerais AS observacoesGerais, "
                + "rs.tipo_atendimento AS tipoAtendimento, rs.objetivos_trabalhados AS objetivosTrabalhados, "
                + "rs.evolucao_observada AS evolucaoObservada, rs.dificuldades_observadas AS dificuldadesObservadas, "
                + "rs.recomendacoes, rs.proximos_passos AS proximosPassos, ur.nome_completo AS registradoPor, "
                + Consultas.dt("COALESCE(rs.data_registro, t.data_registro)") + " AS dataRegistro, ua.nome_completo AS atualizadoPor, "
                + Consultas.dt("rs.data_atualizacao") + " AS dataAtualizacao "
                + "FROM atendimento t JOIN agendamento a ON a.id_agendamento = t.id_agendamento JOIN crianca c ON c.id_crianca = a.id_crianca "
                + "LEFT JOIN registro_sessao rs ON rs.id_atendimento = t.id_atendimento "
                + "LEFT JOIN usuario ur ON ur.id_usuario = COALESCE(rs.id_usuario_registro, t.id_usuario_registro) "
                + "LEFT JOIN usuario ua ON ua.id_usuario = rs.id_usuario_atualizacao WHERE t.id_atendimento = ?", idAtendimento);
        if (s == null) throw new NaoEncontradoException("atendimento", idAtendimento);
        if (ctx.familia()) s.remove("observacoesGerais");   // anotações internas da equipe
        s.put("profissionais", consultas.lista("SELECT tp.id_profissional AS idProfissional, u.nome_completo AS nome, "
                + "tp.funcao_no_atendimento AS funcao FROM atendimento_profissional tp JOIN profissional p ON p.id_profissional = tp.id_profissional "
                + "JOIN usuario u ON u.id_usuario = p.id_usuario WHERE tp.id_atendimento = ? ORDER BY u.nome_completo", idAtendimento));
        s.put("atividades", consultas.lista("SELECT aa.id_atividade AS idAtividade, at.nome, aa.duracao_minutos AS duracaoMinutos, "
                + "aa.observacao FROM atendimento_atividade aa JOIN atividade at ON at.id_atividade = aa.id_atividade "
                + "WHERE aa.id_atendimento = ? ORDER BY at.nome", idAtendimento));
        String filtroRel = ctx.familia() ? " AND r.situacao = 'LIBERADO_RESPONSAVEL'" : " AND r.situacao <> 'SUBSTITUIDO'";
        s.put("relatorios", consultas.lista("SELECT r.id_relatorio AS idRelatorio, r.titulo, r.conteudo, r.situacao, "
                + "r.numero_versao AS versao, u.nome_completo AS autor, " + Consultas.dt("r.data_elaboracao") + " AS dataElaboracao "
                + "FROM relatorio_atendimento r JOIN profissional p ON p.id_profissional = r.id_profissional_autor "
                + "JOIN usuario u ON u.id_usuario = p.id_usuario WHERE r.id_atendimento = ?" + filtroRel
                + " ORDER BY r.data_elaboracao DESC", idAtendimento));
        return s;
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> sessoesDaPessoa(Long idCrianca) {
        escopo.exigirAcompanhamento(idCrianca);
        return consultas.lista("SELECT t.id_atendimento AS idAtendimento, " + Consultas.dt("t.data_hora_inicio_real") + " AS inicio, "
                + "rs.tipo_atendimento AS tipoAtendimento, "
                + "(SELECT GROUP_CONCAT(u.nome_completo SEPARATOR ', ') FROM atendimento_profissional tp "
                + " JOIN profissional p ON p.id_profissional = tp.id_profissional JOIN usuario u ON u.id_usuario = p.id_usuario "
                + " WHERE tp.id_atendimento = t.id_atendimento) AS profissionais "
                + "FROM atendimento t JOIN agendamento a ON a.id_agendamento = t.id_agendamento LEFT JOIN registro_sessao rs "
                + "ON rs.id_atendimento = t.id_atendimento WHERE a.id_crianca = ? ORDER BY t.data_hora_inicio_real DESC", idCrianca);
    }

    // ============================================================== trajetória

    @Transactional(readOnly = true)
    public Map<String, Object> trajetoria(Long idCrianca) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        escopo.exigirAcompanhamento(idCrianca);
        boolean familia = ctx.familia();
        List<Map<String, Object>> itens = new ArrayList<>();

        for (Map<String, Object> a : consultas.lista("SELECT a.id_agendamento AS id, a.status, "
                + Consultas.dt("COALESCE(a.data_hora_inicio, a.data_hora_inicio_solicitada)") + " AS data, "
                + Consultas.dt("COALESCE(a.data_hora_fim, a.data_hora_fim_solicitada)") + " AS fim, "
                + "(SELECT GROUP_CONCAT(u.nome_completo SEPARATOR ', ') FROM agendamento_profissional ap "
                + " JOIN profissional p ON p.id_profissional = ap.id_profissional JOIN usuario u ON u.id_usuario = p.id_usuario "
                + " WHERE ap.id_agendamento = a.id_agendamento) AS profissionais "
                + "FROM agendamento a WHERE a.id_crianca = ? AND NOT EXISTS (SELECT 1 FROM atendimento t WHERE t.id_agendamento = a.id_agendamento)",
                idCrianca)) {
            a.put("tipo", "AGENDAMENTO");
            itens.add(a);
        }
        for (Map<String, Object> s : consultas.lista("SELECT t.id_atendimento AS id, " + Consultas.dt("t.data_hora_inicio_real") + " AS data, "
                + Consultas.dt("t.data_hora_fim_real") + " AS fim, rs.tipo_atendimento AS tipoAtendimento, "
                + "rs.objetivos_trabalhados AS objetivosTrabalhados, rs.evolucao_observada AS evolucaoObservada, "
                + "rs.dificuldades_observadas AS dificuldadesObservadas, rs.recomendacoes, rs.proximos_passos AS proximosPassos, "
                + "(SELECT GROUP_CONCAT(u.nome_completo SEPARATOR ', ') FROM atendimento_profissional tp "
                + " JOIN profissional p ON p.id_profissional = tp.id_profissional JOIN usuario u ON u.id_usuario = p.id_usuario "
                + " WHERE tp.id_atendimento = t.id_atendimento) AS profissionais, "
                + "(SELECT GROUP_CONCAT(at.nome SEPARATOR ', ') FROM atendimento_atividade aa JOIN atividade at ON at.id_atividade = aa.id_atividade "
                + " WHERE aa.id_atendimento = t.id_atendimento) AS atividades "
                + "FROM atendimento t JOIN agendamento a ON a.id_agendamento = t.id_agendamento "
                + "LEFT JOIN registro_sessao rs ON rs.id_atendimento = t.id_atendimento WHERE a.id_crianca = ?", idCrianca)) {
            s.put("tipo", "SESSAO");
            itens.add(s);
        }
        String filtroRel = familia ? " AND r.situacao = 'LIBERADO_RESPONSAVEL'" : " AND r.situacao <> 'SUBSTITUIDO'";
        for (Map<String, Object> r : consultas.lista("SELECT r.id_relatorio AS id, r.id_atendimento AS idAtendimento, r.titulo, "
                + "r.situacao, r.numero_versao AS versao, " + Consultas.dt("COALESCE(r.data_finalizacao, r.data_elaboracao)") + " AS data, "
                + "u.nome_completo AS autor FROM relatorio_atendimento r JOIN atendimento t ON t.id_atendimento = r.id_atendimento "
                + "JOIN agendamento a ON a.id_agendamento = t.id_agendamento JOIN profissional p ON p.id_profissional = r.id_profissional_autor "
                + "JOIN usuario u ON u.id_usuario = p.id_usuario WHERE a.id_crianca = ?" + filtroRel, idCrianca)) {
            r.put("tipo", "RELATORIO");
            itens.add(r);
        }
        for (Map<String, Object> h : consultas.lista("SELECT h.id_historico_saude AS id, h.tipo_evento AS tipoEvento, h.titulo, "
                + "h.descricao, " + Consultas.d("h.data_evento") + " AS data, h.instituicao_origem AS instituicaoOrigem, "
                + "h.situacao_validacao AS situacaoValidacao FROM historico_saude h WHERE h.id_crianca = ? AND h.situacao_registro = 'ATIVO'",
                idCrianca)) {
            h.put("tipo", "SAUDE");
            itens.add(h);
        }
        itens.sort(Comparator.comparing((Map<String, Object> m) -> String.valueOf(m.get("data"))).reversed());

        List<Map<String, Object>> objetivos = consultas.lista("SELECT o.id_objetivo AS idObjetivo, o.titulo, o.descricao, o.situacao, "
                + Consultas.d("o.data_inicio") + " AS dataInicio, " + Consultas.d("o.data_prevista_fim") + " AS dataPrevistaFim, "
                + "u.nome_completo AS definidoPor FROM objetivo o JOIN profissional p ON p.id_profissional = o.id_profissional_definidor "
                + "JOIN usuario u ON u.id_usuario = p.id_usuario WHERE o.id_crianca = ? AND o.situacao <> 'CANCELADO' "
                + "ORDER BY o.situacao, o.data_inicio DESC", idCrianca);
        for (Map<String, Object> o : objetivos) {
            List<Map<String, Object>> indicadores = consultas.lista("SELECT i.id_indicador AS idIndicador, i.nome, i.tipo_medida AS tipoMedida, "
                    + "i.unidade_medida AS unidade, oi.valor_referencia_inicial AS valorInicial, oi.meta_valor AS meta, "
                    + "oi.descricao_meta AS descricaoMeta FROM objetivo_indicador oi JOIN indicador i ON i.id_indicador = oi.id_indicador "
                    + "WHERE oi.id_objetivo = ? ORDER BY i.nome", o.get("idObjetivo"));
            for (Map<String, Object> ind : indicadores) {
                ind.put("avaliacoes", consultas.lista("SELECT " + Consultas.d("av.data_avaliacao") + " AS data, "
                        + "av.valor_numerico AS valorNumerico, av.valor_qualitativo AS valorQualitativo, av.observacao "
                        + "FROM avaliacao_indicador av WHERE av.id_objetivo = ? AND av.id_indicador = ? AND av.situacao = 'VIGENTE' "
                        + "ORDER BY av.data_avaliacao", o.get("idObjetivo"), ind.get("idIndicador")));
            }
            o.put("indicadores", indicadores);
        }
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("idCrianca", idCrianca);
        r.put("itens", itens);
        r.put("objetivos", objetivos);
        r.put("aviso", "Esta linha do tempo reúne o que foi registrado pela equipe e pela família. "
                + "Ela não substitui a avaliação dos profissionais que acompanham a pessoa.");
        return r;
    }
}
