package br.com.ecoconnect.api.config;

import br.com.ecoconnect.api.seguranca.EscopoInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/** CORS (acesso do front-end) e codificador de senha BCrypt. */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    /**
     * Origens de OUTROS endereços autorizadas a chamar a API com cookie (separe por vírgula).
     * Vazio (padrão): só o próprio EcoConect, servido no mesmo endereço da API, pode chamá-la.
     */
    @Value("${ecoconnect.cors.origens:}")
    private String origens;

    private final EscopoInterceptor escopoInterceptor;

    public WebConfig(EscopoInterceptor escopoInterceptor) {
        this.escopoInterceptor = escopoInterceptor;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(escopoInterceptor).addPathPatterns("/api/**");
    }

    /** A aplicação web fica em /app/ (arquivos em static/app). Spring Boot só serve index.html automaticamente na raiz. */
    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/app").setViewName("redirect:/app/");
        registry.addViewController("/app/").setViewName("forward:/app/index.html");
    }

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        if (origens == null || origens.isBlank() || "*".equals(origens.trim())) return;
        registry.addMapping("/api/**")
                .allowedOrigins(origens.trim().split("\\s*,\\s*"))
                .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);
    }

    /** Senhas guardadas como hash BCrypt em usuario.senha_hash (nunca texto puro). */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
