package br.com.ecoconnect.api.controller.app;

import br.com.ecoconnect.api.service.app.AdminService;
import br.com.ecoconnect.api.service.app.PrivacidadeService;
import br.com.ecoconnect.api.service.app.RelatorioService;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** Relatórios (CSV), privacidade do titular (LGPD) e administração de contas e auditoria. */
@RestController
public class GestaoController {

    private final RelatorioService relatorios;
    private final PrivacidadeService privacidade;
    private final AdminService admin;

    public GestaoController(RelatorioService relatorios, PrivacidadeService privacidade, AdminService admin) {
        this.relatorios = relatorios;
        this.privacidade = privacidade;
        this.admin = admin;
    }

    // ---------------------------------------------------------------- relatórios

    @GetMapping("/api/relatorios")
    public List<Map<String, Object>> relatoriosDisponiveis() {
        return relatorios.disponiveis();
    }

    @GetMapping("/api/relatorios/{tipo}")
    public ResponseEntity<byte[]> relatorio(@PathVariable("tipo") String tipo,
                                            @RequestParam(name = "de", required = false) LocalDate de,
                                            @RequestParam(name = "ate", required = false) LocalDate ate,
                                            @RequestParam(name = "idCrianca", required = false) Long idCrianca) {
        RelatorioService.Arquivo a = relatorios.gerar(tipo, de, ate, idCrianca);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename(a.nome(), StandardCharsets.UTF_8).build().toString())
                .contentType(MediaType.parseMediaType("text/csv; charset=UTF-8"))
                .body(a.conteudo());
    }

    // ---------------------------------------------------------------- privacidade (titular)

    @GetMapping("/api/app/privacidade")
    public Map<String, Object> privacidade() {
        return privacidade.resumo();
    }

    @GetMapping("/api/app/privacidade/exportacao")
    public ResponseEntity<Map<String, Object>> exportar() {
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename("meus-dados-ecoconect.json").build().toString())
                .contentType(MediaType.APPLICATION_JSON)
                .body(privacidade.exportar());
    }

    @PostMapping("/api/app/privacidade/pedidos")
    public Map<String, Object> pedido(@RequestBody PrivacidadeService.NovoPedido dados) {
        return privacidade.solicitar(dados);
    }

    @PostMapping("/api/app/privacidade/consentimentos/{id}/revogacao")
    public Map<String, Object> revogar(@PathVariable("id") Long id) {
        return privacidade.revogarConsentimento(id);
    }

    // ---------------------------------------------------------------- administração

    @GetMapping("/api/admin/usuarios")
    public List<Map<String, Object>> usuarios(@RequestParam(name = "texto", required = false) String texto,
                                              @RequestParam(name = "perfil", required = false) String perfil,
                                              @RequestParam(name = "status", required = false) String status) {
        return admin.usuarios(texto, perfil, status);
    }

    @PostMapping("/api/admin/usuarios")
    public Map<String, Object> criarUsuario(@RequestBody AdminService.NovoUsuario dados) {
        return admin.criar(dados);
    }

    @PatchMapping("/api/admin/usuarios/{id}/status")
    public Map<String, Object> status(@PathVariable("id") Long id, @RequestBody AdminService.NovoStatus dados) {
        return admin.alterarStatus(id, dados);
    }

    @PostMapping("/api/admin/usuarios/{id}/senha-temporaria")
    public Map<String, Object> redefinirSenha(@PathVariable("id") Long id) {
        return admin.redefinirSenha(id);
    }

    @GetMapping("/api/admin/auditoria")
    public Map<String, Object> auditoria(@RequestParam(name = "acao", required = false) String acao,
                                         @RequestParam(name = "tabela", required = false) String tabela,
                                         @RequestParam(name = "idUsuario", required = false) Long idUsuario,
                                         @RequestParam(name = "idCrianca", required = false) Long idCrianca,
                                         @RequestParam(name = "de", required = false) LocalDate de,
                                         @RequestParam(name = "ate", required = false) LocalDate ate,
                                         @RequestParam(name = "pagina", required = false) Integer pagina) {
        return admin.auditoria(new AdminService.FiltroAuditoria(acao, tabela, idUsuario, idCrianca, de, ate, pagina));
    }

    @GetMapping("/api/admin/privacidade")
    public List<Map<String, Object>> pedidosPrivacidade(@RequestParam(name = "situacao", required = false) String situacao) {
        return privacidade.pedidos(situacao);
    }

    @PostMapping("/api/admin/privacidade/{id}/resposta")
    public List<Map<String, Object>> responderPedido(@PathVariable("id") Long id, @RequestBody PrivacidadeService.RespostaPedido dados) {
        return privacidade.responder(id, dados);
    }
}
