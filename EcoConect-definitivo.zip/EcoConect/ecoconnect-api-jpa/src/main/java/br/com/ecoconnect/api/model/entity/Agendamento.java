package br.com.ecoconnect.api.model.entity;

import br.com.ecoconnect.api.model.enums.StatusAgendamento;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;

/**
 * Tabela `agendamento` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 * CHECK chk_ag_confirmacao: ((status not in ('CONFIRMADO','AUSENTE','REALIZADO')) or ((data_hora_inicio is not null) and (id_usuario_confirmacao is not null)))
 * CHECK chk_ag_horario: ((data_hora_fim is null) or (data_hora_fim > data_hora_inicio))
 * CHECK chk_ag_horario_solicitado: ((data_hora_fim_solicitada is null) or (data_hora_fim_solicitada > data_hora_inicio_solicitada))
 */
@Entity
@Table(name = "agendamento")
public class Agendamento implements Entidade<Long>, PertenceACrianca {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_agendamento", nullable = false)
    private Long idAgendamento;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_crianca", nullable = false)
    private Long idCrianca;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_usuario_solicitante", nullable = false)
    private Long idUsuarioSolicitante;

    @NotNull(message = "campo obrigatório")
    @Column(name = "data_hora_inicio_solicitada", nullable = false)
    private LocalDateTime dataHoraInicioSolicitada;

    @Column(name = "data_hora_fim_solicitada")
    private LocalDateTime dataHoraFimSolicitada;

    @Size(max = 500)
    @Column(name = "observacao_solicitacao", length = 500)
    private String observacaoSolicitacao;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private StatusAgendamento status;

    @Column(name = "data_hora_inicio")
    private LocalDateTime dataHoraInicio;

    @Column(name = "data_hora_fim")
    private LocalDateTime dataHoraFim;

    @Column(name = "id_usuario_confirmacao")
    private Long idUsuarioConfirmacao;

    @Column(name = "data_confirmacao")
    private LocalDateTime dataConfirmacao;

    @Column(name = "data_solicitacao", nullable = false)
    private LocalDateTime dataSolicitacao;

    @PrePersist
    void aoInserir() {
        if (status == null) {
            status = StatusAgendamento.SOLICITADO;
        }
        if (dataSolicitacao == null) {
            dataSolicitacao = LocalDateTime.now();
        }
    }

    public Long getIdAgendamento() {
        return idAgendamento;
    }

    public void setIdAgendamento(Long idAgendamento) {
        this.idAgendamento = idAgendamento;
    }

    public Long getIdCrianca() {
        return idCrianca;
    }

    public void setIdCrianca(Long idCrianca) {
        this.idCrianca = idCrianca;
    }

    public Long getIdUsuarioSolicitante() {
        return idUsuarioSolicitante;
    }

    public void setIdUsuarioSolicitante(Long idUsuarioSolicitante) {
        this.idUsuarioSolicitante = idUsuarioSolicitante;
    }

    public LocalDateTime getDataHoraInicioSolicitada() {
        return dataHoraInicioSolicitada;
    }

    public void setDataHoraInicioSolicitada(LocalDateTime dataHoraInicioSolicitada) {
        this.dataHoraInicioSolicitada = dataHoraInicioSolicitada;
    }

    public LocalDateTime getDataHoraFimSolicitada() {
        return dataHoraFimSolicitada;
    }

    public void setDataHoraFimSolicitada(LocalDateTime dataHoraFimSolicitada) {
        this.dataHoraFimSolicitada = dataHoraFimSolicitada;
    }

    public String getObservacaoSolicitacao() {
        return observacaoSolicitacao;
    }

    public void setObservacaoSolicitacao(String observacaoSolicitacao) {
        this.observacaoSolicitacao = observacaoSolicitacao;
    }

    public StatusAgendamento getStatus() {
        return status;
    }

    public void setStatus(StatusAgendamento status) {
        this.status = status;
    }

    public LocalDateTime getDataHoraInicio() {
        return dataHoraInicio;
    }

    public void setDataHoraInicio(LocalDateTime dataHoraInicio) {
        this.dataHoraInicio = dataHoraInicio;
    }

    public LocalDateTime getDataHoraFim() {
        return dataHoraFim;
    }

    public void setDataHoraFim(LocalDateTime dataHoraFim) {
        this.dataHoraFim = dataHoraFim;
    }

    public Long getIdUsuarioConfirmacao() {
        return idUsuarioConfirmacao;
    }

    public void setIdUsuarioConfirmacao(Long idUsuarioConfirmacao) {
        this.idUsuarioConfirmacao = idUsuarioConfirmacao;
    }

    public LocalDateTime getDataConfirmacao() {
        return dataConfirmacao;
    }

    public void setDataConfirmacao(LocalDateTime dataConfirmacao) {
        this.dataConfirmacao = dataConfirmacao;
    }

    public LocalDateTime getDataSolicitacao() {
        return dataSolicitacao;
    }

    public void setDataSolicitacao(LocalDateTime dataSolicitacao) {
        this.dataSolicitacao = dataSolicitacao;
    }

    @Override
    public Long chave() {
        return idAgendamento;
    }

    @Override
    public void definirChave(Long id) {
        this.idAgendamento = id;
    }
}
