package br.com.ecoconnect.api.controller.agenda;

import br.com.ecoconnect.api.controller.base.LeituraController;
import br.com.ecoconnect.api.model.entity.Atendimento;
import br.com.ecoconnect.api.service.agenda.AtendimentoService;
import br.com.ecoconnect.api.service.base.CrudService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/** Atendimentos realizados. Sem DELETE. Profissionais e atividades em sub-recursos. */
@RestController
@RequestMapping("/api/atendimentos")
public class AtendimentoController extends LeituraController<Atendimento, Long> {

    private final AtendimentoService service;

    public AtendimentoController(AtendimentoService service) {
        this.service = service;
    }

    @Override
    protected CrudService<Atendimento, Long> service() {
        return service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Atendimento criar(@Valid @RequestBody Atendimento dados) {
        return service.criar(dados);
    }

    @PutMapping("/{id}")
    public Atendimento atualizar(@PathVariable Long id, @Valid @RequestBody Atendimento dados) {
        return service.atualizar(id, dados);
    }
}
