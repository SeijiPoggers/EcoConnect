package br.com.ecoconnect.api.dominio;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Política de acesso por rota (primeira regra que casar vence; o que não casar é negado).
 * Complementada pela verificação por registro (EscopoAcesso) dentro dos serviços:
 * esta classe decide "este perfil pode usar esta rota?"; o escopo decide
 * "pode ver ESTA pessoa?". Classe sem dependências de framework, testada isoladamente.
 */
public final class PoliticaAcesso {

    public enum Decisao { PUBLICA, PERMITIDA, NEGADA, EXIGE_LOGIN }

    private record Regra(String metodo, String padrao, Set<String> perfis, boolean publica) {
        boolean casa(String m, String caminho) {
            return ("*".equals(metodo) || metodo.equals(m)) && casaPadrao(padrao, caminho);
        }
    }

    private static final Set<String> AUTENTICADO = Papeis.TODOS;
    private static final Set<String> EQUIPE = Papeis.EQUIPE;
    private static final Set<String> ADMIN = Set.of(Papeis.ADMINISTRADOR);
    private static final Set<String> EQUIPE_E_FAMILIA = Set.of(Papeis.ADMINISTRADOR, Papeis.PROFISSIONAL,
            Papeis.RESPONSAVEL, Papeis.PESSOA_ACOMPANHADA);
    private static final Set<String> GESTORES_REDE = Set.of(Papeis.ADMINISTRADOR, Papeis.ADMIN_INSTITUCIONAL);

    private static final List<Regra> REGRAS = new ArrayList<>();

    static {
        publica("POST", "/api/auth/login");
        publica("POST", "/api/auth/token");
        publica("POST", "/api/auth/cadastro");
        publica("GET", "/api/saude");
        publica("GET", "/api/rede/catalogos");

        regra("*", "/api/auth/**", AUTENTICADO);
        regra("*", "/api/app/**", AUTENTICADO);          // regras finas nos serviços

        // Rede de apoio, SUS, FHIR e RNDS
        regra("GET", "/api/rede/**", AUTENTICADO);
        regra("*", "/api/rede/**", GESTORES_REDE);       // o serviço confere a instituição do administrador institucional
        regra("GET", "/api/sus/**", AUTENTICADO);
        regra("*", "/api/sus/**", ADMIN);                // importação do CNES
        regra("GET", "/api/fhir/**", Set.of(Papeis.ADMINISTRADOR, Papeis.PROFISSIONAL, Papeis.ADMIN_INSTITUCIONAL));
        regra("GET", "/api/rnds/**", AUTENTICADO);
        regra("*", "/api/rnds/**", ADMIN);
        regra("*", "/api/relatorios/**", Set.of(Papeis.ADMINISTRADOR, Papeis.PROFISSIONAL, Papeis.ADMIN_INSTITUCIONAL));
        regra("*", "/api/admin/**", ADMIN);

        // API original: catálogos (leitura para todos, escrita só administrador)
        for (String cat : List.of("/api/especialidades", "/api/atividades", "/api/indicadores",
                "/api/condicoes-saude", "/api/diagnosticos")) {
            regra("GET", cat, AUTENTICADO);
            regra("GET", cat + "/**", AUTENTICADO);
            regra("*", cat, ADMIN);
            regra("*", cat + "/**", ADMIN);
        }
        regra("GET", "/api/perfis", AUTENTICADO);
        regra("*", "/api/perfis/**", ADMIN);
        regra("*", "/api/perfis", ADMIN);
        regra("*", "/api/usuarios/**", ADMIN);
        regra("*", "/api/usuarios", ADMIN);
        regra("*", "/api/auditoria/**", ADMIN);
        regra("*", "/api/auditoria", ADMIN);
        regra("*", "/api/notificacoes/**", ADMIN);      // cada usuário usa /api/app/notificacoes
        regra("*", "/api/notificacoes", ADMIN);

        // API original: rotas que a família também usa (o serviço confere o vínculo)
        regra("POST", "/api/agendamentos", EQUIPE_E_FAMILIA);
        regra("PATCH", "/api/agendamentos/*/status", EQUIPE_E_FAMILIA);
        regra("GET", "/api/responsaveis/*/relatorios", Set.of(Papeis.ADMINISTRADOR, Papeis.PROFISSIONAL, Papeis.RESPONSAVEL));
        regra("POST", "/api/fila-espera", EQUIPE_E_FAMILIA);

        // API original: cadastros de pessoas
        regra("GET", "/api/profissionais/**", Set.of(Papeis.ADMINISTRADOR, Papeis.PROFISSIONAL, Papeis.ADMIN_INSTITUCIONAL));
        regra("GET", "/api/profissionais", Set.of(Papeis.ADMINISTRADOR, Papeis.PROFISSIONAL, Papeis.ADMIN_INSTITUCIONAL));
        regra("*", "/api/profissionais/**", ADMIN);
        regra("*", "/api/profissionais", ADMIN);
        regra("*", "/api/responsaveis/**", ADMIN);      // CPF e conta: só administrador (a equipe vê os nomes em /api/app)
        regra("*", "/api/responsaveis", ADMIN);

        // Demais rotas da API original (crianças, saúde, agenda, atendimentos, evolução, fila, comunicados):
        // equipe, com o escopo por pessoa aplicado nos serviços para o PROFISSIONAL.
        regra("*", "/api/**", EQUIPE);
    }

    private PoliticaAcesso() {
    }

    private static void publica(String metodo, String padrao) {
        REGRAS.add(new Regra(metodo, padrao, Set.of(), true));
    }

    private static void regra(String metodo, String padrao, Set<String> perfis) {
        REGRAS.add(new Regra(metodo, padrao, perfis, false));
    }

    /**
     * @param perfil perfil do usuário autenticado, ou null se não houver sessão
     */
    public static Decisao decidir(String metodo, String caminho, String perfil) {
        String m = metodo == null ? "" : metodo.toUpperCase(Locale.ROOT);
        String c = normalizar(caminho);
        if ("OPTIONS".equals(m)) return Decisao.PUBLICA;
        for (Regra r : REGRAS) {
            if (!r.casa(m, c)) continue;
            if (r.publica()) return Decisao.PUBLICA;
            if (perfil == null) return Decisao.EXIGE_LOGIN;
            return r.perfis().contains(perfil) ? Decisao.PERMITIDA : Decisao.NEGADA;
        }
        return perfil == null ? Decisao.EXIGE_LOGIN : Decisao.NEGADA;
    }

    static String normalizar(String caminho) {
        if (caminho == null || caminho.isEmpty()) return "/";
        String c = caminho;
        int q = c.indexOf('?');
        if (q >= 0) c = c.substring(0, q);
        while (c.contains("//")) c = c.replace("//", "/");
        if (c.length() > 1 && c.endsWith("/")) c = c.substring(0, c.length() - 1);
        return c;
    }

    /** "*" casa um segmento; "**" casa zero ou mais segmentos (no fim do padrão). */
    static boolean casaPadrao(String padrao, String caminho) {
        String[] p = padrao.split("/");
        String[] c = caminho.split("/");
        int i = 0;
        for (; i < p.length; i++) {
            if ("**".equals(p[i])) return true;
            if (i >= c.length) return false;
            if (!"*".equals(p[i]) && !p[i].equals(c[i])) return false;
        }
        return i == c.length;
    }
}
