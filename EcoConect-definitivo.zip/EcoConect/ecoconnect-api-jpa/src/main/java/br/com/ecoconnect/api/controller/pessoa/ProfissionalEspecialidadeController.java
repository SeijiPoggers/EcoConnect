package br.com.ecoconnect.api.controller.pessoa;

import br.com.ecoconnect.api.dto.EspecialidadeDoProfissional;
import br.com.ecoconnect.api.dto.MarcacaoPrincipal;
import br.com.ecoconnect.api.model.entity.ProfissionalEspecialidade;
import br.com.ecoconnect.api.service.pessoa.ProfissionalEspecialidadeService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Especialidades de um profissional. */
@RestController
@RequestMapping("/api/profissionais/{idProfissional}/especialidades")
public class ProfissionalEspecialidadeController {

    private final ProfissionalEspecialidadeService service;

    public ProfissionalEspecialidadeController(ProfissionalEspecialidadeService service) {
        this.service = service;
    }

    @GetMapping
    public List<ProfissionalEspecialidade> listar(@PathVariable Long idProfissional) {
        return service.listar(idProfissional);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ProfissionalEspecialidade adicionar(@PathVariable Long idProfissional,
                                               @Valid @RequestBody EspecialidadeDoProfissional dados) {
        return service.adicionar(idProfissional, dados.idEspecialidade(), dados.principal());
    }

    @PutMapping("/{idEspecialidade}")
    public ProfissionalEspecialidade alterar(@PathVariable Long idProfissional, @PathVariable Integer idEspecialidade,
                                             @Valid @RequestBody MarcacaoPrincipal dados) {
        return service.alterarPrincipal(idProfissional, idEspecialidade, dados.principal());
    }

    @DeleteMapping("/{idEspecialidade}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void remover(@PathVariable Long idProfissional, @PathVariable Integer idEspecialidade) {
        service.remover(idProfissional, idEspecialidade);
    }
}
