package br.com.ecoconnect.api.controller.base;

import br.com.ecoconnect.api.model.entity.Entidade;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * CRUD completo: listagem, busca, POST (criar), PUT (alterar) e DELETE.
 * O DELETE segue o ModoExclusao do service (físico, lógico ou proibido).
 */
public abstract class CrudController<E extends Entidade<ID>, ID> extends LeituraController<E, ID> {

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public E criar(@Valid @RequestBody E entidade) {
        return service().criar(entidade);
    }

    @PutMapping("/{id}")
    public E atualizar(@PathVariable ID id, @Valid @RequestBody E entidade) {
        return service().atualizar(id, entidade);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void excluir(@PathVariable ID id) {
        service().excluir(id);
    }
}
