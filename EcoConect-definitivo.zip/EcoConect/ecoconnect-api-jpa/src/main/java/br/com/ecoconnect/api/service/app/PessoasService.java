package br.com.ecoconnect.api.service.app;

import br.com.ecoconnect.api.dominio.Codigos;
import br.com.ecoconnect.api.dominio.MotorCorrespondencia;
import br.com.ecoconnect.api.dominio.Papeis;
import br.com.ecoconnect.api.exception.ConflitoException;
import br.com.ecoconnect.api.exception.NaoAutorizadoException;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Consentimento;
import br.com.ecoconnect.api.model.entity.Crianca;
import br.com.ecoconnect.api.model.entity.CriancaProfissional;
import br.com.ecoconnect.api.model.entity.CriancaResponsavel;
import br.com.ecoconnect.api.model.entity.PerfilNecessidades;
import br.com.ecoconnect.api.model.entity.Responsavel;
import br.com.ecoconnect.api.model.entity.Usuario;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.Sexo;
import br.com.ecoconnect.api.model.enums.SituacaoEcocura;
import br.com.ecoconnect.api.model.enums.StatusVinculo;
import br.com.ecoconnect.api.repository.CriancaProfissionalRepository;
import br.com.ecoconnect.api.repository.CriancaRepository;
import br.com.ecoconnect.api.repository.CriancaResponsavelRepository;
import br.com.ecoconnect.api.repository.PerfilNecessidadesRepository;
import br.com.ecoconnect.api.repository.ProfissionalRepository;
import br.com.ecoconnect.api.repository.ResponsavelRepository;
import br.com.ecoconnect.api.repository.UsuarioRepository;
import br.com.ecoconnect.api.seguranca.ContextoAtual;
import br.com.ecoconnect.api.seguranca.ContextoUsuario;
import br.com.ecoconnect.api.seguranca.EscopoAcesso;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.Verificacoes;
import br.com.ecoconnect.api.service.pessoa.CriancaResponsavelService;
import br.com.ecoconnect.api.service.pessoa.CriancaService;
import br.com.ecoconnect.api.service.saude.ConsentimentoService;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Cadastro e perfil das pessoas acompanhadas (tabela CRIANCA da modelagem original, que também
 * acolhe adultos), com responsáveis, profissionais autorizados, perfil de necessidades e histórico.
 * Reaproveita os serviços originais (CriancaService, CriancaResponsavelService, ConsentimentoService)
 * para manter as regras de negócio e a auditoria.
 */
@Service
public class PessoasService {

    public static final String VERSAO_TERMO = "EcoConect-1.0";
    public static final String FINALIDADE_PADRAO = "Cadastro e acompanhamento da pessoa na plataforma EcoConect, "
            + "incluindo o compartilhamento com os profissionais e instituições autorizados.";

    private final CriancaService criancaService;
    private final CriancaRepository criancaRepository;
    private final CriancaResponsavelService vinculoService;
    private final CriancaResponsavelRepository vinculoRepository;
    private final ResponsavelRepository responsavelRepository;
    private final ProfissionalRepository profissionalRepository;
    private final UsuarioRepository usuarioRepository;
    private final CriancaProfissionalRepository autorizacaoRepository;
    private final PerfilNecessidadesRepository necessidadesRepository;
    private final ConsentimentoService consentimentoService;
    private final EscopoAcesso escopo;
    private final AuditoriaService auditoria;
    private final Verificacoes verificacoes;
    private final Consultas consultas;

    public PessoasService(CriancaService criancaService, CriancaRepository criancaRepository,
                          CriancaResponsavelService vinculoService, CriancaResponsavelRepository vinculoRepository,
                          ResponsavelRepository responsavelRepository, ProfissionalRepository profissionalRepository,
                          UsuarioRepository usuarioRepository, CriancaProfissionalRepository autorizacaoRepository,
                          PerfilNecessidadesRepository necessidadesRepository, ConsentimentoService consentimentoService,
                          EscopoAcesso escopo, AuditoriaService auditoria, Verificacoes verificacoes, Consultas consultas) {
        this.criancaService = criancaService;
        this.criancaRepository = criancaRepository;
        this.vinculoService = vinculoService;
        this.vinculoRepository = vinculoRepository;
        this.responsavelRepository = responsavelRepository;
        this.profissionalRepository = profissionalRepository;
        this.usuarioRepository = usuarioRepository;
        this.autorizacaoRepository = autorizacaoRepository;
        this.necessidadesRepository = necessidadesRepository;
        this.consentimentoService = consentimentoService;
        this.escopo = escopo;
        this.auditoria = auditoria;
        this.verificacoes = verificacoes;
        this.consultas = consultas;
    }

    // ============================================================== consultas

    @Transactional(readOnly = true)
    public List<Map<String, Object>> listar(String texto) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        List<Long> ids = new ArrayList<>(escopo.criancas());
        if (ids.isEmpty()) return List.of();
        String filtro = texto == null || texto.isBlank() ? null : "%" + texto.trim().toLowerCase(Locale.ROOT) + "%";
        List<Object> args = new ArrayList<>(ids);
        if (filtro != null) args.add(filtro);
        List<Map<String, Object>> linhas = consultas.lista("SELECT c.id_crianca AS idCrianca, c.nome_completo AS nomeCompleto, "
                + Consultas.d("c.data_nascimento") + " AS dataNascimento, TIMESTAMPDIFF(YEAR, c.data_nascimento, CURDATE()) AS idade, "
                + "c.situacao_ecocura AS situacao, pn.condicoes_informadas AS condicoes, "
                + "(SELECT GROUP_CONCAT(u.nome_completo ORDER BY cr.responsavel_principal DESC SEPARATOR ', ') FROM crianca_responsavel cr "
                + " JOIN responsavel r ON r.id_responsavel = cr.id_responsavel JOIN usuario u ON u.id_usuario = r.id_usuario "
                + " WHERE cr.id_crianca = c.id_crianca AND cr.status = 'ATIVO') AS responsaveis, "
                + "(SELECT GROUP_CONCAT(u.nome_completo SEPARATOR ', ') FROM crianca_profissional cp "
                + " JOIN profissional p ON p.id_profissional = cp.id_profissional JOIN usuario u ON u.id_usuario = p.id_usuario "
                + " WHERE cp.id_crianca = c.id_crianca AND cp.status = 'ATIVO') AS profissionais, "
                + "(SELECT " + Consultas.dt("MIN(a.data_hora_inicio)") + " FROM agendamento a WHERE a.id_crianca = c.id_crianca "
                + " AND a.status = 'CONFIRMADO' AND a.data_hora_inicio >= NOW()) AS proximoAtendimento "
                + "FROM crianca c LEFT JOIN perfil_necessidades pn ON pn.id_crianca = c.id_crianca "
                + "WHERE c.id_crianca IN (" + Consultas.marcadores(ids) + ")"
                + (filtro != null ? " AND LOWER(c.nome_completo) LIKE ?" : "")
                + " ORDER BY c.nome_completo", args.toArray());
        if (ctx.adminInstitucional()) {
            // instituição vê somente o necessário para responder à solicitação
            for (Map<String, Object> l : linhas) {
                l.remove("responsaveis");
                l.remove("profissionais");
                l.remove("proximoAtendimento");
            }
        }
        return linhas;
    }

    @Transactional(readOnly = true)
    public Map<String, Object> detalhe(Long idCrianca) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        escopo.exigirCrianca(idCrianca);
        Crianca c = criancaRepository.findById(idCrianca).orElseThrow(() -> new NaoEncontradoException("crianca", idCrianca));
        Map<String, Object> r = new LinkedHashMap<>();
        Map<String, Object> pessoa = new LinkedHashMap<>();
        pessoa.put("idCrianca", c.getIdCrianca());
        pessoa.put("nomeCompleto", c.getNomeCompleto());
        pessoa.put("dataNascimento", c.getDataNascimento());
        pessoa.put("idade", MotorCorrespondencia.idade(c.getDataNascimento(), LocalDate.now()));
        pessoa.put("sexo", c.getSexo());
        pessoa.put("situacao", c.getSituacaoEcocura());
        pessoa.put("dataIngresso", c.getDataIngressoEcocura());
        pessoa.put("dataCadastro", c.getDataCadastro());
        pessoa.put("dataAtualizacao", c.getDataAtualizacao());
        boolean institucional = ctx.adminInstitucional();
        if (!institucional) pessoa.put("cpf", c.getCpf());
        r.put("pessoa", pessoa);
        r.put("necessidades", necessidadesRepository.findById(idCrianca).orElse(null));
        if (!institucional) {
            r.put("responsaveis", consultas.lista("SELECT cr.id_crianca_responsavel AS idVinculo, cr.id_responsavel AS idResponsavel, "
                    + "u.id_usuario AS idUsuario, u.nome_completo AS nome, cr.parentesco, cr.responsavel_principal AS principal, "
                    + "cr.pode_consultar_dados AS podeConsultarDados, cr.pode_solicitar_agendamento AS podeSolicitarAgendamento, "
                    + "cr.status, " + Consultas.d("cr.data_inicio") + " AS dataInicio FROM crianca_responsavel cr "
                    + "JOIN responsavel r ON r.id_responsavel = cr.id_responsavel JOIN usuario u ON u.id_usuario = r.id_usuario "
                    + "WHERE cr.id_crianca = ? ORDER BY cr.status, cr.responsavel_principal DESC, u.nome_completo", idCrianca));
            r.put("profissionais", consultas.lista("SELECT cp.id_crianca_profissional AS idAutorizacao, cp.id_profissional AS idProfissional, "
                    + "u.id_usuario AS idUsuario, u.nome_completo AS nome, cp.funcao, cp.status, " + Consultas.d("cp.data_inicio")
                    + " AS dataInicio, " + Consultas.d("cp.data_fim") + " AS dataFim, "
                    + "(SELECT GROUP_CONCAT(e.nome ORDER BY pe.principal DESC SEPARATOR ', ') FROM profissional_especialidade pe "
                    + " JOIN especialidade e ON e.id_especialidade = pe.id_especialidade WHERE pe.id_profissional = cp.id_profissional) AS especialidades "
                    + "FROM crianca_profissional cp JOIN profissional p ON p.id_profissional = cp.id_profissional "
                    + "JOIN usuario u ON u.id_usuario = p.id_usuario WHERE cp.id_crianca = ? ORDER BY cp.status, u.nome_completo", idCrianca));
            r.put("consentimentos", consultas.lista("SELECT co.id_consentimento AS idConsentimento, co.finalidade, co.versao_termo AS versaoTermo, "
                    + "co.situacao_autorizacao AS situacao, " + Consultas.dt("co.data_autorizacao") + " AS dataAutorizacao, "
                    + Consultas.dt("co.data_revogacao") + " AS dataRevogacao, u.nome_completo AS responsavel FROM consentimento co "
                    + "JOIN responsavel r ON r.id_responsavel = co.id_responsavel JOIN usuario u ON u.id_usuario = r.id_usuario "
                    + "WHERE co.id_crianca = ? ORDER BY co.data_autorizacao DESC", idCrianca));
        }
        Map<String, Object> permissoes = new LinkedHashMap<>();
        boolean principal = ehResponsavelPrincipal(ctx, idCrianca);
        permissoes.put("editarDados", ctx.equipe() || principal);
        permissoes.put("editarNecessidades", ctx.equipe() || ctx.familia());
        permissoes.put("gerirResponsaveis", ctx.equipe());
        permissoes.put("gerirProfissionais", ctx.equipe() || principal);
        permissoes.put("registrarSessao", ctx.equipe());
        permissoes.put("verAcompanhamento", !institucional);
        permissoes.put("verHistoricoAlteracoes", ctx.equipe());
        r.put("permissoes", permissoes);
        return r;
    }

    // ============================================================== cadastro

    public record NovaPessoa(String nomeCompleto, LocalDate dataNascimento, String sexo, String cpf, String situacao,
                             String parentesco, Boolean consentimentoAceito) {
    }

    @Transactional
    public Map<String, Object> criar(NovaPessoa dados) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (!ctx.equipe() && !ctx.responsavel()) {
            throw new NaoAutorizadoException(403, "Somente a equipe ou um responsável pode cadastrar uma pessoa.");
        }
        if (dados.nomeCompleto() == null || dados.nomeCompleto().isBlank()) throw new RegraNegocioException("Informe o nome completo.");
        if (dados.dataNascimento() == null) throw new RegraNegocioException("Informe a data de nascimento.");
        if (ctx.responsavel()) {
            if (!Boolean.TRUE.equals(dados.consentimentoAceito())) {
                throw new RegraNegocioException("Para cadastrar, é preciso aceitar o termo de consentimento (LGPD).");
            }
            if (ctx.idResponsavel() == null) {
                throw new RegraNegocioException("Seu usuário ainda não tem cadastro de responsável. Fale com a equipe EcoConect.");
            }
        }
        Crianca c = new Crianca();
        c.setNomeCompleto(dados.nomeCompleto().trim());
        c.setDataNascimento(dados.dataNascimento());
        c.setSexo(dados.sexo() == null || dados.sexo().isBlank() ? null : Sexo.valueOf(dados.sexo()));
        c.setCpf(dados.cpf() == null || dados.cpf().isBlank() ? null : dados.cpf().replaceAll("\\D", ""));
        SituacaoEcocura situacao = ctx.equipe() && dados.situacao() != null && !dados.situacao().isBlank()
                ? SituacaoEcocura.valueOf(dados.situacao()) : SituacaoEcocura.EM_ANALISE;
        c.setSituacaoEcocura(situacao);
        if (situacao == SituacaoEcocura.ATIVA) c.setDataIngressoEcocura(LocalDate.now());
        Crianca salva = criancaService.criar(c);

        if (ctx.profissional() && ctx.idProfissional() != null) {
            autorizar(salva.getIdCrianca(), ctx.idProfissional(), "Profissional que realizou o cadastro", ctx.idUsuario());
        }
        if (ctx.responsavel()) {
            // Cadastro feito pela família: vínculo principal criado diretamente (a regra original exige
            // a equipe como cadastrante; aqui o próprio responsável se declara, e a equipe pode revisar).
            CriancaResponsavel v = new CriancaResponsavel();
            v.setIdCrianca(salva.getIdCrianca());
            v.setIdResponsavel(ctx.idResponsavel());
            v.setParentesco(dados.parentesco() == null || dados.parentesco().isBlank() ? "Responsável" : dados.parentesco().trim());
            v.setResponsavelPrincipal(true);
            v.setPodeConsultarDados(true);
            v.setPodeSolicitarAgendamento(true);
            v.setStatus(StatusVinculo.ATIVO);
            v.setDataInicio(LocalDate.now());
            v.setIdUsuarioCadastro(ctx.idUsuario());
            CriancaResponsavel vs = vinculoRepository.saveAndFlush(v);
            auditoria.registrar(AcaoAuditoria.CRIACAO, "crianca_responsavel", vs, null, vs);
            registrarConsentimento(salva.getIdCrianca(), ctx.idResponsavel(), FINALIDADE_PADRAO);
        }
        return detalhe(salva.getIdCrianca());
    }

    public record AlteracaoPessoa(String nomeCompleto, LocalDate dataNascimento, String sexo, String cpf, String situacao) {
    }

    @Transactional
    public Map<String, Object> alterar(Long idCrianca, AlteracaoPessoa dados) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        escopo.exigirCrianca(idCrianca);
        if (!ctx.equipe() && !ehResponsavelPrincipal(ctx, idCrianca)) {
            throw new NaoAutorizadoException(403, "Só a equipe ou o responsável principal podem alterar estes dados.");
        }
        Crianca atual = criancaRepository.findById(idCrianca).orElseThrow(() -> new NaoEncontradoException("crianca", idCrianca));
        Crianca novo = new Crianca();
        novo.setNomeCompleto(dados.nomeCompleto() == null || dados.nomeCompleto().isBlank() ? atual.getNomeCompleto() : dados.nomeCompleto().trim());
        novo.setDataNascimento(dados.dataNascimento() == null ? atual.getDataNascimento() : dados.dataNascimento());
        novo.setSexo(dados.sexo() == null ? atual.getSexo() : (dados.sexo().isBlank() ? null : Sexo.valueOf(dados.sexo())));
        novo.setCpf(dados.cpf() == null ? atual.getCpf() : (dados.cpf().isBlank() ? null : dados.cpf().replaceAll("\\D", "")));
        SituacaoEcocura sit = atual.getSituacaoEcocura();
        if (ctx.equipe() && dados.situacao() != null && !dados.situacao().isBlank()) sit = SituacaoEcocura.valueOf(dados.situacao());
        novo.setSituacaoEcocura(sit);
        novo.setDataIngressoEcocura(sit == SituacaoEcocura.ATIVA && atual.getDataIngressoEcocura() == null
                ? LocalDate.now() : atual.getDataIngressoEcocura());
        criancaService.atualizar(idCrianca, novo);
        return detalhe(idCrianca);
    }

    @Transactional
    public PerfilNecessidades salvarNecessidades(Long idCrianca, PerfilNecessidades dados) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        escopo.exigirAcompanhamento(idCrianca);
        if (!ctx.equipe() && !ctx.familia()) throw new NaoAutorizadoException(403, "Sem permissão para alterar o perfil de necessidades.");
        PerfilNecessidades atual = necessidadesRepository.findById(idCrianca).orElse(null);
        String antes = auditoria.json(atual);
        PerfilNecessidades p = atual != null ? atual : new PerfilNecessidades();
        p.setIdCrianca(idCrianca);
        p.setCondicoesInformadas(Codigos.normalizar(dados.getCondicoesInformadas(), Codigos.CONDICOES, "condições"));
        p.setPreferenciasSensoriais(Codigos.normalizar(dados.getPreferenciasSensoriais(), Codigos.SENSORIAL, "preferências sensoriais"));
        p.setNecessidadesAcessibilidade(Codigos.normalizar(dados.getNecessidadesAcessibilidade(), Codigos.ACESSIBILIDADE, "acessibilidade"));
        String com = dados.getComunicacaoPreferida() == null ? "SEM_PREFERENCIA" : dados.getComunicacaoPreferida();
        if (!Set.of("ESCRITA", "FALADA", "VISUAL", "COMUNICACAO_ALTERNATIVA", "SEM_PREFERENCIA").contains(com)) {
            throw new RegraNegocioException("Preferência de comunicação inválida.");
        }
        p.setComunicacaoPreferida(com);
        String mod = dados.getModalidadePreferida() == null ? "SEM_PREFERENCIA" : dados.getModalidadePreferida();
        if (!Set.of("PRESENCIAL", "ONLINE", "DOMICILIAR", "SEM_PREFERENCIA").contains(mod)) {
            throw new RegraNegocioException("Modalidade preferida inválida.");
        }
        p.setModalidadePreferida(mod);
        p.setNecessidadesAcompanhamento(texto(dados.getNecessidadesAcompanhamento(), 500));
        p.setObservacoesSensoriais(texto(dados.getObservacoesSensoriais(), 500));
        p.setObservacoesAcompanhamento(texto(dados.getObservacoesAcompanhamento(), 5000));
        p.setMunicipio(texto(dados.getMunicipio(), 80));
        p.setUf(dados.getUf() == null || dados.getUf().isBlank() ? null : dados.getUf().trim().toUpperCase(Locale.ROOT));
        p.setSomenteGratuito(Boolean.TRUE.equals(dados.getSomenteGratuito()));
        p.setIdUsuarioAtualizacao(ctx.idUsuario());
        p.setDataAtualizacao(LocalDateTime.now());
        PerfilNecessidades salvo = necessidadesRepository.saveAndFlush(p);
        auditoria.registrar(atual == null ? AcaoAuditoria.CRIACAO : AcaoAuditoria.ATUALIZACAO, "perfil_necessidades", salvo, antes, salvo);
        return salvo;
    }

    // ============================================================== vínculos

    public record NovoResponsavel(String email, String parentesco, Boolean principal, Boolean podeConsultarDados,
                                  Boolean podeSolicitarAgendamento) {
    }

    @Transactional
    public Map<String, Object> vincularResponsavel(Long idCrianca, NovoResponsavel dados) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (!ctx.equipe()) throw new NaoAutorizadoException(403, "Somente a equipe vincula responsáveis.");
        escopo.exigirCrianca(idCrianca);
        Usuario u = usuarioRepository.findByEmail(dados.email() == null ? "" : dados.email().trim().toLowerCase(Locale.ROOT))
                .orElseThrow(() -> new RegraNegocioException("Não há usuário com este e-mail. Peça ao administrador para criar a conta."));
        if (!Papeis.RESPONSAVEL.equals(verificacoes.perfilDe(u))) {
            throw new RegraNegocioException("Este usuário não tem perfil de responsável.");
        }
        Responsavel r = responsavelRepository.findByIdUsuario(u.getIdUsuario()).orElseGet(() -> {
            Responsavel novo = new Responsavel();
            novo.setIdUsuario(u.getIdUsuario());
            Responsavel s = responsavelRepository.saveAndFlush(novo);
            auditoria.registrar(AcaoAuditoria.CRIACAO, "responsavel", s, null, s);
            return s;
        });
        CriancaResponsavel v = new CriancaResponsavel();
        v.setIdCrianca(idCrianca);
        v.setIdResponsavel(r.getIdResponsavel());
        v.setParentesco(dados.parentesco() == null || dados.parentesco().isBlank() ? "Responsável" : dados.parentesco().trim());
        v.setResponsavelPrincipal(Boolean.TRUE.equals(dados.principal()));
        v.setPodeConsultarDados(dados.podeConsultarDados() == null || dados.podeConsultarDados());
        v.setPodeSolicitarAgendamento(dados.podeSolicitarAgendamento() == null || dados.podeSolicitarAgendamento());
        v.setStatus(StatusVinculo.ATIVO);
        v.setIdUsuarioCadastro(ctx.idUsuario());
        vinculoService.criar(v);
        return detalhe(idCrianca);
    }

    @Transactional
    public Map<String, Object> revogarResponsavel(Long idCrianca, Long idVinculo) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (!ctx.equipe()) throw new NaoAutorizadoException(403, "Somente a equipe revoga vínculos.");
        CriancaResponsavel v = vinculoService.buscar(idVinculo);
        if (!v.getIdCrianca().equals(idCrianca)) throw new NaoEncontradoException("crianca_responsavel", idVinculo);
        vinculoService.excluir(idVinculo);
        return detalhe(idCrianca);
    }

    public record NovaAutorizacao(Long idProfissional, String funcao) {
    }

    @Transactional
    public Map<String, Object> autorizarProfissional(Long idCrianca, NovaAutorizacao dados) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        escopo.exigirCrianca(idCrianca);
        if (!ctx.equipe() && !ehResponsavelPrincipal(ctx, idCrianca)) {
            throw new NaoAutorizadoException(403, "Só a equipe ou o responsável principal autorizam profissionais.");
        }
        verificacoes.profissionalAtivo(dados.idProfissional());
        autorizar(idCrianca, dados.idProfissional(), dados.funcao(), ctx.idUsuario());
        return detalhe(idCrianca);
    }

    @Transactional
    public Map<String, Object> encerrarAutorizacao(Long idCrianca, Long idProfissional) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        escopo.exigirCrianca(idCrianca);
        if (!ctx.equipe() && !ehResponsavelPrincipal(ctx, idCrianca)) {
            throw new NaoAutorizadoException(403, "Só a equipe ou o responsável principal encerram autorizações.");
        }
        CriancaProfissional a = autorizacaoRepository.findByIdCriancaAndIdProfissional(idCrianca, idProfissional)
                .orElseThrow(() -> new NaoEncontradoException("Este profissional não está autorizado para esta pessoa."));
        if ("ENCERRADO".equals(a.getStatus())) return detalhe(idCrianca);
        String antes = auditoria.json(a);
        a.setStatus("ENCERRADO");
        a.setDataFim(LocalDate.now());
        CriancaProfissional s = autorizacaoRepository.saveAndFlush(a);
        auditoria.registrar(AcaoAuditoria.EXCLUSAO_LOGICA, "crianca_profissional", s, antes, s);
        return detalhe(idCrianca);
    }

    private void autorizar(Long idCrianca, Long idProfissional, String funcao, Long idUsuario) {
        CriancaProfissional a = autorizacaoRepository.findByIdCriancaAndIdProfissional(idCrianca, idProfissional).orElse(null);
        String antes = auditoria.json(a);
        if (a != null && "ATIVO".equals(a.getStatus())) throw new ConflitoException("Este profissional já está autorizado.");
        if (a == null) a = new CriancaProfissional();
        a.setIdCrianca(idCrianca);
        a.setIdProfissional(idProfissional);
        a.setFuncao(texto(funcao, 80));
        a.setStatus("ATIVO");
        a.setDataInicio(LocalDate.now());
        a.setDataFim(null);
        a.setIdUsuarioCadastro(idUsuario);
        CriancaProfissional s = autorizacaoRepository.saveAndFlush(a);
        auditoria.registrar(antes == null ? AcaoAuditoria.CRIACAO : AcaoAuditoria.ATUALIZACAO, "crianca_profissional", s, antes, s);
    }

    // ============================================================== histórico de alterações

    @Transactional(readOnly = true)
    public List<Map<String, Object>> historicoAlteracoes(Long idCrianca) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (!ctx.equipe()) throw new NaoAutorizadoException(403, "O histórico de alterações é visível para a equipe.");
        escopo.exigirCrianca(idCrianca);
        return consultas.lista("SELECT a.id_auditoria AS idAuditoria, " + Consultas.dt("a.data_hora") + " AS dataHora, a.acao, "
                + "a.tabela_afetada AS tabela, a.id_registro_afetado AS idRegistro, COALESCE(u.nome_completo, 'Sistema') AS usuario "
                + "FROM auditoria a LEFT JOIN usuario u ON u.id_usuario = a.id_usuario WHERE a.id_crianca = ? "
                + "ORDER BY a.data_hora DESC, a.id_auditoria DESC LIMIT 150", idCrianca);
    }

    /** Profissionais ativos (diretório para autorização e designação). */
    @Transactional(readOnly = true)
    public List<Map<String, Object>> profissionais(String texto) {
        String f = texto == null || texto.isBlank() ? "%" : "%" + texto.trim().toLowerCase(Locale.ROOT) + "%";
        return consultas.lista("SELECT p.id_profissional AS idProfissional, u.id_usuario AS idUsuario, u.nome_completo AS nome, "
                + "p.conselho_profissional AS conselho, "
                + "(SELECT GROUP_CONCAT(e.nome ORDER BY pe.principal DESC SEPARATOR ', ') FROM profissional_especialidade pe "
                + " JOIN especialidade e ON e.id_especialidade = pe.id_especialidade WHERE pe.id_profissional = p.id_profissional) AS especialidades, "
                + "(SELECT GROUP_CONCAT(i.nome SEPARATOR ', ') FROM instituicao_membro m JOIN instituicao i ON i.id_instituicao = m.id_instituicao "
                + " WHERE m.id_usuario = u.id_usuario AND m.ativo = 1) AS instituicoes "
                + "FROM profissional p JOIN usuario u ON u.id_usuario = p.id_usuario WHERE p.ativo = 1 AND u.status = 'ATIVO' "
                + "AND LOWER(u.nome_completo) LIKE ? ORDER BY u.nome_completo LIMIT 100", f);
    }

    // ============================================================== apoio

    Consentimento registrarConsentimento(Long idCrianca, Long idResponsavel, String finalidade) {
        Consentimento co = new Consentimento();
        co.setIdCrianca(idCrianca);
        co.setIdResponsavel(idResponsavel);
        co.setFinalidade(finalidade.length() > 200 ? finalidade.substring(0, 200) : finalidade);
        co.setVersaoTermo(VERSAO_TERMO);
        co.setDataAutorizacao(LocalDateTime.now());
        co.setIdUsuarioRegistro(ContextoAtual.exigir().idUsuario());
        return consentimentoService.criar(co);
    }

    boolean ehResponsavelPrincipal(ContextoUsuario ctx, Long idCrianca) {
        return ctx.responsavel() && ctx.idResponsavel() != null
                && vinculoRepository.existsByIdCriancaAndIdResponsavelAndStatus(idCrianca, ctx.idResponsavel(), StatusVinculo.ATIVO)
                && consultas.contar("SELECT COUNT(*) FROM crianca_responsavel WHERE id_crianca = ? AND id_responsavel = ? "
                + "AND status = 'ATIVO' AND responsavel_principal = 1", idCrianca, ctx.idResponsavel()) > 0;
    }

    static String texto(String s, int max) {
        if (s == null || s.isBlank()) return null;
        String t = s.trim();
        return t.length() > max ? t.substring(0, max) : t;
    }
}
