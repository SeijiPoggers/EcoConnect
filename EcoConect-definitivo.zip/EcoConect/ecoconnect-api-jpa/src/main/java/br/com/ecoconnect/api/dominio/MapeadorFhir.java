package br.com.ecoconnect.api.dominio;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Conversão dos dados do EcoConect para recursos HL7 FHIR R4 (JSON), preparando a
 * interoperabilidade com a RNDS. Gera apenas a representação: o envio à RNDS exige
 * credenciamento e não é feito por esta classe.
 */
public final class MapeadorFhir {

    public static final String SISTEMA_CNES = "https://saude.gov.br/fhir/r4/NamingSystem/cnes";
    public static final String SISTEMA_CPF = "https://saude.gov.br/fhir/r4/NamingSystem/cpf";
    public static final String SISTEMA_ECOCONECT = "urn:ecoconect:id";

    private MapeadorFhir() {
    }

    public static Map<String, Object> organization(String cnes, String nome, String telefone, String email,
                                                   Map<String, Object> endereco, boolean ativa) {
        Map<String, Object> r = base("Organization", "cnes-" + cnes);
        r.put("identifier", List.of(identificador(SISTEMA_CNES, cnes)));
        r.put("active", ativa);
        r.put("name", nome);
        List<Map<String, Object>> telecom = new ArrayList<>();
        if (telefone != null) telecom.add(Map.of("system", "phone", "value", telefone));
        if (email != null) telecom.add(Map.of("system", "email", "value", email));
        if (!telecom.isEmpty()) r.put("telecom", telecom);
        if (endereco != null) r.put("address", List.of(endereco));
        return r;
    }

    public static Map<String, Object> location(String cnes, String nome, Map<String, Object> endereco,
                                               Double latitude, Double longitude) {
        Map<String, Object> r = base("Location", "cnes-" + cnes);
        r.put("status", "active");
        r.put("name", nome);
        if (endereco != null) r.put("address", endereco);
        if (latitude != null && longitude != null) r.put("position", Map.of("latitude", latitude, "longitude", longitude));
        r.put("managingOrganization", Map.of("reference", "Organization/cnes-" + cnes));
        return r;
    }

    public static Map<String, Object> healthcareService(String id, String referenciaOrganizacao, String nome,
                                                        String categoria, String descricao, boolean ativo) {
        Map<String, Object> r = base("HealthcareService", id);
        r.put("active", ativo);
        r.put("providedBy", Map.of("reference", referenciaOrganizacao));
        r.put("name", nome);
        if (categoria != null) r.put("category", List.of(Map.of("text", categoria)));
        if (descricao != null) r.put("comment", descricao);
        return r;
    }

    public static Map<String, Object> endereco(String logradouro, String numero, String bairro, String municipio,
                                               String uf, String cep) {
        Map<String, Object> a = new LinkedHashMap<>();
        a.put("use", "work");
        List<String> linhas = new ArrayList<>();
        if (logradouro != null) linhas.add(numero != null ? logradouro + ", " + numero : logradouro);
        if (bairro != null) linhas.add(bairro);
        if (!linhas.isEmpty()) a.put("line", linhas);
        if (municipio != null) a.put("city", municipio);
        if (uf != null) a.put("state", uf);
        if (cep != null) a.put("postalCode", cep);
        a.put("country", "BRA");
        return a;
    }

    /**
     * Patient com o mínimo necessário. O CPF só é incluído quando o chamador confirma que há
     * consentimento registrado (minimização de dados, LGPD).
     */
    public static Map<String, Object> patient(long idCrianca, String nome, LocalDate nascimento, String sexo,
                                              String cpf, boolean incluirCpf) {
        Map<String, Object> r = base("Patient", String.valueOf(idCrianca));
        List<Map<String, Object>> ids = new ArrayList<>();
        ids.add(identificador(SISTEMA_ECOCONECT + ":crianca", String.valueOf(idCrianca)));
        if (incluirCpf && cpf != null) ids.add(identificador(SISTEMA_CPF, cpf));
        r.put("identifier", ids);
        r.put("name", List.of(Map.of("text", nome)));
        if (nascimento != null) r.put("birthDate", nascimento.toString());
        r.put("gender", sexo == null ? "unknown" : switch (sexo) {
            case "F" -> "female";
            case "M" -> "male";
            default -> "unknown";
        });
        return r;
    }

    /** ServiceRequest a partir de uma solicitação de atendimento. status/intent seguem o vocabulário do FHIR R4. */
    public static Map<String, Object> serviceRequest(long idSolicitacao, String situacao, Long idCrianca,
                                                     String referenciaInstituicao, String servico, String mensagem,
                                                     String dataCriacaoIso) {
        Map<String, Object> r = base("ServiceRequest", String.valueOf(idSolicitacao));
        r.put("status", switch (situacao) {
            case "ENVIADA", "EM_ANALISE", "ACEITA" -> "active";
            case "CONCLUIDA" -> "completed";
            case "CANCELADA" -> "revoked";
            case "RECUSADA" -> "revoked";
            default -> "unknown";
        });
        r.put("intent", "order");
        if (servico != null) r.put("code", Map.of("text", servico));
        if (idCrianca != null) r.put("subject", Map.of("reference", "Patient/" + idCrianca));
        r.put("performer", List.of(Map.of("reference", referenciaInstituicao)));
        if (dataCriacaoIso != null) r.put("authoredOn", dataCriacaoIso);
        if (mensagem != null) r.put("note", List.of(Map.of("text", mensagem)));
        return r;
    }

    public static Map<String, Object> bundle(List<Map<String, Object>> recursos) {
        Map<String, Object> b = new LinkedHashMap<>();
        b.put("resourceType", "Bundle");
        b.put("type", "searchset");
        b.put("total", recursos.size());
        List<Map<String, Object>> entry = new ArrayList<>();
        for (Map<String, Object> r : recursos) entry.add(Map.of("resource", r));
        b.put("entry", entry);
        return b;
    }

    private static Map<String, Object> base(String tipo, String id) {
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("resourceType", tipo);
        r.put("id", id);
        return r;
    }

    private static Map<String, Object> identificador(String sistema, String valor) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("system", sistema);
        m.put("value", valor);
        return m;
    }
}
