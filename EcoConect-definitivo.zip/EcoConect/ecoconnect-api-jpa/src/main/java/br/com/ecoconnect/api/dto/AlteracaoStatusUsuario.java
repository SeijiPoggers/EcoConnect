package br.com.ecoconnect.api.dto;

import br.com.ecoconnect.api.model.enums.StatusUsuario;
import jakarta.validation.constraints.NotNull;

public record AlteracaoStatusUsuario(@NotNull(message = "campo obrigatório") StatusUsuario status) {
}
