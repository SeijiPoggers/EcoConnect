package br.com.ecoconnect.api.service;

import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Crianca;
import br.com.ecoconnect.api.model.entity.Perfil;
import br.com.ecoconnect.api.model.entity.Profissional;
import br.com.ecoconnect.api.model.entity.Responsavel;
import br.com.ecoconnect.api.model.entity.Usuario;
import br.com.ecoconnect.api.model.enums.StatusUsuario;
import br.com.ecoconnect.api.model.enums.StatusVinculo;
import br.com.ecoconnect.api.repository.CriancaRepository;
import br.com.ecoconnect.api.repository.CriancaResponsavelRepository;
import br.com.ecoconnect.api.repository.DocumentoRepository;
import br.com.ecoconnect.api.repository.PerfilRepository;
import br.com.ecoconnect.api.repository.ProfissionalRepository;
import br.com.ecoconnect.api.repository.ResponsavelRepository;
import br.com.ecoconnect.api.repository.UsuarioRepository;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Optional;

/**
 * Verificações reutilizadas pelos services, incluindo as regras da seção E.3 da
 * modelagem que o MySQL não impõe sozinho (perfil coerente, vínculo ativo etc.).
 */
@Component
public class Verificacoes {

    public static final String ADMINISTRADOR = "ADMINISTRADOR";
    public static final String PROFISSIONAL = "PROFISSIONAL";
    public static final String RESPONSAVEL = "RESPONSAVEL";

    private final UsuarioRepository usuarioRepository;
    private final PerfilRepository perfilRepository;
    private final ResponsavelRepository responsavelRepository;
    private final ProfissionalRepository profissionalRepository;
    private final CriancaRepository criancaRepository;
    private final DocumentoRepository documentoRepository;
    private final CriancaResponsavelRepository vinculoRepository;

    public Verificacoes(UsuarioRepository usuarioRepository, PerfilRepository perfilRepository,
                        ResponsavelRepository responsavelRepository, ProfissionalRepository profissionalRepository,
                        CriancaRepository criancaRepository, DocumentoRepository documentoRepository,
                        CriancaResponsavelRepository vinculoRepository) {
        this.usuarioRepository = usuarioRepository;
        this.perfilRepository = perfilRepository;
        this.responsavelRepository = responsavelRepository;
        this.profissionalRepository = profissionalRepository;
        this.criancaRepository = criancaRepository;
        this.documentoRepository = documentoRepository;
        this.vinculoRepository = vinculoRepository;
    }

    // ---------------------------------------------------------------- usuários

    public Usuario usuario(Long id) {
        if (id == null) throw new RegraNegocioException("Informe o usuário.");
        return usuarioRepository.findById(id).orElseThrow(() -> new NaoEncontradoException("usuario", id));
    }

    public String perfilDe(Usuario u) {
        return perfilRepository.findById(u.getIdPerfil()).map(Perfil::getNome).orElse("");
    }

    /** Usuário existente e com conta ATIVA. */
    public Usuario usuarioAtivo(Long id, String papel) {
        Usuario u = usuario(id);
        if (u.getStatus() != StatusUsuario.ATIVO) {
            throw new RegraNegocioException(papel + ": o usuário " + id + " não está ATIVO (status " + u.getStatus() + ").");
        }
        return u;
    }

    /** Usuário ATIVO da equipe (ADMINISTRADOR ou PROFISSIONAL), nunca um responsável. */
    public Usuario usuarioDaEquipe(Long id, String papel) {
        Usuario u = usuarioAtivo(id, papel);
        String perfil = perfilDe(u);
        if (!ADMINISTRADOR.equals(perfil) && !PROFISSIONAL.equals(perfil)) {
            throw new RegraNegocioException(papel + " deve ser alguém da equipe (ADMINISTRADOR ou PROFISSIONAL).");
        }
        return u;
    }

    // ---------------------------------------------------------------- pessoas

    public Crianca crianca(Long id) {
        if (id == null) throw new RegraNegocioException("Informe a criança (idCrianca).");
        return criancaRepository.findById(id).orElseThrow(() -> new NaoEncontradoException("crianca", id));
    }

    public Responsavel responsavel(Long id) {
        if (id == null) throw new RegraNegocioException("Informe o responsável (idResponsavel).");
        return responsavelRepository.findById(id).orElseThrow(() -> new NaoEncontradoException("responsavel", id));
    }

    public Profissional profissionalAtivo(Long id) {
        if (id == null) throw new RegraNegocioException("Informe o profissional (idProfissional).");
        Profissional p = profissionalRepository.findById(id)
                .orElseThrow(() -> new NaoEncontradoException("profissional", id));
        if (!Boolean.TRUE.equals(p.getAtivo())) {
            throw new RegraNegocioException("O profissional " + id + " está inativo.");
        }
        return p;
    }

    // ---------------------------------------------------------------- regras

    /** RI-07: documento vinculado a um registro precisa ser da mesma criança. */
    public void documentoDaCrianca(Long idDocumento, Long idCrianca) {
        if (idDocumento == null) return;
        if (!documentoRepository.existsByIdDocumentoAndIdCrianca(idDocumento, idCrianca)) {
            throw new RegraNegocioException("O documento " + idDocumento + " não existe ou não pertence à criança " + idCrianca + ".");
        }
    }

    /**
     * E.3: se quem solicita é um RESPONSAVEL, ele precisa ter vínculo ATIVO com a criança
     * e permissão pode_solicitar_agendamento. Equipe pode solicitar por qualquer criança.
     */
    public void podeSolicitarPelaCrianca(Long idUsuario, Long idCrianca) {
        Usuario u = usuarioAtivo(idUsuario, "Solicitante");
        if (!RESPONSAVEL.equals(perfilDe(u))) return;
        Optional<Responsavel> r = responsavelRepository.findByIdUsuario(idUsuario);
        boolean autorizado = r.isPresent() && vinculoRepository
                .existsByIdCriancaAndIdResponsavelAndStatusAndPodeSolicitarAgendamentoTrue(
                        idCrianca, r.get().getIdResponsavel(), StatusVinculo.ATIVO);
        if (!autorizado) {
            throw new RegraNegocioException("O responsável não tem vínculo ATIVO com a criança "
                    + idCrianca + " ou não tem permissão para solicitar agendamentos.");
        }
    }

    /** Se o usuário for RESPONSAVEL, exige vínculo ATIVO com a criança. */
    public void responsavelVinculado(Long idUsuario, Long idCrianca) {
        Usuario u = usuario(idUsuario);
        if (!RESPONSAVEL.equals(perfilDe(u))) return;
        Optional<Responsavel> r = responsavelRepository.findByIdUsuario(idUsuario);
        if (r.isEmpty() || !vinculoRepository.existsByIdCriancaAndIdResponsavelAndStatus(
                idCrianca, r.get().getIdResponsavel(), StatusVinculo.ATIVO)) {
            throw new RegraNegocioException("O responsável não tem vínculo ATIVO com a criança " + idCrianca + ".");
        }
    }

    public static void naoFutura(LocalDate data, String campo) {
        if (data != null && data.isAfter(LocalDate.now())) {
            throw new RegraNegocioException(campo + " não pode estar no futuro.");
        }
    }
}
