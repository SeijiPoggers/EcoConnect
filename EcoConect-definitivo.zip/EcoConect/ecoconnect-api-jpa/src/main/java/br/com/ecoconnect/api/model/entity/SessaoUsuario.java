package br.com.ecoconnect.api.model.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;

/** Tabela `sessao_usuario` (migration V2/V3). Gerada no mesmo padrão das entidades originais. */
@Entity
@Table(name = "sessao_usuario")
public class SessaoUsuario implements Entidade<Long> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_sessao", nullable = false)
    private Long idSessao;

    @Column(name = "id_usuario", nullable = false)
    private Long idUsuario;

    @JsonIgnore
    @Size(max = 64)
    @Column(name = "token_hash", nullable = false, length = 64)
    private String tokenHash;

    @Column(name = "data_criacao")
    private LocalDateTime dataCriacao;

    @Column(name = "data_expiracao", nullable = false)
    private LocalDateTime dataExpiracao;

    @Column(name = "data_ultimo_uso")
    private LocalDateTime dataUltimoUso;

    @Column(name = "data_revogacao")
    private LocalDateTime dataRevogacao;

    @Size(max = 45)
    @Column(name = "ip_origem", length = 45)
    private String ipOrigem;

    @Size(max = 255)
    @Column(name = "agente_usuario", length = 255)
    private String agenteUsuario;

    @PrePersist
    void aoInserir() {
        if (dataCriacao == null) dataCriacao = LocalDateTime.now();
    }

    @Override
    public Long chave() {
        return idSessao;
    }

    @Override
    public void definirChave(Long id) {
        this.idSessao = id;
    }

    public Long getIdSessao() {
        return idSessao;
    }

    public void setIdSessao(Long idSessao) {
        this.idSessao = idSessao;
    }

    public Long getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getTokenHash() {
        return tokenHash;
    }

    public void setTokenHash(String tokenHash) {
        this.tokenHash = tokenHash;
    }

    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDateTime dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public LocalDateTime getDataExpiracao() {
        return dataExpiracao;
    }

    public void setDataExpiracao(LocalDateTime dataExpiracao) {
        this.dataExpiracao = dataExpiracao;
    }

    public LocalDateTime getDataUltimoUso() {
        return dataUltimoUso;
    }

    public void setDataUltimoUso(LocalDateTime dataUltimoUso) {
        this.dataUltimoUso = dataUltimoUso;
    }

    public LocalDateTime getDataRevogacao() {
        return dataRevogacao;
    }

    public void setDataRevogacao(LocalDateTime dataRevogacao) {
        this.dataRevogacao = dataRevogacao;
    }

    public String getIpOrigem() {
        return ipOrigem;
    }

    public void setIpOrigem(String ipOrigem) {
        this.ipOrigem = ipOrigem;
    }

    public String getAgenteUsuario() {
        return agenteUsuario;
    }

    public void setAgenteUsuario(String agenteUsuario) {
        this.agenteUsuario = agenteUsuario;
    }
}
