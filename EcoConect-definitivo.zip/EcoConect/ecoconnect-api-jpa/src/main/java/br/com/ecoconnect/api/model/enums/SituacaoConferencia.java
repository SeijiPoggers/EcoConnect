package br.com.ecoconnect.api.model.enums;

/** Conferência de um documento. Valores idênticos ao ENUM do MySQL. */
public enum SituacaoConferencia {
    NAO_CONFERIDO, CONFERIDO, REJEITADO
}
