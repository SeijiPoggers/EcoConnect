package br.com.ecoconnect.api.model.entity;

import br.com.ecoconnect.api.model.enums.StatusAgendamento;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

/**
 * Tabela `atendimento` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 * CHECK chk_at_horario: ((data_hora_fim_real is null) or (data_hora_fim_real >= data_hora_inicio_real))
 */
@Entity
@Table(name = "atendimento")
public class Atendimento implements Entidade<Long> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_atendimento", nullable = false)
    private Long idAtendimento;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_agendamento", nullable = false)
    private Long idAgendamento;

    @Enumerated(EnumType.STRING)
    @Column(name = "status_agendamento_ref", nullable = false, updatable = false)
    private StatusAgendamento statusAgendamentoRef;

    @NotNull(message = "campo obrigatório")
    @Column(name = "data_hora_inicio_real", nullable = false)
    private LocalDateTime dataHoraInicioReal;

    @Column(name = "data_hora_fim_real")
    private LocalDateTime dataHoraFimReal;

    @Column(name = "observacoes_gerais", columnDefinition = "text")
    private String observacoesGerais;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_usuario_registro", nullable = false)
    private Long idUsuarioRegistro;

    @Column(name = "data_registro", nullable = false)
    private LocalDateTime dataRegistro;

    @PrePersist
    void aoInserir() {
        if (statusAgendamentoRef == null) {
            statusAgendamentoRef = StatusAgendamento.REALIZADO;
        }
        if (dataRegistro == null) {
            dataRegistro = LocalDateTime.now();
        }
    }

    public Long getIdAtendimento() {
        return idAtendimento;
    }

    public void setIdAtendimento(Long idAtendimento) {
        this.idAtendimento = idAtendimento;
    }

    public Long getIdAgendamento() {
        return idAgendamento;
    }

    public void setIdAgendamento(Long idAgendamento) {
        this.idAgendamento = idAgendamento;
    }

    public StatusAgendamento getStatusAgendamentoRef() {
        return statusAgendamentoRef;
    }

    public void setStatusAgendamentoRef(StatusAgendamento statusAgendamentoRef) {
        this.statusAgendamentoRef = statusAgendamentoRef;
    }

    public LocalDateTime getDataHoraInicioReal() {
        return dataHoraInicioReal;
    }

    public void setDataHoraInicioReal(LocalDateTime dataHoraInicioReal) {
        this.dataHoraInicioReal = dataHoraInicioReal;
    }

    public LocalDateTime getDataHoraFimReal() {
        return dataHoraFimReal;
    }

    public void setDataHoraFimReal(LocalDateTime dataHoraFimReal) {
        this.dataHoraFimReal = dataHoraFimReal;
    }

    public String getObservacoesGerais() {
        return observacoesGerais;
    }

    public void setObservacoesGerais(String observacoesGerais) {
        this.observacoesGerais = observacoesGerais;
    }

    public Long getIdUsuarioRegistro() {
        return idUsuarioRegistro;
    }

    public void setIdUsuarioRegistro(Long idUsuarioRegistro) {
        this.idUsuarioRegistro = idUsuarioRegistro;
    }

    public LocalDateTime getDataRegistro() {
        return dataRegistro;
    }

    public void setDataRegistro(LocalDateTime dataRegistro) {
        this.dataRegistro = dataRegistro;
    }

    @Override
    public Long chave() {
        return idAtendimento;
    }

    @Override
    public void definirChave(Long id) {
        this.idAtendimento = id;
    }
}
