package br.com.ecoconnect.api.controller.agenda;

import br.com.ecoconnect.api.dto.AtividadeDoAtendimento;
import br.com.ecoconnect.api.dto.ParticipacaoAtendimento;
import br.com.ecoconnect.api.model.entity.AtendimentoAtividade;
import br.com.ecoconnect.api.model.entity.AtendimentoProfissional;
import br.com.ecoconnect.api.service.agenda.AtendimentoEquipeService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Profissionais e atividades de um atendimento. */
@RestController
@RequestMapping("/api/atendimentos/{idAtendimento}")
public class AtendimentoEquipeController {

    private final AtendimentoEquipeService service;

    public AtendimentoEquipeController(AtendimentoEquipeService service) {
        this.service = service;
    }

    // ---------------- profissionais

    @GetMapping("/profissionais")
    public List<AtendimentoProfissional> profissionais(@PathVariable Long idAtendimento) {
        return service.profissionais(idAtendimento);
    }

    @PostMapping("/profissionais")
    @ResponseStatus(HttpStatus.CREATED)
    public AtendimentoProfissional adicionarProfissional(@PathVariable Long idAtendimento,
                                                         @Valid @RequestBody ParticipacaoAtendimento dados) {
        return service.adicionarProfissional(idAtendimento, dados.idProfissional(), dados.funcaoNoAtendimento());
    }

    /** Traz para o atendimento os profissionais previstos no agendamento. */
    @PostMapping("/profissionais/importar-do-agendamento")
    @ResponseStatus(HttpStatus.CREATED)
    public List<AtendimentoProfissional> importar(@PathVariable Long idAtendimento) {
        return service.importarDoAgendamento(idAtendimento);
    }

    @PutMapping("/profissionais/{idProfissional}")
    public AtendimentoProfissional alterarFuncao(@PathVariable Long idAtendimento, @PathVariable Long idProfissional,
                                                 @Valid @RequestBody ParticipacaoAtendimento dados) {
        return service.alterarFuncao(idAtendimento, idProfissional, dados.funcaoNoAtendimento());
    }

    @DeleteMapping("/profissionais/{idProfissional}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void removerProfissional(@PathVariable Long idAtendimento, @PathVariable Long idProfissional) {
        service.removerProfissional(idAtendimento, idProfissional);
    }

    // ---------------- atividades

    @GetMapping("/atividades")
    public List<AtendimentoAtividade> atividades(@PathVariable Long idAtendimento) {
        return service.atividades(idAtendimento);
    }

    @PostMapping("/atividades")
    @ResponseStatus(HttpStatus.CREATED)
    public AtendimentoAtividade adicionarAtividade(@PathVariable Long idAtendimento,
                                                   @Valid @RequestBody AtividadeDoAtendimento dados) {
        return service.adicionarAtividade(idAtendimento, dados.idAtividade(), dados.duracaoMinutos(), dados.observacao());
    }

    @PutMapping("/atividades/{idAtividade}")
    public AtendimentoAtividade alterarAtividade(@PathVariable Long idAtendimento, @PathVariable Integer idAtividade,
                                                 @Valid @RequestBody AtividadeDoAtendimento dados) {
        return service.alterarAtividade(idAtendimento, idAtividade, dados.duracaoMinutos(), dados.observacao());
    }

    @DeleteMapping("/atividades/{idAtividade}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void removerAtividade(@PathVariable Long idAtendimento, @PathVariable Integer idAtividade) {
        service.removerAtividade(idAtendimento, idAtividade);
    }
}
