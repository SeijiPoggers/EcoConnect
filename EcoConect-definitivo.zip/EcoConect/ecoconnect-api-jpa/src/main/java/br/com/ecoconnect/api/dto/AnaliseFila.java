package br.com.ecoconnect.api.dto;

import br.com.ecoconnect.api.model.enums.SituacaoFila;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/** Decisão institucional sobre a fila de espera (sem pontuação automática, RI-16). */
public record AnaliseFila(
        @NotNull(message = "campo obrigatório") SituacaoFila situacao,
        @NotNull(message = "campo obrigatório") Long idUsuarioAnalise,
        String justificativaDecisao,
        String criteriosInstitucionais,
        @Size(max = 30) String nivelPrioridade) {
}
