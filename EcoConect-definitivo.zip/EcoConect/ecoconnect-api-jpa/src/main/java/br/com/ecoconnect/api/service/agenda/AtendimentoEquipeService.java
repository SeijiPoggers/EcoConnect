package br.com.ecoconnect.api.service.agenda;

import br.com.ecoconnect.api.exception.ConflitoException;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.AgendamentoProfissional;
import br.com.ecoconnect.api.model.entity.Atendimento;
import br.com.ecoconnect.api.model.entity.AtendimentoAtividade;
import br.com.ecoconnect.api.model.entity.AtendimentoAtividadeId;
import br.com.ecoconnect.api.model.entity.AtendimentoProfissional;
import br.com.ecoconnect.api.model.entity.AtendimentoProfissionalId;
import br.com.ecoconnect.api.model.entity.Atividade;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.repository.AgendamentoProfissionalRepository;
import br.com.ecoconnect.api.repository.AtendimentoAtividadeRepository;
import br.com.ecoconnect.api.repository.AtendimentoProfissionalRepository;
import br.com.ecoconnect.api.repository.AtendimentoRepository;
import br.com.ecoconnect.api.repository.AtividadeRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.Verificacoes;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * ATENDIMENTO_PROFISSIONAL (quem participou e com qual função) e
 * ATENDIMENTO_ATIVIDADE (atividades feitas, duração e observação).
 * Remover um participante que já é autor de relatório é bloqueado pelo banco (FK composta).
 */
@Service
public class AtendimentoEquipeService {

    private final AtendimentoRepository atendimentoRepository;
    private final AtendimentoProfissionalRepository participanteRepository;
    private final AtendimentoAtividadeRepository atividadeDoAtendimentoRepository;
    private final AtividadeRepository atividadeRepository;
    private final AgendamentoProfissionalRepository previstoRepository;
    private final Verificacoes verificacoes;
    private final AuditoriaService auditoria;

    public AtendimentoEquipeService(AtendimentoRepository atendimentoRepository,
                                    AtendimentoProfissionalRepository participanteRepository,
                                    AtendimentoAtividadeRepository atividadeDoAtendimentoRepository,
                                    AtividadeRepository atividadeRepository,
                                    AgendamentoProfissionalRepository previstoRepository,
                                    Verificacoes verificacoes, AuditoriaService auditoria) {
        this.atendimentoRepository = atendimentoRepository;
        this.participanteRepository = participanteRepository;
        this.atividadeDoAtendimentoRepository = atividadeDoAtendimentoRepository;
        this.atividadeRepository = atividadeRepository;
        this.previstoRepository = previstoRepository;
        this.verificacoes = verificacoes;
        this.auditoria = auditoria;
    }

    // ------------------------------------------------------------- profissionais

    @Transactional(readOnly = true)
    public List<AtendimentoProfissional> profissionais(Long idAtendimento) {
        atendimento(idAtendimento);
        return participanteRepository.findByIdAtendimento(idAtendimento);
    }

    @Transactional
    public AtendimentoProfissional adicionarProfissional(Long idAtendimento, Long idProfissional, String funcao) {
        atendimento(idAtendimento);
        if (idProfissional == null) throw new RegraNegocioException("Informe o idProfissional.");
        verificacoes.profissionalAtivo(idProfissional);
        if (participanteRepository.existsById(new AtendimentoProfissionalId(idAtendimento, idProfissional))) {
            throw new ConflitoException("Este profissional já consta no atendimento.");
        }
        AtendimentoProfissional ap = new AtendimentoProfissional();
        ap.setIdAtendimento(idAtendimento);
        ap.setIdProfissional(idProfissional);
        ap.setFuncaoNoAtendimento(vazioParaNulo(funcao));
        AtendimentoProfissional salvo = participanteRepository.saveAndFlush(ap);
        auditoria.registrar(AcaoAuditoria.CRIACAO, "atendimento_profissional", salvo, null, salvo);
        return salvo;
    }

    /** Copia os profissionais previstos no agendamento que ainda não constam no atendimento. */
    @Transactional
    public List<AtendimentoProfissional> importarDoAgendamento(Long idAtendimento) {
        Atendimento at = atendimento(idAtendimento);
        List<AtendimentoProfissional> incluidos = new ArrayList<>();
        for (AgendamentoProfissional previsto : previstoRepository.findByIdAgendamento(at.getIdAgendamento())) {
            if (!participanteRepository.existsById(new AtendimentoProfissionalId(idAtendimento, previsto.getIdProfissional()))) {
                incluidos.add(adicionarProfissional(idAtendimento, previsto.getIdProfissional(), null));
            }
        }
        return incluidos;
    }

    @Transactional
    public AtendimentoProfissional alterarFuncao(Long idAtendimento, Long idProfissional, String funcao) {
        AtendimentoProfissionalId id = new AtendimentoProfissionalId(idAtendimento, idProfissional);
        AtendimentoProfissional ap = participanteRepository.findById(id)
                .orElseThrow(() -> new NaoEncontradoException("atendimento_profissional", id));
        String antes = auditoria.json(ap);
        ap.setFuncaoNoAtendimento(vazioParaNulo(funcao));
        AtendimentoProfissional salvo = participanteRepository.saveAndFlush(ap);
        auditoria.registrar(AcaoAuditoria.ATUALIZACAO, "atendimento_profissional", salvo, antes, salvo);
        return salvo;
    }

    @Transactional
    public void removerProfissional(Long idAtendimento, Long idProfissional) {
        AtendimentoProfissionalId id = new AtendimentoProfissionalId(idAtendimento, idProfissional);
        AtendimentoProfissional ap = participanteRepository.findById(id)
                .orElseThrow(() -> new NaoEncontradoException("atendimento_profissional", id));
        String antes = auditoria.json(ap);
        participanteRepository.delete(ap);
        participanteRepository.flush();
        auditoria.registrar(AcaoAuditoria.ATUALIZACAO, "atendimento_profissional", ap, antes, null);
    }

    // ------------------------------------------------------------- atividades

    @Transactional(readOnly = true)
    public List<AtendimentoAtividade> atividades(Long idAtendimento) {
        atendimento(idAtendimento);
        return atividadeDoAtendimentoRepository.findByIdAtendimento(idAtendimento);
    }

    @Transactional
    public AtendimentoAtividade adicionarAtividade(Long idAtendimento, Integer idAtividade, Integer duracao, String observacao) {
        atendimento(idAtendimento);
        if (idAtividade == null) throw new RegraNegocioException("Informe o idAtividade.");
        Atividade atividade = atividadeRepository.findById(idAtividade)
                .orElseThrow(() -> new NaoEncontradoException("atividade", idAtividade));
        if (!Boolean.TRUE.equals(atividade.getAtivo())) {
            throw new RegraNegocioException("A atividade " + atividade.getNome() + " está inativa no catálogo.");
        }
        if (atividadeDoAtendimentoRepository.existsById(new AtendimentoAtividadeId(idAtendimento, idAtividade))) {
            throw new ConflitoException("Esta atividade já consta no atendimento.");
        }
        AtendimentoAtividade aa = new AtendimentoAtividade();
        aa.setIdAtendimento(idAtendimento);
        aa.setIdAtividade(idAtividade);
        aa.setDuracaoMinutos(duracao);
        aa.setObservacao(vazioParaNulo(observacao));
        AtendimentoAtividade salvo = atividadeDoAtendimentoRepository.saveAndFlush(aa);
        auditoria.registrar(AcaoAuditoria.CRIACAO, "atendimento_atividade", salvo, null, salvo);
        return salvo;
    }

    @Transactional
    public AtendimentoAtividade alterarAtividade(Long idAtendimento, Integer idAtividade, Integer duracao, String observacao) {
        AtendimentoAtividadeId id = new AtendimentoAtividadeId(idAtendimento, idAtividade);
        AtendimentoAtividade aa = atividadeDoAtendimentoRepository.findById(id)
                .orElseThrow(() -> new NaoEncontradoException("atendimento_atividade", id));
        String antes = auditoria.json(aa);
        aa.setDuracaoMinutos(duracao);
        aa.setObservacao(vazioParaNulo(observacao));
        AtendimentoAtividade salvo = atividadeDoAtendimentoRepository.saveAndFlush(aa);
        auditoria.registrar(AcaoAuditoria.ATUALIZACAO, "atendimento_atividade", salvo, antes, salvo);
        return salvo;
    }

    @Transactional
    public void removerAtividade(Long idAtendimento, Integer idAtividade) {
        AtendimentoAtividadeId id = new AtendimentoAtividadeId(idAtendimento, idAtividade);
        AtendimentoAtividade aa = atividadeDoAtendimentoRepository.findById(id)
                .orElseThrow(() -> new NaoEncontradoException("atendimento_atividade", id));
        String antes = auditoria.json(aa);
        atividadeDoAtendimentoRepository.delete(aa);
        atividadeDoAtendimentoRepository.flush();
        auditoria.registrar(AcaoAuditoria.ATUALIZACAO, "atendimento_atividade", aa, antes, null);
    }

    // ------------------------------------------------------------------

    private Atendimento atendimento(Long id) {
        return atendimentoRepository.findById(id).orElseThrow(() -> new NaoEncontradoException("atendimento", id));
    }

    private static String vazioParaNulo(String s) {
        return s == null || s.isBlank() ? null : s.trim();
    }
}
