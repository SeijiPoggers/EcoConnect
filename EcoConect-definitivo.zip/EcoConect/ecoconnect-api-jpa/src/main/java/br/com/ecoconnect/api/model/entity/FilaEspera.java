package br.com.ecoconnect.api.model.entity;

import br.com.ecoconnect.api.model.enums.SituacaoFila;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;

/**
 * Tabela `fila_espera` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 * CHECK chk_fe_analise: ((situacao not in ('AGUARDANDO_VAGA','CONVOCADA','NAO_ACEITA')) or ((id_usuario_analise is not null) and (data_analise is not null) and (justificativa_decisao is not null)))
 */
@Entity
@Table(name = "fila_espera")
public class FilaEspera implements Entidade<Long>, PertenceACrianca {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_fila_espera", nullable = false)
    private Long idFilaEspera;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_crianca", nullable = false)
    private Long idCrianca;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_usuario_solicitante", nullable = false)
    private Long idUsuarioSolicitante;

    @Column(name = "data_solicitacao", nullable = false)
    private LocalDateTime dataSolicitacao;

    @Size(max = 500)
    @Column(name = "observacao_solicitacao", length = 500)
    private String observacaoSolicitacao;

    @Enumerated(EnumType.STRING)
    @Column(name = "situacao", nullable = false)
    private SituacaoFila situacao;

    @Column(name = "criterios_institucionais", columnDefinition = "text")
    private String criteriosInstitucionais;

    @Column(name = "justificativa_decisao", columnDefinition = "text")
    private String justificativaDecisao;

    @Size(max = 30)
    @Column(name = "nivel_prioridade", length = 30)
    private String nivelPrioridade;

    @Column(name = "id_usuario_analise")
    private Long idUsuarioAnalise;

    @Column(name = "data_analise")
    private LocalDateTime dataAnalise;

    @PrePersist
    void aoInserir() {
        if (dataSolicitacao == null) {
            dataSolicitacao = LocalDateTime.now();
        }
        if (situacao == null) {
            situacao = SituacaoFila.SOLICITADA;
        }
    }

    public Long getIdFilaEspera() {
        return idFilaEspera;
    }

    public void setIdFilaEspera(Long idFilaEspera) {
        this.idFilaEspera = idFilaEspera;
    }

    public Long getIdCrianca() {
        return idCrianca;
    }

    public void setIdCrianca(Long idCrianca) {
        this.idCrianca = idCrianca;
    }

    public Long getIdUsuarioSolicitante() {
        return idUsuarioSolicitante;
    }

    public void setIdUsuarioSolicitante(Long idUsuarioSolicitante) {
        this.idUsuarioSolicitante = idUsuarioSolicitante;
    }

    public LocalDateTime getDataSolicitacao() {
        return dataSolicitacao;
    }

    public void setDataSolicitacao(LocalDateTime dataSolicitacao) {
        this.dataSolicitacao = dataSolicitacao;
    }

    public String getObservacaoSolicitacao() {
        return observacaoSolicitacao;
    }

    public void setObservacaoSolicitacao(String observacaoSolicitacao) {
        this.observacaoSolicitacao = observacaoSolicitacao;
    }

    public SituacaoFila getSituacao() {
        return situacao;
    }

    public void setSituacao(SituacaoFila situacao) {
        this.situacao = situacao;
    }

    public String getCriteriosInstitucionais() {
        return criteriosInstitucionais;
    }

    public void setCriteriosInstitucionais(String criteriosInstitucionais) {
        this.criteriosInstitucionais = criteriosInstitucionais;
    }

    public String getJustificativaDecisao() {
        return justificativaDecisao;
    }

    public void setJustificativaDecisao(String justificativaDecisao) {
        this.justificativaDecisao = justificativaDecisao;
    }

    public String getNivelPrioridade() {
        return nivelPrioridade;
    }

    public void setNivelPrioridade(String nivelPrioridade) {
        this.nivelPrioridade = nivelPrioridade;
    }

    public Long getIdUsuarioAnalise() {
        return idUsuarioAnalise;
    }

    public void setIdUsuarioAnalise(Long idUsuarioAnalise) {
        this.idUsuarioAnalise = idUsuarioAnalise;
    }

    public LocalDateTime getDataAnalise() {
        return dataAnalise;
    }

    public void setDataAnalise(LocalDateTime dataAnalise) {
        this.dataAnalise = dataAnalise;
    }

    @Override
    public Long chave() {
        return idFilaEspera;
    }

    @Override
    public void definirChave(Long id) {
        this.idFilaEspera = id;
    }
}
