package br.com.ecoconnect.api.model.enums;

/** Situação da criança no projeto. Não existe "alta". Valores idênticos ao ENUM do MySQL. */
public enum SituacaoEcocura {
    EM_ANALISE, AGUARDANDO_VAGA, ATIVA, CICLO_ENCERRADO, INATIVA
}
