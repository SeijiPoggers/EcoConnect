package br.com.ecoconnect.api.model.entity;

import br.com.ecoconnect.api.model.enums.SituacaoValidacao;

import java.time.LocalDateTime;

/**
 * Colunas de procedência comuns a CRIANCA_DIAGNOSTICO, CRIANCA_CONDICAO e HISTORICO_SAUDE
 * (origem, validação, autor e documento). Permite tratar a validação de forma única.
 */
public interface RegistroDeSaude extends PertenceACrianca {

    SituacaoValidacao getSituacaoValidacao();

    void setSituacaoValidacao(SituacaoValidacao situacaoValidacao);

    Long getIdUsuarioValidacao();

    void setIdUsuarioValidacao(Long idUsuarioValidacao);

    LocalDateTime getDataValidacao();

    void setDataValidacao(LocalDateTime dataValidacao);

    Long getIdDocumento();

    Long getIdUsuarioRegistro();
}
