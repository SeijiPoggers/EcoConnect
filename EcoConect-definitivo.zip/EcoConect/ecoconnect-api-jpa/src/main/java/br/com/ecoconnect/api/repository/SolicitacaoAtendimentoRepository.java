package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.SolicitacaoAtendimento;
import java.util.Collection;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SolicitacaoAtendimentoRepository extends JpaRepository<SolicitacaoAtendimento, Long> {

    List<SolicitacaoAtendimento> findByIdUsuarioSolicitanteOrderByDataCriacaoDesc(Long id);
    List<SolicitacaoAtendimento> findByIdInstituicaoInOrderByDataCriacaoDesc(Collection<Long> ids);
    List<SolicitacaoAtendimento> findAllByOrderByDataCriacaoDesc();

}
