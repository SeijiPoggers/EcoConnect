package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.Atendimento;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `atendimento` (Spring Data JPA). */
public interface AtendimentoRepository extends JpaRepository<Atendimento, Long> {

    boolean existsByIdAgendamento(Long idAgendamento);
}
