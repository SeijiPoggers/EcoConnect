package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

/**
 * Tabela `profissional_especialidade` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 */
@Entity
@Table(name = "profissional_especialidade")
@IdClass(ProfissionalEspecialidadeId.class)
public class ProfissionalEspecialidade {

    @Id
    @Column(name = "id_profissional", nullable = false)
    private Long idProfissional;

    @Id
    @Column(name = "id_especialidade", nullable = false)
    private Integer idEspecialidade;

    @Column(name = "principal", nullable = false)
    private Boolean principal;

    @PrePersist
    void aoInserir() {
        if (principal == null) {
            principal = Boolean.FALSE;
        }
    }

    public Long getIdProfissional() {
        return idProfissional;
    }

    public void setIdProfissional(Long idProfissional) {
        this.idProfissional = idProfissional;
    }

    public Integer getIdEspecialidade() {
        return idEspecialidade;
    }

    public void setIdEspecialidade(Integer idEspecialidade) {
        this.idEspecialidade = idEspecialidade;
    }

    public Boolean getPrincipal() {
        return principal;
    }

    public void setPrincipal(Boolean principal) {
        this.principal = principal;
    }
}
