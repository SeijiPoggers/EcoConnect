package br.com.ecoconnect.api.service.evolucao;

import br.com.ecoconnect.api.dto.IndicadorDoObjetivo;
import br.com.ecoconnect.api.exception.ConflitoException;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Indicador;
import br.com.ecoconnect.api.model.entity.Objetivo;
import br.com.ecoconnect.api.model.entity.ObjetivoIndicador;
import br.com.ecoconnect.api.model.entity.ObjetivoIndicadorId;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.SituacaoObjetivo;
import br.com.ecoconnect.api.repository.IndicadorRepository;
import br.com.ecoconnect.api.repository.ObjetivoIndicadorRepository;
import br.com.ecoconnect.api.repository.ObjetivoRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/** OBJETIVO_INDICADOR: indicadores aplicáveis a cada objetivo, com referência inicial e meta. */
@Service
public class ObjetivoIndicadorService {

    private static final String TABELA = "objetivo_indicador";

    private final ObjetivoIndicadorRepository repository;
    private final ObjetivoRepository objetivoRepository;
    private final IndicadorRepository indicadorRepository;
    private final AuditoriaService auditoria;

    public ObjetivoIndicadorService(ObjetivoIndicadorRepository repository, ObjetivoRepository objetivoRepository,
                                    IndicadorRepository indicadorRepository, AuditoriaService auditoria) {
        this.repository = repository;
        this.objetivoRepository = objetivoRepository;
        this.indicadorRepository = indicadorRepository;
        this.auditoria = auditoria;
    }

    @Transactional(readOnly = true)
    public List<ObjetivoIndicador> listar(Long idObjetivo) {
        objetivo(idObjetivo);
        return repository.findByIdObjetivo(idObjetivo);
    }

    @Transactional
    public ObjetivoIndicador vincular(Long idObjetivo, IndicadorDoObjetivo dados) {
        Objetivo o = objetivo(idObjetivo);
        if (o.getSituacao() != SituacaoObjetivo.EM_ANDAMENTO) {
            throw new RegraNegocioException("Só objetivos EM_ANDAMENTO recebem novos indicadores.");
        }
        if (dados.idIndicador() == null) throw new RegraNegocioException("Informe o idIndicador.");
        Indicador ind = indicadorRepository.findById(dados.idIndicador())
                .orElseThrow(() -> new NaoEncontradoException("indicador", dados.idIndicador()));
        if (!Boolean.TRUE.equals(ind.getAtivo())) {
            throw new RegraNegocioException("O indicador " + ind.getNome() + " está inativo.");
        }
        if (repository.existsById(new ObjetivoIndicadorId(idObjetivo, dados.idIndicador()))) {
            throw new ConflitoException("Este indicador já está vinculado ao objetivo.");
        }
        ObjetivoIndicador oi = new ObjetivoIndicador();
        oi.setIdObjetivo(idObjetivo);
        oi.setIdIndicador(dados.idIndicador());
        oi.setValorReferenciaInicial(dados.valorReferenciaInicial());
        oi.setMetaValor(dados.metaValor());
        oi.setDescricaoMeta(dados.descricaoMeta());
        ObjetivoIndicador salvo = repository.saveAndFlush(oi);
        auditoria.registrar(AcaoAuditoria.CRIACAO, TABELA, salvo, null, salvo);
        return salvo;
    }

    @Transactional
    public ObjetivoIndicador alterar(Long idObjetivo, Long idIndicador, IndicadorDoObjetivo dados) {
        ObjetivoIndicador oi = buscar(idObjetivo, idIndicador);
        String antes = auditoria.json(oi);
        oi.setValorReferenciaInicial(dados.valorReferenciaInicial());
        oi.setMetaValor(dados.metaValor());
        oi.setDescricaoMeta(dados.descricaoMeta());
        ObjetivoIndicador salvo = repository.saveAndFlush(oi);
        auditoria.registrar(AcaoAuditoria.ATUALIZACAO, TABELA, salvo, antes, salvo);
        return salvo;
    }

    /** O banco bloqueia (409) se já houver avaliações deste indicador no objetivo. */
    @Transactional
    public void remover(Long idObjetivo, Long idIndicador) {
        ObjetivoIndicador oi = buscar(idObjetivo, idIndicador);
        String antes = auditoria.json(oi);
        repository.delete(oi);
        repository.flush();
        auditoria.registrar(AcaoAuditoria.ATUALIZACAO, TABELA, oi, antes, null);
    }

    private ObjetivoIndicador buscar(Long idObjetivo, Long idIndicador) {
        ObjetivoIndicadorId id = new ObjetivoIndicadorId(idObjetivo, idIndicador);
        return repository.findById(id).orElseThrow(() -> new NaoEncontradoException(TABELA, id));
    }

    private Objetivo objetivo(Long id) {
        return objetivoRepository.findById(id).orElseThrow(() -> new NaoEncontradoException("objetivo", id));
    }
}
