package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.AvaliacaoIndicador;
import br.com.ecoconnect.api.model.enums.SituacaoAvaliacao;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `avaliacao_indicador` (Spring Data JPA). */
public interface AvaliacaoIndicadorRepository extends JpaRepository<AvaliacaoIndicador, Long> {

    List<AvaliacaoIndicador> findByIdObjetivoAndIdIndicadorAndSituacaoOrderByDataAvaliacaoAsc(Long idObjetivo, Long idIndicador, SituacaoAvaliacao situacao);
}
