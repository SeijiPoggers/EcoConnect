package br.com.ecoconnect.api.seguranca;

import br.com.ecoconnect.api.dominio.Papeis;
import java.util.Set;

/** Quem está autenticado nesta requisição (montado a partir da sessão). */
public record ContextoUsuario(
        Long idUsuario,
        Long idSessao,
        String nome,
        String email,
        String perfil,
        Long idResponsavel,
        Long idProfissional,
        Long idCriancaPropria,
        Set<Long> instituicoes,
        boolean exigeTrocaSenha) {

    public boolean administrador() {
        return Papeis.ADMINISTRADOR.equals(perfil);
    }

    public boolean profissional() {
        return Papeis.PROFISSIONAL.equals(perfil);
    }

    public boolean equipe() {
        return Papeis.EQUIPE.contains(perfil);
    }

    public boolean responsavel() {
        return Papeis.RESPONSAVEL.equals(perfil);
    }

    public boolean familia() {
        return Papeis.FAMILIA.contains(perfil);
    }

    public boolean adminInstitucional() {
        return Papeis.ADMIN_INSTITUCIONAL.equals(perfil);
    }
}
