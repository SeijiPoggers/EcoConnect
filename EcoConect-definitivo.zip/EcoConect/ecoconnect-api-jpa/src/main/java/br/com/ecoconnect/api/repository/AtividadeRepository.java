package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.Atividade;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `atividade` (Spring Data JPA). */
public interface AtividadeRepository extends JpaRepository<Atividade, Integer> {
}
