package br.com.ecoconnect.api.service.base;

import br.com.ecoconnect.api.exception.RequisicaoInvalidaException;
import br.com.ecoconnect.api.model.entity.PertenceACrianca;
import br.com.ecoconnect.api.seguranca.EscopoAcesso;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.ecoconnect.api.dto.Pagina;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Entidade;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.service.AuditoriaService;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.Set;

/**
 * Regras comuns de CRUD para tabelas com chave primária simples.
 *
 * Cada tabela tem um service que estende esta classe e personaliza os "ganchos":
 * antesDeCriar, depoisDeCriar, validarAtualizacao, antesDeSalvarAtualizacao,
 * camposProtegidos, modoExclusao e aplicarExclusaoLogica.
 * Toda gravação gera uma linha em AUDITORIA.
 */
public abstract class CrudService<E extends Entidade<ID>, ID> {

    /** Campos preenchidos pelo sistema que nunca são trocados por um PUT. */
    private static final Set<String> SEMPRE_PROTEGIDOS = Set.of(
            "dataCadastro", "dataRegistro", "dataSolicitacao", "dataCriacao", "dataUpload",
            "dataDesignacao", "dataVinculo", "dataElaboracao", "dataAtualizacao", "dataHora");

    protected final JpaRepository<E, ID> repository;
    protected final AuditoriaService auditoria;
    private final String tabela;

    /** Escopo por pessoa (injetado por setter para não alterar o construtor de cada service). */
    private EscopoAcesso escopo;

    @Autowired(required = false)
    public void setEscopoAcesso(EscopoAcesso escopo) {
        this.escopo = escopo;
    }

    protected EscopoAcesso escopo() {
        return escopo;
    }

    /** true quando o usuário atual só pode ver as pessoas do seu escopo (não é administrador). */
    protected boolean escopoRestrito() {
        return escopo != null && !escopo.irrestrito();
    }

    /** Pessoa acompanhada a que o registro pertence (null = registro sem pessoa, como os catálogos). */
    protected Long criancaDoRegistro(E entidade) {
        return entidade instanceof PertenceACrianca p ? p.getIdCrianca() : null;
    }

    /** Pessoa indicada no filtro da listagem; os services sem id_crianca resolvem pelo registro-pai. */
    protected Long criancaDoFiltro(E filtro) {
        return criancaDoRegistro(filtro);
    }

    /** O registro é de alguma pessoa? (se sim, a listagem restrita exige o filtro da pessoa) */
    protected boolean registroDePessoa() {
        return false;
    }

    protected void verificarEscopo(E entidade) {
        if (!escopoRestrito()) return;
        Long c = criancaDoRegistro(entidade);
        if (c != null) escopo.exigirCrianca(c);
    }

    protected CrudService(JpaRepository<E, ID> repository, AuditoriaService auditoria, String tabela) {
        this.repository = repository;
        this.auditoria = auditoria;
        this.tabela = tabela;
    }

    public String tabela() {
        return tabela;
    }

    // ------------------------------------------------------------- leitura

    /**
     * Lista com filtros: cada parâmetro da URL com o nome de um campo vira filtro
     * (texto: "contém", sem diferenciar maiúsculas; demais tipos: igual).
     */
    @Transactional(readOnly = true)
    public Pagina<E> listar(E filtro, Pageable pageable) {
        if (escopoRestrito() && (filtro instanceof PertenceACrianca || registroDePessoa())) {
            Long c = criancaDoFiltro(filtro);
            if (c == null) {
                throw new RequisicaoInvalidaException("Informe a pessoa acompanhada (idCrianca ou o registro de origem) "
                        + "para listar " + tabela + ".");
            }
            escopo.exigirCrianca(c);
        }
        ExampleMatcher matcher = ExampleMatcher.matching()
                .withIgnoreNullValues()
                .withIgnoreCase()
                .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING);
        return Pagina.de(repository.findAll(Example.of(filtro, matcher), pageable));
    }

    @Transactional(readOnly = true)
    public E buscar(ID id) {
        E e = repository.findById(id).orElseThrow(() -> new NaoEncontradoException(tabela, id));
        verificarEscopo(e);
        return e;
    }

    // ------------------------------------------------------------- escrita

    @Transactional
    public E criar(E entidade) {
        entidade.definirChave(null);
        verificarEscopo(entidade);
        antesDeCriar(entidade);
        E salvo = repository.saveAndFlush(entidade);
        depoisDeCriar(salvo);
        auditoria.registrar(AcaoAuditoria.CRIACAO, tabela, salvo, null, salvo);
        return salvo;
    }

    /** PUT: copia os campos enviados sobre o registro atual, exceto os protegidos. */
    @Transactional
    public E atualizar(ID id, E dados) {
        E atual = buscar(id);
        String antes = auditoria.json(atual);
        validarAtualizacao(atual, dados);
        Set<String> ignorar = new HashSet<>(SEMPRE_PROTEGIDOS);
        ignorar.addAll(camposProtegidos());
        BeanUtils.copyProperties(dados, atual, ignorar.toArray(new String[0]));
        atual.definirChave(id);
        antesDeSalvarAtualizacao(atual);
        E salvo = repository.saveAndFlush(atual);
        auditoria.registrar(AcaoAuditoria.ATUALIZACAO, tabela, salvo, antes, salvo);
        return salvo;
    }

    @Transactional
    public void excluir(ID id) {
        E atual = buscar(id);
        String antes = auditoria.json(atual);
        switch (modoExclusao()) {
            case PROIBIDA -> throw new RegraNegocioException(motivoExclusaoProibida());
            case LOGICA -> {
                aplicarExclusaoLogica(atual);
                E salvo = repository.saveAndFlush(atual);
                auditoria.registrar(AcaoAuditoria.EXCLUSAO_LOGICA, tabela, salvo, antes, salvo);
            }
            case FISICA -> {
                validarExclusaoFisica(atual);
                repository.delete(atual);
                repository.flush();
                // O ENUM de auditoria não tem ação de exclusão física: registra como ATUALIZACAO sem valores novos.
                auditoria.registrar(AcaoAuditoria.ATUALIZACAO, tabela, atual, antes, null);
            }
        }
    }

    /** Grava uma alteração feita por regra de negócio (status, validação...) com auditoria. */
    protected E salvarAlteracao(E entidade, String antesJson, AcaoAuditoria acao) {
        E salvo = repository.saveAndFlush(entidade);
        auditoria.registrar(acao, tabela, salvo, antesJson, salvo);
        return salvo;
    }

    // ------------------------------------------------------------- ganchos

    /** Ajustes e validações antes do INSERT (ex.: forçar situação inicial). */
    protected void antesDeCriar(E entidade) {
    }

    /** Ações após o INSERT (ex.: gravar histórico). */
    protected void depoisDeCriar(E salvo) {
    }

    /** Verifica se o registro pode ser alterado (antes de copiar os dados). */
    protected void validarAtualizacao(E atual, E dados) {
    }

    /** Validações finais antes do UPDATE. */
    protected void antesDeSalvarAtualizacao(E atual) {
    }

    /** Campos (nome Java) que o PUT não pode alterar, além dos de data automática. */
    protected Set<String> camposProtegidos() {
        return Set.of();
    }

    protected ModoExclusao modoExclusao() {
        return ModoExclusao.PROIBIDA;
    }

    protected void aplicarExclusaoLogica(E entidade) {
        throw new UnsupportedOperationException("exclusão lógica não definida para " + tabela);
    }

    protected void validarExclusaoFisica(E entidade) {
    }

    protected String motivoExclusaoProibida() {
        return "Registros de " + tabela + " não são excluídos (dados de saúde, histórico ou documentos). "
                + "Use a situação/substituição do próprio registro.";
    }
}
