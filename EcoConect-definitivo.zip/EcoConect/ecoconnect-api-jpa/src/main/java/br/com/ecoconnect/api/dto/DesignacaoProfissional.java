package br.com.ecoconnect.api.dto;

import jakarta.validation.constraints.NotNull;

public record DesignacaoProfissional(
        @NotNull(message = "campo obrigatório") Long idProfissional,
        @NotNull(message = "campo obrigatório") Long idUsuarioDesignacao) {
}
