package br.com.ecoconnect.api.controller.agenda;

import br.com.ecoconnect.api.dto.DesignacaoProfissional;
import br.com.ecoconnect.api.model.entity.AgendamentoProfissional;
import br.com.ecoconnect.api.service.agenda.AgendamentoProfissionalService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Profissionais previstos em um agendamento. */
@RestController
@RequestMapping("/api/agendamentos/{idAgendamento}/profissionais")
public class AgendamentoProfissionalController {

    private final AgendamentoProfissionalService service;

    public AgendamentoProfissionalController(AgendamentoProfissionalService service) {
        this.service = service;
    }

    @GetMapping
    public List<AgendamentoProfissional> listar(@PathVariable Long idAgendamento) {
        return service.listar(idAgendamento);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public AgendamentoProfissional designar(@PathVariable Long idAgendamento, @Valid @RequestBody DesignacaoProfissional dados) {
        return service.designar(idAgendamento, dados.idProfissional(), dados.idUsuarioDesignacao());
    }

    @DeleteMapping("/{idProfissional}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void remover(@PathVariable Long idAgendamento, @PathVariable Long idProfissional) {
        service.remover(idAgendamento, idProfissional);
    }
}
