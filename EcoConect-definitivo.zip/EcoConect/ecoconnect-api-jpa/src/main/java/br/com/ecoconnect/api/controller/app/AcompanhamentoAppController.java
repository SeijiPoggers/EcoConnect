package br.com.ecoconnect.api.controller.app;

import br.com.ecoconnect.api.service.app.AcompanhamentoService;
import br.com.ecoconnect.api.service.app.AgendaService;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** Registro de sessões e agenda de atendimentos. */
@RestController
@RequestMapping("/api/app")
public class AcompanhamentoAppController {

    private final AcompanhamentoService acompanhamento;
    private final AgendaService agenda;

    public AcompanhamentoAppController(AcompanhamentoService acompanhamento, AgendaService agenda) {
        this.acompanhamento = acompanhamento;
        this.agenda = agenda;
    }

    @PostMapping("/sessoes")
    public Map<String, Object> registrar(@RequestBody AcompanhamentoService.NovaSessao dados) {
        return acompanhamento.registrarSessao(dados);
    }

    @GetMapping("/sessoes/{id}")
    public Map<String, Object> sessao(@PathVariable("id") Long id) {
        return acompanhamento.sessao(id);
    }

    @PutMapping("/sessoes/{id}")
    public Map<String, Object> alterar(@PathVariable("id") Long id, @RequestBody AcompanhamentoService.AlteracaoSessao dados) {
        return acompanhamento.alterarSessao(id, dados);
    }

    @GetMapping("/agenda")
    public List<Map<String, Object>> agenda(@RequestParam(name = "inicio", required = false) LocalDate inicio,
                                            @RequestParam(name = "fim", required = false) LocalDate fim,
                                            @RequestParam(name = "meus", required = false, defaultValue = "false") boolean meus,
                                            @RequestParam(name = "idCrianca", required = false) Long idCrianca) {
        return agenda.listar(inicio, fim, meus, idCrianca);
    }

    @PostMapping("/agenda")
    public Map<String, Object> agendar(@RequestBody AgendaService.NovoAgendamento dados) {
        return agenda.agendar(dados);
    }

    @GetMapping("/agenda/{id}")
    public Map<String, Object> agendamento(@PathVariable("id") Long id) {
        return agenda.detalhe(id);
    }

    @PostMapping("/agenda/{id}/acao")
    public Map<String, Object> acao(@PathVariable("id") Long id, @RequestBody AgendaService.AcaoAgenda dados) {
        return agenda.executar(id, dados);
    }
}
