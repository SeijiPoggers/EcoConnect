package br.com.ecoconnect.api.controller.comunicacao;

import br.com.ecoconnect.api.controller.base.LeituraController;
import br.com.ecoconnect.api.model.entity.Notificacao;
import br.com.ecoconnect.api.service.NotificacaoService;
import br.com.ecoconnect.api.service.base.CrudService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/** Notificações. Caixa de um usuário: ?idUsuarioDestinatario=5&sort=dataCriacao,desc */
@RestController
@RequestMapping("/api/notificacoes")
public class NotificacaoController extends LeituraController<Notificacao, Long> {

    private final NotificacaoService service;

    public NotificacaoController(NotificacaoService service) {
        this.service = service;
    }

    @Override
    protected CrudService<Notificacao, Long> service() {
        return service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Notificacao criar(@Valid @RequestBody Notificacao dados) {
        return service.criar(dados);
    }

    @PatchMapping("/{id}/leitura")
    public Notificacao marcarComoLida(@PathVariable Long id) {
        return service.marcarComoLida(id);
    }
}
