package br.com.ecoconnect.api.controller.pessoa;

import br.com.ecoconnect.api.controller.base.CrudController;
import br.com.ecoconnect.api.model.entity.CriancaResponsavel;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.pessoa.CriancaResponsavelService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Vínculos criança-responsável. Filtro útil: ?idCrianca=1&status=ATIVO. DELETE revoga. */
@RestController
@RequestMapping("/api/criancas-responsaveis")
public class CriancaResponsavelController extends CrudController<CriancaResponsavel, Long> {

    private final CriancaResponsavelService service;

    public CriancaResponsavelController(CriancaResponsavelService service) {
        this.service = service;
    }

    @Override
    protected CrudService<CriancaResponsavel, Long> service() {
        return service;
    }
}
