package br.com.ecoconnect.api.controller.pessoa;

import br.com.ecoconnect.api.dominio.LimitadorTentativas;
import br.com.ecoconnect.api.dto.AlteracaoSenha;
import br.com.ecoconnect.api.dto.LoginRequisicao;
import br.com.ecoconnect.api.dto.LoginResposta;
import br.com.ecoconnect.api.exception.NaoAutorizadoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Usuario;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.repository.UsuarioRepository;
import br.com.ecoconnect.api.seguranca.ContextoAtual;
import br.com.ecoconnect.api.seguranca.ContextoUsuario;
import br.com.ecoconnect.api.seguranca.FiltroAutenticacao;
import br.com.ecoconnect.api.seguranca.SessaoService;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.UsuarioAtual;
import br.com.ecoconnect.api.service.app.PreferenciasService;
import br.com.ecoconnect.api.service.pessoa.UsuarioService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import java.time.Clock;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Autenticação real:
 *  - POST /api/auth/login  : confere e-mail e senha e abre uma sessão em cookie HttpOnly (navegador);
 *  - POST /api/auth/token  : idem, mas devolve o token para clientes de API (Authorization: Bearer);
 *  - POST /api/auth/logout : encerra a sessão; GET /api/auth/me: quem está conectado;
 *  - POST /api/auth/senha  : troca da própria senha (encerra as outras sessões).
 * Após 5 senhas erradas em 15 minutos para o mesmo e-mail e IP, o login fica bloqueado por 15 minutos.
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UsuarioService usuarioService;
    private final SessaoService sessaoService;
    private final UsuarioRepository usuarioRepository;
    private final AuditoriaService auditoria;
    private final UsuarioAtual usuarioAtual;
    private final PreferenciasService preferenciasService;
    private final LimitadorTentativas limitador = new LimitadorTentativas(5, Duration.ofMinutes(15), Clock.systemUTC());

    @Value("${ecoconnect.seguranca.cookie-seguro:false}")
    private boolean cookieSeguro;

    public AuthController(UsuarioService usuarioService, SessaoService sessaoService, UsuarioRepository usuarioRepository,
                          AuditoriaService auditoria, UsuarioAtual usuarioAtual, PreferenciasService preferenciasService) {
        this.usuarioService = usuarioService;
        this.sessaoService = sessaoService;
        this.usuarioRepository = usuarioRepository;
        this.auditoria = auditoria;
        this.usuarioAtual = usuarioAtual;
        this.preferenciasService = preferenciasService;
    }

    @PostMapping("/login")
    public Map<String, Object> login(@Valid @RequestBody LoginRequisicao dados, HttpServletRequest req,
                                     HttpServletResponse resp) {
        LoginResposta r = autenticar(dados, req);
        SessaoService.SessaoCriada s = sessaoService.criar(r.usuario().getIdUsuario(), usuarioAtual.ip(), req.getHeader("User-Agent"));
        resp.addHeader(HttpHeaders.SET_COOKIE, cookie(s.token(), sessaoService.segundosDeValidade(), req).toString());
        ContextoUsuario ctx = sessaoService.contexto(r.usuario(), s.idSessao());
        return resposta(ctx);
    }

    @PostMapping("/token")
    public Map<String, Object> token(@Valid @RequestBody LoginRequisicao dados, HttpServletRequest req) {
        LoginResposta r = autenticar(dados, req);
        SessaoService.SessaoCriada s = sessaoService.criar(r.usuario().getIdUsuario(), usuarioAtual.ip(), req.getHeader("User-Agent"));
        Map<String, Object> m = resposta(sessaoService.contexto(r.usuario(), s.idSessao()));
        m.put("token", s.token());
        m.put("tipo", "Bearer");
        m.put("expiraEm", s.expiraEm());
        return m;
    }

    @PostMapping("/logout")
    public Map<String, Object> logout(HttpServletRequest req, HttpServletResponse resp) {
        ContextoUsuario ctx = ContextoAtual.obter();
        if (ctx != null) {
            sessaoService.revogar(ctx.idSessao());
            auditoria.registrarAcao(AcaoAuditoria.LOGOUT, ctx.idUsuario(), "usuario", String.valueOf(ctx.idUsuario()));
        }
        resp.addHeader(HttpHeaders.SET_COOKIE, cookie("", 0, req).toString());
        return Map.of("mensagem", "Sessão encerrada.");
    }

    @GetMapping("/me")
    public Map<String, Object> me() {
        return resposta(ContextoAtual.exigir());
    }

    @PostMapping("/senha")
    public Map<String, Object> trocarSenha(@Valid @RequestBody AlteracaoSenha dados) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (dados.senhaAtual() == null || dados.senhaAtual().isBlank()) {
            throw new RegraNegocioException("Informe a senha atual.");
        }
        if (dados.senhaAtual().equals(dados.novaSenha())) {
            throw new RegraNegocioException("A nova senha deve ser diferente da atual.");
        }
        usuarioService.alterarSenha(ctx.idUsuario(), dados);
        sessaoService.concluirTrocaDeSenha(ctx.idUsuario());
        int encerradas = sessaoService.revogarTodas(ctx.idUsuario(), ctx.idSessao());
        Usuario u = usuarioRepository.findById(ctx.idUsuario()).orElseThrow();
        Map<String, Object> m = resposta(sessaoService.contexto(u, ctx.idSessao()));
        m.put("mensagem", "Senha alterada." + (encerradas > 0 ? " Outras " + encerradas + " sessões foram encerradas." : ""));
        return m;
    }

    // ------------------------------------------------------------------

    private LoginResposta autenticar(LoginRequisicao dados, HttpServletRequest req) {
        String chave = (dados.email() == null ? "" : dados.email().trim().toLowerCase()) + "|" + usuarioAtual.ip();
        if (limitador.bloqueado(chave)) {
            throw new NaoAutorizadoException(429, "Muitas tentativas de login. Aguarde 15 minutos e tente de novo.");
        }
        try {
            LoginResposta r = usuarioService.login(dados.email(), dados.senha());
            limitador.limpar(chave);
            return r;
        } catch (NaoAutorizadoException e) {
            if (e.getStatus() == 401) limitador.registrarFalha(chave);
            throw e;
        }
    }

    private Map<String, Object> resposta(ContextoUsuario ctx) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("idUsuario", ctx.idUsuario());
        m.put("nome", ctx.nome());
        m.put("email", ctx.email());
        m.put("perfil", ctx.perfil());
        m.put("idResponsavel", ctx.idResponsavel());
        m.put("idProfissional", ctx.idProfissional());
        m.put("idCriancaPropria", ctx.idCriancaPropria());
        m.put("instituicoes", ctx.instituicoes());
        m.put("exigeTrocaSenha", ctx.exigeTrocaSenha());
        m.put("preferencias", preferenciasService.obter(ctx.idUsuario()));
        return m;
    }

    private ResponseCookie cookie(String valor, long segundos, HttpServletRequest req) {
        return ResponseCookie.from(FiltroAutenticacao.COOKIE, valor)
                .httpOnly(true)
                .secure(cookieSeguro || req.isSecure())
                .sameSite("Strict")
                .path("/")
                .maxAge(segundos)
                .build();
    }
}
