package br.com.ecoconnect.api.controller.saude;

import br.com.ecoconnect.api.controller.base.LeituraController;
import br.com.ecoconnect.api.dto.ValidacaoRequisicao;
import br.com.ecoconnect.api.model.entity.CriancaDiagnostico;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.saude.CriancaDiagnosticoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/** Diagnósticos das crianças. Sem DELETE (dado de saúde); use a validação REJEITADO. */
@RestController
@RequestMapping("/api/criancas-diagnosticos")
public class CriancaDiagnosticoController extends LeituraController<CriancaDiagnostico, Long> {

    private final CriancaDiagnosticoService service;

    public CriancaDiagnosticoController(CriancaDiagnosticoService service) {
        this.service = service;
    }

    @Override
    protected CrudService<CriancaDiagnostico, Long> service() {
        return service;
    }

    /** Registra a informação. Ela nasce com situacaoValidacao = DECLARADO. */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CriancaDiagnostico criar(@Valid @RequestBody CriancaDiagnostico dados) {
        return service.criar(dados);
    }

    /** Corrige um registro ainda não VALIDADO. */
    @PutMapping("/{id}")
    public CriancaDiagnostico atualizar(@PathVariable Long id, @Valid @RequestBody CriancaDiagnostico dados) {
        return service.atualizar(id, dados);
    }

    /** {"situacaoValidacao": "VALIDADO", "idUsuarioValidacao": 2} */
    @PatchMapping("/{id}/validacao")
    public CriancaDiagnostico validar(@PathVariable Long id, @Valid @RequestBody ValidacaoRequisicao dados) {
        return service.validar(id, dados.situacaoValidacao(), dados.idUsuarioValidacao());
    }
}
