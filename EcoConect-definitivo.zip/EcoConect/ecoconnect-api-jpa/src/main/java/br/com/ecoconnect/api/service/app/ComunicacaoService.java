package br.com.ecoconnect.api.service.app;

import br.com.ecoconnect.api.exception.NaoAutorizadoException;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.TipoNotificacao;
import br.com.ecoconnect.api.seguranca.ContextoAtual;
import br.com.ecoconnect.api.seguranca.ContextoUsuario;
import br.com.ecoconnect.api.seguranca.EscopoAcesso;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.NotificacaoService;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Comunicação assíncrona (preferência de muitas pessoas neurodivergentes): conversas entre
 * usuários autorizados e instituições, mensagens com situação de leitura e as notificações do usuário.
 * Somente os participantes leem uma conversa (nem o administrador lê conversas de terceiros).
 */
@Service
public class ComunicacaoService {

    private final Consultas consultas;
    private final EscopoAcesso escopo;
    private final NotificacaoService notificacaoService;
    private final AuditoriaService auditoria;

    public ComunicacaoService(Consultas consultas, EscopoAcesso escopo, NotificacaoService notificacaoService,
                              AuditoriaService auditoria) {
        this.consultas = consultas;
        this.escopo = escopo;
        this.notificacaoService = notificacaoService;
        this.auditoria = auditoria;
    }

    // ============================================================== conversas

    @Transactional(readOnly = true)
    public List<Map<String, Object>> conversas() {
        ContextoUsuario ctx = ContextoAtual.exigir();
        return consultas.lista("SELECT c.id_conversa AS idConversa, c.assunto, c.id_instituicao AS idInstituicao, i.nome AS instituicao, "
                + "c.id_crianca AS idCrianca, cr.nome_completo AS pessoa, " + Consultas.dt("COALESCE(c.data_ultima_mensagem, c.data_criacao)")
                + " AS atualizadaEm, (SELECT LEFT(m.conteudo, 140) FROM mensagem m WHERE m.id_conversa = c.id_conversa "
                + " ORDER BY m.data_envio DESC, m.id_mensagem DESC LIMIT 1) AS ultimaMensagem, "
                + "(SELECT COUNT(*) FROM mensagem m WHERE m.id_conversa = c.id_conversa AND m.id_usuario_autor <> ? "
                + " AND (p.data_ultima_leitura IS NULL OR m.data_envio > p.data_ultima_leitura)) AS naoLidas, "
                + "(SELECT GROUP_CONCAT(u.nome_completo ORDER BY u.nome_completo SEPARATOR ', ') FROM conversa_participante p2 "
                + " JOIN usuario u ON u.id_usuario = p2.id_usuario WHERE p2.id_conversa = c.id_conversa AND p2.id_usuario <> ?) AS participantes "
                + "FROM conversa c JOIN conversa_participante p ON p.id_conversa = c.id_conversa AND p.id_usuario = ? "
                + "LEFT JOIN instituicao i ON i.id_instituicao = c.id_instituicao LEFT JOIN crianca cr ON cr.id_crianca = c.id_crianca "
                + "ORDER BY COALESCE(c.data_ultima_mensagem, c.data_criacao) DESC LIMIT 200",
                ctx.idUsuario(), ctx.idUsuario(), ctx.idUsuario());
    }

    /** Abre a conversa (mensagens em ordem) e marca como lida para o usuário. */
    @Transactional
    public Map<String, Object> abrir(Long idConversa) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        exigirParticipante(idConversa, ctx.idUsuario());
        Map<String, Object> c = consultas.um("SELECT c.id_conversa AS idConversa, c.assunto, c.id_instituicao AS idInstituicao, "
                + "i.nome AS instituicao, c.id_crianca AS idCrianca, cr.nome_completo AS pessoa, " + Consultas.dt("c.data_criacao")
                + " AS dataCriacao FROM conversa c LEFT JOIN instituicao i ON i.id_instituicao = c.id_instituicao "
                + "LEFT JOIN crianca cr ON cr.id_crianca = c.id_crianca WHERE c.id_conversa = ?", idConversa);
        c.put("participantes", consultas.lista("SELECT u.id_usuario AS idUsuario, u.nome_completo AS nome, pf.nome AS perfil, "
                + Consultas.dt("p.data_ultima_leitura") + " AS ultimaLeitura FROM conversa_participante p "
                + "JOIN usuario u ON u.id_usuario = p.id_usuario JOIN perfil pf ON pf.id_perfil = u.id_perfil "
                + "WHERE p.id_conversa = ? ORDER BY u.nome_completo", idConversa));
        c.put("mensagens", consultas.lista("SELECT m.id_mensagem AS idMensagem, m.id_usuario_autor AS idAutor, u.nome_completo AS autor, "
                + "m.conteudo, " + Consultas.dt("m.data_envio") + " AS dataEnvio, (m.id_usuario_autor = ?) AS minha, "
                + "(SELECT COUNT(*) FROM conversa_participante p WHERE p.id_conversa = m.id_conversa AND p.id_usuario <> m.id_usuario_autor "
                + " AND p.data_ultima_leitura >= m.data_envio) AS lidaPor "
                + "FROM mensagem m JOIN usuario u ON u.id_usuario = m.id_usuario_autor WHERE m.id_conversa = ? "
                + "ORDER BY m.data_envio, m.id_mensagem", ctx.idUsuario(), idConversa));
        consultas.executar("UPDATE conversa_participante SET data_ultima_leitura = ? WHERE id_conversa = ? AND id_usuario = ?",
                LocalDateTime.now(), idConversa, ctx.idUsuario());
        return c;
    }

    public record NovaMensagem(String conteudo) {
    }

    @Transactional
    public Map<String, Object> enviar(Long idConversa, NovaMensagem d) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        exigirParticipante(idConversa, ctx.idUsuario());
        gravarMensagem(idConversa, ctx, d.conteudo());
        return abrir(idConversa);
    }

    public record NovaConversa(String assunto, List<Long> idsUsuarios, Long idCrianca, String mensagem) {
    }

    @Transactional
    public Map<String, Object> nova(NovaConversa d) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        String assunto = PessoasService.texto(d.assunto(), 150);
        if (assunto == null) throw new RegraNegocioException("Informe o assunto da conversa.");
        if (d.idsUsuarios() == null || d.idsUsuarios().isEmpty()) throw new RegraNegocioException("Escolha pelo menos um destinatário.");
        if (d.idCrianca() != null) escopo.exigirCrianca(d.idCrianca());
        Set<Long> permitidos = new LinkedHashSet<>();
        for (Map<String, Object> c : contatos()) permitidos.add(((Number) c.get("idUsuario")).longValue());
        Set<Long> destinos = new LinkedHashSet<>(d.idsUsuarios());
        destinos.remove(ctx.idUsuario());
        if (destinos.isEmpty()) throw new RegraNegocioException("Escolha pelo menos um destinatário diferente de você.");
        for (Long id : destinos) {
            if (!permitidos.contains(id)) throw new NaoAutorizadoException(403, "Você não pode iniciar conversa com o usuário " + id + ".");
        }
        long id = criarConversa(assunto, null, d.idCrianca(), ctx.idUsuario(), destinos);
        gravarMensagem(id, ctx, d.mensagem());
        return abrir(id);
    }

    /** Usado também pelas solicitações de atendimento. Devolve o id da conversa. */
    @Transactional
    public long criarConversa(String assunto, Long idInstituicao, Long idCrianca, Long idCriador, Set<Long> outros) {
        long id = consultas.inserir("INSERT INTO conversa (assunto, id_instituicao, id_crianca, id_usuario_criador) VALUES (?, ?, ?, ?)",
                assunto, idInstituicao, idCrianca, idCriador);
        consultas.executar("INSERT INTO conversa_participante (id_conversa, id_usuario, data_ultima_leitura) VALUES (?, ?, ?)",
                id, idCriador, LocalDateTime.now());
        for (Long u : outros) {
            if (!u.equals(idCriador)) {
                consultas.executar("INSERT INTO conversa_participante (id_conversa, id_usuario) VALUES (?, ?)", id, u);
            }
        }
        auditoria.registrarDados(AcaoAuditoria.CRIACAO, "conversa", id, idCrianca, null,
                Map.of("assunto", assunto, "participantes", outros.size() + 1));
        return id;
    }

    /** Grava a mensagem e avisa quem estava com a conversa em dia (evita uma notificação por mensagem). */
    @Transactional
    public void gravarMensagem(long idConversa, ContextoUsuario ctx, String conteudo) {
        String texto = PessoasService.texto(conteudo, 4000);
        if (texto == null) throw new RegraNegocioException("Escreva a mensagem.");
        String assunto = String.valueOf(consultas.um("SELECT assunto FROM conversa WHERE id_conversa = ?", idConversa).get("assunto"));
        List<Map<String, Object>> outros = consultas.lista("SELECT p.id_usuario AS idUsuario, "
                + "(SELECT COUNT(*) FROM mensagem m WHERE m.id_conversa = p.id_conversa AND m.id_usuario_autor <> p.id_usuario "
                + " AND (p.data_ultima_leitura IS NULL OR m.data_envio > p.data_ultima_leitura)) AS pendentes "
                + "FROM conversa_participante p WHERE p.id_conversa = ? AND p.id_usuario <> ?", idConversa, ctx.idUsuario());
        LocalDateTime agora = LocalDateTime.now();
        long id = consultas.inserir("INSERT INTO mensagem (id_conversa, id_usuario_autor, conteudo, data_envio) VALUES (?, ?, ?, ?)",
                idConversa, ctx.idUsuario(), texto, agora);
        consultas.executar("UPDATE conversa SET data_ultima_mensagem = ? WHERE id_conversa = ?", agora, idConversa);
        consultas.executar("UPDATE conversa_participante SET data_ultima_leitura = ? WHERE id_conversa = ? AND id_usuario = ?",
                agora, idConversa, ctx.idUsuario());
        for (Map<String, Object> o : outros) {
            if (((Number) o.get("pendentes")).longValue() == 0) {
                notificacaoService.notificar(((Number) o.get("idUsuario")).longValue(), TipoNotificacao.MENSAGEM,
                        "Nova mensagem: " + assunto, ctx.nome() + " enviou uma mensagem. Abra Mensagens para ler.", null, null, null);
            }
        }
        auditoria.registrarDados(AcaoAuditoria.CRIACAO, "mensagem", id, null, null, Map.of("idConversa", idConversa));
    }

    private void exigirParticipante(Long idConversa, Long idUsuario) {
        if (consultas.numero("SELECT COUNT(*) FROM conversa WHERE id_conversa = ?", idConversa) == 0) {
            throw new NaoEncontradoException("conversa", idConversa);
        }
        if (consultas.numero("SELECT COUNT(*) FROM conversa_participante WHERE id_conversa = ? AND id_usuario = ?", idConversa, idUsuario) == 0) {
            throw new NaoAutorizadoException(403, "Você não participa desta conversa.");
        }
    }

    /** Com quem o usuário pode iniciar uma conversa (de acordo com o perfil e os vínculos). */
    @Transactional(readOnly = true)
    public List<Map<String, Object>> contatos() {
        ContextoUsuario ctx = ContextoAtual.exigir();
        String base = "SELECT DISTINCT u.id_usuario AS idUsuario, u.nome_completo AS nome, pf.nome AS perfil FROM usuario u "
                + "JOIN perfil pf ON pf.id_perfil = u.id_perfil WHERE u.status = 'ATIVO' AND u.id_usuario <> ? ";
        List<Object> args = new ArrayList<>();
        args.add(ctx.idUsuario());
        StringBuilder cond = new StringBuilder();
        if (ctx.administrador()) {
            cond.append("AND 1 = 1");
        } else {
            List<Long> pessoas = new ArrayList<>(escopo.criancas());
            String in = Consultas.marcadores(pessoas);
            // administradores sempre podem ser contatados
            cond.append("AND (pf.nome = 'ADMINISTRADOR'");
            if (ctx.equipe() || ctx.familia()) {
                // equipe e família das pessoas do meu escopo
                cond.append(" OR u.id_usuario IN (SELECT p.id_usuario FROM crianca_profissional cp JOIN profissional p ")
                        .append("ON p.id_profissional = cp.id_profissional WHERE cp.status = 'ATIVO' AND cp.id_crianca IN (").append(in).append("))");
                args.addAll(pessoas);
                cond.append(" OR u.id_usuario IN (SELECT r.id_usuario FROM crianca_responsavel cr JOIN responsavel r ")
                        .append("ON r.id_responsavel = cr.id_responsavel WHERE cr.status = 'ATIVO' AND cr.id_crianca IN (").append(in).append("))");
                args.addAll(pessoas);
                cond.append(" OR u.id_usuario IN (SELECT cu.id_usuario FROM crianca_usuario cu WHERE cu.id_crianca IN (").append(in).append("))");
                args.addAll(pessoas);
                cond.append(" OR u.id_usuario IN (SELECT m.id_usuario FROM instituicao_membro m JOIN crianca_instituicao ci ")
                        .append("ON ci.id_instituicao = m.id_instituicao WHERE m.ativo = 1 AND ci.status = 'ATIVO' AND ci.id_crianca IN (")
                        .append(in).append("))");
                args.addAll(pessoas);
            }
            if (ctx.profissional()) cond.append(" OR pf.nome = 'PROFISSIONAL'");
            if (ctx.adminInstitucional() && !ctx.instituicoes().isEmpty()) {
                List<Long> inst = new ArrayList<>(ctx.instituicoes());
                String ini = Consultas.marcadores(inst);
                cond.append(" OR u.id_usuario IN (SELECT s.id_usuario_solicitante FROM solicitacao_atendimento s WHERE s.id_instituicao IN (")
                        .append(ini).append("))");
                args.addAll(inst);
                cond.append(" OR u.id_usuario IN (SELECT m.id_usuario FROM instituicao_membro m WHERE m.ativo = 1 AND m.id_instituicao IN (")
                        .append(ini).append("))");
                args.addAll(inst);
            }
            cond.append(")");
        }
        return consultas.lista(base + cond + " ORDER BY u.nome_completo LIMIT 500", args.toArray());
    }

    // ============================================================== notificações do usuário

    @Transactional(readOnly = true)
    public Map<String, Object> notificacoes(boolean somenteNaoLidas) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("itens", consultas.lista("SELECT id_notificacao AS idNotificacao, tipo_notificacao AS tipo, titulo, mensagem, "
                + "id_agendamento AS idAgendamento, id_relatorio AS idRelatorio, id_comunicado AS idComunicado, "
                + Consultas.dt("data_criacao") + " AS dataCriacao, " + Consultas.dt("data_leitura") + " AS dataLeitura "
                + "FROM notificacao WHERE id_usuario_destinatario = ?" + (somenteNaoLidas ? " AND data_leitura IS NULL" : "")
                + " ORDER BY data_criacao DESC, id_notificacao DESC LIMIT 100", ctx.idUsuario()));
        r.put("naoLidas", contarNaoLidas(ctx.idUsuario()));
        return r;
    }

    @Transactional
    public Map<String, Object> marcarLida(Long idNotificacao) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        int n = consultas.executar("UPDATE notificacao SET data_leitura = ? WHERE id_notificacao = ? AND id_usuario_destinatario = ? "
                + "AND data_leitura IS NULL", LocalDateTime.now(), idNotificacao, ctx.idUsuario());
        if (n == 0 && consultas.numero("SELECT COUNT(*) FROM notificacao WHERE id_notificacao = ? AND id_usuario_destinatario = ?",
                idNotificacao, ctx.idUsuario()) == 0) {
            throw new NaoEncontradoException("notificacao", idNotificacao);
        }
        return notificacoes(false);
    }

    @Transactional
    public Map<String, Object> marcarTodasLidas() {
        ContextoUsuario ctx = ContextoAtual.exigir();
        consultas.executar("UPDATE notificacao SET data_leitura = ? WHERE id_usuario_destinatario = ? AND data_leitura IS NULL",
                LocalDateTime.now(), ctx.idUsuario());
        return notificacoes(false);
    }

    /** Contadores para o cabeçalho (notificações e mensagens não lidas). */
    @Transactional(readOnly = true)
    public Map<String, Object> contadores() {
        ContextoUsuario ctx = ContextoAtual.exigir();
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("notificacoes", contarNaoLidas(ctx.idUsuario()));
        r.put("mensagens", consultas.numero("SELECT COUNT(*) FROM mensagem m JOIN conversa_participante p ON p.id_conversa = m.id_conversa "
                + "AND p.id_usuario = ? WHERE m.id_usuario_autor <> ? AND (p.data_ultima_leitura IS NULL OR m.data_envio > p.data_ultima_leitura)",
                ctx.idUsuario(), ctx.idUsuario()));
        return r;
    }

    private long contarNaoLidas(Long idUsuario) {
        return consultas.numero("SELECT COUNT(*) FROM notificacao WHERE id_usuario_destinatario = ? AND data_leitura IS NULL", idUsuario);
    }

    /** Avisa todos os administradores ativos (ex.: novo cadastro aguardando ativação, pedido do titular). */
    @Transactional
    public void avisarAdministradores(String titulo, String mensagem) {
        for (Long id : consultas.ids("SELECT u.id_usuario FROM usuario u JOIN perfil p ON p.id_perfil = u.id_perfil "
                + "WHERE p.nome = 'ADMINISTRADOR' AND u.status = 'ATIVO'")) {
            notificacaoService.notificar(id, TipoNotificacao.OUTRO, titulo, mensagem, null, null, null);
        }
    }
}
