package br.com.ecoconnect.api.controller.app;

import br.com.ecoconnect.api.model.entity.PreferenciaInterface;
import br.com.ecoconnect.api.seguranca.ContextoAtual;
import br.com.ecoconnect.api.service.app.ComunicacaoService;
import br.com.ecoconnect.api.service.app.PainelService;
import br.com.ecoconnect.api.service.app.PreferenciasService;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** Rotas gerais do aplicativo: painel, contadores, notificações, conversas e preferências de acessibilidade. */
@RestController
@RequestMapping("/api/app")
public class AppController {

    private final PainelService painelService;
    private final ComunicacaoService comunicacao;
    private final PreferenciasService preferencias;

    public AppController(PainelService painelService, ComunicacaoService comunicacao, PreferenciasService preferencias) {
        this.painelService = painelService;
        this.comunicacao = comunicacao;
        this.preferencias = preferencias;
    }

    @GetMapping("/painel")
    public Map<String, Object> painel() {
        return painelService.painel();
    }

    @GetMapping("/contadores")
    public Map<String, Object> contadores() {
        return comunicacao.contadores();
    }

    @GetMapping("/preferencias")
    public PreferenciaInterface preferencias() {
        return preferencias.obter(ContextoAtual.exigir().idUsuario());
    }

    @PutMapping("/preferencias")
    public PreferenciaInterface salvarPreferencias(@RequestBody PreferenciaInterface dados) {
        return preferencias.salvar(ContextoAtual.exigir().idUsuario(), dados);
    }

    @GetMapping("/notificacoes")
    public Map<String, Object> notificacoes(@RequestParam(name = "naoLidas", required = false, defaultValue = "false") boolean naoLidas) {
        return comunicacao.notificacoes(naoLidas);
    }

    @PatchMapping("/notificacoes/{id}/leitura")
    public Map<String, Object> lerNotificacao(@PathVariable("id") Long id) {
        return comunicacao.marcarLida(id);
    }

    @PostMapping("/notificacoes/leitura")
    public Map<String, Object> lerTodas() {
        return comunicacao.marcarTodasLidas();
    }

    @GetMapping("/conversas")
    public List<Map<String, Object>> conversas() {
        return comunicacao.conversas();
    }

    @PostMapping("/conversas")
    public Map<String, Object> novaConversa(@RequestBody ComunicacaoService.NovaConversa dados) {
        return comunicacao.nova(dados);
    }

    @GetMapping("/conversas/{id}")
    public Map<String, Object> conversa(@PathVariable("id") Long id) {
        return comunicacao.abrir(id);
    }

    @PostMapping("/conversas/{id}/mensagens")
    public Map<String, Object> enviar(@PathVariable("id") Long id, @RequestBody ComunicacaoService.NovaMensagem dados) {
        return comunicacao.enviar(id, dados);
    }

    @GetMapping("/contatos")
    public List<Map<String, Object>> contatos() {
        return comunicacao.contatos();
    }
}
