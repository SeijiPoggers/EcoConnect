package br.com.ecoconnect.api.model.enums;

/** Status do vínculo criança-responsável. Valores idênticos ao ENUM do MySQL. */
public enum StatusVinculo {
    ATIVO, REVOGADO
}
