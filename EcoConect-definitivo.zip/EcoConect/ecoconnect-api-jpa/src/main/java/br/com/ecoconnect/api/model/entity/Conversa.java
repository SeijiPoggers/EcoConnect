package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;

/** Tabela `conversa` (migration V2/V3). Gerada no mesmo padrão das entidades originais. */
@Entity
@Table(name = "conversa")
public class Conversa implements Entidade<Long>, PertenceACrianca {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_conversa", nullable = false)
    private Long idConversa;

    @Size(max = 150)
    @Column(name = "assunto", nullable = false, length = 150)
    private String assunto;

    @Column(name = "id_instituicao")
    private Long idInstituicao;

    @Column(name = "id_crianca")
    private Long idCrianca;

    @Column(name = "id_usuario_criador", nullable = false)
    private Long idUsuarioCriador;

    @Column(name = "data_criacao")
    private LocalDateTime dataCriacao;

    @Column(name = "data_ultima_mensagem")
    private LocalDateTime dataUltimaMensagem;

    @PrePersist
    void aoInserir() {
        if (dataCriacao == null) dataCriacao = LocalDateTime.now();
    }

    @Override
    public Long chave() {
        return idConversa;
    }

    @Override
    public void definirChave(Long id) {
        this.idConversa = id;
    }

    public Long getIdConversa() {
        return idConversa;
    }

    public void setIdConversa(Long idConversa) {
        this.idConversa = idConversa;
    }

    public String getAssunto() {
        return assunto;
    }

    public void setAssunto(String assunto) {
        this.assunto = assunto;
    }

    public Long getIdInstituicao() {
        return idInstituicao;
    }

    public void setIdInstituicao(Long idInstituicao) {
        this.idInstituicao = idInstituicao;
    }

    public Long getIdCrianca() {
        return idCrianca;
    }

    public void setIdCrianca(Long idCrianca) {
        this.idCrianca = idCrianca;
    }

    public Long getIdUsuarioCriador() {
        return idUsuarioCriador;
    }

    public void setIdUsuarioCriador(Long idUsuarioCriador) {
        this.idUsuarioCriador = idUsuarioCriador;
    }

    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDateTime dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public LocalDateTime getDataUltimaMensagem() {
        return dataUltimaMensagem;
    }

    public void setDataUltimaMensagem(LocalDateTime dataUltimaMensagem) {
        this.dataUltimaMensagem = dataUltimaMensagem;
    }
}
