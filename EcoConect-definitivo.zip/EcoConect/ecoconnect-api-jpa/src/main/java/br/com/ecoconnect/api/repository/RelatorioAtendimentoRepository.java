package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.dto.RelatorioResponsavelDTO;
import br.com.ecoconnect.api.model.entity.RelatorioAtendimento;
import br.com.ecoconnect.api.model.enums.SituacaoRelatorio;
import br.com.ecoconnect.api.model.enums.StatusVinculo;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/** Acesso à tabela `relatorio_atendimento` (Spring Data JPA). */
public interface RelatorioAtendimentoRepository extends JpaRepository<RelatorioAtendimento, Long> {

    /**
     * Equivalente à VW_RELATORIO_RESPONSAVEL da modelagem: relatórios liberados de crianças
     * com vínculo ATIVO e pode_consultar_dados = 1 para o responsável informado.
     */
    @Query("select new br.com.ecoconnect.api.dto.RelatorioResponsavelDTO("
            + "r.idRelatorio, r.idAtendimento, ag.idCrianca, r.titulo, r.conteudo, r.numeroVersao, r.dataFinalizacao) "
            + "from RelatorioAtendimento r, Atendimento t, Agendamento ag, CriancaResponsavel cr "
            + "where t.idAtendimento = r.idAtendimento and ag.idAgendamento = t.idAgendamento "
            + "and cr.idCrianca = ag.idCrianca and cr.idResponsavel = :idResponsavel "
            + "and cr.status = :statusVinculo and cr.podeConsultarDados = true and r.situacao = :situacao "
            + "order by r.dataFinalizacao desc")
    List<RelatorioResponsavelDTO> liberadosParaResponsavel(@Param("idResponsavel") Long idResponsavel,
                                                           @Param("statusVinculo") StatusVinculo statusVinculo,
                                                           @Param("situacao") SituacaoRelatorio situacao);
}
