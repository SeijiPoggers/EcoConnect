package br.com.ecoconnect.api.service.saude;

import br.com.ecoconnect.api.exception.ConflitoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Documento;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.SituacaoConferencia;
import br.com.ecoconnect.api.model.enums.SituacaoDocumento;
import br.com.ecoconnect.api.repository.DocumentoRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.Verificacoes;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * DOCUMENTO: metadados e referência privada do arquivo (chave_armazenamento, RI-06).
 * A API não recebe o arquivo em si: o front-end/serviço de arquivos guarda o arquivo e
 * informa aqui a chave. Correção por substituição; DELETE = REMOVIDO_LOGICAMENTE.
 */
@Service
public class DocumentoService extends CrudService<Documento, Long> {

    private final DocumentoRepository documentoRepository;
    private final Verificacoes verificacoes;

    public DocumentoService(DocumentoRepository repository, AuditoriaService auditoria, Verificacoes verificacoes) {
        super(repository, auditoria, "documento");
        this.documentoRepository = repository;
        this.verificacoes = verificacoes;
    }

    @Override
    protected void antesDeCriar(Documento d) {
        verificacoes.crianca(d.getIdCrianca());
        verificacoes.usuarioAtivo(d.getIdUsuarioUpload(), "Quem envia o documento");
        if (documentoRepository.existsByChaveArmazenamento(d.getChaveArmazenamento())) {
            throw new ConflitoException("Já existe um documento com esta chave de armazenamento.");
        }
        Verificacoes.naoFutura(d.getDataDocumento(), "A data do documento");
        d.setSituacaoValidacao(SituacaoConferencia.NAO_CONFERIDO);
        d.setSituacaoDocumento(SituacaoDocumento.VIGENTE);
        d.setIdDocumentoSubstituido(null);
    }

    /** Conferência pela equipe (auditoria VALIDACAO). */
    @Transactional
    public Documento conferir(Long id, SituacaoConferencia situacao, Long idUsuario) {
        Documento d = buscar(id);
        if (d.getSituacaoDocumento() != SituacaoDocumento.VIGENTE) {
            throw new RegraNegocioException("Só documentos VIGENTES podem ser conferidos.");
        }
        if (situacao == SituacaoConferencia.NAO_CONFERIDO) {
            throw new RegraNegocioException("Use CONFERIDO ou REJEITADO.");
        }
        verificacoes.usuarioDaEquipe(idUsuario, "Quem confere o documento");
        String antes = auditoria.json(d);
        d.setSituacaoValidacao(situacao);
        return salvarAlteracao(d, antes, AcaoAuditoria.VALIDACAO);
    }

    /** Envia uma nova versão: a anterior fica SUBSTITUIDO e a nova aponta para ela. */
    @Transactional
    public Documento substituir(Long id, Documento novo) {
        Documento antigo = buscar(id);
        if (antigo.getSituacaoDocumento() != SituacaoDocumento.VIGENTE) {
            throw new RegraNegocioException("Só documentos VIGENTES podem ser substituídos.");
        }
        novo.setIdCrianca(antigo.getIdCrianca());
        Documento criado = criar(novo);
        criado.setIdDocumentoSubstituido(antigo.getIdDocumento());
        criado = repository.saveAndFlush(criado);

        String antes = auditoria.json(antigo);
        antigo.setSituacaoDocumento(SituacaoDocumento.SUBSTITUIDO);
        salvarAlteracao(antigo, antes, AcaoAuditoria.ATUALIZACAO);
        return criado;
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.LOGICA;
    }

    @Override
    protected void aplicarExclusaoLogica(Documento d) {
        d.setSituacaoDocumento(SituacaoDocumento.REMOVIDO_LOGICAMENTE);
    }
}
