package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * Tabela `condicao_saude` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 */
@Entity
@Table(name = "condicao_saude")
public class CondicaoSaude implements Entidade<Long> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_condicao_saude", nullable = false)
    private Long idCondicaoSaude;

    @NotBlank(message = "campo obrigatório")
    @Size(max = 150)
    @Column(name = "nome", nullable = false, length = 150)
    private String nome;

    @Size(max = 300)
    @Column(name = "descricao", length = 300)
    private String descricao;

    @Column(name = "ativo", nullable = false)
    private Boolean ativo;

    @PrePersist
    void aoInserir() {
        if (ativo == null) {
            ativo = Boolean.TRUE;
        }
    }

    public Long getIdCondicaoSaude() {
        return idCondicaoSaude;
    }

    public void setIdCondicaoSaude(Long idCondicaoSaude) {
        this.idCondicaoSaude = idCondicaoSaude;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Boolean getAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    @Override
    public Long chave() {
        return idCondicaoSaude;
    }

    @Override
    public void definirChave(Long id) {
        this.idCondicaoSaude = id;
    }
}
