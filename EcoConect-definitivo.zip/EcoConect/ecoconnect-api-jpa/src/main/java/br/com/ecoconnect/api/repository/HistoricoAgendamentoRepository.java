package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.HistoricoAgendamento;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `historico_agendamento` (Spring Data JPA). */
public interface HistoricoAgendamentoRepository extends JpaRepository<HistoricoAgendamento, Long> {

    List<HistoricoAgendamento> findByIdAgendamentoOrderByDataHoraAlteracaoAsc(Long idAgendamento);
}
