package br.com.ecoconnect.api.service.catalogo;

import br.com.ecoconnect.api.model.entity.Diagnostico;
import br.com.ecoconnect.api.repository.DiagnosticoRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;

/** Diagnósticos reutilizáveis (catálogo). DELETE apenas desativa (ativo = 0). */
@Service
public class DiagnosticoService extends CrudService<Diagnostico, Long> {

    public DiagnosticoService(DiagnosticoRepository repository, AuditoriaService auditoria) {
        super(repository, auditoria, "diagnostico");
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.LOGICA;
    }

    @Override
    protected void aplicarExclusaoLogica(Diagnostico e) {
        e.setAtivo(false);
    }
}
