package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.Notificacao;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `notificacao` (Spring Data JPA). */
public interface NotificacaoRepository extends JpaRepository<Notificacao, Long> {
}
