package br.com.ecoconnect.api.controller.agenda;

import br.com.ecoconnect.api.controller.base.LeituraController;
import br.com.ecoconnect.api.model.entity.HistoricoAgendamento;
import br.com.ecoconnect.api.service.agenda.HistoricoAgendamentoService;
import br.com.ecoconnect.api.service.base.CrudService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Histórico de agendamentos: somente leitura (imutável). */
@RestController
@RequestMapping("/api/historicos-agendamento")
public class HistoricoAgendamentoController extends LeituraController<HistoricoAgendamento, Long> {

    private final HistoricoAgendamentoService service;

    public HistoricoAgendamentoController(HistoricoAgendamentoService service) {
        this.service = service;
    }

    @Override
    protected CrudService<HistoricoAgendamento, Long> service() {
        return service;
    }
}
