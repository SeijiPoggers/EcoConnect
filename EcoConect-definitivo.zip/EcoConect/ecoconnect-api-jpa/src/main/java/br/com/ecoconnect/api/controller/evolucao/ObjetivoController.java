package br.com.ecoconnect.api.controller.evolucao;

import br.com.ecoconnect.api.controller.base.CrudController;
import br.com.ecoconnect.api.model.entity.Objetivo;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.evolucao.ObjetivoService;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Objetivos das crianças. DELETE = CANCELADO. */
@RestController
@RequestMapping("/api/objetivos")
public class ObjetivoController extends CrudController<Objetivo, Long> {

    private final ObjetivoService service;

    public ObjetivoController(ObjetivoService service) {
        this.service = service;
    }

    @Override
    protected CrudService<Objetivo, Long> service() {
        return service;
    }

    @PatchMapping("/{id}/encerramento")
    public Objetivo encerrar(@PathVariable Long id) {
        return service.encerrarCiclo(id);
    }
}
