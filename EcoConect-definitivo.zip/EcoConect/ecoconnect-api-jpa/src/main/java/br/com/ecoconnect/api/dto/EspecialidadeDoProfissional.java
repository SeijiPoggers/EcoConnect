package br.com.ecoconnect.api.dto;

import jakarta.validation.constraints.NotNull;

public record EspecialidadeDoProfissional(
        @NotNull(message = "campo obrigatório") Integer idEspecialidade,
        Boolean principal) {
}
