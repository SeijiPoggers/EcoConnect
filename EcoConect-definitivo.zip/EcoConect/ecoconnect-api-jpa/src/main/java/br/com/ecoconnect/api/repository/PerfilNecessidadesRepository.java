package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.PerfilNecessidades;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PerfilNecessidadesRepository extends JpaRepository<PerfilNecessidades, Long> {

}
