package br.com.ecoconnect.api.controller.app;

import br.com.ecoconnect.api.model.entity.PerfilNecessidades;
import br.com.ecoconnect.api.service.app.AcompanhamentoService;
import br.com.ecoconnect.api.service.app.PessoasService;
import br.com.ecoconnect.api.service.app.RedeService;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** Pessoas acompanhadas: cadastro, perfil de necessidades, responsáveis, profissionais, instituições e trajetória. */
@RestController
@RequestMapping("/api/app/pessoas")
public class PessoasAppController {

    private final PessoasService pessoas;
    private final AcompanhamentoService acompanhamento;
    private final RedeService rede;

    public PessoasAppController(PessoasService pessoas, AcompanhamentoService acompanhamento, RedeService rede) {
        this.pessoas = pessoas;
        this.acompanhamento = acompanhamento;
        this.rede = rede;
    }

    @GetMapping
    public List<Map<String, Object>> listar(@RequestParam(name = "texto", required = false) String texto) {
        return pessoas.listar(texto);
    }

    @PostMapping
    public Map<String, Object> criar(@RequestBody PessoasService.NovaPessoa dados) {
        return pessoas.criar(dados);
    }

    @GetMapping("/{id}")
    public Map<String, Object> detalhe(@PathVariable("id") Long id) {
        return pessoas.detalhe(id);
    }

    @PutMapping("/{id}")
    public Map<String, Object> alterar(@PathVariable("id") Long id, @RequestBody PessoasService.AlteracaoPessoa dados) {
        return pessoas.alterar(id, dados);
    }

    @PutMapping("/{id}/necessidades")
    public PerfilNecessidades necessidades(@PathVariable("id") Long id, @RequestBody PerfilNecessidades dados) {
        return pessoas.salvarNecessidades(id, dados);
    }

    @PostMapping("/{id}/responsaveis")
    public Map<String, Object> vincularResponsavel(@PathVariable("id") Long id, @RequestBody PessoasService.NovoResponsavel dados) {
        return pessoas.vincularResponsavel(id, dados);
    }

    @DeleteMapping("/{id}/responsaveis/{idVinculo}")
    public Map<String, Object> revogarResponsavel(@PathVariable("id") Long id, @PathVariable("idVinculo") Long idVinculo) {
        return pessoas.revogarResponsavel(id, idVinculo);
    }

    @PostMapping("/{id}/profissionais")
    public Map<String, Object> autorizarProfissional(@PathVariable("id") Long id, @RequestBody PessoasService.NovaAutorizacao dados) {
        return pessoas.autorizarProfissional(id, dados);
    }

    @DeleteMapping("/{id}/profissionais/{idProfissional}")
    public Map<String, Object> encerrarAutorizacao(@PathVariable("id") Long id, @PathVariable("idProfissional") Long idProfissional) {
        return pessoas.encerrarAutorizacao(id, idProfissional);
    }

    @GetMapping("/{id}/historico-alteracoes")
    public List<Map<String, Object>> historico(@PathVariable("id") Long id) {
        return pessoas.historicoAlteracoes(id);
    }

    @GetMapping("/{id}/trajetoria")
    public Map<String, Object> trajetoria(@PathVariable("id") Long id) {
        return acompanhamento.trajetoria(id);
    }

    @GetMapping("/{id}/sessoes")
    public List<Map<String, Object>> sessoes(@PathVariable("id") Long id) {
        return acompanhamento.sessoesDaPessoa(id);
    }

    @GetMapping("/{id}/instituicoes")
    public List<Map<String, Object>> instituicoes(@PathVariable("id") Long id) {
        return rede.vinculosDaPessoa(id);
    }

    @PostMapping("/{id}/instituicoes")
    public List<Map<String, Object>> vincularInstituicao(@PathVariable("id") Long id, @RequestBody RedeService.NovoVinculo dados) {
        return rede.vincular(id, dados);
    }

    @DeleteMapping("/{id}/instituicoes/{idVinculo}")
    public List<Map<String, Object>> encerrarVinculo(@PathVariable("id") Long id, @PathVariable("idVinculo") Long idVinculo) {
        return rede.encerrarVinculo(id, idVinculo);
    }
}
