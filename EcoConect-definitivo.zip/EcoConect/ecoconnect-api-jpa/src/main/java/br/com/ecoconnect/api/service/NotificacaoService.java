package br.com.ecoconnect.api.service;

import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Notificacao;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.TipoNotificacao;
import br.com.ecoconnect.api.repository.NotificacaoRepository;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

/** NOTIFICACAO: aviso individual a um usuário. Não é alterada nem excluída; só marcada como lida. */
@Service
public class NotificacaoService extends CrudService<Notificacao, Long> {

    private final Verificacoes verificacoes;

    public NotificacaoService(NotificacaoRepository repository, AuditoriaService auditoria, Verificacoes verificacoes) {
        super(repository, auditoria, "notificacao");
        this.verificacoes = verificacoes;
    }

    @Override
    protected void antesDeCriar(Notificacao n) {
        verificacoes.usuario(n.getIdUsuarioDestinatario());
        int origens = (n.getIdComunicado() != null ? 1 : 0) + (n.getIdAgendamento() != null ? 1 : 0)
                + (n.getIdRelatorio() != null ? 1 : 0);
        if (origens > 1) {
            throw new RegraNegocioException("A notificação pode apontar para no máximo uma origem (comunicado, agendamento ou relatório).");
        }
        n.setDataLeitura(null);
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.PROIBIDA;
    }

    /** Usado pelos outros services para avisar um usuário. */
    @Transactional
    public Notificacao notificar(Long idUsuario, TipoNotificacao tipo, String titulo, String mensagem,
                                 Long idComunicado, Long idAgendamento, Long idRelatorio) {
        Notificacao n = new Notificacao();
        n.setIdUsuarioDestinatario(idUsuario);
        n.setTipoNotificacao(tipo);
        n.setTitulo(cortar(titulo, 150));
        n.setMensagem(cortar(mensagem, 500));
        n.setIdComunicado(idComunicado);
        n.setIdAgendamento(idAgendamento);
        n.setIdRelatorio(idRelatorio);
        return repository.save(n);
    }

    @Transactional
    public Notificacao marcarComoLida(Long id) {
        Notificacao n = buscar(id);
        if (n.getDataLeitura() != null) return n;
        String antes = auditoria.json(n);
        n.setDataLeitura(LocalDateTime.now());
        return salvarAlteracao(n, antes, AcaoAuditoria.ATUALIZACAO);
    }

    private static String cortar(String s, int max) {
        return s == null || s.length() <= max ? s : s.substring(0, max);
    }
}
