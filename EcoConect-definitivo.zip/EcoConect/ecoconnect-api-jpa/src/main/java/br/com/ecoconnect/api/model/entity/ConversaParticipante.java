package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import java.time.LocalDateTime;

/** Tabela `conversa_participante` (migration V2/V3). Gerada no mesmo padrão das entidades originais. */
@Entity
@Table(name = "conversa_participante")
public class ConversaParticipante implements Entidade<Long> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_participante", nullable = false)
    private Long idParticipante;

    @Column(name = "id_conversa", nullable = false)
    private Long idConversa;

    @Column(name = "id_usuario", nullable = false)
    private Long idUsuario;

    @Column(name = "data_entrada")
    private LocalDateTime dataEntrada;

    @Column(name = "data_ultima_leitura")
    private LocalDateTime dataUltimaLeitura;

    @PrePersist
    void aoInserir() {
        if (dataEntrada == null) dataEntrada = LocalDateTime.now();
    }

    @Override
    public Long chave() {
        return idParticipante;
    }

    @Override
    public void definirChave(Long id) {
        this.idParticipante = id;
    }

    public Long getIdParticipante() {
        return idParticipante;
    }

    public void setIdParticipante(Long idParticipante) {
        this.idParticipante = idParticipante;
    }

    public Long getIdConversa() {
        return idConversa;
    }

    public void setIdConversa(Long idConversa) {
        this.idConversa = idConversa;
    }

    public Long getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public LocalDateTime getDataEntrada() {
        return dataEntrada;
    }

    public void setDataEntrada(LocalDateTime dataEntrada) {
        this.dataEntrada = dataEntrada;
    }

    public LocalDateTime getDataUltimaLeitura() {
        return dataUltimaLeitura;
    }

    public void setDataUltimaLeitura(LocalDateTime dataUltimaLeitura) {
        this.dataUltimaLeitura = dataUltimaLeitura;
    }
}
