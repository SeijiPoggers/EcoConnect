package br.com.ecoconnect.api.service.app;

import br.com.ecoconnect.api.exception.NaoAutorizadoException;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Consentimento;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.TipoNotificacao;
import br.com.ecoconnect.api.seguranca.ContextoAtual;
import br.com.ecoconnect.api.seguranca.ContextoUsuario;
import br.com.ecoconnect.api.seguranca.SessaoService;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.NotificacaoService;
import br.com.ecoconnect.api.service.saude.ConsentimentoService;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Direitos do titular (LGPD, art. 18): ver e exportar os próprios dados, revogar consentimentos e
 * pedir correção ou exclusão. O atendimento dos pedidos é feito pelo administrador. Dados de saúde
 * não são apagados fisicamente (guarda obrigatória do histórico, regra RI-20); a conta pode ser anonimizada.
 */
@Service
public class PrivacidadeService {

    private static final Set<String> TIPOS = Set.of("ACESSO", "CORRECAO", "EXCLUSAO", "PORTABILIDADE", "REVOGACAO_CONSENTIMENTO", "OUTRA");

    private final Consultas consultas;
    private final ConsentimentoService consentimentoService;
    private final ComunicacaoService comunicacao;
    private final NotificacaoService notificacaoService;
    private final SessaoService sessaoService;
    private final AuditoriaService auditoria;

    public PrivacidadeService(Consultas consultas, ConsentimentoService consentimentoService, ComunicacaoService comunicacao,
                              NotificacaoService notificacaoService, SessaoService sessaoService, AuditoriaService auditoria) {
        this.consultas = consultas;
        this.consentimentoService = consentimentoService;
        this.comunicacao = comunicacao;
        this.notificacaoService = notificacaoService;
        this.sessaoService = sessaoService;
        this.auditoria = auditoria;
    }

    @Transactional(readOnly = true)
    public Map<String, Object> resumo() {
        ContextoUsuario ctx = ContextoAtual.exigir();
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("conta", conta(ctx.idUsuario()));
        r.put("consentimentos", ctx.idResponsavel() == null ? List.of() : consultas.lista("SELECT co.id_consentimento AS idConsentimento, "
                + "c.nome_completo AS pessoa, co.finalidade, co.versao_termo AS versaoTermo, co.situacao_autorizacao AS situacao, "
                + Consultas.dt("co.data_autorizacao") + " AS dataAutorizacao, " + Consultas.dt("co.data_revogacao") + " AS dataRevogacao "
                + "FROM consentimento co JOIN crianca c ON c.id_crianca = co.id_crianca WHERE co.id_responsavel = ? "
                + "ORDER BY co.data_autorizacao DESC", ctx.idResponsavel()));
        r.put("pedidos", consultas.lista("SELECT id_solicitacao_titular AS id, tipo, detalhe, situacao, resposta, "
                + Consultas.dt("data_criacao") + " AS dataCriacao, " + Consultas.dt("data_resposta") + " AS dataResposta "
                + "FROM solicitacao_titular WHERE id_usuario = ? ORDER BY data_criacao DESC", ctx.idUsuario()));
        r.put("informacoes", List.of(
                "Coletamos apenas os dados necessários para o acompanhamento e para a conexão com a rede de apoio.",
                "Dados de saúde são dados pessoais sensíveis: só a equipe autorizada e a família vinculada têm acesso.",
                "Cada consulta ou alteração de dados sensíveis fica registrada na auditoria.",
                "O EcoConect não vende dados e não exibe anúncios.",
                "O histórico de saúde é guardado mesmo após um pedido de exclusão, pelo dever legal de guarda; "
                        + "nesse caso a conta é anonimizada e o acesso é encerrado."));
        return r;
    }

    private Map<String, Object> conta(Long idUsuario) {
        return consultas.um("SELECT u.id_usuario AS idUsuario, u.nome_completo AS nome, u.email, u.telefone, p.nome AS perfil, u.status, "
                + Consultas.dt("u.data_cadastro") + " AS dataCadastro, " + Consultas.dt("u.data_ultimo_acesso") + " AS ultimoAcesso "
                + "FROM usuario u JOIN perfil p ON p.id_perfil = u.id_perfil WHERE u.id_usuario = ?", idUsuario);
    }

    /** Portabilidade/acesso: todos os dados pessoais do usuário em um JSON. */
    @Transactional(readOnly = true)
    public Map<String, Object> exportar() {
        ContextoUsuario ctx = ContextoAtual.exigir();
        Long id = ctx.idUsuario();
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("geradoEm", LocalDateTime.now().withNano(0).toString());
        r.put("observacao", "Exportação dos dados pessoais do titular (LGPD, art. 18, II e V).");
        r.put("conta", conta(id));
        r.put("preferenciasDeAcessibilidade", consultas.um("SELECT baixo_estimulo AS baixoEstimulo, tamanho_fonte AS tamanhoFonte, "
                + "alto_contraste AS altoContraste, espacamento_leitura AS espacamentoLeitura, reduzir_movimento AS reduzirMovimento "
                + "FROM preferencia_interface WHERE id_usuario = ?", id));
        r.put("acessos", consultas.lista("SELECT " + Consultas.dt("data_criacao") + " AS inicio, " + Consultas.dt("data_ultimo_uso")
                + " AS ultimoUso, ip_origem AS ip, agente_usuario AS navegador, (data_revogacao IS NOT NULL) AS encerrada "
                + "FROM sessao_usuario WHERE id_usuario = ? ORDER BY data_criacao DESC LIMIT 100", id));
        List<Long> pessoas = new ArrayList<>();
        if (ctx.idResponsavel() != null) {
            r.put("cadastroDeResponsavel", consultas.um("SELECT id_responsavel AS idResponsavel, cpf FROM responsavel WHERE id_responsavel = ?",
                    ctx.idResponsavel()));
            pessoas.addAll(consultas.ids("SELECT id_crianca FROM crianca_responsavel WHERE id_responsavel = ? AND status = 'ATIVO' "
                    + "AND pode_consultar_dados = 1", ctx.idResponsavel()));
        }
        if (ctx.idCriancaPropria() != null) pessoas.add(ctx.idCriancaPropria());
        List<Map<String, Object>> dadosPessoas = new ArrayList<>();
        for (Long c : pessoas) {
            Map<String, Object> p = new LinkedHashMap<>();
            p.put("pessoa", consultas.um("SELECT id_crianca AS idCrianca, nome_completo AS nome, " + Consultas.d("data_nascimento")
                    + " AS dataNascimento, sexo, cpf, situacao_ecocura AS situacao FROM crianca WHERE id_crianca = ?", c));
            p.put("perfilDeNecessidades", consultas.um("SELECT condicoes_informadas AS condicoes, necessidades_acompanhamento AS necessidades, "
                    + "preferencias_sensoriais AS sensorial, comunicacao_preferida AS comunicacao, necessidades_acessibilidade AS acessibilidade, "
                    + "municipio, uf FROM perfil_necessidades WHERE id_crianca = ?", c));
            p.put("agendamentos", consultas.lista("SELECT " + Consultas.dt("COALESCE(data_hora_inicio, data_hora_inicio_solicitada)")
                    + " AS data, status FROM agendamento WHERE id_crianca = ? ORDER BY data", c));
            p.put("sessoes", consultas.lista("SELECT " + Consultas.dt("t.data_hora_inicio_real") + " AS data, rs.tipo_atendimento AS tipo "
                    + "FROM atendimento t JOIN agendamento a ON a.id_agendamento = t.id_agendamento LEFT JOIN registro_sessao rs "
                    + "ON rs.id_atendimento = t.id_atendimento WHERE a.id_crianca = ? ORDER BY data", c));
            p.put("relatoriosLiberados", consultas.lista("SELECT r.titulo, r.conteudo, " + Consultas.dt("r.data_finalizacao") + " AS data "
                    + "FROM relatorio_atendimento r JOIN atendimento t ON t.id_atendimento = r.id_atendimento JOIN agendamento a "
                    + "ON a.id_agendamento = t.id_agendamento WHERE a.id_crianca = ? AND r.situacao = 'LIBERADO_RESPONSAVEL'", c));
            p.put("instituicoes", consultas.lista("SELECT i.nome, ci.status, " + Consultas.d("ci.data_inicio") + " AS desde "
                    + "FROM crianca_instituicao ci JOIN instituicao i ON i.id_instituicao = ci.id_instituicao WHERE ci.id_crianca = ?", c));
            dadosPessoas.add(p);
        }
        r.put("pessoasAcompanhadas", dadosPessoas);
        r.put("solicitacoesDeAtendimento", consultas.lista("SELECT i.nome AS instituicao, s.mensagem, s.situacao, s.resposta, "
                + Consultas.dt("s.data_criacao") + " AS data FROM solicitacao_atendimento s JOIN instituicao i ON i.id_instituicao = s.id_instituicao "
                + "WHERE s.id_usuario_solicitante = ? ORDER BY s.data_criacao", id));
        r.put("mensagensEnviadas", consultas.lista("SELECT c.assunto, m.conteudo, " + Consultas.dt("m.data_envio") + " AS data FROM mensagem m "
                + "JOIN conversa c ON c.id_conversa = m.id_conversa WHERE m.id_usuario_autor = ? ORDER BY m.data_envio", id));
        r.put("notificacoes", consultas.lista("SELECT titulo, mensagem, " + Consultas.dt("data_criacao") + " AS data FROM notificacao "
                + "WHERE id_usuario_destinatario = ? ORDER BY data_criacao DESC LIMIT 200", id));
        r.put("pedidosDePrivacidade", consultas.lista("SELECT tipo, detalhe, situacao, resposta, " + Consultas.dt("data_criacao")
                + " AS data FROM solicitacao_titular WHERE id_usuario = ?", id));
        auditoria.registrarDados(AcaoAuditoria.CONSULTA, "usuario", id, null, null, Map.of("exportacao", "dados do titular"));
        return r;
    }

    public record NovoPedido(String tipo, String detalhe) {
    }

    @Transactional
    public Map<String, Object> solicitar(NovoPedido d) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        String tipo = d.tipo() == null ? "" : d.tipo().trim().toUpperCase();
        if (!TIPOS.contains(tipo)) throw new RegraNegocioException("Tipo de pedido inválido.");
        if (consultas.numero("SELECT COUNT(*) FROM solicitacao_titular WHERE id_usuario = ? AND tipo = ? AND situacao IN ('ABERTA','EM_ANALISE')",
                ctx.idUsuario(), tipo) > 0) {
            throw new RegraNegocioException("Você já tem um pedido deste tipo em andamento.");
        }
        long id = consultas.inserir("INSERT INTO solicitacao_titular (id_usuario, tipo, detalhe) VALUES (?, ?, ?)", ctx.idUsuario(), tipo,
                PessoasService.texto(d.detalhe(), 1000));
        auditoria.registrarDados(AcaoAuditoria.CRIACAO, "solicitacao_titular", id, null, null, Map.of("tipo", tipo));
        comunicacao.avisarAdministradores("Pedido de privacidade (LGPD)", ctx.nome() + " registrou um pedido do tipo " + tipo
                + ". Responda em Administração > Privacidade.");
        return resumo();
    }

    @Transactional
    public Map<String, Object> revogarConsentimento(Long idConsentimento) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        Consentimento c = consentimentoService.buscar(idConsentimento);
        if (ctx.idResponsavel() == null || !ctx.idResponsavel().equals(c.getIdResponsavel())) {
            throw new NaoAutorizadoException(403, "Somente o responsável que autorizou pode revogar este consentimento.");
        }
        consentimentoService.revogar(idConsentimento);
        comunicacao.avisarAdministradores("Consentimento revogado", ctx.nome() + " revogou um consentimento. Avalie a base legal do tratamento.");
        return resumo();
    }

    // ============================================================== atendimento pelo administrador

    @Transactional(readOnly = true)
    public List<Map<String, Object>> pedidos(String situacao) {
        exigirAdministrador();
        String filtro = RedeService.vazio(situacao) == null ? "" : " WHERE s.situacao = ?";
        Object[] args = filtro.isEmpty() ? new Object[0] : new Object[]{situacao.trim().toUpperCase()};
        return consultas.lista("SELECT s.id_solicitacao_titular AS id, s.id_usuario AS idUsuario, u.nome_completo AS titular, u.email, "
                + "s.tipo, s.detalhe, s.situacao, s.resposta, ur.nome_completo AS respondidoPor, " + Consultas.dt("s.data_criacao")
                + " AS dataCriacao, " + Consultas.dt("s.data_resposta") + " AS dataResposta FROM solicitacao_titular s "
                + "JOIN usuario u ON u.id_usuario = s.id_usuario LEFT JOIN usuario ur ON ur.id_usuario = s.id_usuario_resposta" + filtro
                + " ORDER BY FIELD(s.situacao,'ABERTA','EM_ANALISE','ATENDIDA','RECUSADA'), s.data_criacao", args);
    }

    public record RespostaPedido(String situacao, String resposta, Boolean anonimizarConta) {
    }

    @Transactional
    public List<Map<String, Object>> responder(Long id, RespostaPedido d) {
        ContextoUsuario ctx = exigirAdministrador();
        Map<String, Object> p = consultas.um("SELECT id_usuario AS idUsuario, tipo, situacao FROM solicitacao_titular WHERE id_solicitacao_titular = ?", id);
        if (p == null) throw new NaoEncontradoException("solicitacao_titular", id);
        String nova = d.situacao() == null ? "" : d.situacao().trim().toUpperCase();
        if (!Set.of("EM_ANALISE", "ATENDIDA", "RECUSADA").contains(nova)) throw new RegraNegocioException("Situação inválida.");
        if (Set.of("ATENDIDA", "RECUSADA").contains(String.valueOf(p.get("situacao")))) throw new RegraNegocioException("Pedido já encerrado.");
        String texto = PessoasService.texto(d.resposta(), 1000);
        if (!"EM_ANALISE".equals(nova) && texto == null) throw new RegraNegocioException("Escreva a resposta ao titular.");
        Long titular = ((Number) p.get("idUsuario")).longValue();
        if (Boolean.TRUE.equals(d.anonimizarConta())) {
            if (!"EXCLUSAO".equals(p.get("tipo")) || !"ATENDIDA".equals(nova)) {
                throw new RegraNegocioException("A anonimização só é feita ao atender um pedido de EXCLUSAO.");
            }
            if (titular.equals(ctx.idUsuario())) throw new RegraNegocioException("Você não pode anonimizar a própria conta.");
            anonimizar(titular);
        }
        consultas.executar("UPDATE solicitacao_titular SET situacao = ?, resposta = COALESCE(?, resposta), id_usuario_resposta = ?, "
                + "data_resposta = ? WHERE id_solicitacao_titular = ?", nova, texto, ctx.idUsuario(), LocalDateTime.now(), id);
        auditoria.registrarDados(AcaoAuditoria.ATUALIZACAO, "solicitacao_titular", id, null, p, Map.of("situacao", nova));
        if (!Boolean.TRUE.equals(d.anonimizarConta())) {
            notificacaoService.notificar(titular, TipoNotificacao.OUTRO, "Seu pedido de privacidade foi atualizado",
                    "Situação: " + nova + (texto == null ? "" : ". " + texto), null, null, null);
        }
        return pedidos(null);
    }

    /** Remove os dados de identificação da conta e encerra o acesso. Registros de saúde são mantidos (dever de guarda). */
    private void anonimizar(Long idUsuario) {
        Map<String, Object> antes = conta(idUsuario);
        consultas.executar("UPDATE usuario SET nome_completo = ?, email = ?, telefone = NULL, status = 'INATIVO' WHERE id_usuario = ?",
                "Titular anonimizado " + idUsuario, "anonimizado-" + idUsuario + "@ecoconect.invalid", idUsuario);
        consultas.executar("UPDATE responsavel SET cpf = NULL WHERE id_usuario = ?", idUsuario);
        consultas.executar("DELETE FROM preferencia_interface WHERE id_usuario = ?", idUsuario);
        sessaoService.revogarTodas(idUsuario, null);
        auditoria.registrarDados(AcaoAuditoria.EXCLUSAO_LOGICA, "usuario", idUsuario, null, antes, Map.of("anonimizado", true));
    }

    private ContextoUsuario exigirAdministrador() {
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (!ctx.administrador()) throw new NaoAutorizadoException(403, "Somente o administrador atende pedidos de privacidade.");
        return ctx;
    }
}
