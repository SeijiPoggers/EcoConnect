package br.com.ecoconnect.api.model.entity;

import br.com.ecoconnect.api.model.enums.StatusAgendamento;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;

/**
 * Tabela `historico_agendamento` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 */
@Entity
@Table(name = "historico_agendamento")
public class HistoricoAgendamento implements Entidade<Long> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_historico_agendamento", nullable = false)
    private Long idHistoricoAgendamento;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_agendamento", nullable = false)
    private Long idAgendamento;

    @Enumerated(EnumType.STRING)
    @Column(name = "status_anterior")
    private StatusAgendamento statusAnterior;

    @NotNull(message = "campo obrigatório")
    @Enumerated(EnumType.STRING)
    @Column(name = "status_novo", nullable = false)
    private StatusAgendamento statusNovo;

    @Column(name = "data_hora_inicio_anterior")
    private LocalDateTime dataHoraInicioAnterior;

    @Column(name = "data_hora_inicio_novo")
    private LocalDateTime dataHoraInicioNovo;

    @Size(max = 500)
    @Column(name = "motivo", length = 500)
    private String motivo;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_usuario", nullable = false)
    private Long idUsuario;

    @Column(name = "data_hora_alteracao", nullable = false)
    private LocalDateTime dataHoraAlteracao;

    @PrePersist
    void aoInserir() {
        if (dataHoraAlteracao == null) {
            dataHoraAlteracao = LocalDateTime.now();
        }
    }

    public Long getIdHistoricoAgendamento() {
        return idHistoricoAgendamento;
    }

    public void setIdHistoricoAgendamento(Long idHistoricoAgendamento) {
        this.idHistoricoAgendamento = idHistoricoAgendamento;
    }

    public Long getIdAgendamento() {
        return idAgendamento;
    }

    public void setIdAgendamento(Long idAgendamento) {
        this.idAgendamento = idAgendamento;
    }

    public StatusAgendamento getStatusAnterior() {
        return statusAnterior;
    }

    public void setStatusAnterior(StatusAgendamento statusAnterior) {
        this.statusAnterior = statusAnterior;
    }

    public StatusAgendamento getStatusNovo() {
        return statusNovo;
    }

    public void setStatusNovo(StatusAgendamento statusNovo) {
        this.statusNovo = statusNovo;
    }

    public LocalDateTime getDataHoraInicioAnterior() {
        return dataHoraInicioAnterior;
    }

    public void setDataHoraInicioAnterior(LocalDateTime dataHoraInicioAnterior) {
        this.dataHoraInicioAnterior = dataHoraInicioAnterior;
    }

    public LocalDateTime getDataHoraInicioNovo() {
        return dataHoraInicioNovo;
    }

    public void setDataHoraInicioNovo(LocalDateTime dataHoraInicioNovo) {
        this.dataHoraInicioNovo = dataHoraInicioNovo;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public Long getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public LocalDateTime getDataHoraAlteracao() {
        return dataHoraAlteracao;
    }

    public void setDataHoraAlteracao(LocalDateTime dataHoraAlteracao) {
        this.dataHoraAlteracao = dataHoraAlteracao;
    }

    @Override
    public Long chave() {
        return idHistoricoAgendamento;
    }

    @Override
    public void definirChave(Long id) {
        this.idHistoricoAgendamento = id;
    }
}
