package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import java.time.LocalDateTime;

/** Tabela `crianca_usuario` (migration V2/V3). Gerada no mesmo padrão das entidades originais. */
@Entity
@Table(name = "crianca_usuario")
public class CriancaUsuario implements Entidade<Long>, PertenceACrianca {

    @Id
    @Column(name = "id_crianca", nullable = false)
    private Long idCrianca;

    @Column(name = "id_usuario", nullable = false)
    private Long idUsuario;

    @Column(name = "data_vinculo")
    private LocalDateTime dataVinculo;

    @PrePersist
    void aoInserir() {
        if (dataVinculo == null) dataVinculo = LocalDateTime.now();
    }

    @Override
    public Long chave() {
        return idCrianca;
    }

    @Override
    public void definirChave(Long id) {
        this.idCrianca = id;
    }

    public Long getIdCrianca() {
        return idCrianca;
    }

    public void setIdCrianca(Long idCrianca) {
        this.idCrianca = idCrianca;
    }

    public Long getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public LocalDateTime getDataVinculo() {
        return dataVinculo;
    }

    public void setDataVinculo(LocalDateTime dataVinculo) {
        this.dataVinculo = dataVinculo;
    }
}
