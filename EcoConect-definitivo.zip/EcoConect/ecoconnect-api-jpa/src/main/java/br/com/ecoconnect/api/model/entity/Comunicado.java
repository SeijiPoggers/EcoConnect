package br.com.ecoconnect.api.model.entity;

import br.com.ecoconnect.api.model.enums.AbrangenciaComunicado;
import br.com.ecoconnect.api.model.enums.SituacaoComunicado;
import br.com.ecoconnect.api.model.enums.TipoComunicado;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;

/**
 * Tabela `comunicado` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 */
@Entity
@Table(name = "comunicado")
public class Comunicado implements Entidade<Long> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_comunicado", nullable = false)
    private Long idComunicado;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_usuario_criador", nullable = false)
    private Long idUsuarioCriador;

    @NotBlank(message = "campo obrigatório")
    @Size(max = 150)
    @Column(name = "titulo", nullable = false, length = 150)
    private String titulo;

    @NotBlank(message = "campo obrigatório")
    @Column(name = "mensagem", nullable = false, columnDefinition = "text")
    private String mensagem;

    @NotNull(message = "campo obrigatório")
    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_comunicado", nullable = false)
    private TipoComunicado tipoComunicado;

    @NotNull(message = "campo obrigatório")
    @Enumerated(EnumType.STRING)
    @Column(name = "abrangencia", nullable = false)
    private AbrangenciaComunicado abrangencia;

    @Size(max = 100)
    @Column(name = "descricao_grupo", length = 100)
    private String descricaoGrupo;

    @Enumerated(EnumType.STRING)
    @Column(name = "situacao", nullable = false)
    private SituacaoComunicado situacao;

    @Column(name = "data_criacao", nullable = false)
    private LocalDateTime dataCriacao;

    @Column(name = "data_publicacao")
    private LocalDateTime dataPublicacao;

    @PrePersist
    void aoInserir() {
        if (situacao == null) {
            situacao = SituacaoComunicado.RASCUNHO;
        }
        if (dataCriacao == null) {
            dataCriacao = LocalDateTime.now();
        }
    }

    public Long getIdComunicado() {
        return idComunicado;
    }

    public void setIdComunicado(Long idComunicado) {
        this.idComunicado = idComunicado;
    }

    public Long getIdUsuarioCriador() {
        return idUsuarioCriador;
    }

    public void setIdUsuarioCriador(Long idUsuarioCriador) {
        this.idUsuarioCriador = idUsuarioCriador;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public TipoComunicado getTipoComunicado() {
        return tipoComunicado;
    }

    public void setTipoComunicado(TipoComunicado tipoComunicado) {
        this.tipoComunicado = tipoComunicado;
    }

    public AbrangenciaComunicado getAbrangencia() {
        return abrangencia;
    }

    public void setAbrangencia(AbrangenciaComunicado abrangencia) {
        this.abrangencia = abrangencia;
    }

    public String getDescricaoGrupo() {
        return descricaoGrupo;
    }

    public void setDescricaoGrupo(String descricaoGrupo) {
        this.descricaoGrupo = descricaoGrupo;
    }

    public SituacaoComunicado getSituacao() {
        return situacao;
    }

    public void setSituacao(SituacaoComunicado situacao) {
        this.situacao = situacao;
    }

    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDateTime dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public LocalDateTime getDataPublicacao() {
        return dataPublicacao;
    }

    public void setDataPublicacao(LocalDateTime dataPublicacao) {
        this.dataPublicacao = dataPublicacao;
    }

    @Override
    public Long chave() {
        return idComunicado;
    }

    @Override
    public void definirChave(Long id) {
        this.idComunicado = id;
    }
}
