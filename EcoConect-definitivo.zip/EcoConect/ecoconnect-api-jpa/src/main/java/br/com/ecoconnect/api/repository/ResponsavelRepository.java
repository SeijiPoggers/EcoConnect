package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.Responsavel;
import br.com.ecoconnect.api.model.enums.StatusUsuario;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/** Acesso à tabela `responsavel` (Spring Data JPA). */
public interface ResponsavelRepository extends JpaRepository<Responsavel, Long> {

    Optional<Responsavel> findByIdUsuario(Long idUsuario);
    boolean existsByIdUsuario(Long idUsuario);

    /** Responsáveis cujo usuário está no status informado (ex.: ATIVO), para comunicados "TODOS". */
    @Query("select r from Responsavel r, Usuario u where u.idUsuario = r.idUsuario and u.status = :status")
    List<Responsavel> comUsuarioNoStatus(@Param("status") StatusUsuario status);
}
