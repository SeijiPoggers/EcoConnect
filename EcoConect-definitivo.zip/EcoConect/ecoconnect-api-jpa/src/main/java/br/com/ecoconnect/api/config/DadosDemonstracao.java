package br.com.ecoconnect.api.config;

import br.com.ecoconnect.api.service.app.Consultas;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Ao subir (depois das migrations e do administrador inicial):
 *  1. CATÁLOGOS BÁSICOS (sempre, só se a tabela estiver vazia): especialidades, atividades terapêuticas,
 *     indicadores, condições de saúde e diagnósticos de referência (CID-10). Não são dados de pessoas.
 *  2. DADOS DE DEMONSTRAÇÃO (somente com ecoconnect.demo.dados=true e banco sem pessoas e sem instituições):
 *     pessoas, famílias, profissionais e instituições FICTÍCIOS, todos listados em registro_demonstracao
 *     e com e-mails do domínio inexistente demo.ecoconect.local. Nunca use dados reais aqui.
 */
@Component
@Order(20)
public class DadosDemonstracao implements CommandLineRunner {

    public static final String SENHA_DEMO = "EcoDemo2026";
    private static final Logger log = LoggerFactory.getLogger(DadosDemonstracao.class);

    private final Consultas db;
    private final PasswordEncoder passwordEncoder;

    @Value("${ecoconnect.demo.dados:false}")
    private boolean carregarDemonstracao;

    public DadosDemonstracao(Consultas db, PasswordEncoder passwordEncoder) {
        this.db = db;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public void run(String... args) {
        catalogos();
        if (!carregarDemonstracao) return;
        if (db.numero("SELECT COUNT(*) FROM crianca") > 0 || db.numero("SELECT COUNT(*) FROM instituicao") > 0
                || db.numero("SELECT COUNT(*) FROM registro_demonstracao") > 0) {
            return;
        }
        demonstracao();
        log.info("Dados FICTÍCIOS de demonstração carregados. Senha das contas *@demo.ecoconect.local: {}", SENHA_DEMO);
    }

    // ============================================================== catálogos de referência

    private void catalogos() {
        if (db.numero("SELECT COUNT(*) FROM especialidade") == 0) {
            for (String[] e : new String[][]{{"Psicologia", "Avaliação e acompanhamento psicológico"},
                    {"Fonoaudiologia", "Linguagem, fala e comunicação"}, {"Terapia Ocupacional", "Autonomia, rotina e integração sensorial"},
                    {"Fisioterapia", "Desenvolvimento motor e postura"}, {"Psicopedagogia", "Aprendizagem e estratégias escolares"},
                    {"Equoterapia", "Terapia com cavalos, abordagem interdisciplinar"}, {"Neuropediatria", "Neurologia infantil"},
                    {"Psiquiatria", "Psiquiatria da infância e de adultos"}, {"Serviço Social", "Direitos, benefícios e rede de proteção"}}) {
                db.executar("INSERT INTO especialidade (nome, descricao) VALUES (?, ?)", e[0], e[1]);
            }
        }
        if (db.numero("SELECT COUNT(*) FROM atividade") == 0) {
            for (String[] a : new String[][]{{"Montaria terapêutica", "Atividade de equoterapia com o cavalo"},
                    {"Integração sensorial", "Atividades de regulação e integração sensorial"},
                    {"Treino de habilidades sociais", "Interação, turnos e cooperação"},
                    {"Comunicação alternativa", "Uso de pranchas, figuras e comunicação aumentativa"},
                    {"Atividade lúdica dirigida", "Brincadeira com objetivo terapêutico"},
                    {"Organização da rotina", "Agenda visual, planejamento e funções executivas"},
                    {"Leitura e escrita assistidas", "Estratégias para dislexia e leitura funcional"},
                    {"Orientação à família", "Conversa e combinados com a família"}}) {
                db.executar("INSERT INTO atividade (nome, descricao, ativo) VALUES (?, ?, 1)", a[0], a[1]);
            }
        }
        if (db.numero("SELECT COUNT(*) FROM indicador") == 0) {
            db.executar("INSERT INTO indicador (nome, descricao, tipo_medida, unidade_medida, ativo) VALUES (?, ?, 'NUMERICA', ?, 1)",
                    "Pedidos espontâneos por sessão", "Quantas vezes a pessoa fez pedidos por iniciativa própria", "pedidos");
            db.executar("INSERT INTO indicador (nome, descricao, tipo_medida, unidade_medida, ativo) VALUES (?, ?, 'NUMERICA', ?, 1)",
                    "Tempo de atenção sustentada", "Minutos em uma atividade sem interrupção", "minutos");
            db.executar("INSERT INTO indicador (nome, descricao, tipo_medida, unidade_medida, ativo) VALUES (?, ?, 'NUMERICA', ?, 1)",
                    "Equilíbrio postural", "Escala de 0 a 10 observada na montaria", "pontos (0-10)");
            db.executar("INSERT INTO indicador (nome, descricao, tipo_medida, unidade_medida, ativo) VALUES (?, ?, 'QUALITATIVA', NULL, 1)",
                    "Tolerância a mudanças na rotina", "Como a pessoa reage a mudanças combinadas");
            db.executar("INSERT INTO indicador (nome, descricao, tipo_medida, unidade_medida, ativo) VALUES (?, ?, 'QUALITATIVA', NULL, 1)",
                    "Interação com os pares", "Qualidade da interação com outras pessoas");
        }
        if (db.numero("SELECT COUNT(*) FROM condicao_saude") == 0) {
            for (String c : List.of("Transtorno do Espectro Autista (TEA)", "Transtorno do Déficit de Atenção com Hiperatividade (TDAH)",
                    "Dislexia", "Discalculia", "Deficiência intelectual", "Transtorno do Processamento Sensorial")) {
                db.executar("INSERT INTO condicao_saude (nome, ativo) VALUES (?, 1)", c);
            }
        }
        if (db.numero("SELECT COUNT(*) FROM diagnostico") == 0) {
            for (String[] d : new String[][]{{"F84.0", "Autismo infantil"}, {"F84.1", "Autismo atípico"}, {"F84.5", "Síndrome de Asperger"},
                    {"F90.0", "Distúrbios da atividade e da atenção (TDAH)"}, {"F81.0", "Transtorno específico de leitura (dislexia)"},
                    {"F81.2", "Transtorno específico da habilidade em aritmética"}, {"F70", "Retardo mental leve (deficiência intelectual leve)"}}) {
                db.executar("INSERT INTO diagnostico (codigo_cid, nome, ativo) VALUES (?, ?, 1)", d[0], d[1]);
            }
        }
    }

    // ============================================================== demonstração (dados fictícios)

    private void demonstracao() {
        LocalDate hoje = LocalDate.now();
        LocalDateTime agora = LocalDateTime.now();

        long ana = usuario("PROFISSIONAL", "Ana Paula Ribeiro", "ana.ribeiro@demo.ecoconect.local", "(15) 90000-0001");
        long carlos = usuario("PROFISSIONAL", "Carlos Henrique Souza", "carlos.souza@demo.ecoconect.local", "(15) 90000-0002");
        long mariana = usuario("RESPONSAVEL", "Mariana Alves", "mariana.alves@demo.ecoconect.local", "(15) 90000-0003");
        long paulo = usuario("RESPONSAVEL", "Paulo Costa", "paulo.costa@demo.ecoconect.local", "(15) 90000-0004");
        long lucasConta = usuario("PESSOA_ACOMPANHADA", "Lucas Martins", "lucas.martins@demo.ecoconect.local", null);
        long roberta = usuario("ADMIN_INSTITUCIONAL", "Roberta Lima", "roberta.lima@demo.ecoconect.local", "(15) 90000-0005");

        long pAna = inserir("profissional", "INSERT INTO profissional (id_usuario, conselho_profissional, registro_profissional, ativo) VALUES (?, 'CRP', '06/DEMO-001', 1)", ana);
        long pCarlos = inserir("profissional", "INSERT INTO profissional (id_usuario, conselho_profissional, registro_profissional, ativo) VALUES (?, 'CRFa', '2/DEMO-002', 1)", carlos);
        especialidade(pAna, "Psicologia", true);
        especialidade(pAna, "Equoterapia", false);
        especialidade(pCarlos, "Fonoaudiologia", true);
        long rMariana = inserir("responsavel", "INSERT INTO responsavel (id_usuario) VALUES (?)", mariana);
        long rPaulo = inserir("responsavel", "INSERT INTO responsavel (id_usuario) VALUES (?)", paulo);

        // pessoas acompanhadas (fictícias; inspiradas nas personas do projeto)
        long theo = inserir("crianca", "INSERT INTO crianca (nome_completo, data_nascimento, sexo, data_ingresso_ecocura, situacao_ecocura, data_atualizacao) "
                + "VALUES ('Theo Alves', ?, 'M', ?, 'ATIVA', ?)", hoje.minusYears(6).minusMonths(4), hoje.minusMonths(3), agora);
        long lucas = inserir("crianca", "INSERT INTO crianca (nome_completo, data_nascimento, sexo, data_ingresso_ecocura, situacao_ecocura, data_atualizacao) "
                + "VALUES ('Lucas Martins', ?, 'M', ?, 'ATIVA', ?)", hoje.minusYears(23).minusMonths(2), hoje.minusMonths(1), agora);
        long helena = inserir("crianca", "INSERT INTO crianca (nome_completo, data_nascimento, sexo, situacao_ecocura, data_atualizacao) "
                + "VALUES ('Helena Costa', ?, 'F', 'AGUARDANDO_VAGA', ?)", hoje.minusYears(9).minusMonths(7), agora);
        db.executar("INSERT INTO crianca_usuario (id_crianca, id_usuario) VALUES (?, ?)", lucas, lucasConta);
        marcar("crianca_usuario", lucas);

        inserir("crianca_responsavel", "INSERT INTO crianca_responsavel (id_crianca, id_responsavel, parentesco, responsavel_principal, "
                + "pode_consultar_dados, pode_solicitar_agendamento, status, data_inicio, id_usuario_cadastro) VALUES (?, ?, 'Mãe', 1, 1, 1, 'ATIVO', ?, ?)",
                theo, rMariana, hoje.minusMonths(3), mariana);
        inserir("crianca_responsavel", "INSERT INTO crianca_responsavel (id_crianca, id_responsavel, parentesco, responsavel_principal, "
                + "pode_consultar_dados, pode_solicitar_agendamento, status, data_inicio, id_usuario_cadastro) VALUES (?, ?, 'Pai', 1, 1, 1, 'ATIVO', ?, ?)",
                helena, rPaulo, hoje.minusWeeks(3), paulo);
        for (long[] c : new long[][]{{theo, rMariana, mariana}, {helena, rPaulo, paulo}}) {
            inserir("consentimento", "INSERT INTO consentimento (id_crianca, id_responsavel, finalidade, versao_termo, situacao_autorizacao, "
                    + "data_autorizacao, id_usuario_registro) VALUES (?, ?, ?, 'EcoConect-1.0', 'REGISTRADA', ?, ?)", c[0], c[1],
                    "Cadastro e acompanhamento da pessoa na plataforma EcoConect, incluindo dados de saúde necessários ao cuidado.",
                    agora.minusWeeks(3), c[2]);
        }
        inserir("crianca_profissional", "INSERT INTO crianca_profissional (id_crianca, id_profissional, funcao, status, data_inicio, id_usuario_cadastro) "
                + "VALUES (?, ?, 'Psicóloga de referência', 'ATIVO', ?, ?)", theo, pAna, hoje.minusMonths(3), ana);
        inserir("crianca_profissional", "INSERT INTO crianca_profissional (id_crianca, id_profissional, funcao, status, data_inicio, id_usuario_cadastro) "
                + "VALUES (?, ?, 'Fonoaudiólogo', 'ATIVO', ?, ?)", theo, pCarlos, hoje.minusMonths(2), ana);
        inserir("crianca_profissional", "INSERT INTO crianca_profissional (id_crianca, id_profissional, funcao, status, data_inicio, id_usuario_cadastro) "
                + "VALUES (?, ?, 'Psicóloga', 'ATIVO', ?, ?)", lucas, pAna, hoje.minusMonths(1), ana);

        necessidades(theo, "TEA", "Comunicação funcional, regulação sensorial e preparação para a escola.", "SENSIVEL_A_SONS,PREFERE_AMBIENTES_CALMOS",
                "Fica desconfortável com barulho de secador e com muitas pessoas falando ao mesmo tempo.", "VISUAL",
                "BAIXO_ESTIMULO,ANTECIPACAO_DA_ROTINA", "Sorocaba", "SP", true, "PRESENCIAL", mariana);
        necessidades(lucas, "TDAH,DISLEXIA", "Organização dos estudos e laudo para adaptações na faculdade.", "SENSIVEL_A_LUZ", null, "ESCRITA",
                "COMUNICACAO_ESCRITA,HORARIOS_FLEXIVEIS", "Sorocaba", "SP", true, "ONLINE", lucasConta);
        necessidades(helena, "TEA,TDAH", "Avaliação multiprofissional e apoio escolar.", "BUSCA_ESTIMULO_SENSORIAL", null, "FALADA",
                "ANTECIPACAO_DA_ROTINA", "Sorocaba", "SP", true, "PRESENCIAL", paulo);

        // instituições (fictícias)
        long equo = instituicao("Centro de Equoterapia Passo a Passo", "FILANTROPICA", "Atendimento interdisciplinar com equoterapia para crianças e adolescentes.",
                "Sorocaba", "Jardim Exemplo", 3, 17, "TEA,TDAH,DEFICIENCIA_INTELECTUAL", "PRESENCIAL", "BAIXO_ESTIMULO,ANTECIPACAO_DA_ROTINA,ACESSIBILIDADE_FISICA",
                true, false, 4, true);
        long assoc = instituicao("Associação Mãos que Acolhem", "ASSOCIACAO", "Grupo de apoio e orientação para famílias de pessoas autistas.",
                "Sorocaba", "Centro", null, null, "TEA", "PRESENCIAL,ONLINE", "COMUNICACAO_ESCRITA,HORARIOS_FLEXIVEIS", true, false, null, true);
        long clinEscola = instituicao("Clínica-Escola de Psicologia Universitária", "CLINICA_ESCOLA",
                "Atendimento psicológico e avaliação feitos por estudantes supervisionados.", "Sorocaba", "Vila Universitária", 6, 60,
                "TEA,TDAH,DISLEXIA", "PRESENCIAL", "COMUNICACAO_ESCRITA", true, false, 0, true);
        long integrar = instituicao("Espaço Integrar Terapias", "PRIVADA", "Fonoaudiologia e terapia ocupacional com sala de integração sensorial.",
                "Votorantim", "Centro", 2, 12, "TEA,TDAH", "PRESENCIAL", "SALA_SENSORIAL,BAIXO_ESTIMULO", false, false, 2, false);
        long nucleo = instituicao("Núcleo Adulto Neurodivergente", "ONG", "Grupos on-line e acolhimento para adultos com diagnóstico tardio.",
                "São Paulo", "Bela Vista", 18, 99, "TDAH,TEA,DISLEXIA", "ONLINE", "COMUNICACAO_ESCRITA,HORARIOS_FLEXIVEIS", true, false, 15, true);
        servico(equo, "Equoterapia infantil", "EQUOTERAPIA", true);
        servico(equo, "Acompanhamento psicológico", "PSICOLOGIA", true);
        servico(equo, "Orientação às famílias", "ORIENTACAO_FAMILIAR", true);
        servico(assoc, "Roda de conversa de famílias", "GRUPO_DE_APOIO", true);
        servico(assoc, "Orientação sobre direitos", "ORIENTACAO_FAMILIAR", true);
        servico(clinEscola, "Avaliação psicológica", "AVALIACAO_DIAGNOSTICA", true);
        servico(clinEscola, "Psicopedagogia", "PSICOPEDAGOGIA", true);
        servico(integrar, "Fonoaudiologia", "FONOAUDIOLOGIA", false);
        servico(integrar, "Terapia ocupacional", "TERAPIA_OCUPACIONAL", false);
        servico(nucleo, "Grupo on-line de adultos com TDAH", "GRUPO_DE_APOIO", true);
        servico(nucleo, "Acolhimento psicológico", "PSICOLOGIA", true);
        inserir("instituicao_membro", "INSERT INTO instituicao_membro (id_instituicao, id_usuario, papel, ativo) VALUES (?, ?, 'ADMIN_INSTITUCIONAL', 1)", equo, roberta);
        inserir("instituicao_membro", "INSERT INTO instituicao_membro (id_instituicao, id_usuario, papel, ativo) VALUES (?, ?, 'PROFISSIONAL', 1)", equo, ana);

        // agenda e sessões do Theo
        long atividadeMontaria = db.numero("SELECT id_atividade FROM atividade WHERE nome = 'Montaria terapêutica'");
        long atividadeComunicacao = db.numero("SELECT id_atividade FROM atividade WHERE nome = 'Comunicação alternativa'");
        long[] sessoesTheo = new long[3];
        for (int i = 0; i < 3; i++) {
            LocalDateTime inicio = hoje.minusDays(21 - 7L * i).atTime(14, 0);
            long ag = agendamento(theo, mariana, inicio, "REALIZADO", ana, pAna);
            long at = inserir("atendimento", "INSERT INTO atendimento (id_agendamento, status_agendamento_ref, data_hora_inicio_real, data_hora_fim_real, "
                    + "observacoes_gerais, id_usuario_registro) VALUES (?, 'REALIZADO', ?, ?, ?, ?)", ag, inicio, inicio.plusMinutes(50),
                    "Sessão realizada conforme o planejado.", ana);
            db.executar("INSERT INTO atendimento_profissional (id_atendimento, id_profissional, funcao_no_atendimento) VALUES (?, ?, 'Responsável pela sessão')", at, pAna);
            marcar("atendimento_profissional", at + "-" + pAna);
            db.executar("INSERT INTO atendimento_atividade (id_atendimento, id_atividade, duracao_minutos, observacao) VALUES (?, ?, 30, NULL)", at, atividadeMontaria);
            db.executar("INSERT INTO atendimento_atividade (id_atendimento, id_atividade, duracao_minutos, observacao) VALUES (?, ?, 15, NULL)", at, atividadeComunicacao);
            marcar("atendimento_atividade", at + "-*");
            String[] evolucao = {"Aceitou o capacete com apoio da agenda visual; fez 1 pedido espontâneo.",
                    "Antecipou as etapas olhando a agenda visual; fez 2 pedidos espontâneos.",
                    "Montou com menos apoio e fez 3 pedidos espontâneos usando figuras."};
            db.executar("INSERT INTO registro_sessao (id_atendimento, tipo_atendimento, objetivos_trabalhados, evolucao_observada, dificuldades_observadas, "
                    + "recomendacoes, proximos_passos, id_usuario_registro) VALUES (?, 'Equoterapia', ?, ?, ?, ?, ?, ?)", at,
                    "Comunicação funcional e regulação sensorial.", evolucao[i], i == 0 ? "Desconforto com o barulho do pátio no início." : null,
                    "Manter a agenda visual em casa antes das sessões.", "Introduzir o pedido de troca de atividade.", ana);
            marcar("registro_sessao", at);
            sessoesTheo[i] = at;
        }
        long relatorio = inserir("relatorio_atendimento", "INSERT INTO relatorio_atendimento (id_atendimento, id_profissional_autor, titulo, conteudo, situacao, "
                + "numero_versao, data_finalizacao) VALUES (?, ?, ?, ?, 'LIBERADO_RESPONSAVEL', 1, ?)", sessoesTheo[2], pAna,
                "Resumo do primeiro mês de acompanhamento",
                "Theo está se adaptando bem à rotina das sessões. A agenda visual ajuda a antecipar as etapas e reduziu o desconforto "
                        + "no início. Os pedidos espontâneos aumentaram de 1 para 3 por sessão. Sugerimos manter a agenda visual em casa.",
                agora.minusDays(6));
        agendamento(theo, mariana, hoje.plusDays(2).atTime(14, 0), "CONFIRMADO", ana, pAna);
        agendamento(theo, mariana, hoje.plusDays(9).atTime(14, 0), "CONFIRMADO", ana, pAna);
        agendamento(theo, mariana, hoje.plusDays(4).atTime(10, 0), "SOLICITADO", null, pCarlos);

        long objetivo = inserir("objetivo", "INSERT INTO objetivo (id_crianca, id_profissional_definidor, titulo, descricao, data_inicio, data_prevista_fim, situacao) "
                + "VALUES (?, ?, 'Ampliar a comunicação funcional', 'Fazer pedidos por iniciativa própria usando figuras ou palavras.', ?, ?, 'EM_ANDAMENTO')",
                theo, pAna, hoje.minusDays(25), hoje.plusMonths(4));
        long indPedidos = db.numero("SELECT id_indicador FROM indicador WHERE nome = 'Pedidos espontâneos por sessão'");
        db.executar("INSERT INTO objetivo_indicador (id_objetivo, id_indicador, valor_referencia_inicial, meta_valor, descricao_meta) VALUES (?, ?, 1, 5, ?)",
                objetivo, indPedidos, "Chegar a 5 pedidos espontâneos por sessão");
        marcar("objetivo_indicador", objetivo + "-" + indPedidos);
        for (int i = 0; i < 3; i++) {
            inserir("avaliacao_indicador", "INSERT INTO avaliacao_indicador (id_objetivo, id_indicador, id_profissional_avaliador, id_atendimento, data_avaliacao, "
                    + "valor_numerico, situacao) VALUES (?, ?, ?, ?, ?, ?, 'VIGENTE')", objetivo, indPedidos, pAna, sessoesTheo[i],
                    hoje.minusDays(21 - 7L * i), i + 1);
        }

        // Lucas: uma sessão on-line realizada e uma confirmada
        LocalDateTime inicioLucas = hoje.minusDays(5).atTime(19, 0);
        long agLucas = agendamento(lucas, lucasConta, inicioLucas, "REALIZADO", ana, pAna);
        long atLucas = inserir("atendimento", "INSERT INTO atendimento (id_agendamento, status_agendamento_ref, data_hora_inicio_real, data_hora_fim_real, "
                + "id_usuario_registro) VALUES (?, 'REALIZADO', ?, ?, ?)", agLucas, inicioLucas, inicioLucas.plusMinutes(50), ana);
        db.executar("INSERT INTO atendimento_profissional (id_atendimento, id_profissional) VALUES (?, ?)", atLucas, pAna);
        marcar("atendimento_profissional", atLucas + "-" + pAna);
        db.executar("INSERT INTO registro_sessao (id_atendimento, tipo_atendimento, objetivos_trabalhados, evolucao_observada, recomendacoes, proximos_passos, "
                + "id_usuario_registro) VALUES (?, 'Psicoterapia on-line', ?, ?, ?, ?, ?)", atLucas, "Organização da rotina de estudos.",
                "Montou um quadro semanal com blocos de 25 minutos e pausas.", "Usar o leitor de tela para textos longos.",
                "Revisar o quadro na próxima sessão.", ana);
        marcar("registro_sessao", atLucas);
        agendamento(lucas, lucasConta, hoje.plusDays(3).atTime(19, 0), "CONFIRMADO", ana, pAna);

        // solicitações a instituições, vínculo e conversas
        long conversaTheo = conversa("Solicitação de atendimento - Centro de Equoterapia Passo a Passo", equo, theo, mariana, roberta);
        mensagem(conversaTheo, mariana, agora.minusDays(30), "Olá! Meu filho Theo tem 6 anos e é autista. Gostaria de saber se há vaga para equoterapia.");
        mensagem(conversaTheo, roberta, agora.minusDays(29), "Olá, Mariana! Temos vaga às quintas à tarde. Vamos agendar uma avaliação inicial.");
        mensagem(conversaTheo, roberta, agora.minusDays(29).plusMinutes(5), "Situação da solicitação: Aceita. Bem-vindos ao Passo a Passo!");
        long solTheo = inserir("solicitacao_atendimento", "INSERT INTO solicitacao_atendimento (id_instituicao, id_crianca, id_usuario_solicitante, mensagem, "
                + "forma_contato, situacao, resposta, id_usuario_resposta, data_resposta, id_conversa, data_criacao) VALUES (?, ?, ?, ?, "
                + "'MENSAGEM_NA_PLATAFORMA', 'ACEITA', ?, ?, ?, ?, ?)", equo, theo, mariana,
                "Meu filho Theo tem 6 anos e é autista. Gostaria de saber se há vaga para equoterapia.",
                "Temos vaga às quintas à tarde. Bem-vindos!", roberta, agora.minusDays(29), conversaTheo, agora.minusDays(30));
        inserir("crianca_instituicao", "INSERT INTO crianca_instituicao (id_crianca, id_instituicao, origem, id_solicitacao, status, data_inicio, id_usuario_cadastro) "
                + "VALUES (?, ?, 'SOLICITACAO', ?, 'ATIVO', ?, ?)", theo, equo, solTheo, hoje.minusDays(29), roberta);
        long conversaHelena = conversa("Solicitação de atendimento - Centro de Equoterapia Passo a Passo", equo, helena, paulo, roberta);
        mensagem(conversaHelena, paulo, agora.minusDays(2), "Boa tarde. A Helena tem 9 anos e está aguardando avaliação. Vocês atendem crianças com TEA e TDAH?");
        inserir("solicitacao_atendimento", "INSERT INTO solicitacao_atendimento (id_instituicao, id_crianca, id_usuario_solicitante, mensagem, forma_contato, "
                + "situacao, id_conversa, data_criacao) VALUES (?, ?, ?, ?, 'MENSAGEM_NA_PLATAFORMA', 'ENVIADA', ?, ?)", equo, helena, paulo,
                "A Helena tem 9 anos e está aguardando avaliação. Vocês atendem crianças com TEA e TDAH?", conversaHelena, agora.minusDays(2));
        long conversaEquipe = conversa("Combinados para as próximas sessões do Theo", null, theo, ana, mariana);
        mensagem(conversaEquipe, ana, agora.minusDays(6), "Mariana, liberei o resumo do primeiro mês. Se puder, use a agenda visual antes de sairem de casa.");
        mensagem(conversaEquipe, mariana, agora.minusDays(5), "Obrigada, Ana! Vou imprimir as figuras hoje.");

        notificacao(mariana, "RELATORIO_LIBERADO", "Relatório liberado", "O relatório \"Resumo do primeiro mês de acompanhamento\" do Theo está disponível.", null, relatorio);
        notificacao(roberta, "SOLICITACAO", "Nova solicitação de atendimento", "Paulo Costa enviou uma solicitação para Centro de Equoterapia Passo a Passo.", null, null);

        // estabelecimentos do SUS FICTÍCIOS (para testar sem o arquivo do CNES)
        estabelecimento("9990001", "UBS Exemplo Jardim das Flores (fictícia)", "UBS", "Rua Exemplo", "100", "Jardim das Flores");
        estabelecimento("9990002", "UBS Exemplo Vila Nova (fictícia)", "UBS", "Avenida Modelo", "250", "Vila Nova");
        estabelecimento("9990003", "CAPS Infantojuvenil Exemplo (fictício)", "CAPS_INFANTIL", "Rua Demonstração", "45", "Centro");
        estabelecimento("9990004", "CAPS II Exemplo (fictício)", "CAPS", "Rua Ilustrativa", "12", "Centro");
        estabelecimento("9990005", "CER II Exemplo (fictício)", "CER", "Avenida Teste", "800", "Além Ponte");
        estabelecimento("9990006", "Policlínica Municipal Exemplo (fictícia)", "POLICLINICA", "Praça Simulada", "1", "Centro");
    }

    // ============================================================== auxiliares

    private long usuario(String perfil, String nome, String email, String telefone) {
        long idPerfil = db.numero("SELECT id_perfil FROM perfil WHERE nome = ?", perfil);
        return inserir("usuario", "INSERT INTO usuario (id_perfil, nome_completo, email, telefone, senha_hash, status, exige_troca_senha) "
                + "VALUES (?, ?, ?, ?, ?, 'ATIVO', 0)", idPerfil, nome, email, telefone, passwordEncoder.encode(SENHA_DEMO));
    }

    private void especialidade(long idProfissional, String nome, boolean principal) {
        long id = db.numero("SELECT id_especialidade FROM especialidade WHERE nome = ?", nome);
        if (id == 0) return;
        db.executar("INSERT INTO profissional_especialidade (id_profissional, id_especialidade, principal) VALUES (?, ?, ?)", idProfissional, id, principal);
        marcar("profissional_especialidade", idProfissional + "-" + id);
    }

    private void necessidades(long crianca, String condicoes, String necessidades, String sensorial, String obsSensorial, String comunicacao,
                              String acessibilidade, String municipio, String uf, boolean gratuito, String modalidade, long usuario) {
        db.executar("INSERT INTO perfil_necessidades (id_crianca, condicoes_informadas, necessidades_acompanhamento, preferencias_sensoriais, "
                + "observacoes_sensoriais, comunicacao_preferida, necessidades_acessibilidade, municipio, uf, somente_gratuito, modalidade_preferida, "
                + "id_usuario_atualizacao) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", crianca, condicoes, necessidades, sensorial, obsSensorial,
                comunicacao, acessibilidade, municipio, uf, gratuito, modalidade, usuario);
        marcar("perfil_necessidades", crianca);
    }

    private long instituicao(String nome, String tipo, String descricao, String municipio, String bairro, Integer idadeMin, Integer idadeMax,
                             String condicoes, String modalidades, String acessibilidade, boolean gratuito, boolean sus, Integer vagas, boolean verificada) {
        return inserir("instituicao", "INSERT INTO instituicao (nome, tipo, descricao, email, telefone, logradouro, numero, bairro, municipio, uf, "
                + "idade_minima, idade_maxima, condicoes_atendidas, modalidades, recursos_acessibilidade, atendimento_gratuito, atende_pelo_sus, "
                + "vagas_disponiveis, aceita_solicitacoes, verificada, ativa, dados_demonstracao) VALUES (?, ?, ?, ?, ?, 'Rua Fictícia', 'S/N', ?, ?, 'SP', "
                + "?, ?, ?, ?, ?, ?, ?, ?, 1, ?, 1, 1)", nome, tipo, descricao,
                "contato@" + nome.toLowerCase().replaceAll("[^a-z]+", "") + ".demo.ecoconect.local", "(15) 3000-0000", bairro, municipio,
                idadeMin, idadeMax, condicoes, modalidades, acessibilidade, gratuito, sus, vagas, verificada);
    }

    private void servico(long instituicao, String nome, String tipo, boolean gratuito) {
        inserir("instituicao_servico", "INSERT INTO instituicao_servico (id_instituicao, nome, tipo_servico, gratuito, ativo) VALUES (?, ?, ?, ?, 1)",
                instituicao, nome, tipo, gratuito);
    }

    private long agendamento(long crianca, long solicitante, LocalDateTime inicio, String status, Long confirmador, long profissional) {
        boolean confirmado = !"SOLICITADO".equals(status);
        long id = inserir("agendamento", "INSERT INTO agendamento (id_crianca, id_usuario_solicitante, data_hora_inicio_solicitada, data_hora_fim_solicitada, "
                + "status, data_hora_inicio, data_hora_fim, id_usuario_confirmacao, data_confirmacao) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", crianca, solicitante,
                inicio, inicio.plusMinutes(50), status, confirmado ? inicio : null, confirmado ? inicio.plusMinutes(50) : null,
                confirmado ? confirmador : null, confirmado ? inicio.minusDays(3) : null);
        db.executar("INSERT INTO agendamento_profissional (id_agendamento, id_profissional, id_usuario_designacao) VALUES (?, ?, ?)", id, profissional,
                confirmador != null ? confirmador : solicitante);
        marcar("agendamento_profissional", id + "-" + profissional);
        db.executar("INSERT INTO historico_agendamento (id_agendamento, status_anterior, status_novo, data_hora_inicio_novo, motivo, id_usuario) "
                + "VALUES (?, NULL, ?, ?, 'Carga de demonstração', ?)", id, status, confirmado ? inicio : null, confirmador != null ? confirmador : solicitante);
        marcar("historico_agendamento", id + "-*");
        return id;
    }

    private long conversa(String assunto, Long instituicao, long crianca, long criador, long outro) {
        long id = inserir("conversa", "INSERT INTO conversa (assunto, id_instituicao, id_crianca, id_usuario_criador) VALUES (?, ?, ?, ?)",
                assunto, instituicao, crianca, criador);
        inserir("conversa_participante", "INSERT INTO conversa_participante (id_conversa, id_usuario, data_ultima_leitura) VALUES (?, ?, NULL)", id, criador);
        inserir("conversa_participante", "INSERT INTO conversa_participante (id_conversa, id_usuario, data_ultima_leitura) VALUES (?, ?, NULL)", id, outro);
        return id;
    }

    private void mensagem(long conversa, long autor, LocalDateTime quando, String texto) {
        inserir("mensagem", "INSERT INTO mensagem (id_conversa, id_usuario_autor, conteudo, data_envio) VALUES (?, ?, ?, ?)", conversa, autor, texto, quando);
        db.executar("UPDATE conversa SET data_ultima_mensagem = ? WHERE id_conversa = ?", quando, conversa);
        db.executar("UPDATE conversa_participante SET data_ultima_leitura = ? WHERE id_conversa = ? AND id_usuario = ?", quando, conversa, autor);
    }

    private void notificacao(long usuario, String tipo, String titulo, String texto, Long agendamento, Long relatorio) {
        inserir("notificacao", "INSERT INTO notificacao (id_usuario_destinatario, tipo_notificacao, titulo, mensagem, id_agendamento, id_relatorio) "
                + "VALUES (?, ?, ?, ?, ?, ?)", usuario, tipo, titulo, texto, agendamento, relatorio);
    }

    private void estabelecimento(String cnes, String nome, String categoria, String logradouro, String numero, String bairro) {
        db.executar("INSERT INTO estabelecimento_sus (codigo_cnes, nome, categoria, codigo_municipio, municipio, uf, logradouro, numero, bairro, "
                + "telefone, fonte) VALUES (?, ?, ?, '355220', 'Sorocaba', 'SP', ?, ?, ?, '(15) 3000-0000', 'DEMONSTRACAO')",
                cnes, nome, categoria, logradouro, numero, bairro);
        marcar("estabelecimento_sus", cnes);
    }

    private long inserir(String tabela, String sql, Object... args) {
        long id = db.inserir(sql, args);
        marcar(tabela, id);
        return id;
    }

    private void marcar(String tabela, Object id) {
        db.executar("INSERT IGNORE INTO registro_demonstracao (tabela, id_registro) VALUES (?, ?)", tabela, String.valueOf(id));
    }

    /** Resumo usado pelo README e pela tela de login (somente quando a demonstração está carregada). */
    public static Map<String, String> contas() {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("ana.ribeiro@demo.ecoconect.local", "Profissional (psicóloga)");
        m.put("carlos.souza@demo.ecoconect.local", "Profissional (fonoaudiólogo)");
        m.put("mariana.alves@demo.ecoconect.local", "Responsável (mãe do Theo)");
        m.put("paulo.costa@demo.ecoconect.local", "Responsável (pai da Helena)");
        m.put("lucas.martins@demo.ecoconect.local", "Pessoa acompanhada (adulto)");
        m.put("roberta.lima@demo.ecoconect.local", "Administradora institucional");
        return m;
    }
}
