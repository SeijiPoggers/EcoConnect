package br.com.ecoconnect.api.dominio;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Vocabulários controlados guardados como texto separado por vírgula
 * (condições, recursos de acessibilidade, modalidades, preferências sensoriais).
 * Os rótulos são exibidos na interface e usados nas explicações das recomendações.
 */
public final class Codigos {

    public static final Map<String, String> CONDICOES = mapa(
            "TEA", "Transtorno do Espectro Autista (TEA)",
            "TDAH", "Transtorno do Déficit de Atenção com Hiperatividade (TDAH)",
            "DISLEXIA", "Dislexia",
            "DISCALCULIA", "Discalculia",
            "DEFICIENCIA_INTELECTUAL", "Deficiência intelectual",
            "TOD", "Transtorno Opositor Desafiador (TOD)",
            "SINDROME_DE_TOURETTE", "Síndrome de Tourette",
            "ALTAS_HABILIDADES", "Altas habilidades / superdotação",
            "OUTRAS", "Outras condições do neurodesenvolvimento");

    public static final Map<String, String> ACESSIBILIDADE = mapa(
            "BAIXO_ESTIMULO", "Ambiente de baixo estímulo",
            "SALA_SENSORIAL", "Sala de integração sensorial",
            "COMUNICACAO_ESCRITA", "Contato por mensagem escrita",
            "COMUNICACAO_ALTERNATIVA", "Comunicação alternativa (CAA)",
            "LIBRAS", "Atendimento em Libras",
            "ACESSIBILIDADE_FISICA", "Acessibilidade física",
            "HORARIOS_FLEXIVEIS", "Horários flexíveis",
            "ANTECIPACAO_DA_ROTINA", "Antecipação da rotina (o que vai acontecer na sessão)");

    public static final Map<String, String> SENSORIAL = mapa(
            "SENSIVEL_A_SONS", "Sensível a sons",
            "SENSIVEL_A_LUZ", "Sensível a luz",
            "SENSIVEL_AO_TOQUE", "Sensível ao toque",
            "PREFERE_AMBIENTES_CALMOS", "Prefere ambientes calmos",
            "BUSCA_ESTIMULO_SENSORIAL", "Busca estímulos sensoriais");

    public static final Map<String, String> MODALIDADES = mapa(
            "PRESENCIAL", "Presencial",
            "ONLINE", "On-line",
            "DOMICILIAR", "No domicílio");

    private Codigos() {
    }

    private static Map<String, String> mapa(String... pares) {
        Map<String, String> m = new java.util.LinkedHashMap<>();
        for (int i = 0; i < pares.length; i += 2) m.put(pares[i], pares[i + 1]);
        return java.util.Collections.unmodifiableMap(m);
    }

    /** "TEA, tdah ,TEA" -> {TEA, TDAH} (mantém a ordem e remove repetidos/vazios). */
    public static Set<String> lista(String texto) {
        if (texto == null || texto.isBlank()) return Set.of();
        return Arrays.stream(texto.split(","))
                .map(s -> s.trim().toUpperCase(Locale.ROOT))
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toCollection(LinkedHashSet::new));
    }

    /** Valida contra o vocabulário e devolve o texto normalizado (ou null se vazio). */
    public static String normalizar(String texto, Map<String, String> vocabulario, String campo) {
        Set<String> itens = lista(texto);
        for (String i : itens) {
            if (!vocabulario.containsKey(i)) {
                throw new IllegalArgumentException("Valor '" + i + "' inválido em " + campo
                        + ". Aceitos: " + String.join(", ", vocabulario.keySet()));
            }
        }
        return itens.isEmpty() ? null : String.join(",", itens);
    }

    public static String rotulo(Map<String, String> vocabulario, String codigo) {
        return vocabulario.getOrDefault(codigo, codigo);
    }
}
