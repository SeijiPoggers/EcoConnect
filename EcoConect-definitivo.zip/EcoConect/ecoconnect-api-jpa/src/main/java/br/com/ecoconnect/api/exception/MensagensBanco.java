package br.com.ecoconnect.api.exception;

import java.sql.SQLException;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Traduz os erros do MySQL (chaves, UNIQUE e CHECK do script EcoConnect)
 * para mensagens que o front-end pode mostrar ao usuário.
 */
public final class MensagensBanco {

    /** Mensagens dos CHECKs definidos no script do banco. */
    private static final Map<String, String> CHECKS = Map.ofEntries(
            Map.entry("chk_ag_confirmacao", "Agendamento CONFIRMADO, AUSENTE ou REALIZADO exige data/hora de início e usuário que confirmou."),
            Map.entry("chk_ag_horario", "O fim do agendamento deve ser depois do início."),
            Map.entry("chk_ag_horario_solicitado", "O fim solicitado deve ser depois do início solicitado."),
            Map.entry("chk_at_horario", "O fim real do atendimento não pode ser antes do início."),
            Map.entry("chk_aa_duracao", "A duração da atividade deve ser maior que zero."),
            Map.entry("chk_ai_valor", "Informe o valor numérico ou o valor qualitativo da avaliação."),
            Map.entry("consentimento_chk_1", "Consentimento REVOGADO exige data de revogação."),
            Map.entry("consentimento_chk_2", "Base legal avaliada exige usuário e data da avaliação."),
            Map.entry("chk_cc_data", "A data de fim da condição não pode ser antes da data de início."),
            Map.entry("chk_cc_validacao", "Condição VALIDADA exige usuário e data de validação."),
            Map.entry("chk_cd_validacao", "Diagnóstico VALIDADO exige usuário e data de validação."),
            Map.entry("chk_fe_analise", "Esta situação da fila exige analista, data da análise e justificativa."),
            Map.entry("historico_saude_chk_1", "A data de fim do evento não pode ser antes da data do evento."),
            Map.entry("historico_saude_chk_2", "Registro VALIDADO exige usuário e data de validação."),
            Map.entry("chk_not_origem", "A notificação pode apontar para no máximo uma origem (comunicado, agendamento ou relatório)."),
            Map.entry("chk_obj_data", "A data prevista de fim não pode ser antes da data de início."),
            Map.entry("chk_ra_finalizacao", "Relatório FINALIZADO, LIBERADO ou SUBSTITUÍDO exige data de finalização."),
            Map.entry("chk_ra_versao", "O número da versão do relatório deve ser 1 ou maior."));

    private static final Pattern REFERENCIA = Pattern.compile("REFERENCES `(\\w+)` \\(`?([^)`]*)");
    private static final Pattern FILHA = Pattern.compile("`\\w+`\\.`(\\w+)`, CONSTRAINT");
    private static final Pattern DUPLICADO = Pattern.compile("Duplicate entry '(.*)' for key '([^']+)'");
    private static final Pattern CHECK = Pattern.compile("Check constraint '(\\w+)'");
    private static final Pattern NULO = Pattern.compile("Column '(\\w+)' cannot be null");

    private MensagensBanco() {}

    /** Status HTTP adequado ao erro do MySQL. */
    public static int status(SQLException e) {
        return switch (e.getErrorCode()) {
            case 1062, 1451 -> 409;
            case 1452, 3819, 1048, 1364, 1265, 1366, 1406 -> 422;
            default -> 500;
        };
    }

    public static String traduzir(SQLException e) {
        String msg = e.getMessage() == null ? "" : e.getMessage();
        Matcher m;
        switch (e.getErrorCode()) {
            case 1062:
                m = DUPLICADO.matcher(msg);
                return m.find()
                        ? "Já existe um registro com o valor '" + m.group(1) + "' (" + m.group(2) + ")."
                        : "Já existe um registro com estes dados.";
            case 1452:
                m = REFERENCIA.matcher(msg);
                return m.find()
                        ? "Registro relacionado não encontrado: não existe " + m.group(1) + " com "
                                + m.group(2).replace("`", "") + " informado."
                        : "Registro relacionado não encontrado.";
            case 1451:
                m = FILHA.matcher(msg);
                return m.find()
                        ? "Não é possível excluir/alterar: existem registros em " + m.group(1) + " ligados a este."
                        : "Não é possível excluir/alterar: existem registros ligados a este.";
            case 3819:
                m = CHECK.matcher(msg);
                if (m.find()) {
                    return CHECKS.getOrDefault(m.group(1), "Regra do banco violada (" + m.group(1) + ").");
                }
                return "Regra do banco violada.";
            case 1048:
                m = NULO.matcher(msg);
                return m.find() ? "O campo " + m.group(1) + " é obrigatório." : "Campo obrigatório não informado.";
            case 1406:
                return "Texto maior que o tamanho permitido pelo banco.";
            case 1265, 1366:
                return "Valor fora do domínio permitido pelo banco.";
            default:
                return "Erro no banco de dados (" + e.getErrorCode() + ").";
        }
    }
}
