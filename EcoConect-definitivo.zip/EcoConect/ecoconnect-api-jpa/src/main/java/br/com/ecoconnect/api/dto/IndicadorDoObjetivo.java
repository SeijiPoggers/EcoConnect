package br.com.ecoconnect.api.dto;

import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

/** Vínculo objetivo-indicador. idIndicador obrigatório no POST; no PUT vem da URL. */
public record IndicadorDoObjetivo(
        Long idIndicador,
        BigDecimal valorReferenciaInicial,
        BigDecimal metaValor,
        @Size(max = 300) String descricaoMeta) {
}
