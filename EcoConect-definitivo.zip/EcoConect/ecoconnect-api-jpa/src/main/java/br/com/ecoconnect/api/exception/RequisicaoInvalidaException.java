package br.com.ecoconnect.api.exception;

/** Dado da requisição em formato inválido (HTTP 400). */
public class RequisicaoInvalidaException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public RequisicaoInvalidaException(String mensagem) {
        super(mensagem);
    }
}
