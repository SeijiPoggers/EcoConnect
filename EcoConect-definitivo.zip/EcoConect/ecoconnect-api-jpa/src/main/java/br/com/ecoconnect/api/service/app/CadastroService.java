package br.com.ecoconnect.api.service.app;

import br.com.ecoconnect.api.dominio.LimitadorTentativas;
import br.com.ecoconnect.api.dominio.Papeis;
import br.com.ecoconnect.api.exception.NaoAutorizadoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Responsavel;
import br.com.ecoconnect.api.model.entity.Usuario;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.StatusUsuario;
import br.com.ecoconnect.api.repository.PerfilRepository;
import br.com.ecoconnect.api.repository.ResponsavelRepository;
import br.com.ecoconnect.api.repository.UsuarioRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import java.time.Clock;
import java.time.Duration;
import java.util.Locale;
import java.util.Map;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Cadastro público de famílias e de pessoas acompanhadas. A conta nasce PENDENTE_ATIVACAO:
 * um administrador confere e ativa. A resposta é sempre a mesma (não revela e-mails já cadastrados).
 */
@Service
public class CadastroService {

    public static final String RESPOSTA = "Cadastro recebido. Um administrador vai conferir seus dados e ativar a conta; "
            + "você poderá entrar depois da ativação.";

    private final UsuarioRepository usuarioRepository;
    private final PerfilRepository perfilRepository;
    private final ResponsavelRepository responsavelRepository;
    private final PasswordEncoder passwordEncoder;
    private final ComunicacaoService comunicacao;
    private final AuditoriaService auditoria;
    private final LimitadorTentativas limitador = new LimitadorTentativas(5, Duration.ofHours(1), Clock.systemUTC());

    public CadastroService(UsuarioRepository usuarioRepository, PerfilRepository perfilRepository, ResponsavelRepository responsavelRepository,
                           PasswordEncoder passwordEncoder, ComunicacaoService comunicacao, AuditoriaService auditoria) {
        this.usuarioRepository = usuarioRepository;
        this.perfilRepository = perfilRepository;
        this.responsavelRepository = responsavelRepository;
        this.passwordEncoder = passwordEncoder;
        this.comunicacao = comunicacao;
        this.auditoria = auditoria;
    }

    public record NovoCadastro(String nomeCompleto, String email, String telefone, String senha, String perfil, Boolean aceiteTermos) {
    }

    @Transactional
    public Map<String, Object> cadastrar(NovoCadastro d, String ip) {
        String chave = "cadastro|" + ip;
        if (limitador.bloqueado(chave)) throw new NaoAutorizadoException(429, "Muitos cadastros a partir deste endereço. Tente mais tarde.");
        limitador.registrarFalha(chave); // conta todas as tentativas (5 por hora por IP)
        if (!Boolean.TRUE.equals(d.aceiteTermos())) {
            throw new RegraNegocioException("Para criar a conta, leia e aceite o termo de uso e a política de privacidade.");
        }
        String nome = PessoasService.texto(d.nomeCompleto(), 150);
        if (nome == null || nome.length() < 3) throw new RegraNegocioException("Informe o nome completo.");
        String email = d.email() == null ? "" : d.email().trim().toLowerCase(Locale.ROOT);
        if (!email.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$") || email.length() > 150) throw new RegraNegocioException("Informe um e-mail válido.");
        String senha = d.senha();
        if (senha == null || senha.length() < 8 || senha.length() > 72 || !senha.matches(".*[A-Za-z].*") || !senha.matches(".*\\d.*")) {
            throw new RegraNegocioException("A senha deve ter de 8 a 72 caracteres, com letras e números.");
        }
        String perfil = d.perfil() == null ? Papeis.RESPONSAVEL : d.perfil().trim().toUpperCase(Locale.ROOT);
        if (!Papeis.FAMILIA.contains(perfil)) throw new RegraNegocioException("Perfil inválido para o cadastro público.");
        if (usuarioRepository.existsByEmail(email)) return Map.of("mensagem", RESPOSTA);
        Integer idPerfil = perfilRepository.findByNome(perfil).orElseThrow(() -> new RegraNegocioException("Perfil não configurado.")).getIdPerfil();
        Usuario u = new Usuario();
        u.setIdPerfil(idPerfil);
        u.setNomeCompleto(nome);
        u.setEmail(email);
        u.setTelefone(PessoasService.texto(d.telefone(), 20));
        u.setSenhaHash(passwordEncoder.encode(senha));
        u.setStatus(StatusUsuario.PENDENTE_ATIVACAO);
        u.setExigeTrocaSenha(Boolean.FALSE);
        Usuario salvo = usuarioRepository.saveAndFlush(u);
        if (Papeis.RESPONSAVEL.equals(perfil)) {
            Responsavel r = new Responsavel();
            r.setIdUsuario(salvo.getIdUsuario());
            responsavelRepository.saveAndFlush(r);
        }
        auditoria.registrar(AcaoAuditoria.CRIACAO, "usuario", salvo, null, salvo);
        comunicacao.avisarAdministradores("Novo cadastro aguardando ativação",
                nome + " criou uma conta (" + (Papeis.RESPONSAVEL.equals(perfil) ? "família" : "pessoa acompanhada")
                        + "). Confira em Administração > Usuários.");
        return Map.of("mensagem", RESPOSTA);
    }
}
