package br.com.ecoconnect.api.service.evolucao;

import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Objetivo;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.SituacaoObjetivo;
import br.com.ecoconnect.api.repository.ObjetivoRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.Verificacoes;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Set;

/**
 * OBJETIVO individual da criança. Nasce EM_ANDAMENTO; encerrar ciclo não é alta clínica (RI-17).
 * DELETE = CANCELADO (com data de encerramento).
 */
@Service
public class ObjetivoService extends CrudService<Objetivo, Long> {

    private final Verificacoes verificacoes;

    public ObjetivoService(ObjetivoRepository repository, AuditoriaService auditoria, Verificacoes verificacoes) {
        super(repository, auditoria, "objetivo");
        this.verificacoes = verificacoes;
    }

    @Override
    protected void antesDeCriar(Objetivo o) {
        verificacoes.crianca(o.getIdCrianca());
        verificacoes.profissionalAtivo(o.getIdProfissionalDefinidor());
        o.setSituacao(SituacaoObjetivo.EM_ANDAMENTO);
        o.setDataEncerramento(null);
        validarDatas(o);
    }

    @Override
    protected void validarAtualizacao(Objetivo atual, Objetivo dados) {
        if (atual.getSituacao() != SituacaoObjetivo.EM_ANDAMENTO) {
            throw new RegraNegocioException("Só objetivos EM_ANDAMENTO podem ser alterados.");
        }
    }

    @Override
    protected Set<String> camposProtegidos() {
        return Set.of("idCrianca", "situacao", "dataEncerramento");
    }

    @Override
    protected void antesDeSalvarAtualizacao(Objetivo o) {
        verificacoes.profissionalAtivo(o.getIdProfissionalDefinidor());
        validarDatas(o);
    }

    /** Encerra o ciclo do objetivo (CICLO_ENCERRADO). */
    @Transactional
    public Objetivo encerrarCiclo(Long id) {
        Objetivo o = buscar(id);
        if (o.getSituacao() != SituacaoObjetivo.EM_ANDAMENTO) {
            throw new RegraNegocioException("O objetivo já está " + o.getSituacao() + ".");
        }
        String antes = auditoria.json(o);
        o.setSituacao(SituacaoObjetivo.CICLO_ENCERRADO);
        o.setDataEncerramento(LocalDate.now());
        return salvarAlteracao(o, antes, AcaoAuditoria.ATUALIZACAO);
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.LOGICA;
    }

    @Override
    protected void aplicarExclusaoLogica(Objetivo o) {
        if (o.getSituacao() != SituacaoObjetivo.EM_ANDAMENTO) {
            throw new RegraNegocioException("O objetivo já está " + o.getSituacao() + ".");
        }
        o.setSituacao(SituacaoObjetivo.CANCELADO);
        o.setDataEncerramento(LocalDate.now());
    }

    private static void validarDatas(Objetivo o) {
        if (o.getDataPrevistaFim() != null && o.getDataPrevistaFim().isBefore(o.getDataInicio())) {
            throw new RegraNegocioException("A data prevista de fim não pode ser antes da data de início.");
        }
    }
}
