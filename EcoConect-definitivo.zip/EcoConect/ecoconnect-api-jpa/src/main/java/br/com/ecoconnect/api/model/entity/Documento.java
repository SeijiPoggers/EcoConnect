package br.com.ecoconnect.api.model.entity;

import br.com.ecoconnect.api.model.enums.OrigemInformacao;
import br.com.ecoconnect.api.model.enums.SituacaoConferencia;
import br.com.ecoconnect.api.model.enums.SituacaoDocumento;
import br.com.ecoconnect.api.model.enums.TipoDocumento;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Tabela `documento` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 */
@Entity
@Table(name = "documento")
public class Documento implements Entidade<Long>, PertenceACrianca {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_documento", nullable = false)
    private Long idDocumento;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_crianca", nullable = false)
    private Long idCrianca;

    @NotNull(message = "campo obrigatório")
    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_documento", nullable = false)
    private TipoDocumento tipoDocumento;

    @NotBlank(message = "campo obrigatório")
    @Size(max = 150)
    @Column(name = "titulo", nullable = false, length = 150)
    private String titulo;

    @Column(name = "data_documento")
    private LocalDate dataDocumento;

    @NotBlank(message = "campo obrigatório")
    @Size(max = 255)
    @Column(name = "nome_arquivo_original", nullable = false, length = 255)
    private String nomeArquivoOriginal;

    @Size(max = 100)
    @Column(name = "tipo_mime", length = 100)
    private String tipoMime;

    @Column(name = "tamanho_bytes")
    private Long tamanhoBytes;

    @Size(max = 64)
    @Pattern(regexp = "[0-9a-fA-F]{64}", message = "hash SHA-256 deve ter 64 caracteres hexadecimais")
    @Column(name = "hash_sha256", length = 64)
    private String hashSha256;

    @NotBlank(message = "campo obrigatório")
    @Size(max = 255)
    @Column(name = "chave_armazenamento", nullable = false, length = 255)
    private String chaveArmazenamento;

    @NotNull(message = "campo obrigatório")
    @Enumerated(EnumType.STRING)
    @Column(name = "origem_informacao", nullable = false)
    private OrigemInformacao origemInformacao;

    @Enumerated(EnumType.STRING)
    @Column(name = "situacao_validacao", nullable = false)
    private SituacaoConferencia situacaoValidacao;

    @Enumerated(EnumType.STRING)
    @Column(name = "situacao_documento", nullable = false)
    private SituacaoDocumento situacaoDocumento;

    @Column(name = "id_documento_substituido")
    private Long idDocumentoSubstituido;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_usuario_upload", nullable = false)
    private Long idUsuarioUpload;

    @Column(name = "data_upload", nullable = false)
    private LocalDateTime dataUpload;

    @PrePersist
    void aoInserir() {
        if (situacaoValidacao == null) {
            situacaoValidacao = SituacaoConferencia.NAO_CONFERIDO;
        }
        if (situacaoDocumento == null) {
            situacaoDocumento = SituacaoDocumento.VIGENTE;
        }
        if (dataUpload == null) {
            dataUpload = LocalDateTime.now();
        }
    }

    public Long getIdDocumento() {
        return idDocumento;
    }

    public void setIdDocumento(Long idDocumento) {
        this.idDocumento = idDocumento;
    }

    public Long getIdCrianca() {
        return idCrianca;
    }

    public void setIdCrianca(Long idCrianca) {
        this.idCrianca = idCrianca;
    }

    public TipoDocumento getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(TipoDocumento tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public LocalDate getDataDocumento() {
        return dataDocumento;
    }

    public void setDataDocumento(LocalDate dataDocumento) {
        this.dataDocumento = dataDocumento;
    }

    public String getNomeArquivoOriginal() {
        return nomeArquivoOriginal;
    }

    public void setNomeArquivoOriginal(String nomeArquivoOriginal) {
        this.nomeArquivoOriginal = nomeArquivoOriginal;
    }

    public String getTipoMime() {
        return tipoMime;
    }

    public void setTipoMime(String tipoMime) {
        this.tipoMime = tipoMime;
    }

    public Long getTamanhoBytes() {
        return tamanhoBytes;
    }

    public void setTamanhoBytes(Long tamanhoBytes) {
        this.tamanhoBytes = tamanhoBytes;
    }

    public String getHashSha256() {
        return hashSha256;
    }

    public void setHashSha256(String hashSha256) {
        this.hashSha256 = hashSha256;
    }

    public String getChaveArmazenamento() {
        return chaveArmazenamento;
    }

    public void setChaveArmazenamento(String chaveArmazenamento) {
        this.chaveArmazenamento = chaveArmazenamento;
    }

    public OrigemInformacao getOrigemInformacao() {
        return origemInformacao;
    }

    public void setOrigemInformacao(OrigemInformacao origemInformacao) {
        this.origemInformacao = origemInformacao;
    }

    public SituacaoConferencia getSituacaoValidacao() {
        return situacaoValidacao;
    }

    public void setSituacaoValidacao(SituacaoConferencia situacaoValidacao) {
        this.situacaoValidacao = situacaoValidacao;
    }

    public SituacaoDocumento getSituacaoDocumento() {
        return situacaoDocumento;
    }

    public void setSituacaoDocumento(SituacaoDocumento situacaoDocumento) {
        this.situacaoDocumento = situacaoDocumento;
    }

    public Long getIdDocumentoSubstituido() {
        return idDocumentoSubstituido;
    }

    public void setIdDocumentoSubstituido(Long idDocumentoSubstituido) {
        this.idDocumentoSubstituido = idDocumentoSubstituido;
    }

    public Long getIdUsuarioUpload() {
        return idUsuarioUpload;
    }

    public void setIdUsuarioUpload(Long idUsuarioUpload) {
        this.idUsuarioUpload = idUsuarioUpload;
    }

    public LocalDateTime getDataUpload() {
        return dataUpload;
    }

    public void setDataUpload(LocalDateTime dataUpload) {
        this.dataUpload = dataUpload;
    }

    @Override
    public Long chave() {
        return idDocumento;
    }

    @Override
    public void definirChave(Long id) {
        this.idDocumento = id;
    }
}
