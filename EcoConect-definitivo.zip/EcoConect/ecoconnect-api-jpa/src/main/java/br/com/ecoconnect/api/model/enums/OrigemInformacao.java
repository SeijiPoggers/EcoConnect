package br.com.ecoconnect.api.model.enums;

/** De onde veio a informação. Valores idênticos ao ENUM do MySQL. */
public enum OrigemInformacao {
    DECLARADO_FAMILIA, DOCUMENTO_ANEXADO, PROFISSIONAL_ECOCURA
}
