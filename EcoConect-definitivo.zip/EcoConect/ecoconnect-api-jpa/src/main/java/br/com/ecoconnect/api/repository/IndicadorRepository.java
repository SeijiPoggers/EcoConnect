package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.Indicador;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `indicador` (Spring Data JPA). */
public interface IndicadorRepository extends JpaRepository<Indicador, Long> {
}
