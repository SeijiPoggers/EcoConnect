package br.com.ecoconnect.api.controller.pessoa;

import br.com.ecoconnect.api.controller.base.CrudController;
import br.com.ecoconnect.api.model.entity.Crianca;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.pessoa.CriancaService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Crianças atendidas. DELETE = situacao_ecocura INATIVA. */
@RestController
@RequestMapping("/api/criancas")
public class CriancaController extends CrudController<Crianca, Long> {

    private final CriancaService service;

    public CriancaController(CriancaService service) {
        this.service = service;
    }

    @Override
    protected CrudService<Crianca, Long> service() {
        return service;
    }
}
