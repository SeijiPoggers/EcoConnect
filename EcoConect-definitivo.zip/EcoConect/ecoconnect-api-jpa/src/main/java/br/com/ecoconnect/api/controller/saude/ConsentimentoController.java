package br.com.ecoconnect.api.controller.saude;

import br.com.ecoconnect.api.controller.base.LeituraController;
import br.com.ecoconnect.api.dto.AvaliacaoBaseLegal;
import br.com.ecoconnect.api.model.entity.Consentimento;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.saude.ConsentimentoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/** Consentimentos (LGPD). Sem PUT e sem DELETE: revogação, expiração e avaliação da base legal. */
@RestController
@RequestMapping("/api/consentimentos")
public class ConsentimentoController extends LeituraController<Consentimento, Long> {

    private final ConsentimentoService service;

    public ConsentimentoController(ConsentimentoService service) {
        this.service = service;
    }

    @Override
    protected CrudService<Consentimento, Long> service() {
        return service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Consentimento criar(@Valid @RequestBody Consentimento dados) {
        return service.criar(dados);
    }

    @PatchMapping("/{id}/revogacao")
    public Consentimento revogar(@PathVariable Long id) {
        return service.revogar(id);
    }

    @PatchMapping("/{id}/expiracao")
    public Consentimento expirar(@PathVariable Long id) {
        return service.expirar(id);
    }

    @PatchMapping("/{id}/base-legal")
    public Consentimento avaliarBaseLegal(@PathVariable Long id, @Valid @RequestBody AvaliacaoBaseLegal dados) {
        return service.avaliarBaseLegal(id, dados.baseLegalAvaliada(), dados.idUsuarioAvaliacaoBase());
    }
}
