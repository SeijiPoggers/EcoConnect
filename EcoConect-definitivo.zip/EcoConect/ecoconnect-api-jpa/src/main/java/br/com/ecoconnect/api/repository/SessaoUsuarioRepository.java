package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.SessaoUsuario;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SessaoUsuarioRepository extends JpaRepository<SessaoUsuario, Long> {

    Optional<SessaoUsuario> findByTokenHash(String tokenHash);
    List<SessaoUsuario> findByIdUsuarioAndDataRevogacaoIsNull(Long idUsuario);

}
