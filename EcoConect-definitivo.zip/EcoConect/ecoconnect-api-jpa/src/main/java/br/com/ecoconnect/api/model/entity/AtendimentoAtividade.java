package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

/**
 * Tabela `atendimento_atividade` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 * CHECK chk_aa_duracao: ((duracao_minutos is null) or (duracao_minutos > 0))
 */
@Entity
@Table(name = "atendimento_atividade")
@IdClass(AtendimentoAtividadeId.class)
public class AtendimentoAtividade {

    @Id
    @Column(name = "id_atendimento", nullable = false)
    private Long idAtendimento;

    @Id
    @Column(name = "id_atividade", nullable = false)
    private Integer idAtividade;

    @Positive(message = "deve ser maior que zero")
    @Column(name = "duracao_minutos")
    private Integer duracaoMinutos;

    @Size(max = 300)
    @Column(name = "observacao", length = 300)
    private String observacao;

    @PrePersist
    void aoInserir() {
        // sem valores padrão a preencher
    }

    public Long getIdAtendimento() {
        return idAtendimento;
    }

    public void setIdAtendimento(Long idAtendimento) {
        this.idAtendimento = idAtendimento;
    }

    public Integer getIdAtividade() {
        return idAtividade;
    }

    public void setIdAtividade(Integer idAtividade) {
        this.idAtividade = idAtividade;
    }

    public Integer getDuracaoMinutos() {
        return duracaoMinutos;
    }

    public void setDuracaoMinutos(Integer duracaoMinutos) {
        this.duracaoMinutos = duracaoMinutos;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }
}
