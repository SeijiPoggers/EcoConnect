package br.com.ecoconnect.api.seguranca;

import br.com.ecoconnect.api.dominio.Papeis;
import br.com.ecoconnect.api.dominio.Tokens;
import br.com.ecoconnect.api.model.entity.CriancaUsuario;
import br.com.ecoconnect.api.model.entity.InstituicaoMembro;
import br.com.ecoconnect.api.model.entity.Perfil;
import br.com.ecoconnect.api.model.entity.Profissional;
import br.com.ecoconnect.api.model.entity.Responsavel;
import br.com.ecoconnect.api.model.entity.SessaoUsuario;
import br.com.ecoconnect.api.model.entity.Usuario;
import br.com.ecoconnect.api.model.enums.StatusUsuario;
import br.com.ecoconnect.api.repository.CriancaUsuarioRepository;
import br.com.ecoconnect.api.repository.InstituicaoMembroRepository;
import br.com.ecoconnect.api.repository.PerfilRepository;
import br.com.ecoconnect.api.repository.ProfissionalRepository;
import br.com.ecoconnect.api.repository.ResponsavelRepository;
import br.com.ecoconnect.api.repository.SessaoUsuarioRepository;
import br.com.ecoconnect.api.repository.UsuarioRepository;
import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.Optional;
import java.util.Set;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Sessões de login guardadas no MySQL (tabela sessao_usuario). O navegador recebe o token
 * em um cookie HttpOnly; o banco guarda só o hash SHA-256. Logout e troca de senha revogam sessões.
 */
@Service
public class SessaoService {

    private final SessaoUsuarioRepository sessaoRepository;
    private final UsuarioRepository usuarioRepository;
    private final PerfilRepository perfilRepository;
    private final ResponsavelRepository responsavelRepository;
    private final ProfissionalRepository profissionalRepository;
    private final CriancaUsuarioRepository criancaUsuarioRepository;
    private final InstituicaoMembroRepository membroRepository;

    @Value("${ecoconnect.seguranca.sessao-horas:8}")
    private long horasSessao;

    public SessaoService(SessaoUsuarioRepository sessaoRepository, UsuarioRepository usuarioRepository,
                         PerfilRepository perfilRepository, ResponsavelRepository responsavelRepository,
                         ProfissionalRepository profissionalRepository, CriancaUsuarioRepository criancaUsuarioRepository,
                         InstituicaoMembroRepository membroRepository) {
        this.sessaoRepository = sessaoRepository;
        this.usuarioRepository = usuarioRepository;
        this.perfilRepository = perfilRepository;
        this.responsavelRepository = responsavelRepository;
        this.profissionalRepository = profissionalRepository;
        this.criancaUsuarioRepository = criancaUsuarioRepository;
        this.membroRepository = membroRepository;
    }

    public long segundosDeValidade() {
        return horasSessao * 3600;
    }

    @Transactional
    public SessaoCriada criar(Long idUsuario, String ip, String agente) {
        String token = Tokens.novoToken();
        SessaoUsuario s = new SessaoUsuario();
        s.setIdUsuario(idUsuario);
        s.setTokenHash(Tokens.sha256Hex(token));
        s.setDataExpiracao(LocalDateTime.now().plusHours(horasSessao));
        s.setIpOrigem(ip);
        s.setAgenteUsuario(agente == null ? null : (agente.length() > 255 ? agente.substring(0, 255) : agente));
        SessaoUsuario salva = sessaoRepository.saveAndFlush(s);
        return new SessaoCriada(token, salva.getIdSessao(), salva.getDataExpiracao());
    }

    public record SessaoCriada(String token, Long idSessao, LocalDateTime expiraEm) {
    }

    /** Sessão válida -> contexto do usuário; inválida, expirada, revogada ou conta não ATIVA -> vazio. */
    @Transactional
    public Optional<ContextoUsuario> validar(String token) {
        if (token == null || token.isBlank() || token.length() > 100) return Optional.empty();
        Optional<SessaoUsuario> opt = sessaoRepository.findByTokenHash(Tokens.sha256Hex(token));
        if (opt.isEmpty()) return Optional.empty();
        SessaoUsuario s = opt.get();
        LocalDateTime agora = LocalDateTime.now();
        if (s.getDataRevogacao() != null || s.getDataExpiracao().isBefore(agora)) return Optional.empty();
        Usuario u = usuarioRepository.findById(s.getIdUsuario()).orElse(null);
        if (u == null || u.getStatus() != StatusUsuario.ATIVO) return Optional.empty();
        if (s.getDataUltimoUso() == null || s.getDataUltimoUso().isBefore(agora.minusMinutes(5))) {
            s.setDataUltimoUso(agora);
            sessaoRepository.save(s);
        }
        return Optional.of(contexto(u, s.getIdSessao()));
    }

    @Transactional(readOnly = true)
    public ContextoUsuario contexto(Usuario u, Long idSessao) {
        String perfil = perfilRepository.findById(u.getIdPerfil()).map(Perfil::getNome).orElse("");
        Long idResp = responsavelRepository.findByIdUsuario(u.getIdUsuario()).map(Responsavel::getIdResponsavel).orElse(null);
        Long idProf = profissionalRepository.findByIdUsuario(u.getIdUsuario()).map(Profissional::getIdProfissional).orElse(null);
        Long idCrianca = Papeis.PESSOA_ACOMPANHADA.equals(perfil)
                ? criancaUsuarioRepository.findByIdUsuario(u.getIdUsuario()).map(CriancaUsuario::getIdCrianca).orElse(null)
                : null;
        Set<Long> inst = new LinkedHashSet<>();
        for (InstituicaoMembro m : membroRepository.findByIdUsuarioAndAtivoTrue(u.getIdUsuario())) {
            inst.add(m.getIdInstituicao());
        }
        return new ContextoUsuario(u.getIdUsuario(), idSessao, u.getNomeCompleto(), u.getEmail(), perfil, idResp, idProf,
                idCrianca, Set.copyOf(inst), Boolean.TRUE.equals(u.getExigeTrocaSenha()));
    }

    @Transactional
    public void revogar(Long idSessao) {
        if (idSessao == null) return;
        sessaoRepository.findById(idSessao).ifPresent(s -> {
            if (s.getDataRevogacao() == null) {
                s.setDataRevogacao(LocalDateTime.now());
                sessaoRepository.save(s);
            }
        });
    }

    /** Revoga todas as sessões do usuário, exceto (opcionalmente) a atual. */
    @Transactional
    public int revogarTodas(Long idUsuario, Long exceto) {
        int n = 0;
        for (SessaoUsuario s : sessaoRepository.findByIdUsuarioAndDataRevogacaoIsNull(idUsuario)) {
            if (exceto != null && exceto.equals(s.getIdSessao())) continue;
            s.setDataRevogacao(LocalDateTime.now());
            sessaoRepository.save(s);
            n++;
        }
        return n;
    }

    @Transactional
    public void concluirTrocaDeSenha(Long idUsuario) {
        usuarioRepository.findById(idUsuario).ifPresent(u -> {
            u.setExigeTrocaSenha(Boolean.FALSE);
            usuarioRepository.save(u);
        });
    }
}
