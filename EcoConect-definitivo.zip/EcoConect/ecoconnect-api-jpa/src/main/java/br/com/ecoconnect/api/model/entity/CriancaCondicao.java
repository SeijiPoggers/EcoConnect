package br.com.ecoconnect.api.model.entity;

import br.com.ecoconnect.api.model.enums.OrigemInformacao;
import br.com.ecoconnect.api.model.enums.PrecisaoData;
import br.com.ecoconnect.api.model.enums.SituacaoValidacao;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Tabela `crianca_condicao` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 * CHECK chk_cc_data: ((data_fim is null) or (data_inicio is null) or (data_fim >= data_inicio))
 * CHECK chk_cc_validacao: ((situacao_validacao <> 'VALIDADO') or ((id_usuario_validacao is not null) and (data_validacao is not null)))
 */
@Entity
@Table(name = "crianca_condicao")
public class CriancaCondicao implements Entidade<Long>, RegistroDeSaude {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_crianca_condicao", nullable = false)
    private Long idCriancaCondicao;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_crianca", nullable = false)
    private Long idCrianca;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_condicao_saude", nullable = false)
    private Long idCondicaoSaude;

    @Column(name = "data_inicio")
    private LocalDate dataInicio;

    @Column(name = "data_fim")
    private LocalDate dataFim;

    @NotNull(message = "campo obrigatório")
    @Enumerated(EnumType.STRING)
    @Column(name = "precisao_data", nullable = false)
    private PrecisaoData precisaoData;

    @NotNull(message = "campo obrigatório")
    @Enumerated(EnumType.STRING)
    @Column(name = "origem_informacao", nullable = false)
    private OrigemInformacao origemInformacao;

    @Enumerated(EnumType.STRING)
    @Column(name = "situacao_validacao", nullable = false)
    private SituacaoValidacao situacaoValidacao;

    @Column(name = "id_documento")
    private Long idDocumento;

    @Size(max = 500)
    @Column(name = "observacao", length = 500)
    private String observacao;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_usuario_registro", nullable = false)
    private Long idUsuarioRegistro;

    @Column(name = "data_registro", nullable = false)
    private LocalDateTime dataRegistro;

    @Column(name = "id_usuario_validacao")
    private Long idUsuarioValidacao;

    @Column(name = "data_validacao")
    private LocalDateTime dataValidacao;

    @PrePersist
    void aoInserir() {
        if (situacaoValidacao == null) {
            situacaoValidacao = SituacaoValidacao.DECLARADO;
        }
        if (dataRegistro == null) {
            dataRegistro = LocalDateTime.now();
        }
    }

    public Long getIdCriancaCondicao() {
        return idCriancaCondicao;
    }

    public void setIdCriancaCondicao(Long idCriancaCondicao) {
        this.idCriancaCondicao = idCriancaCondicao;
    }

    public Long getIdCrianca() {
        return idCrianca;
    }

    public void setIdCrianca(Long idCrianca) {
        this.idCrianca = idCrianca;
    }

    public Long getIdCondicaoSaude() {
        return idCondicaoSaude;
    }

    public void setIdCondicaoSaude(Long idCondicaoSaude) {
        this.idCondicaoSaude = idCondicaoSaude;
    }

    public LocalDate getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(LocalDate dataInicio) {
        this.dataInicio = dataInicio;
    }

    public LocalDate getDataFim() {
        return dataFim;
    }

    public void setDataFim(LocalDate dataFim) {
        this.dataFim = dataFim;
    }

    public PrecisaoData getPrecisaoData() {
        return precisaoData;
    }

    public void setPrecisaoData(PrecisaoData precisaoData) {
        this.precisaoData = precisaoData;
    }

    public OrigemInformacao getOrigemInformacao() {
        return origemInformacao;
    }

    public void setOrigemInformacao(OrigemInformacao origemInformacao) {
        this.origemInformacao = origemInformacao;
    }

    public SituacaoValidacao getSituacaoValidacao() {
        return situacaoValidacao;
    }

    public void setSituacaoValidacao(SituacaoValidacao situacaoValidacao) {
        this.situacaoValidacao = situacaoValidacao;
    }

    public Long getIdDocumento() {
        return idDocumento;
    }

    public void setIdDocumento(Long idDocumento) {
        this.idDocumento = idDocumento;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public Long getIdUsuarioRegistro() {
        return idUsuarioRegistro;
    }

    public void setIdUsuarioRegistro(Long idUsuarioRegistro) {
        this.idUsuarioRegistro = idUsuarioRegistro;
    }

    public LocalDateTime getDataRegistro() {
        return dataRegistro;
    }

    public void setDataRegistro(LocalDateTime dataRegistro) {
        this.dataRegistro = dataRegistro;
    }

    public Long getIdUsuarioValidacao() {
        return idUsuarioValidacao;
    }

    public void setIdUsuarioValidacao(Long idUsuarioValidacao) {
        this.idUsuarioValidacao = idUsuarioValidacao;
    }

    public LocalDateTime getDataValidacao() {
        return dataValidacao;
    }

    public void setDataValidacao(LocalDateTime dataValidacao) {
        this.dataValidacao = dataValidacao;
    }

    @Override
    public Long chave() {
        return idCriancaCondicao;
    }

    @Override
    public void definirChave(Long id) {
        this.idCriancaCondicao = id;
    }
}
