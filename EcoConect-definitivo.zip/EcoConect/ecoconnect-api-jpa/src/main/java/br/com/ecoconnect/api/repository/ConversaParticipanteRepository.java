package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.ConversaParticipante;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConversaParticipanteRepository extends JpaRepository<ConversaParticipante, Long> {

    List<ConversaParticipante> findByIdConversa(Long idConversa);
    List<ConversaParticipante> findByIdUsuario(Long idUsuario);
    Optional<ConversaParticipante> findByIdConversaAndIdUsuario(Long idConversa, Long idUsuario);
    boolean existsByIdConversaAndIdUsuario(Long idConversa, Long idUsuario);

}
