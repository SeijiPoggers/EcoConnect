package br.com.ecoconnect.api.model.entity;

import java.io.Serializable;
import java.util.Objects;

/** Chave primária composta de `profissional_especialidade`: (id_profissional, id_especialidade). */
public class ProfissionalEspecialidadeId implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long idProfissional;
    private Integer idEspecialidade;

    public ProfissionalEspecialidadeId() {
    }

    public ProfissionalEspecialidadeId(Long idProfissional, Integer idEspecialidade) {
        this.idProfissional = idProfissional;
        this.idEspecialidade = idEspecialidade;
    }

    public Long getIdProfissional() {
        return idProfissional;
    }

    public void setIdProfissional(Long idProfissional) {
        this.idProfissional = idProfissional;
    }

    public Integer getIdEspecialidade() {
        return idEspecialidade;
    }

    public void setIdEspecialidade(Integer idEspecialidade) {
        this.idEspecialidade = idEspecialidade;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ProfissionalEspecialidadeId outro)) return false;
        return Objects.equals(idProfissional, outro.idProfissional) && Objects.equals(idEspecialidade, outro.idEspecialidade);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProfissional, idEspecialidade);
    }

    @Override
    public String toString() {
        return "idProfissional=" + idProfissional + ","
                + "idEspecialidade=" + idEspecialidade;
    }
}
