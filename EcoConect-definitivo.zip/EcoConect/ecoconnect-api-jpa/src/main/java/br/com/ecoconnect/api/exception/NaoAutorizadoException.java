package br.com.ecoconnect.api.exception;

/** Credenciais inválidas ou conta sem acesso (HTTP 401/403). */
public class NaoAutorizadoException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final int status;

    public NaoAutorizadoException(int status, String mensagem) {
        super(mensagem);
        this.status = status;
    }

    public int getStatus() {
        return status;
    }
}
