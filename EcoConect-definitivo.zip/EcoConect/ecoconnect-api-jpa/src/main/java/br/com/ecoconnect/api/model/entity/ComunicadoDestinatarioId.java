package br.com.ecoconnect.api.model.entity;

import java.io.Serializable;
import java.util.Objects;

/** Chave primária composta de `comunicado_destinatario`: (id_comunicado, id_responsavel). */
public class ComunicadoDestinatarioId implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long idComunicado;
    private Long idResponsavel;

    public ComunicadoDestinatarioId() {
    }

    public ComunicadoDestinatarioId(Long idComunicado, Long idResponsavel) {
        this.idComunicado = idComunicado;
        this.idResponsavel = idResponsavel;
    }

    public Long getIdComunicado() {
        return idComunicado;
    }

    public void setIdComunicado(Long idComunicado) {
        this.idComunicado = idComunicado;
    }

    public Long getIdResponsavel() {
        return idResponsavel;
    }

    public void setIdResponsavel(Long idResponsavel) {
        this.idResponsavel = idResponsavel;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ComunicadoDestinatarioId outro)) return false;
        return Objects.equals(idComunicado, outro.idComunicado) && Objects.equals(idResponsavel, outro.idResponsavel);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idComunicado, idResponsavel);
    }

    @Override
    public String toString() {
        return "idComunicado=" + idComunicado + ","
                + "idResponsavel=" + idResponsavel;
    }
}
