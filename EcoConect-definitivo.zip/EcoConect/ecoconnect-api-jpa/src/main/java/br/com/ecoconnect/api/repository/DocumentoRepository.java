package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.Documento;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `documento` (Spring Data JPA). */
public interface DocumentoRepository extends JpaRepository<Documento, Long> {

    boolean existsByIdDocumentoAndIdCrianca(Long idDocumento, Long idCrianca);
    boolean existsByChaveArmazenamento(String chaveArmazenamento);
}
