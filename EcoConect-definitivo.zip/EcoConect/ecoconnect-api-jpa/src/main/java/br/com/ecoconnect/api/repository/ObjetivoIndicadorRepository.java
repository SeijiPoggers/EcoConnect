package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.ObjetivoIndicador;
import br.com.ecoconnect.api.model.entity.ObjetivoIndicadorId;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `objetivo_indicador` (Spring Data JPA). */
public interface ObjetivoIndicadorRepository extends JpaRepository<ObjetivoIndicador, ObjetivoIndicadorId> {

    boolean existsByIdIndicador(Long idIndicador);
    List<ObjetivoIndicador> findByIdObjetivo(Long idObjetivo);
}
