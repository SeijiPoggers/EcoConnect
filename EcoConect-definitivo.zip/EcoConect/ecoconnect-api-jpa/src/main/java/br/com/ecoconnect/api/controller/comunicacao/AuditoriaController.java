package br.com.ecoconnect.api.controller.comunicacao;

import br.com.ecoconnect.api.dto.Pagina;
import br.com.ecoconnect.api.model.entity.Auditoria;
import br.com.ecoconnect.api.service.AuditoriaService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/** Auditoria: somente consulta e inserção (RI-21). Filtros: ?acao=LOGIN&idUsuario=1&tabelaAfetada=crianca */
@RestController
@RequestMapping("/api/auditoria")
public class AuditoriaController {

    private final AuditoriaService service;

    public AuditoriaController(AuditoriaService service) {
        this.service = service;
    }

    @GetMapping
    public Pagina<Auditoria> listar(@ModelAttribute Auditoria filtro,
                                    @PageableDefault(size = 50, sort = "dataHora", direction = Sort.Direction.DESC) Pageable pageable) {
        return service.listar(filtro, pageable);
    }

    @GetMapping("/{id}")
    public Auditoria buscar(@PathVariable Long id) {
        return service.buscar(id);
    }

    /** Registro manual pelo front-end (ex.: LOGOUT ou CONSULTA a um prontuário). */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Auditoria registrar(@Valid @RequestBody Auditoria dados) {
        return service.inserirManual(dados);
    }
}
