package br.com.ecoconnect.api.dominio;

import java.util.Set;

/** Nomes dos perfis (tabela PERFIL). Os três primeiros já existiam na API original. */
public final class Papeis {

    public static final String ADMINISTRADOR = "ADMINISTRADOR";
    public static final String PROFISSIONAL = "PROFISSIONAL";
    public static final String RESPONSAVEL = "RESPONSAVEL";
    public static final String ADMIN_INSTITUCIONAL = "ADMIN_INSTITUCIONAL";
    public static final String PESSOA_ACOMPANHADA = "PESSOA_ACOMPANHADA";

    /** Equipe de acompanhamento: pode registrar e validar informações de saúde. */
    public static final Set<String> EQUIPE = Set.of(ADMINISTRADOR, PROFISSIONAL);
    /** Família: responsável ou a própria pessoa acompanhada. */
    public static final Set<String> FAMILIA = Set.of(RESPONSAVEL, PESSOA_ACOMPANHADA);
    public static final Set<String> TODOS = Set.of(ADMINISTRADOR, PROFISSIONAL, RESPONSAVEL, ADMIN_INSTITUCIONAL, PESSOA_ACOMPANHADA);

    private Papeis() {
    }
}
