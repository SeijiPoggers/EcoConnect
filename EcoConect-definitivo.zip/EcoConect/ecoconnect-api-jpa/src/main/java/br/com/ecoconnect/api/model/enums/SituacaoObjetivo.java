package br.com.ecoconnect.api.model.enums;

/** Situação do objetivo. Valores idênticos ao ENUM do MySQL. */
public enum SituacaoObjetivo {
    EM_ANDAMENTO, CICLO_ENCERRADO, CANCELADO
}
