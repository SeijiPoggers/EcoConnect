package br.com.ecoconnect.api.service.agenda;

import br.com.ecoconnect.api.service.app.ConflitoAgenda;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.ecoconnect.api.dto.MudancaStatusAgendamento;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Agendamento;
import br.com.ecoconnect.api.model.entity.HistoricoAgendamento;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.StatusAgendamento;
import br.com.ecoconnect.api.model.enums.TipoNotificacao;
import br.com.ecoconnect.api.repository.AgendamentoRepository;
import br.com.ecoconnect.api.repository.HistoricoAgendamentoRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.NotificacaoService;
import br.com.ecoconnect.api.service.Verificacoes;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import static br.com.ecoconnect.api.model.enums.StatusAgendamento.AUSENTE;
import static br.com.ecoconnect.api.model.enums.StatusAgendamento.CANCELADO;
import static br.com.ecoconnect.api.model.enums.StatusAgendamento.CONFIRMADO;
import static br.com.ecoconnect.api.model.enums.StatusAgendamento.EM_ANALISE;
import static br.com.ecoconnect.api.model.enums.StatusAgendamento.REALIZADO;
import static br.com.ecoconnect.api.model.enums.StatusAgendamento.RECUSADO;
import static br.com.ecoconnect.api.model.enums.StatusAgendamento.SOLICITADO;

/**
 * AGENDAMENTO: solicitação, análise, confirmação e situação final.
 * Regras aplicadas:
 *  - E.3: responsável só solicita com vínculo ATIVO e pode_solicitar_agendamento = 1;
 *  - RI-08: CONFIRMADO/AUSENTE/REALIZADO exigem data/hora e usuário da equipe;
 *  - RI-09: toda mudança de status ou horário gera linha em HISTORICO_AGENDAMENTO;
 *  - sem exclusão: cancela-se pelo status.
 * O fluxo de status abaixo é uma proposta (ponto 6 "pendente de validação" da modelagem).
 */
@Service
public class AgendamentoService extends CrudService<Agendamento, Long> {

    /** Transições permitidas. CONFIRMADO -> CONFIRMADO = remarcação. */
    private static final Map<StatusAgendamento, Set<StatusAgendamento>> TRANSICOES = Map.of(
            SOLICITADO, EnumSet.of(EM_ANALISE, CONFIRMADO, RECUSADO, CANCELADO),
            EM_ANALISE, EnumSet.of(CONFIRMADO, RECUSADO, CANCELADO),
            CONFIRMADO, EnumSet.of(CONFIRMADO, REALIZADO, AUSENTE, CANCELADO),
            RECUSADO, EnumSet.noneOf(StatusAgendamento.class),
            CANCELADO, EnumSet.noneOf(StatusAgendamento.class),
            AUSENTE, EnumSet.noneOf(StatusAgendamento.class),
            REALIZADO, EnumSet.noneOf(StatusAgendamento.class));

    private static final Set<StatusAgendamento> SO_EQUIPE = EnumSet.of(EM_ANALISE, CONFIRMADO, RECUSADO, REALIZADO, AUSENTE);

    private final HistoricoAgendamentoRepository historicoRepository;

    /** Conflitos de horário (pessoa e profissionais designados) ao confirmar ou remarcar. */
    private ConflitoAgenda conflitoAgenda;

    @Autowired(required = false)
    public void setConflitoAgenda(ConflitoAgenda conflitoAgenda) {
        this.conflitoAgenda = conflitoAgenda;
    }
    private final NotificacaoService notificacaoService;
    private final Verificacoes verificacoes;

    public AgendamentoService(AgendamentoRepository repository, AuditoriaService auditoria,
                              HistoricoAgendamentoRepository historicoRepository,
                              NotificacaoService notificacaoService, Verificacoes verificacoes) {
        super(repository, auditoria, "agendamento");
        this.historicoRepository = historicoRepository;
        this.notificacaoService = notificacaoService;
        this.verificacoes = verificacoes;
    }

    // ------------------------------------------------------------- criação

    @Override
    protected void antesDeCriar(Agendamento a) {
        verificacoes.crianca(a.getIdCrianca());
        verificacoes.podeSolicitarPelaCrianca(a.getIdUsuarioSolicitante(), a.getIdCrianca());
        validarHorario(a.getDataHoraInicioSolicitada(), a.getDataHoraFimSolicitada(), "solicitado");
        a.setStatus(SOLICITADO);
        a.setDataHoraInicio(null);
        a.setDataHoraFim(null);
        a.setIdUsuarioConfirmacao(null);
        a.setDataConfirmacao(null);
    }

    @Override
    protected void depoisDeCriar(Agendamento a) {
        registrarHistorico(a, null, SOLICITADO, null, a.getIdUsuarioSolicitante(), "Solicitação registrada.");
    }

    // ------------------------------------------------------------- alteração (só dados da solicitação)

    @Override
    protected void validarAtualizacao(Agendamento atual, Agendamento dados) {
        if (atual.getStatus() != SOLICITADO && atual.getStatus() != EM_ANALISE) {
            throw new RegraNegocioException("Só é possível alterar a solicitação enquanto está SOLICITADO ou EM_ANALISE.");
        }
    }

    @Override
    protected Set<String> camposProtegidos() {
        return Set.of("idCrianca", "idUsuarioSolicitante", "status", "dataHoraInicio", "dataHoraFim",
                "idUsuarioConfirmacao", "dataConfirmacao");
    }

    @Override
    protected void antesDeSalvarAtualizacao(Agendamento a) {
        validarHorario(a.getDataHoraInicioSolicitada(), a.getDataHoraFimSolicitada(), "solicitado");
    }

    // ------------------------------------------------------------- status

    @Transactional
    public Agendamento mudarStatus(Long id, MudancaStatusAgendamento req) {
        Agendamento a = buscar(id);
        StatusAgendamento anterior = a.getStatus();
        StatusAgendamento novo = req.status();
        if (!TRANSICOES.get(anterior).contains(novo)) {
            throw new RegraNegocioException("Não é possível passar de " + anterior + " para " + novo
                    + ". Permitidos: " + TRANSICOES.get(anterior) + ".");
        }
        if (SO_EQUIPE.contains(novo)) {
            verificacoes.usuarioDaEquipe(req.idUsuario(), "Quem altera o status para " + novo);
        } else {
            // CANCELADO: equipe ou responsável vinculado à criança
            verificacoes.usuarioAtivo(req.idUsuario(), "Quem cancela");
            verificacoes.responsavelVinculado(req.idUsuario(), a.getIdCrianca());
        }

        String antes = auditoria.json(a);
        LocalDateTime inicioAnterior = a.getDataHoraInicio();

        if (novo == CONFIRMADO) {
            if (anterior == CONFIRMADO && req.dataHoraInicio() == null) {
                throw new RegraNegocioException("Para remarcar, informe a nova dataHoraInicio.");
            }
            LocalDateTime inicio = primeiro(req.dataHoraInicio(), a.getDataHoraInicio(), a.getDataHoraInicioSolicitada());
            LocalDateTime fim = req.dataHoraInicio() != null ? req.dataHoraFim()
                    : primeiro(req.dataHoraFim(), a.getDataHoraFim(), a.getDataHoraFimSolicitada());
            validarHorario(inicio, fim, "confirmado");
            if (conflitoAgenda != null) conflitoAgenda.verificar(a.getIdAgendamento(), a.getIdCrianca(), inicio, fim);
            a.setDataHoraInicio(inicio);
            a.setDataHoraFim(fim);
            a.setIdUsuarioConfirmacao(req.idUsuario());
            a.setDataConfirmacao(LocalDateTime.now());
        }
        a.setStatus(novo);
        Agendamento salvo = salvarAlteracao(a, antes, AcaoAuditoria.ATUALIZACAO);
        registrarHistorico(salvo, anterior, novo, inicioAnterior, req.idUsuario(), req.motivo());

        if (!Objects.equals(req.idUsuario(), salvo.getIdUsuarioSolicitante())
                && EnumSet.of(CONFIRMADO, RECUSADO, CANCELADO).contains(novo)) {
            notificacaoService.notificar(salvo.getIdUsuarioSolicitante(), TipoNotificacao.AGENDAMENTO,
                    "Agendamento " + novo.name().toLowerCase(),
                    "O agendamento " + salvo.getIdAgendamento() + " foi " + novo.name().toLowerCase()
                            + (req.motivo() != null ? ": " + req.motivo() : "."),
                    null, salvo.getIdAgendamento(), null);
        }
        return salvo;
    }

    @Transactional(readOnly = true)
    public List<HistoricoAgendamento> historico(Long id) {
        buscar(id);
        return historicoRepository.findByIdAgendamentoOrderByDataHoraAlteracaoAsc(id);
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.PROIBIDA;
    }

    @Override
    protected String motivoExclusaoProibida() {
        return "Agendamentos não são excluídos: altere o status para CANCELADO.";
    }

    // ------------------------------------------------------------------

    private void registrarHistorico(Agendamento a, StatusAgendamento anterior, StatusAgendamento novo,
                                    LocalDateTime inicioAnterior, Long idUsuario, String motivo) {
        HistoricoAgendamento h = new HistoricoAgendamento();
        h.setIdAgendamento(a.getIdAgendamento());
        h.setStatusAnterior(anterior);
        h.setStatusNovo(novo);
        h.setDataHoraInicioAnterior(inicioAnterior);
        h.setDataHoraInicioNovo(a.getDataHoraInicio());
        h.setMotivo(motivo == null || motivo.isBlank() ? null : motivo.trim());
        h.setIdUsuario(idUsuario);
        historicoRepository.save(h);
    }

    private static void validarHorario(LocalDateTime inicio, LocalDateTime fim, String tipo) {
        if (inicio != null && fim != null && !fim.isAfter(inicio)) {
            throw new RegraNegocioException("O fim do horário " + tipo + " deve ser depois do início.");
        }
    }

    @SafeVarargs
    private static <T> T primeiro(T... valores) {
        for (T v : valores) if (v != null) return v;
        return null;
    }
}
