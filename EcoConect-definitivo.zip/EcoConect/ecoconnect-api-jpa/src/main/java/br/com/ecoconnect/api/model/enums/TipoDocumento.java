package br.com.ecoconnect.api.model.enums;

/** Tipo do documento. Valores idênticos ao ENUM do MySQL. */
public enum TipoDocumento {
    LAUDO, EXAME, RELATORIO_EXTERNO, DECLARACAO, TERMO_ASSINADO, OUTRO
}
