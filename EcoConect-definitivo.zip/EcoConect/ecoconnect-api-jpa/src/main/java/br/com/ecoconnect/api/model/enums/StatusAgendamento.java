package br.com.ecoconnect.api.model.enums;

/** Status do agendamento (fluxo pendente de validação pela equipe). Valores idênticos ao ENUM do MySQL. */
public enum StatusAgendamento {
    SOLICITADO, EM_ANALISE, CONFIRMADO, RECUSADO, CANCELADO, AUSENTE, REALIZADO
}
