package br.com.ecoconnect.api.model.enums;

/** Situação de um registro de histórico de saúde. Valores idênticos ao ENUM do MySQL. */
public enum SituacaoRegistro {
    ATIVO, SUBSTITUIDO, REMOVIDO_LOGICAMENTE
}
