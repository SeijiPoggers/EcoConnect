package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.RegistroSessao;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegistroSessaoRepository extends JpaRepository<RegistroSessao, Long> {

}
