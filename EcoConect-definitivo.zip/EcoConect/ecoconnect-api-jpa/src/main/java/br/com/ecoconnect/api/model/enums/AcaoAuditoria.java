package br.com.ecoconnect.api.model.enums;

/** Ação registrada na auditoria. Valores idênticos ao ENUM do MySQL. */
public enum AcaoAuditoria {
    LOGIN, LOGIN_FALHA, LOGOUT, CONSULTA, CRIACAO, ATUALIZACAO, EXCLUSAO_LOGICA, VALIDACAO, LIBERACAO
}
