package br.com.ecoconnect.api.model.enums;

/** Situação do comunicado. Valores idênticos ao ENUM do MySQL. */
public enum SituacaoComunicado {
    RASCUNHO, PUBLICADO, CANCELADO
}
