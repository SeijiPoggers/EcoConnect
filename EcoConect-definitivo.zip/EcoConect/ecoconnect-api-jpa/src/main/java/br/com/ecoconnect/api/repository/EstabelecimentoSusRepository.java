package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.EstabelecimentoSus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EstabelecimentoSusRepository extends JpaRepository<EstabelecimentoSus, String> {

    long countByFonte(String fonte);

}
