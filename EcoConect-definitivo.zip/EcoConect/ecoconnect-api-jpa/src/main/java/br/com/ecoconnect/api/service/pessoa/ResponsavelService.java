package br.com.ecoconnect.api.service.pessoa;

import br.com.ecoconnect.api.dto.RelatorioResponsavelDTO;
import br.com.ecoconnect.api.exception.ConflitoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Responsavel;
import br.com.ecoconnect.api.model.entity.Usuario;
import br.com.ecoconnect.api.model.enums.SituacaoRelatorio;
import br.com.ecoconnect.api.model.enums.StatusVinculo;
import br.com.ecoconnect.api.repository.ProfissionalRepository;
import br.com.ecoconnect.api.repository.RelatorioAtendimentoRepository;
import br.com.ecoconnect.api.repository.ResponsavelRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.Verificacoes;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

/**
 * RESPONSAVEL: cadastro complementar (1:1) de um usuário com perfil RESPONSAVEL.
 * Nome, e-mail e telefone ficam só em USUARIO (ajuste A1).
 */
@Service
public class ResponsavelService extends CrudService<Responsavel, Long> {

    private final ResponsavelRepository responsavelRepository;
    private final ProfissionalRepository profissionalRepository;
    private final RelatorioAtendimentoRepository relatorioRepository;
    private final Verificacoes verificacoes;

    public ResponsavelService(ResponsavelRepository repository, AuditoriaService auditoria,
                              ProfissionalRepository profissionalRepository,
                              RelatorioAtendimentoRepository relatorioRepository, Verificacoes verificacoes) {
        super(repository, auditoria, "responsavel");
        this.responsavelRepository = repository;
        this.profissionalRepository = profissionalRepository;
        this.relatorioRepository = relatorioRepository;
        this.verificacoes = verificacoes;
    }

    /** RI-02: perfil RESPONSAVEL e sem cadastro de profissional. */
    @Override
    protected void antesDeCriar(Responsavel r) {
        Usuario u = verificacoes.usuario(r.getIdUsuario());
        if (!Verificacoes.RESPONSAVEL.equals(verificacoes.perfilDe(u))) {
            throw new RegraNegocioException("O usuário " + u.getIdUsuario() + " não tem perfil RESPONSAVEL.");
        }
        if (responsavelRepository.existsByIdUsuario(u.getIdUsuario())) {
            throw new ConflitoException("O usuário " + u.getIdUsuario() + " já tem cadastro de responsável.");
        }
        if (profissionalRepository.existsByIdUsuario(u.getIdUsuario())) {
            throw new RegraNegocioException("Um usuário não pode ser responsável e profissional ao mesmo tempo.");
        }
    }

    @Override
    protected Set<String> camposProtegidos() {
        return Set.of("idUsuario");
    }

    /** Sem coluna de situação: exclusão física (o banco bloqueia se houver vínculos ou consentimentos). */
    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.FISICA;
    }

    /**
     * Relatórios que o responsável pode ver (equivalente à VW_RELATORIO_RESPONSAVEL da modelagem):
     * só LIBERADO_RESPONSAVEL, de crianças com vínculo ATIVO e pode_consultar_dados = 1.
     */
    @Transactional(readOnly = true)
    public List<RelatorioResponsavelDTO> relatoriosLiberados(Long idResponsavel) {
        buscar(idResponsavel);
        return relatorioRepository.liberadosParaResponsavel(idResponsavel, StatusVinculo.ATIVO,
                SituacaoRelatorio.LIBERADO_RESPONSAVEL);
    }
}
