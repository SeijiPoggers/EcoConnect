package br.com.ecoconnect.api.model.enums;

/** Situação da autorização de consentimento. Valores idênticos ao ENUM do MySQL. */
public enum SituacaoAutorizacao {
    REGISTRADA, REVOGADA, EXPIRADA
}
