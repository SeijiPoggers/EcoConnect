package br.com.ecoconnect.api.service.app;

import br.com.ecoconnect.api.exception.NaoAutorizadoException;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.model.entity.Profissional;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.repository.ProfissionalRepository;
import br.com.ecoconnect.api.seguranca.ContextoAtual;
import br.com.ecoconnect.api.seguranca.ContextoUsuario;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.pessoa.ProfissionalEspecialidadeService;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Gestão de profissionais: área de atuação, especialidades, instituições, situação de acesso,
 * pessoas sob acompanhamento, agenda e atividades. A instituição vê apenas os seus membros.
 */
@Service
public class ProfissionaisAppService {

    private final Consultas consultas;
    private final ProfissionalRepository profissionalRepository;
    private final ProfissionalEspecialidadeService especialidadeService;
    private final AuditoriaService auditoria;

    public ProfissionaisAppService(Consultas consultas, ProfissionalRepository profissionalRepository,
                                   ProfissionalEspecialidadeService especialidadeService, AuditoriaService auditoria) {
        this.consultas = consultas;
        this.profissionalRepository = profissionalRepository;
        this.especialidadeService = especialidadeService;
        this.auditoria = auditoria;
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> listar(String texto) {
        ContextoUsuario ctx = exigirGestao();
        StringBuilder sql = new StringBuilder("SELECT p.id_profissional AS idProfissional, u.id_usuario AS idUsuario, u.nome_completo AS nome, "
                + "p.conselho_profissional AS conselho, p.registro_profissional AS registro, p.ativo, u.status AS situacaoConta, "
                + "(SELECT GROUP_CONCAT(e.nome ORDER BY pe.principal DESC SEPARATOR ', ') FROM profissional_especialidade pe "
                + " JOIN especialidade e ON e.id_especialidade = pe.id_especialidade WHERE pe.id_profissional = p.id_profissional) AS especialidades, "
                + "(SELECT GROUP_CONCAT(i.nome SEPARATOR ', ') FROM instituicao_membro m JOIN instituicao i ON i.id_instituicao = m.id_instituicao "
                + " WHERE m.id_usuario = u.id_usuario AND m.ativo = 1) AS instituicoes, "
                + "(SELECT COUNT(*) FROM crianca_profissional cp WHERE cp.id_profissional = p.id_profissional AND cp.status = 'ATIVO') AS pessoas, "
                + "(SELECT COUNT(*) FROM agendamento_profissional ap JOIN agendamento a ON a.id_agendamento = ap.id_agendamento "
                + " WHERE ap.id_profissional = p.id_profissional AND a.status = 'CONFIRMADO' AND a.data_hora_inicio >= NOW()) AS proximasSessoes "
                + "FROM profissional p JOIN usuario u ON u.id_usuario = p.id_usuario WHERE 1 = 1");
        List<Object> args = new ArrayList<>();
        if (ctx.adminInstitucional()) {
            List<Long> inst = new ArrayList<>(ctx.instituicoes());
            sql.append(" AND u.id_usuario IN (SELECT m.id_usuario FROM instituicao_membro m WHERE m.ativo = 1 AND m.id_instituicao IN (")
                    .append(Consultas.marcadores(inst)).append("))");
            args.addAll(inst);
        }
        if (RedeService.vazio(texto) != null) {
            sql.append(" AND LOWER(u.nome_completo) LIKE ?");
            args.add("%" + texto.trim().toLowerCase(Locale.ROOT) + "%");
        }
        sql.append(" ORDER BY p.ativo DESC, u.nome_completo");
        return consultas.lista(sql.toString(), args.toArray());
    }

    @Transactional(readOnly = true)
    public Map<String, Object> detalhe(Long idProfissional) {
        ContextoUsuario ctx = exigirGestao();
        Map<String, Object> p = listar(null).stream().filter(l -> ((Number) l.get("idProfissional")).longValue() == idProfissional)
                .findFirst().orElseThrow(() -> new NaoEncontradoException("profissional", idProfissional));
        Map<String, Object> r = new LinkedHashMap<>(p);
        r.put("listaEspecialidades", consultas.lista("SELECT pe.id_especialidade AS idEspecialidade, e.nome, pe.principal "
                + "FROM profissional_especialidade pe JOIN especialidade e ON e.id_especialidade = pe.id_especialidade "
                + "WHERE pe.id_profissional = ? ORDER BY pe.principal DESC, e.nome", idProfissional));
        boolean vePessoas = ctx.administrador() || idProfissional.equals(ctx.idProfissional());
        if (vePessoas) {
            r.put("pessoasAcompanhadas", consultas.lista("SELECT c.id_crianca AS idCrianca, c.nome_completo AS nome, cp.funcao, "
                    + Consultas.d("cp.data_inicio") + " AS desde FROM crianca_profissional cp JOIN crianca c ON c.id_crianca = cp.id_crianca "
                    + "WHERE cp.id_profissional = ? AND cp.status = 'ATIVO' ORDER BY c.nome_completo", idProfissional));
            r.put("agenda", consultas.lista("SELECT a.id_agendamento AS idAgendamento, c.nome_completo AS pessoa, a.status, "
                    + Consultas.dt("a.data_hora_inicio") + " AS inicio FROM agendamento_profissional ap JOIN agendamento a "
                    + "ON a.id_agendamento = ap.id_agendamento JOIN crianca c ON c.id_crianca = a.id_crianca WHERE ap.id_profissional = ? "
                    + "AND a.status = 'CONFIRMADO' AND a.data_hora_inicio >= ? ORDER BY a.data_hora_inicio LIMIT 20", idProfissional,
                    LocalDateTime.now().minusHours(1)));
            r.put("atividadesRecentes", consultas.lista("SELECT c.nome_completo AS pessoa, rs.tipo_atendimento AS tipo, "
                    + Consultas.dt("t.data_hora_inicio_real") + " AS data FROM atendimento_profissional tp JOIN atendimento t "
                    + "ON t.id_atendimento = tp.id_atendimento JOIN agendamento a ON a.id_agendamento = t.id_agendamento "
                    + "JOIN crianca c ON c.id_crianca = a.id_crianca LEFT JOIN registro_sessao rs ON rs.id_atendimento = t.id_atendimento "
                    + "WHERE tp.id_profissional = ? ORDER BY t.data_hora_inicio_real DESC LIMIT 10", idProfissional));
        }
        r.put("podeEditar", ctx.administrador());
        return r;
    }

    public record AlteracaoProfissional(String conselho, String registro, Boolean ativo) {
    }

    @Transactional
    public Map<String, Object> alterar(Long idProfissional, AlteracaoProfissional d) {
        exigirAdministrador();
        Profissional p = profissionalRepository.findById(idProfissional).orElseThrow(() -> new NaoEncontradoException("profissional", idProfissional));
        String antes = auditoria.json(p);
        p.setConselhoProfissional(PessoasService.texto(d.conselho(), 20));
        p.setRegistroProfissional(PessoasService.texto(d.registro(), 30));
        if (d.ativo() != null) p.setAtivo(d.ativo());
        Profissional salvo = profissionalRepository.saveAndFlush(p);
        auditoria.registrar(AcaoAuditoria.ATUALIZACAO, "profissional", salvo, antes, salvo);
        return detalhe(idProfissional);
    }

    public record NovaEspecialidade(Integer idEspecialidade, Boolean principal) {
    }

    @Transactional
    public Map<String, Object> adicionarEspecialidade(Long idProfissional, NovaEspecialidade d) {
        exigirAdministrador();
        especialidadeService.adicionar(idProfissional, d.idEspecialidade(), Boolean.TRUE.equals(d.principal()));
        return detalhe(idProfissional);
    }

    @Transactional
    public Map<String, Object> removerEspecialidade(Long idProfissional, Integer idEspecialidade) {
        exigirAdministrador();
        especialidadeService.remover(idProfissional, idEspecialidade);
        return detalhe(idProfissional);
    }

    private ContextoUsuario exigirGestao() {
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (!ctx.equipe() && !ctx.adminInstitucional()) {
            throw new NaoAutorizadoException(403, "A gestão de profissionais é da equipe e das instituições.");
        }
        return ctx;
    }

    private void exigirAdministrador() {
        if (!ContextoAtual.exigir().administrador()) throw new NaoAutorizadoException(403, "Somente o administrador altera profissionais.");
    }
}
