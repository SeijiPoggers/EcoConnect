package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.Auditoria;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `auditoria` (Spring Data JPA). */
public interface AuditoriaRepository extends JpaRepository<Auditoria, Long> {
}
