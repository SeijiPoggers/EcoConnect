package br.com.ecoconnect.api.service.comunicacao;

import br.com.ecoconnect.api.dto.AnaliseFila;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.FilaEspera;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.SituacaoFila;
import br.com.ecoconnect.api.model.enums.TipoNotificacao;
import br.com.ecoconnect.api.repository.FilaEsperaRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.NotificacaoService;
import br.com.ecoconnect.api.service.Verificacoes;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.EnumSet;
import java.util.Objects;
import java.util.Set;

/**
 * FILA_ESPERA: solicitação de ingresso e sua análise institucional.
 * RI-16: sem pontuação automática; AGUARDANDO_VAGA, CONVOCADA e NAO_ACEITA exigem analista e justificativa.
 */
@Service
public class FilaEsperaService extends CrudService<FilaEspera, Long> {

    private static final Set<SituacaoFila> FINAIS = EnumSet.of(SituacaoFila.INGRESSOU, SituacaoFila.DESISTENTE, SituacaoFila.NAO_ACEITA);
    private static final Set<SituacaoFila> EXIGE_JUSTIFICATIVA = EnumSet.of(SituacaoFila.AGUARDANDO_VAGA, SituacaoFila.CONVOCADA, SituacaoFila.NAO_ACEITA);

    private final Verificacoes verificacoes;
    private final NotificacaoService notificacaoService;

    public FilaEsperaService(FilaEsperaRepository repository, AuditoriaService auditoria,
                             Verificacoes verificacoes, NotificacaoService notificacaoService) {
        super(repository, auditoria, "fila_espera");
        this.verificacoes = verificacoes;
        this.notificacaoService = notificacaoService;
    }

    @Override
    protected void antesDeCriar(FilaEspera f) {
        verificacoes.crianca(f.getIdCrianca());
        verificacoes.usuarioAtivo(f.getIdUsuarioSolicitante(), "Solicitante");
        verificacoes.responsavelVinculado(f.getIdUsuarioSolicitante(), f.getIdCrianca());
        f.setSituacao(SituacaoFila.SOLICITADA);
        f.setIdUsuarioAnalise(null);
        f.setDataAnalise(null);
        f.setJustificativaDecisao(null);
        f.setCriteriosInstitucionais(null);
        f.setNivelPrioridade(null);
    }

    @Transactional
    public FilaEspera analisar(Long id, AnaliseFila dados) {
        FilaEspera f = buscar(id);
        if (FINAIS.contains(f.getSituacao())) {
            throw new RegraNegocioException("A solicitação já foi encerrada (" + f.getSituacao() + ").");
        }
        if (dados.situacao() == SituacaoFila.SOLICITADA) {
            throw new RegraNegocioException("Informe a nova situação (EM_ANALISE, AGUARDANDO_VAGA, CONVOCADA, INGRESSOU, DESISTENTE ou NAO_ACEITA).");
        }
        String justificativa = dados.justificativaDecisao() == null || dados.justificativaDecisao().isBlank()
                ? null : dados.justificativaDecisao().trim();
        if (EXIGE_JUSTIFICATIVA.contains(dados.situacao()) && justificativa == null) {
            throw new RegraNegocioException("A situação " + dados.situacao() + " exige justificativa da decisão.");
        }
        verificacoes.usuarioDaEquipe(dados.idUsuarioAnalise(), "Quem analisa a fila");
        String antes = auditoria.json(f);
        f.setSituacao(dados.situacao());
        f.setIdUsuarioAnalise(dados.idUsuarioAnalise());
        f.setDataAnalise(LocalDateTime.now());
        if (justificativa != null) f.setJustificativaDecisao(justificativa);
        if (dados.criteriosInstitucionais() != null) f.setCriteriosInstitucionais(dados.criteriosInstitucionais());
        if (dados.nivelPrioridade() != null) f.setNivelPrioridade(dados.nivelPrioridade());
        FilaEspera salvo = salvarAlteracao(f, antes, AcaoAuditoria.ATUALIZACAO);

        if (!Objects.equals(dados.idUsuarioAnalise(), salvo.getIdUsuarioSolicitante())) {
            notificacaoService.notificar(salvo.getIdUsuarioSolicitante(), TipoNotificacao.FILA_ESPERA,
                    "Fila de espera atualizada", "Sua solicitação de ingresso está agora: " + salvo.getSituacao() + ".",
                    null, null, null);
        }
        return salvo;
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.PROIBIDA;
    }

    @Override
    protected String motivoExclusaoProibida() {
        return "A fila de espera não é excluída: registre a situação DESISTENTE pela análise.";
    }
}
