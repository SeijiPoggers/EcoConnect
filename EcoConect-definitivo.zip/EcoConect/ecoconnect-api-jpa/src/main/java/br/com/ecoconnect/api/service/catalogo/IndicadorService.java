package br.com.ecoconnect.api.service.catalogo;

import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Indicador;
import br.com.ecoconnect.api.repository.IndicadorRepository;
import br.com.ecoconnect.api.repository.ObjetivoIndicadorRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;

/**
 * Indicadores de evolução (catálogo). DELETE apenas desativa.
 * O tipo de medida não muda depois que o indicador foi vinculado a um objetivo.
 */
@Service
public class IndicadorService extends CrudService<Indicador, Long> {

    private final ObjetivoIndicadorRepository objetivoIndicadorRepository;

    public IndicadorService(IndicadorRepository repository, AuditoriaService auditoria,
                            ObjetivoIndicadorRepository objetivoIndicadorRepository) {
        super(repository, auditoria, "indicador");
        this.objetivoIndicadorRepository = objetivoIndicadorRepository;
    }

    @Override
    protected void validarAtualizacao(Indicador atual, Indicador dados) {
        if (dados.getTipoMedida() != atual.getTipoMedida()
                && objetivoIndicadorRepository.existsByIdIndicador(atual.getIdIndicador())) {
            throw new RegraNegocioException("O indicador já está vinculado a objetivos: o tipo de medida não pode mudar.");
        }
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.LOGICA;
    }

    @Override
    protected void aplicarExclusaoLogica(Indicador e) {
        e.setAtivo(false);
    }
}
