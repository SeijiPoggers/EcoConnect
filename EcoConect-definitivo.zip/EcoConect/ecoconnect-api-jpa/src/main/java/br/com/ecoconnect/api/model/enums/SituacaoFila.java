package br.com.ecoconnect.api.model.enums;

/** Situação na fila de espera. Valores idênticos ao ENUM do MySQL. */
public enum SituacaoFila {
    SOLICITADA, EM_ANALISE, AGUARDANDO_VAGA, CONVOCADA, INGRESSOU, DESISTENTE, NAO_ACEITA
}
