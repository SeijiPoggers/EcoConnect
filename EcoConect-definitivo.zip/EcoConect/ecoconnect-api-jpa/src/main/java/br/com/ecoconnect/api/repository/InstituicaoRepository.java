package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.Instituicao;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InstituicaoRepository extends JpaRepository<Instituicao, Long> {

    List<Instituicao> findByAtivaTrueOrderByNomeAsc();
    boolean existsByCnpj(String cnpj);
    boolean existsByCnpjAndIdInstituicaoNot(String cnpj, Long idInstituicao);
    long countByAtivaTrue();

}
