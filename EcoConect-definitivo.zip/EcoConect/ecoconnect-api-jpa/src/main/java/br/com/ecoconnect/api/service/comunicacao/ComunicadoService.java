package br.com.ecoconnect.api.service.comunicacao;

import br.com.ecoconnect.api.exception.ConflitoException;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Comunicado;
import br.com.ecoconnect.api.model.entity.ComunicadoDestinatario;
import br.com.ecoconnect.api.model.entity.ComunicadoDestinatarioId;
import br.com.ecoconnect.api.model.entity.Responsavel;
import br.com.ecoconnect.api.model.enums.AbrangenciaComunicado;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.SituacaoComunicado;
import br.com.ecoconnect.api.model.enums.StatusUsuario;
import br.com.ecoconnect.api.model.enums.TipoNotificacao;
import br.com.ecoconnect.api.repository.ComunicadoDestinatarioRepository;
import br.com.ecoconnect.api.repository.ComunicadoRepository;
import br.com.ecoconnect.api.repository.ResponsavelRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.NotificacaoService;
import br.com.ecoconnect.api.service.Verificacoes;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

/**
 * COMUNICADO e COMUNICADO_DESTINATARIO.
 * Fluxo: RASCUNHO (editável, destinatários ajustáveis) -> PUBLICADO (gera notificações) ou CANCELADO.
 * Abrangência TODOS inclui automaticamente todos os responsáveis com conta ATIVA ao publicar.
 * RI-18: registra o criador e a leitura de cada destinatário.
 */
@Service
public class ComunicadoService extends CrudService<Comunicado, Long> {

    private final ComunicadoDestinatarioRepository destinatarioRepository;
    private final ResponsavelRepository responsavelRepository;
    private final NotificacaoService notificacaoService;
    private final Verificacoes verificacoes;

    public ComunicadoService(ComunicadoRepository repository, AuditoriaService auditoria,
                             ComunicadoDestinatarioRepository destinatarioRepository,
                             ResponsavelRepository responsavelRepository,
                             NotificacaoService notificacaoService, Verificacoes verificacoes) {
        super(repository, auditoria, "comunicado");
        this.destinatarioRepository = destinatarioRepository;
        this.responsavelRepository = responsavelRepository;
        this.notificacaoService = notificacaoService;
        this.verificacoes = verificacoes;
    }

    @Override
    protected void antesDeCriar(Comunicado c) {
        verificacoes.usuarioDaEquipe(c.getIdUsuarioCriador(), "Quem cria o comunicado");
        c.setSituacao(SituacaoComunicado.RASCUNHO);
        c.setDataPublicacao(null);
        validarGrupo(c);
    }

    @Override
    protected void validarAtualizacao(Comunicado atual, Comunicado dados) {
        exigirRascunho(atual);
    }

    @Override
    protected Set<String> camposProtegidos() {
        return Set.of("idUsuarioCriador", "situacao", "dataPublicacao");
    }

    @Override
    protected void antesDeSalvarAtualizacao(Comunicado c) {
        validarGrupo(c);
    }

    /** Rascunho pode ser apagado (junto com seus destinatários). */
    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.FISICA;
    }

    @Override
    protected void validarExclusaoFisica(Comunicado c) {
        if (c.getSituacao() != SituacaoComunicado.RASCUNHO) {
            throw new RegraNegocioException("Só rascunhos podem ser excluídos. Comunicados publicados podem ser CANCELADOS.");
        }
        destinatarioRepository.deleteAll(destinatarioRepository.findByIdComunicado(c.getIdComunicado()));
        destinatarioRepository.flush();
    }

    @Transactional
    public Comunicado publicar(Long id) {
        Comunicado c = buscar(id);
        exigirRascunho(c);
        if (c.getAbrangencia() == AbrangenciaComunicado.TODOS) {
            for (Responsavel r : responsavelRepository.comUsuarioNoStatus(StatusUsuario.ATIVO)) {
                ComunicadoDestinatarioId did = new ComunicadoDestinatarioId(id, r.getIdResponsavel());
                if (!destinatarioRepository.existsById(did)) {
                    ComunicadoDestinatario d = new ComunicadoDestinatario();
                    d.setIdComunicado(id);
                    d.setIdResponsavel(r.getIdResponsavel());
                    destinatarioRepository.save(d);
                }
            }
            destinatarioRepository.flush();
        }
        List<ComunicadoDestinatario> destinatarios = destinatarioRepository.findByIdComunicado(id);
        if (destinatarios.isEmpty()) {
            throw new RegraNegocioException("Adicione destinatários antes de publicar (ou use abrangência TODOS).");
        }
        String antes = auditoria.json(c);
        c.setSituacao(SituacaoComunicado.PUBLICADO);
        c.setDataPublicacao(LocalDateTime.now());
        Comunicado salvo = salvarAlteracao(c, antes, AcaoAuditoria.ATUALIZACAO);
        for (ComunicadoDestinatario d : destinatarios) {
            responsavelRepository.findById(d.getIdResponsavel()).ifPresent(r ->
                    notificacaoService.notificar(r.getIdUsuario(), TipoNotificacao.COMUNICADO, salvo.getTitulo(),
                            resumo(salvo.getMensagem()), salvo.getIdComunicado(), null, null));
        }
        return salvo;
    }

    @Transactional
    public Comunicado cancelar(Long id) {
        Comunicado c = buscar(id);
        if (c.getSituacao() == SituacaoComunicado.CANCELADO) {
            throw new RegraNegocioException("O comunicado já está cancelado.");
        }
        String antes = auditoria.json(c);
        c.setSituacao(SituacaoComunicado.CANCELADO);
        return salvarAlteracao(c, antes, AcaoAuditoria.ATUALIZACAO);
    }

    // ------------------------------------------------------------- destinatários

    @Transactional(readOnly = true)
    public List<ComunicadoDestinatario> destinatarios(Long idComunicado) {
        buscar(idComunicado);
        return destinatarioRepository.findByIdComunicado(idComunicado);
    }

    @Transactional
    public ComunicadoDestinatario adicionarDestinatario(Long idComunicado, Long idResponsavel) {
        exigirRascunho(buscar(idComunicado));
        verificacoes.responsavel(idResponsavel);
        ComunicadoDestinatarioId id = new ComunicadoDestinatarioId(idComunicado, idResponsavel);
        if (destinatarioRepository.existsById(id)) throw new ConflitoException("Responsável já é destinatário.");
        ComunicadoDestinatario d = new ComunicadoDestinatario();
        d.setIdComunicado(idComunicado);
        d.setIdResponsavel(idResponsavel);
        ComunicadoDestinatario salvo = destinatarioRepository.saveAndFlush(d);
        auditoria.registrar(AcaoAuditoria.CRIACAO, "comunicado_destinatario", salvo, null, salvo);
        return salvo;
    }

    @Transactional
    public void removerDestinatario(Long idComunicado, Long idResponsavel) {
        exigirRascunho(buscar(idComunicado));
        ComunicadoDestinatario d = destinatario(idComunicado, idResponsavel);
        String antes = auditoria.json(d);
        destinatarioRepository.delete(d);
        destinatarioRepository.flush();
        auditoria.registrar(AcaoAuditoria.ATUALIZACAO, "comunicado_destinatario", d, antes, null);
    }

    /** O responsável leu o comunicado. */
    @Transactional
    public ComunicadoDestinatario registrarLeitura(Long idComunicado, Long idResponsavel) {
        Comunicado c = buscar(idComunicado);
        if (c.getSituacao() != SituacaoComunicado.PUBLICADO) {
            throw new RegraNegocioException("Só comunicados PUBLICADOS podem ser lidos.");
        }
        ComunicadoDestinatario d = destinatario(idComunicado, idResponsavel);
        if (d.getDataLeitura() == null) {
            d.setDataLeitura(LocalDateTime.now());
            d = destinatarioRepository.saveAndFlush(d);
        }
        return d;
    }

    // ------------------------------------------------------------------

    private ComunicadoDestinatario destinatario(Long idComunicado, Long idResponsavel) {
        ComunicadoDestinatarioId id = new ComunicadoDestinatarioId(idComunicado, idResponsavel);
        return destinatarioRepository.findById(id).orElseThrow(() -> new NaoEncontradoException("comunicado_destinatario", id));
    }

    private static void exigirRascunho(Comunicado c) {
        if (c.getSituacao() != SituacaoComunicado.RASCUNHO) {
            throw new RegraNegocioException("O comunicado não está mais em RASCUNHO (situação: " + c.getSituacao() + ").");
        }
    }

    private static void validarGrupo(Comunicado c) {
        if (c.getAbrangencia() == AbrangenciaComunicado.GRUPO
                && (c.getDescricaoGrupo() == null || c.getDescricaoGrupo().isBlank())) {
            throw new RegraNegocioException("Abrangência GRUPO exige descricaoGrupo.");
        }
    }

    private static String resumo(String texto) {
        return texto.length() <= 500 ? texto : texto.substring(0, 497) + "...";
    }
}
