package br.com.ecoconnect.api.service.pessoa;

import org.springframework.transaction.annotation.Transactional;

import org.springframework.data.domain.Pageable;

import java.util.List;

import br.com.ecoconnect.api.dto.Pagina;

import br.com.ecoconnect.api.model.entity.Crianca;
import br.com.ecoconnect.api.model.enums.SituacaoEcocura;
import br.com.ecoconnect.api.repository.CriancaRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.Verificacoes;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;

/**
 * CRIANCA. A idade não é armazenada (calcula-se por data_nascimento).
 * data_atualizacao é preenchida automaticamente a cada gravação.
 * DELETE não apaga dados de saúde: muda situacao_ecocura para INATIVA.
 */
@Service
public class CriancaService extends CrudService<Crianca, Long> {

    public CriancaService(CriancaRepository repository, AuditoriaService auditoria) {
        super(repository, auditoria, "crianca");
    }

    @Override
    protected void antesDeCriar(Crianca c) {
        validar(c);
    }

    @Override
    protected void antesDeSalvarAtualizacao(Crianca c) {
        validar(c);
    }

    private static void validar(Crianca c) {
        Verificacoes.naoFutura(c.getDataNascimento(), "A data de nascimento");
        if (c.getCpf() != null && c.getCpf().isBlank()) c.setCpf(null);
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.LOGICA;
    }

    @Override
    protected void aplicarExclusaoLogica(Crianca c) {
        c.setSituacaoEcocura(SituacaoEcocura.INATIVA);
    }

    /**
     * Para quem não é administrador, a listagem mostra só as pessoas do seu escopo
     * (filtros aceitos: nomeCompleto e situacaoEcocura).
     */
    @Override
    @Transactional(readOnly = true)
    public Pagina<Crianca> listar(Crianca filtro, Pageable pageable) {
        if (!escopoRestrito() || filtro.getIdCrianca() != null) return super.listar(filtro, pageable);
        String nome = filtro.getNomeCompleto() == null ? null : filtro.getNomeCompleto().toLowerCase(java.util.Locale.ROOT);
        List<Crianca> todas = repository.findAllById(escopo().criancas()).stream()
                .filter(c -> nome == null || c.getNomeCompleto().toLowerCase(java.util.Locale.ROOT).contains(nome))
                .filter(c -> filtro.getSituacaoEcocura() == null || filtro.getSituacaoEcocura() == c.getSituacaoEcocura())
                .sorted(java.util.Comparator.comparing(Crianca::getNomeCompleto, String.CASE_INSENSITIVE_ORDER))
                .toList();
        int tamanho = Math.max(1, pageable.getPageSize());
        int inicio = Math.min(todas.size(), pageable.getPageNumber() * tamanho);
        int fim = Math.min(todas.size(), inicio + tamanho);
        return new Pagina<>(todas.subList(inicio, fim), pageable.getPageNumber(), tamanho, todas.size(),
                (todas.size() + tamanho - 1) / tamanho);
    }
}
