package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;

/** Tabela `registro_sessao` (migration V2/V3). Gerada no mesmo padrão das entidades originais. */
@Entity
@Table(name = "registro_sessao")
public class RegistroSessao implements Entidade<Long> {

    @Id
    @Column(name = "id_atendimento", nullable = false)
    private Long idAtendimento;

    @Size(max = 80)
    @Column(name = "tipo_atendimento", nullable = false, length = 80)
    private String tipoAtendimento;

    @Column(name = "objetivos_trabalhados", columnDefinition = "TEXT")
    private String objetivosTrabalhados;

    @Column(name = "evolucao_observada", columnDefinition = "TEXT")
    private String evolucaoObservada;

    @Column(name = "dificuldades_observadas", columnDefinition = "TEXT")
    private String dificuldadesObservadas;

    @Column(name = "recomendacoes", columnDefinition = "TEXT")
    private String recomendacoes;

    @Column(name = "proximos_passos", columnDefinition = "TEXT")
    private String proximosPassos;

    @Column(name = "id_usuario_registro", nullable = false)
    private Long idUsuarioRegistro;

    @Column(name = "data_registro")
    private LocalDateTime dataRegistro;

    @Column(name = "id_usuario_atualizacao")
    private Long idUsuarioAtualizacao;

    @Column(name = "data_atualizacao")
    private LocalDateTime dataAtualizacao;

    @PrePersist
    void aoInserir() {
        if (dataRegistro == null) dataRegistro = LocalDateTime.now();
    }

    @Override
    public Long chave() {
        return idAtendimento;
    }

    @Override
    public void definirChave(Long id) {
        this.idAtendimento = id;
    }

    public Long getIdAtendimento() {
        return idAtendimento;
    }

    public void setIdAtendimento(Long idAtendimento) {
        this.idAtendimento = idAtendimento;
    }

    public String getTipoAtendimento() {
        return tipoAtendimento;
    }

    public void setTipoAtendimento(String tipoAtendimento) {
        this.tipoAtendimento = tipoAtendimento;
    }

    public String getObjetivosTrabalhados() {
        return objetivosTrabalhados;
    }

    public void setObjetivosTrabalhados(String objetivosTrabalhados) {
        this.objetivosTrabalhados = objetivosTrabalhados;
    }

    public String getEvolucaoObservada() {
        return evolucaoObservada;
    }

    public void setEvolucaoObservada(String evolucaoObservada) {
        this.evolucaoObservada = evolucaoObservada;
    }

    public String getDificuldadesObservadas() {
        return dificuldadesObservadas;
    }

    public void setDificuldadesObservadas(String dificuldadesObservadas) {
        this.dificuldadesObservadas = dificuldadesObservadas;
    }

    public String getRecomendacoes() {
        return recomendacoes;
    }

    public void setRecomendacoes(String recomendacoes) {
        this.recomendacoes = recomendacoes;
    }

    public String getProximosPassos() {
        return proximosPassos;
    }

    public void setProximosPassos(String proximosPassos) {
        this.proximosPassos = proximosPassos;
    }

    public Long getIdUsuarioRegistro() {
        return idUsuarioRegistro;
    }

    public void setIdUsuarioRegistro(Long idUsuarioRegistro) {
        this.idUsuarioRegistro = idUsuarioRegistro;
    }

    public LocalDateTime getDataRegistro() {
        return dataRegistro;
    }

    public void setDataRegistro(LocalDateTime dataRegistro) {
        this.dataRegistro = dataRegistro;
    }

    public Long getIdUsuarioAtualizacao() {
        return idUsuarioAtualizacao;
    }

    public void setIdUsuarioAtualizacao(Long idUsuarioAtualizacao) {
        this.idUsuarioAtualizacao = idUsuarioAtualizacao;
    }

    public LocalDateTime getDataAtualizacao() {
        return dataAtualizacao;
    }

    public void setDataAtualizacao(LocalDateTime dataAtualizacao) {
        this.dataAtualizacao = dataAtualizacao;
    }
}
