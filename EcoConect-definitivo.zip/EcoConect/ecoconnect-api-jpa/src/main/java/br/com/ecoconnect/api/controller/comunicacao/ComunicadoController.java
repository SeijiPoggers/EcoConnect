package br.com.ecoconnect.api.controller.comunicacao;

import br.com.ecoconnect.api.controller.base.CrudController;
import br.com.ecoconnect.api.dto.DestinatarioComunicado;
import br.com.ecoconnect.api.model.entity.Comunicado;
import br.com.ecoconnect.api.model.entity.ComunicadoDestinatario;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.comunicacao.ComunicadoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Comunicados institucionais e seus destinatários. PUT e DELETE só em RASCUNHO. */
@RestController
@RequestMapping("/api/comunicados")
public class ComunicadoController extends CrudController<Comunicado, Long> {

    private final ComunicadoService service;

    public ComunicadoController(ComunicadoService service) {
        this.service = service;
    }

    @Override
    protected CrudService<Comunicado, Long> service() {
        return service;
    }

    @PatchMapping("/{id}/publicacao")
    public Comunicado publicar(@PathVariable Long id) {
        return service.publicar(id);
    }

    @PatchMapping("/{id}/cancelamento")
    public Comunicado cancelar(@PathVariable Long id) {
        return service.cancelar(id);
    }

    @GetMapping("/{id}/destinatarios")
    public List<ComunicadoDestinatario> destinatarios(@PathVariable Long id) {
        return service.destinatarios(id);
    }

    @PostMapping("/{id}/destinatarios")
    @ResponseStatus(HttpStatus.CREATED)
    public ComunicadoDestinatario adicionar(@PathVariable Long id, @Valid @RequestBody DestinatarioComunicado dados) {
        return service.adicionarDestinatario(id, dados.idResponsavel());
    }

    @DeleteMapping("/{id}/destinatarios/{idResponsavel}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void remover(@PathVariable Long id, @PathVariable Long idResponsavel) {
        service.removerDestinatario(id, idResponsavel);
    }

    @PatchMapping("/{id}/destinatarios/{idResponsavel}/leitura")
    public ComunicadoDestinatario leitura(@PathVariable Long id, @PathVariable Long idResponsavel) {
        return service.registrarLeitura(id, idResponsavel);
    }
}
