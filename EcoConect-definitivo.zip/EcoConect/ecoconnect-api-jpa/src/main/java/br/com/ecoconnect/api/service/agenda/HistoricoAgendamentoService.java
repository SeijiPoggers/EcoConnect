package br.com.ecoconnect.api.service.agenda;

import br.com.ecoconnect.api.model.entity.HistoricoAgendamento;
import br.com.ecoconnect.api.repository.HistoricoAgendamentoRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.base.CrudService;
import org.springframework.stereotype.Service;

/** HISTORICO_AGENDAMENTO: somente leitura pela API; as linhas são gravadas pelo AgendamentoService. */
@Service
public class HistoricoAgendamentoService extends CrudService<HistoricoAgendamento, Long> {

    public HistoricoAgendamentoService(HistoricoAgendamentoRepository repository, AuditoriaService auditoria) {
        super(repository, auditoria, "historico_agendamento");
    }

    // ------------------------------------------------------------------ escopo por pessoa
    @Override
    protected Long criancaDoRegistro(HistoricoAgendamento h) {
        return escopo() == null ? null : escopo().criancaDoAgendamento(h.getIdAgendamento());
    }

    @Override
    protected boolean registroDePessoa() {
        return true;
    }
}
