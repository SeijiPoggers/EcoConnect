package br.com.ecoconnect.api.exception;

import java.time.LocalDateTime;
import java.util.Map;

/** Formato padrão de todos os erros da API. */
public record ErroResposta(
        LocalDateTime dataHora,
        int status,
        String erro,
        String mensagem,
        Map<String, String> campos) {

    public static ErroResposta de(int status, String erro, String mensagem) {
        return new ErroResposta(LocalDateTime.now(), status, erro, mensagem, null);
    }
}
