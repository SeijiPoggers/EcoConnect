package br.com.ecoconnect.api.service.app;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import java.sql.PreparedStatement;
import java.sql.Statement;
import org.springframework.stereotype.Component;

/**
 * Consultas de leitura agregadas (painel, agenda, trajetória, relatórios). As colunas recebem
 * apelidos em camelCase e as datas saem como texto ISO (aaaa-mm-ddThh:mm:ss), prontas para o JSON.
 * Todos os valores variáveis são passados como parâmetros (?), nunca concatenados (sem SQL injection).
 */
@Component
public class Consultas {

    public static final String DT = "'%Y-%m-%dT%H:%i:%s'";
    public static final String D = "'%Y-%m-%d'";

    private final JdbcTemplate jdbc;

    public Consultas(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<Map<String, Object>> lista(String sql, Object... args) {
        return jdbc.queryForList(sql, args);
    }

    public Map<String, Object> um(String sql, Object... args) {
        List<Map<String, Object>> r = jdbc.queryForList(sql, args);
        return r.isEmpty() ? null : r.get(0);
    }

    public long contar(String sql, Object... args) {
        Long n = jdbc.queryForObject(sql, Long.class, args);
        return n == null ? 0 : n;
    }

    public int executar(String sql, Object... args) {
        return jdbc.update(sql, args);
    }

    /** INSERT que devolve a chave gerada (AUTO_INCREMENT). */
    public long inserir(String sql, Object... args) {
        KeyHolder chave = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            return ps;
        }, chave);
        Number n = chave.getKey();
        if (n == null) throw new IllegalStateException("O banco não devolveu a chave gerada.");
        return n.longValue();
    }

    /** Número inteiro de uma consulta de uma linha e uma coluna (null vira 0). */
    public long numero(String sql, Object... args) {
        List<Long> r = jdbc.queryForList(sql, Long.class, args);
        return r.isEmpty() || r.get(0) == null ? 0 : r.get(0);
    }

    public List<Long> ids(String sql, Object... args) {
        return jdbc.queryForList(sql, Long.class, args);
    }

    /** "?,?,?" para cláusulas IN com coleção (vazia vira "NULL", que não casa com nada). */
    public static String marcadores(Collection<?> itens) {
        return itens.isEmpty() ? "NULL" : String.join(",", Collections.nCopies(itens.size(), "?"));
    }

    public static String dt(String coluna) {
        return "DATE_FORMAT(" + coluna + ", " + DT + ")";
    }

    public static String d(String coluna) {
        return "DATE_FORMAT(" + coluna + ", " + D + ")";
    }
}
