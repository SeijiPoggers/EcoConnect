package br.com.ecoconnect.api.seguranca;

import br.com.ecoconnect.api.dominio.PoliticaAcesso;
import br.com.ecoconnect.api.exception.ErroResposta;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Optional;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Autenticação e autorização das rotas /api/**, executadas no servidor (não dependem do front-end):
 *  1. lê o token do cookie HttpOnly (navegador) ou do cabeçalho Authorization: Bearer (clientes de API);
 *  2. aplica a PoliticaAcesso (perfil x rota);
 *  3. exige o cabeçalho X-Requested-With nas gravações feitas com cookie (proteção CSRF);
 *  4. bloqueia o uso do sistema enquanto a troca obrigatória de senha não for feita.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 20)
public class FiltroAutenticacao extends OncePerRequestFilter {

    public static final String COOKIE = "ECOCONECT_SESSAO";
    public static final String CABECALHO_CSRF = "X-Requested-With";
    public static final String VALOR_CSRF = "EcoConect";

    private static final Logger log = LoggerFactory.getLogger(FiltroAutenticacao.class);
    private static final Set<String> METODOS_SEGUROS = Set.of("GET", "HEAD", "OPTIONS");
    private static final Set<String> LIBERADOS_NA_TROCA = Set.of("/api/auth/me", "/api/auth/senha", "/api/auth/logout",
            "/api/app/preferencias");

    private final SessaoService sessaoService;
    private final ObjectMapper mapper;

    public FiltroAutenticacao(SessaoService sessaoService, ObjectMapper mapper) {
        this.sessaoService = sessaoService;
        this.mapper = mapper;
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest req) {
        return !caminho(req).startsWith("/api/");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse resp, FilterChain chain)
            throws ServletException, IOException {
        String caminho = caminho(req);
        String metodo = req.getMethod();
        String tokenCookie = cookie(req);
        String tokenCabecalho = bearer(req);
        String token = tokenCabecalho != null ? tokenCabecalho : tokenCookie;

        ContextoUsuario ctx = null;
        if (token != null) {
            try {
                Optional<ContextoUsuario> c = sessaoService.validar(token);
                ctx = c.orElse(null);
            } catch (RuntimeException e) {
                log.error("Falha ao validar a sessão (banco indisponível?)", e);
                erro(resp, 503, "Banco indisponível", "Não foi possível verificar a sessão. Tente novamente em instantes.");
                return;
            }
        }
        if (ctx != null) req.setAttribute(ContextoAtual.ATRIBUTO, ctx);

        PoliticaAcesso.Decisao decisao = PoliticaAcesso.decidir(metodo, caminho, ctx == null ? null : ctx.perfil());
        switch (decisao) {
            case PUBLICA -> {
                chain.doFilter(req, resp);
                return;
            }
            case EXIGE_LOGIN -> {
                erro(resp, 401, "Não autorizado", token != null
                        ? "Sua sessão expirou. Entre novamente." : "Faça login para continuar.");
                return;
            }
            case NEGADA -> {
                erro(resp, 403, "Acesso negado", "Seu perfil não tem permissão para esta operação.");
                return;
            }
            default -> {
            }
        }
        if (tokenCabecalho == null && !METODOS_SEGUROS.contains(metodo)
                && !VALOR_CSRF.equals(req.getHeader(CABECALHO_CSRF))) {
            erro(resp, 403, "Acesso negado", "Requisição recusada: falta o cabeçalho de proteção "
                    + CABECALHO_CSRF + ": " + VALOR_CSRF + ".");
            return;
        }
        if (ctx != null && ctx.exigeTrocaSenha() && !LIBERADOS_NA_TROCA.contains(caminho)) {
            erro(resp, 403, "Troca de senha obrigatória", "Defina uma nova senha antes de continuar.");
            return;
        }
        chain.doFilter(req, resp);
    }

    private static String caminho(HttpServletRequest req) {
        String uri = req.getRequestURI();
        String ctx = req.getContextPath();
        if (ctx != null && !ctx.isEmpty() && uri.startsWith(ctx)) uri = uri.substring(ctx.length());
        return uri;
    }

    private static String cookie(HttpServletRequest req) {
        Cookie[] cookies = req.getCookies();
        if (cookies == null) return null;
        for (Cookie c : cookies) {
            if (COOKIE.equals(c.getName()) && c.getValue() != null && !c.getValue().isBlank()) return c.getValue();
        }
        return null;
    }

    private static String bearer(HttpServletRequest req) {
        String h = req.getHeader("Authorization");
        if (h != null && h.regionMatches(true, 0, "Bearer ", 0, 7)) {
            String t = h.substring(7).trim();
            return t.isEmpty() ? null : t;
        }
        return null;
    }

    private void erro(HttpServletResponse resp, int status, String erro, String mensagem) throws IOException {
        resp.setStatus(status);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.getWriter().write(mapper.writeValueAsString(ErroResposta.de(status, erro, mensagem)));
    }
}
