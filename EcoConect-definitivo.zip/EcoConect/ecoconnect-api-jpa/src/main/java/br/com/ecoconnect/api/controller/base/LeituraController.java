package br.com.ecoconnect.api.controller.base;

import br.com.ecoconnect.api.dto.Pagina;
import br.com.ecoconnect.api.model.entity.Entidade;
import br.com.ecoconnect.api.service.base.CrudService;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * GET da listagem (paginada e com filtros) e GET por id.
 * Exemplo: GET /api/criancas?nomeCompleto=ana&situacaoEcocura=ATIVA&page=0&size=10&sort=nomeCompleto
 */
public abstract class LeituraController<E extends Entidade<ID>, ID> {

    protected abstract CrudService<E, ID> service();

    @GetMapping
    public Pagina<E> listar(@ModelAttribute E filtro, @PageableDefault(size = 20) Pageable pageable) {
        return service().listar(filtro, pageable);
    }

    @GetMapping("/{id}")
    public E buscar(@PathVariable ID id) {
        return service().buscar(id);
    }
}
