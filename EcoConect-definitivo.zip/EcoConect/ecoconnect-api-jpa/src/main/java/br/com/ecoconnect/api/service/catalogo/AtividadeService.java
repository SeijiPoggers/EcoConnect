package br.com.ecoconnect.api.service.catalogo;

import br.com.ecoconnect.api.model.entity.Atividade;
import br.com.ecoconnect.api.repository.AtividadeRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;

/** Tipos de atividade dos atendimentos (catálogo). DELETE apenas desativa (ativo = 0). */
@Service
public class AtividadeService extends CrudService<Atividade, Integer> {

    public AtividadeService(AtividadeRepository repository, AuditoriaService auditoria) {
        super(repository, auditoria, "atividade");
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.LOGICA;
    }

    @Override
    protected void aplicarExclusaoLogica(Atividade e) {
        e.setAtivo(false);
    }
}
