package br.com.ecoconnect.api.service.app;

import br.com.ecoconnect.api.dto.MudancaStatusAgendamento;
import br.com.ecoconnect.api.exception.NaoAutorizadoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Agendamento;
import br.com.ecoconnect.api.model.enums.StatusAgendamento;
import br.com.ecoconnect.api.seguranca.ContextoAtual;
import br.com.ecoconnect.api.seguranca.ContextoUsuario;
import br.com.ecoconnect.api.seguranca.EscopoAcesso;
import br.com.ecoconnect.api.service.agenda.AgendamentoProfissionalService;
import br.com.ecoconnect.api.service.agenda.AgendamentoService;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Agenda: calendário, agendamento, confirmação, remarcação, cancelamento e situação de cada
 * atendimento. As mudanças passam pelo AgendamentoService original (histórico, auditoria,
 * notificações) e pelo ConflitoAgenda (sem sobreposição de horários).
 */
@Service
public class AgendaService {

    private final AgendamentoService agendamentoService;
    private final AgendamentoProfissionalService designacaoService;
    private final EscopoAcesso escopo;
    private final Consultas consultas;

    public AgendaService(AgendamentoService agendamentoService, AgendamentoProfissionalService designacaoService,
                         EscopoAcesso escopo, Consultas consultas) {
        this.agendamentoService = agendamentoService;
        this.designacaoService = designacaoService;
        this.escopo = escopo;
        this.consultas = consultas;
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> listar(LocalDate inicio, LocalDate fim, boolean somenteMeus, Long idCrianca) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (ctx.adminInstitucional()) throw new NaoAutorizadoException(403, "A agenda é da equipe de acompanhamento e da família.");
        LocalDate de = inicio == null ? LocalDate.now().minusDays(7) : inicio;
        LocalDate ate = fim == null ? de.plusDays(42) : fim;
        if (ate.isBefore(de) || de.plusDays(400).isBefore(ate)) throw new RegraNegocioException("Período inválido (máximo de 400 dias).");
        List<Object> args = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT a.id_agendamento AS idAgendamento, a.id_crianca AS idCrianca, "
                + "c.nome_completo AS pessoa, a.status, " + Consultas.dt("COALESCE(a.data_hora_inicio, a.data_hora_inicio_solicitada)")
                + " AS inicio, " + Consultas.dt("COALESCE(a.data_hora_fim, a.data_hora_fim_solicitada)") + " AS fim, "
                + "(a.data_hora_inicio IS NOT NULL) AS horarioConfirmado, a.observacao_solicitacao AS observacao, "
                + "us.nome_completo AS solicitante, "
                + "(SELECT GROUP_CONCAT(u.nome_completo SEPARATOR ', ') FROM agendamento_profissional ap "
                + " JOIN profissional p ON p.id_profissional = ap.id_profissional JOIN usuario u ON u.id_usuario = p.id_usuario "
                + " WHERE ap.id_agendamento = a.id_agendamento) AS profissionais, "
                + "(SELECT t.id_atendimento FROM atendimento t WHERE t.id_agendamento = a.id_agendamento) AS idAtendimento "
                + "FROM agendamento a JOIN crianca c ON c.id_crianca = a.id_crianca JOIN usuario us ON us.id_usuario = a.id_usuario_solicitante "
                + "WHERE COALESCE(a.data_hora_inicio, a.data_hora_inicio_solicitada) >= ? "
                + "AND COALESCE(a.data_hora_inicio, a.data_hora_inicio_solicitada) < ?");
        args.add(de.atStartOfDay());
        args.add(ate.plusDays(1).atStartOfDay());
        if (!escopo.irrestrito()) {
            List<Long> ids = new ArrayList<>(escopo.criancas());
            sql.append(" AND a.id_crianca IN (").append(Consultas.marcadores(ids)).append(")");
            args.addAll(ids);
        }
        if (idCrianca != null) {
            escopo.exigirCrianca(idCrianca);
            sql.append(" AND a.id_crianca = ?");
            args.add(idCrianca);
        }
        if (somenteMeus && ctx.idProfissional() != null) {
            sql.append(" AND EXISTS (SELECT 1 FROM agendamento_profissional ap2 WHERE ap2.id_agendamento = a.id_agendamento "
                    + "AND ap2.id_profissional = ?)");
            args.add(ctx.idProfissional());
        }
        sql.append(" ORDER BY inicio");
        return consultas.lista(sql.toString(), args.toArray());
    }

    public record NovoAgendamento(Long idCrianca, LocalDateTime inicio, LocalDateTime fim, Long idProfissional,
                                  String observacao, Boolean confirmar) {
    }

    @Transactional
    public Map<String, Object> agendar(NovoAgendamento d) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (d.idCrianca() == null || d.inicio() == null) throw new RegraNegocioException("Informe a pessoa e o horário.");
        if (d.inicio().isBefore(LocalDateTime.now().minusMinutes(5))) {
            throw new RegraNegocioException("O horário já passou. Para registrar uma sessão que já aconteceu, use \"Registrar sessão\".");
        }
        escopo.exigirAcompanhamento(d.idCrianca());
        Agendamento a = new Agendamento();
        a.setIdCrianca(d.idCrianca());
        a.setIdUsuarioSolicitante(ctx.idUsuario());
        a.setDataHoraInicioSolicitada(d.inicio());
        a.setDataHoraFimSolicitada(d.fim());
        a.setObservacaoSolicitacao(PessoasService.texto(d.observacao(), 500));
        Agendamento salvo = agendamentoService.criar(a);
        if (ctx.equipe()) {
            Long prof = d.idProfissional() != null ? d.idProfissional() : ctx.idProfissional();
            if (prof != null) designacaoService.designar(salvo.getIdAgendamento(), prof, ctx.idUsuario());
            if (!Boolean.FALSE.equals(d.confirmar())) {
                agendamentoService.mudarStatus(salvo.getIdAgendamento(), new MudancaStatusAgendamento(StatusAgendamento.CONFIRMADO,
                        ctx.idUsuario(), d.inicio(), d.fim(), "Agendado pela equipe."));
            }
        }
        return detalhe(salvo.getIdAgendamento());
    }

    public record AcaoAgenda(String acao, LocalDateTime inicio, LocalDateTime fim, String motivo) {
    }

    /** CONFIRMAR, REAGENDAR, CANCELAR, RECUSAR, EM_ANALISE, REALIZADO ou AUSENTE. */
    @Transactional
    public Map<String, Object> executar(Long idAgendamento, AcaoAgenda d) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        String acao = d.acao() == null ? "" : d.acao().trim().toUpperCase();
        StatusAgendamento novo = switch (acao) {
            case "CONFIRMAR", "REAGENDAR" -> StatusAgendamento.CONFIRMADO;
            case "CANCELAR" -> StatusAgendamento.CANCELADO;
            case "RECUSAR" -> StatusAgendamento.RECUSADO;
            case "EM_ANALISE" -> StatusAgendamento.EM_ANALISE;
            case "REALIZADO" -> StatusAgendamento.REALIZADO;
            case "AUSENTE" -> StatusAgendamento.AUSENTE;
            default -> throw new RegraNegocioException("Ação inválida. Use CONFIRMAR, REAGENDAR, CANCELAR, RECUSAR, EM_ANALISE, REALIZADO ou AUSENTE.");
        };
        if ("REAGENDAR".equals(acao) && d.inicio() == null) throw new RegraNegocioException("Informe o novo horário.");
        if ("REAGENDAR".equals(acao) && d.inicio().isBefore(LocalDateTime.now())) {
            throw new RegraNegocioException("O novo horário precisa ser no futuro.");
        }
        agendamentoService.mudarStatus(idAgendamento, new MudancaStatusAgendamento(novo, ctx.idUsuario(), d.inicio(), d.fim(),
                PessoasService.texto(d.motivo(), 500)));
        return detalhe(idAgendamento);
    }

    @Transactional(readOnly = true)
    public Map<String, Object> detalhe(Long idAgendamento) {
        Agendamento a = agendamentoService.buscar(idAgendamento);
        Map<String, Object> r = consultas.um("SELECT a.id_agendamento AS idAgendamento, a.id_crianca AS idCrianca, "
                + "c.nome_completo AS pessoa, a.status, " + Consultas.dt("a.data_hora_inicio_solicitada") + " AS inicioSolicitado, "
                + Consultas.dt("a.data_hora_fim_solicitada") + " AS fimSolicitado, " + Consultas.dt("a.data_hora_inicio") + " AS inicio, "
                + Consultas.dt("a.data_hora_fim") + " AS fim, a.observacao_solicitacao AS observacao, us.nome_completo AS solicitante, "
                + Consultas.dt("a.data_solicitacao") + " AS dataSolicitacao, uc.nome_completo AS confirmadoPor "
                + "FROM agendamento a JOIN crianca c ON c.id_crianca = a.id_crianca JOIN usuario us ON us.id_usuario = a.id_usuario_solicitante "
                + "LEFT JOIN usuario uc ON uc.id_usuario = a.id_usuario_confirmacao WHERE a.id_agendamento = ?", a.getIdAgendamento());
        r.put("profissionais", consultas.lista("SELECT ap.id_profissional AS idProfissional, u.nome_completo AS nome "
                + "FROM agendamento_profissional ap JOIN profissional p ON p.id_profissional = ap.id_profissional "
                + "JOIN usuario u ON u.id_usuario = p.id_usuario WHERE ap.id_agendamento = ?", idAgendamento));
        r.put("historico", consultas.lista("SELECT h.status_anterior AS statusAnterior, h.status_novo AS statusNovo, "
                + Consultas.dt("h.data_hora_inicio_anterior") + " AS inicioAnterior, " + Consultas.dt("h.data_hora_inicio_novo")
                + " AS inicioNovo, h.motivo, u.nome_completo AS usuario, " + Consultas.dt("h.data_hora_alteracao") + " AS dataHora "
                + "FROM historico_agendamento h JOIN usuario u ON u.id_usuario = h.id_usuario WHERE h.id_agendamento = ? "
                + "ORDER BY h.data_hora_alteracao, h.id_historico_agendamento", idAgendamento));
        r.put("idAtendimento", consultas.ids("SELECT id_atendimento FROM atendimento WHERE id_agendamento = ?", idAgendamento)
                .stream().findFirst().orElse(null));
        return r;
    }
}
