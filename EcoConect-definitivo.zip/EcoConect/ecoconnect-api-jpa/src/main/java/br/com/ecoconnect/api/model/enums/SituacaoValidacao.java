package br.com.ecoconnect.api.model.enums;

/** Validação de informação de saúde. Valores idênticos ao ENUM do MySQL. */
public enum SituacaoValidacao {
    DECLARADO, EM_VALIDACAO, VALIDADO, REJEITADO
}
