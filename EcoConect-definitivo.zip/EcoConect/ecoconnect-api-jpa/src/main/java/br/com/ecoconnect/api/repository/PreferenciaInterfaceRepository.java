package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.PreferenciaInterface;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PreferenciaInterfaceRepository extends JpaRepository<PreferenciaInterface, Long> {

}
