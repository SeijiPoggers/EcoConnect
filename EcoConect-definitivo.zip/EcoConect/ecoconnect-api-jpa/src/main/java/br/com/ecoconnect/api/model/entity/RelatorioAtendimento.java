package br.com.ecoconnect.api.model.entity;

import br.com.ecoconnect.api.model.enums.SituacaoRelatorio;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;

/**
 * Tabela `relatorio_atendimento` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 * CHECK chk_ra_finalizacao: ((situacao not in ('FINALIZADO','LIBERADO_RESPONSAVEL','SUBSTITUIDO')) or (data_finalizacao is not null))
 * CHECK chk_ra_versao: (numero_versao >= 1)
 */
@Entity
@Table(name = "relatorio_atendimento")
public class RelatorioAtendimento implements Entidade<Long> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_relatorio", nullable = false)
    private Long idRelatorio;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_atendimento", nullable = false)
    private Long idAtendimento;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_profissional_autor", nullable = false)
    private Long idProfissionalAutor;

    @NotBlank(message = "campo obrigatório")
    @Size(max = 150)
    @Column(name = "titulo", nullable = false, length = 150)
    private String titulo;

    @NotBlank(message = "campo obrigatório")
    @Column(name = "conteudo", nullable = false, columnDefinition = "text")
    private String conteudo;

    @Enumerated(EnumType.STRING)
    @Column(name = "situacao", nullable = false)
    private SituacaoRelatorio situacao;

    @Column(name = "numero_versao", nullable = false)
    private Integer numeroVersao;

    @Column(name = "id_relatorio_substituido")
    private Long idRelatorioSubstituido;

    @Column(name = "data_elaboracao", nullable = false)
    private LocalDateTime dataElaboracao;

    @Column(name = "data_finalizacao")
    private LocalDateTime dataFinalizacao;

    @PrePersist
    void aoInserir() {
        if (situacao == null) {
            situacao = SituacaoRelatorio.RASCUNHO;
        }
        if (numeroVersao == null) {
            numeroVersao = 1;
        }
        if (dataElaboracao == null) {
            dataElaboracao = LocalDateTime.now();
        }
    }

    public Long getIdRelatorio() {
        return idRelatorio;
    }

    public void setIdRelatorio(Long idRelatorio) {
        this.idRelatorio = idRelatorio;
    }

    public Long getIdAtendimento() {
        return idAtendimento;
    }

    public void setIdAtendimento(Long idAtendimento) {
        this.idAtendimento = idAtendimento;
    }

    public Long getIdProfissionalAutor() {
        return idProfissionalAutor;
    }

    public void setIdProfissionalAutor(Long idProfissionalAutor) {
        this.idProfissionalAutor = idProfissionalAutor;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    public SituacaoRelatorio getSituacao() {
        return situacao;
    }

    public void setSituacao(SituacaoRelatorio situacao) {
        this.situacao = situacao;
    }

    public Integer getNumeroVersao() {
        return numeroVersao;
    }

    public void setNumeroVersao(Integer numeroVersao) {
        this.numeroVersao = numeroVersao;
    }

    public Long getIdRelatorioSubstituido() {
        return idRelatorioSubstituido;
    }

    public void setIdRelatorioSubstituido(Long idRelatorioSubstituido) {
        this.idRelatorioSubstituido = idRelatorioSubstituido;
    }

    public LocalDateTime getDataElaboracao() {
        return dataElaboracao;
    }

    public void setDataElaboracao(LocalDateTime dataElaboracao) {
        this.dataElaboracao = dataElaboracao;
    }

    public LocalDateTime getDataFinalizacao() {
        return dataFinalizacao;
    }

    public void setDataFinalizacao(LocalDateTime dataFinalizacao) {
        this.dataFinalizacao = dataFinalizacao;
    }

    @Override
    public Long chave() {
        return idRelatorio;
    }

    @Override
    public void definirChave(Long id) {
        this.idRelatorio = id;
    }
}
