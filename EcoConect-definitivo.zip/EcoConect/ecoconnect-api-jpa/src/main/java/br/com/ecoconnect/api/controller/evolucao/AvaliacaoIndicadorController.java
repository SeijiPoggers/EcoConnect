package br.com.ecoconnect.api.controller.evolucao;

import br.com.ecoconnect.api.controller.base.LeituraController;
import br.com.ecoconnect.api.model.entity.AvaliacaoIndicador;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.evolucao.AvaliacaoIndicadorService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/** Avaliações de indicadores. Sem PUT e sem DELETE: correção por substituição. */
@RestController
@RequestMapping("/api/avaliacoes-indicador")
public class AvaliacaoIndicadorController extends LeituraController<AvaliacaoIndicador, Long> {

    private final AvaliacaoIndicadorService service;

    public AvaliacaoIndicadorController(AvaliacaoIndicadorService service) {
        this.service = service;
    }

    @Override
    protected CrudService<AvaliacaoIndicador, Long> service() {
        return service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public AvaliacaoIndicador criar(@Valid @RequestBody AvaliacaoIndicador dados) {
        return service.criar(dados);
    }

    @PostMapping("/{id}/substituicao")
    @ResponseStatus(HttpStatus.CREATED)
    public AvaliacaoIndicador substituir(@PathVariable Long id, @Valid @RequestBody AvaliacaoIndicador dados) {
        return service.substituir(id, dados);
    }
}
