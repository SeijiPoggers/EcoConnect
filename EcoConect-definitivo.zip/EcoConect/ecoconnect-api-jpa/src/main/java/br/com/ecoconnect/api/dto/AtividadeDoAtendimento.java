package br.com.ecoconnect.api.dto;

import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

/** No POST, idAtividade é obrigatório; no PUT ele vem da URL. */
public record AtividadeDoAtendimento(
        Integer idAtividade,
        @Positive(message = "deve ser maior que zero") Integer duracaoMinutos,
        @Size(max = 300) String observacao) {
}
