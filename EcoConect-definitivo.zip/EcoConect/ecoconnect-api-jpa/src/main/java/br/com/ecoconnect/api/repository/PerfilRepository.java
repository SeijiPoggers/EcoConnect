package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.Perfil;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `perfil` (Spring Data JPA). */
public interface PerfilRepository extends JpaRepository<Perfil, Integer> {

    Optional<Perfil> findByNome(String nome);
}
