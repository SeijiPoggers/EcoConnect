package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;

/** Tabela `instituicao_membro` (migration V2/V3). Gerada no mesmo padrão das entidades originais. */
@Entity
@Table(name = "instituicao_membro")
public class InstituicaoMembro implements Entidade<Long> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_membro", nullable = false)
    private Long idMembro;

    @Column(name = "id_instituicao", nullable = false)
    private Long idInstituicao;

    @Column(name = "id_usuario", nullable = false)
    private Long idUsuario;

    @Size(max = 20)
    @Column(name = "papel", nullable = false, length = 20)
    private String papel;

    @Column(name = "ativo")
    private Boolean ativo;

    @Column(name = "data_inicio")
    private LocalDateTime dataInicio;

    @PrePersist
    void aoInserir() {
        if (ativo == null) ativo = Boolean.TRUE;
        if (dataInicio == null) dataInicio = LocalDateTime.now();
    }

    @Override
    public Long chave() {
        return idMembro;
    }

    @Override
    public void definirChave(Long id) {
        this.idMembro = id;
    }

    public Long getIdMembro() {
        return idMembro;
    }

    public void setIdMembro(Long idMembro) {
        this.idMembro = idMembro;
    }

    public Long getIdInstituicao() {
        return idInstituicao;
    }

    public void setIdInstituicao(Long idInstituicao) {
        this.idInstituicao = idInstituicao;
    }

    public Long getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getPapel() {
        return papel;
    }

    public void setPapel(String papel) {
        this.papel = papel;
    }

    public Boolean getAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    public LocalDateTime getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(LocalDateTime dataInicio) {
        this.dataInicio = dataInicio;
    }
}
