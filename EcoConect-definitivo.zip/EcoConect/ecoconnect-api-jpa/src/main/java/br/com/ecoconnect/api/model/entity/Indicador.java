package br.com.ecoconnect.api.model.entity;

import br.com.ecoconnect.api.model.enums.TipoMedida;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * Tabela `indicador` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 */
@Entity
@Table(name = "indicador")
public class Indicador implements Entidade<Long> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_indicador", nullable = false)
    private Long idIndicador;

    @NotBlank(message = "campo obrigatório")
    @Size(max = 120)
    @Column(name = "nome", nullable = false, length = 120)
    private String nome;

    @Size(max = 300)
    @Column(name = "descricao", length = 300)
    private String descricao;

    @NotNull(message = "campo obrigatório")
    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_medida", nullable = false)
    private TipoMedida tipoMedida;

    @Size(max = 30)
    @Column(name = "unidade_medida", length = 30)
    private String unidadeMedida;

    @Column(name = "ativo", nullable = false)
    private Boolean ativo;

    @PrePersist
    void aoInserir() {
        if (ativo == null) {
            ativo = Boolean.TRUE;
        }
    }

    public Long getIdIndicador() {
        return idIndicador;
    }

    public void setIdIndicador(Long idIndicador) {
        this.idIndicador = idIndicador;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public TipoMedida getTipoMedida() {
        return tipoMedida;
    }

    public void setTipoMedida(TipoMedida tipoMedida) {
        this.tipoMedida = tipoMedida;
    }

    public String getUnidadeMedida() {
        return unidadeMedida;
    }

    public void setUnidadeMedida(String unidadeMedida) {
        this.unidadeMedida = unidadeMedida;
    }

    public Boolean getAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    @Override
    public Long chave() {
        return idIndicador;
    }

    @Override
    public void definirChave(Long id) {
        this.idIndicador = id;
    }
}
