package br.com.ecoconnect.api.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/** Dados alteráveis de um usuário (senha e status têm endpoints próprios). */
public record UsuarioAlteracao(
        @NotNull(message = "campo obrigatório") Integer idPerfil,
        @NotBlank(message = "campo obrigatório") @Size(max = 150) String nomeCompleto,
        @NotBlank(message = "campo obrigatório") @Email(message = "e-mail inválido") @Size(max = 150) String email,
        @Size(max = 20) String telefone) {
}
