package br.com.ecoconnect.api.controller.evolucao;

import br.com.ecoconnect.api.dto.IndicadorDoObjetivo;
import br.com.ecoconnect.api.model.entity.AvaliacaoIndicador;
import br.com.ecoconnect.api.model.entity.ObjetivoIndicador;
import br.com.ecoconnect.api.service.evolucao.AvaliacaoIndicadorService;
import br.com.ecoconnect.api.service.evolucao.ObjetivoIndicadorService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Indicadores de um objetivo e a série de avaliações (evolução). */
@RestController
@RequestMapping("/api/objetivos/{idObjetivo}/indicadores")
public class ObjetivoIndicadorController {

    private final ObjetivoIndicadorService service;
    private final AvaliacaoIndicadorService avaliacaoService;

    public ObjetivoIndicadorController(ObjetivoIndicadorService service, AvaliacaoIndicadorService avaliacaoService) {
        this.service = service;
        this.avaliacaoService = avaliacaoService;
    }

    @GetMapping
    public List<ObjetivoIndicador> listar(@PathVariable Long idObjetivo) {
        return service.listar(idObjetivo);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ObjetivoIndicador vincular(@PathVariable Long idObjetivo, @Valid @RequestBody IndicadorDoObjetivo dados) {
        return service.vincular(idObjetivo, dados);
    }

    @PutMapping("/{idIndicador}")
    public ObjetivoIndicador alterar(@PathVariable Long idObjetivo, @PathVariable Long idIndicador,
                                     @Valid @RequestBody IndicadorDoObjetivo dados) {
        return service.alterar(idObjetivo, idIndicador, dados);
    }

    @DeleteMapping("/{idIndicador}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void remover(@PathVariable Long idObjetivo, @PathVariable Long idIndicador) {
        service.remover(idObjetivo, idIndicador);
    }

    /** Avaliações VIGENTES em ordem de data: base para gráficos de evolução. */
    @GetMapping("/{idIndicador}/serie")
    public List<AvaliacaoIndicador> serie(@PathVariable Long idObjetivo, @PathVariable Long idIndicador) {
        return avaliacaoService.serie(idObjetivo, idIndicador);
    }
}
