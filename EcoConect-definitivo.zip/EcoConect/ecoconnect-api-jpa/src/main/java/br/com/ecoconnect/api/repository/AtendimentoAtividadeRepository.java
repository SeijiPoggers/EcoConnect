package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.AtendimentoAtividade;
import br.com.ecoconnect.api.model.entity.AtendimentoAtividadeId;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `atendimento_atividade` (Spring Data JPA). */
public interface AtendimentoAtividadeRepository extends JpaRepository<AtendimentoAtividade, AtendimentoAtividadeId> {

    List<AtendimentoAtividade> findByIdAtendimento(Long idAtendimento);
}
