package br.com.ecoconnect.api.dto;

import java.time.LocalDateTime;

/** Relatório liberado visto pelo responsável (campos da VW_RELATORIO_RESPONSAVEL da modelagem). */
public record RelatorioResponsavelDTO(
        Long idRelatorio,
        Long idAtendimento,
        Long idCrianca,
        String titulo,
        String conteudo,
        Integer numeroVersao,
        LocalDateTime dataFinalizacao) {
}
