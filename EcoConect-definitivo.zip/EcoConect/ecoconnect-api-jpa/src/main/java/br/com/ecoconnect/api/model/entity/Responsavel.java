package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * Tabela `responsavel` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 */
@Entity
@Table(name = "responsavel")
public class Responsavel implements Entidade<Long> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_responsavel", nullable = false)
    private Long idResponsavel;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_usuario", nullable = false)
    private Long idUsuario;

    @Size(max = 11)
    @Pattern(regexp = "\\d{11}", message = "CPF deve ter 11 dígitos, somente números")
    @Column(name = "cpf", length = 11)
    private String cpf;

    @PrePersist
    void aoInserir() {
        // sem valores padrão a preencher
    }

    public Long getIdResponsavel() {
        return idResponsavel;
    }

    public void setIdResponsavel(Long idResponsavel) {
        this.idResponsavel = idResponsavel;
    }

    public Long getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    @Override
    public Long chave() {
        return idResponsavel;
    }

    @Override
    public void definirChave(Long id) {
        this.idResponsavel = id;
    }
}
