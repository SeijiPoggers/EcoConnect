package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;

/** Tabela `preferencia_interface` (migration V2/V3). Gerada no mesmo padrão das entidades originais. */
@Entity
@Table(name = "preferencia_interface")
public class PreferenciaInterface implements Entidade<Long> {

    @Id
    @Column(name = "id_usuario", nullable = false)
    private Long idUsuario;

    @Column(name = "baixo_estimulo")
    private Boolean baixoEstimulo;

    @Size(max = 12)
    @Column(name = "tamanho_fonte", length = 12)
    private String tamanhoFonte;

    @Column(name = "alto_contraste")
    private Boolean altoContraste;

    @Column(name = "espacamento_leitura")
    private Boolean espacamentoLeitura;

    @Column(name = "reduzir_movimento")
    private Boolean reduzirMovimento;

    @Column(name = "data_atualizacao")
    private LocalDateTime dataAtualizacao;

    @PrePersist
    void aoInserir() {
        if (baixoEstimulo == null) baixoEstimulo = Boolean.FALSE;
        if (tamanhoFonte == null) tamanhoFonte = "PADRAO";
        if (altoContraste == null) altoContraste = Boolean.FALSE;
        if (espacamentoLeitura == null) espacamentoLeitura = Boolean.FALSE;
        if (reduzirMovimento == null) reduzirMovimento = Boolean.FALSE;
        if (dataAtualizacao == null) dataAtualizacao = LocalDateTime.now();
    }

    @PreUpdate
    void aoAtualizar() {
        dataAtualizacao = LocalDateTime.now();
    }

    @Override
    public Long chave() {
        return idUsuario;
    }

    @Override
    public void definirChave(Long id) {
        this.idUsuario = id;
    }

    public Long getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Boolean getBaixoEstimulo() {
        return baixoEstimulo;
    }

    public void setBaixoEstimulo(Boolean baixoEstimulo) {
        this.baixoEstimulo = baixoEstimulo;
    }

    public String getTamanhoFonte() {
        return tamanhoFonte;
    }

    public void setTamanhoFonte(String tamanhoFonte) {
        this.tamanhoFonte = tamanhoFonte;
    }

    public Boolean getAltoContraste() {
        return altoContraste;
    }

    public void setAltoContraste(Boolean altoContraste) {
        this.altoContraste = altoContraste;
    }

    public Boolean getEspacamentoLeitura() {
        return espacamentoLeitura;
    }

    public void setEspacamentoLeitura(Boolean espacamentoLeitura) {
        this.espacamentoLeitura = espacamentoLeitura;
    }

    public Boolean getReduzirMovimento() {
        return reduzirMovimento;
    }

    public void setReduzirMovimento(Boolean reduzirMovimento) {
        this.reduzirMovimento = reduzirMovimento;
    }

    public LocalDateTime getDataAtualizacao() {
        return dataAtualizacao;
    }

    public void setDataAtualizacao(LocalDateTime dataAtualizacao) {
        this.dataAtualizacao = dataAtualizacao;
    }
}
