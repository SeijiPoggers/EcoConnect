package br.com.ecoconnect.api.dto;

import br.com.ecoconnect.api.model.enums.BaseLegal;
import jakarta.validation.constraints.NotNull;

public record AvaliacaoBaseLegal(
        @NotNull(message = "campo obrigatório") BaseLegal baseLegalAvaliada,
        @NotNull(message = "campo obrigatório") Long idUsuarioAvaliacaoBase) {
}
