package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.Comunicado;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `comunicado` (Spring Data JPA). */
public interface ComunicadoRepository extends JpaRepository<Comunicado, Long> {
}
