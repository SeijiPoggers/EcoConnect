package br.com.ecoconnect.api.model.enums;

/** Tipo do comunicado. Valores idênticos ao ENUM do MySQL. */
public enum TipoComunicado {
    GERAL, ALTERACAO_ATIVIDADE, OUTRO
}
