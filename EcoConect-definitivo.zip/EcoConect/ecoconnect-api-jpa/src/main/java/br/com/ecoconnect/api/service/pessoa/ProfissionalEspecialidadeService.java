package br.com.ecoconnect.api.service.pessoa;

import br.com.ecoconnect.api.exception.ConflitoException;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.model.entity.ProfissionalEspecialidade;
import br.com.ecoconnect.api.model.entity.ProfissionalEspecialidadeId;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.repository.EspecialidadeRepository;
import br.com.ecoconnect.api.repository.ProfissionalEspecialidadeRepository;
import br.com.ecoconnect.api.repository.ProfissionalRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/** PROFISSIONAL_ESPECIALIDADE (N:N). Chave composta (id_profissional, id_especialidade). */
@Service
public class ProfissionalEspecialidadeService {

    private static final String TABELA = "profissional_especialidade";

    private final ProfissionalEspecialidadeRepository repository;
    private final ProfissionalRepository profissionalRepository;
    private final EspecialidadeRepository especialidadeRepository;
    private final AuditoriaService auditoria;

    public ProfissionalEspecialidadeService(ProfissionalEspecialidadeRepository repository,
                                            ProfissionalRepository profissionalRepository,
                                            EspecialidadeRepository especialidadeRepository, AuditoriaService auditoria) {
        this.repository = repository;
        this.profissionalRepository = profissionalRepository;
        this.especialidadeRepository = especialidadeRepository;
        this.auditoria = auditoria;
    }

    @Transactional(readOnly = true)
    public List<ProfissionalEspecialidade> listar(Long idProfissional) {
        if (!profissionalRepository.existsById(idProfissional)) throw new NaoEncontradoException("profissional", idProfissional);
        return repository.findByIdProfissional(idProfissional);
    }

    @Transactional
    public ProfissionalEspecialidade adicionar(Long idProfissional, Integer idEspecialidade, Boolean principal) {
        if (!profissionalRepository.existsById(idProfissional)) throw new NaoEncontradoException("profissional", idProfissional);
        if (idEspecialidade == null || !especialidadeRepository.existsById(idEspecialidade)) {
            throw new NaoEncontradoException("especialidade", idEspecialidade);
        }
        ProfissionalEspecialidadeId id = new ProfissionalEspecialidadeId(idProfissional, idEspecialidade);
        if (repository.existsById(id)) throw new ConflitoException("O profissional já tem esta especialidade.");
        ProfissionalEspecialidade pe = new ProfissionalEspecialidade();
        pe.setIdProfissional(idProfissional);
        pe.setIdEspecialidade(idEspecialidade);
        pe.setPrincipal(Boolean.TRUE.equals(principal));
        if (Boolean.TRUE.equals(principal)) desmarcarPrincipais(idProfissional);
        ProfissionalEspecialidade salvo = repository.saveAndFlush(pe);
        auditoria.registrar(AcaoAuditoria.CRIACAO, TABELA, salvo, null, salvo);
        return salvo;
    }

    /** Marca/desmarca como especialidade principal (só uma principal por profissional). */
    @Transactional
    public ProfissionalEspecialidade alterarPrincipal(Long idProfissional, Integer idEspecialidade, Boolean principal) {
        ProfissionalEspecialidade pe = buscar(idProfissional, idEspecialidade);
        String antes = auditoria.json(pe);
        if (Boolean.TRUE.equals(principal)) desmarcarPrincipais(idProfissional);
        pe.setPrincipal(Boolean.TRUE.equals(principal));
        ProfissionalEspecialidade salvo = repository.saveAndFlush(pe);
        auditoria.registrar(AcaoAuditoria.ATUALIZACAO, TABELA, salvo, antes, salvo);
        return salvo;
    }

    @Transactional
    public void remover(Long idProfissional, Integer idEspecialidade) {
        ProfissionalEspecialidade pe = buscar(idProfissional, idEspecialidade);
        String antes = auditoria.json(pe);
        repository.delete(pe);
        repository.flush();
        auditoria.registrar(AcaoAuditoria.ATUALIZACAO, TABELA, pe, antes, null);
    }

    private ProfissionalEspecialidade buscar(Long idProfissional, Integer idEspecialidade) {
        ProfissionalEspecialidadeId id = new ProfissionalEspecialidadeId(idProfissional, idEspecialidade);
        return repository.findById(id).orElseThrow(() -> new NaoEncontradoException(TABELA, id));
    }

    private void desmarcarPrincipais(Long idProfissional) {
        for (ProfissionalEspecialidade outra : repository.findByIdProfissional(idProfissional)) {
            if (Boolean.TRUE.equals(outra.getPrincipal())) {
                outra.setPrincipal(false);
                repository.save(outra);
            }
        }
    }
}
