package br.com.ecoconnect.api.controller.pessoa;

import br.com.ecoconnect.api.controller.base.LeituraController;
import br.com.ecoconnect.api.dto.AlteracaoSenha;
import br.com.ecoconnect.api.dto.AlteracaoStatusUsuario;
import br.com.ecoconnect.api.dto.UsuarioAlteracao;
import br.com.ecoconnect.api.dto.UsuarioCriacao;
import br.com.ecoconnect.api.model.entity.Usuario;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.pessoa.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/** Usuários. O JSON de resposta nunca contém a senha. */
@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController extends LeituraController<Usuario, Long> {

    private final UsuarioService service;

    public UsuarioController(UsuarioService service) {
        this.service = service;
    }

    @Override
    protected CrudService<Usuario, Long> service() {
        return service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Usuario criar(@Valid @RequestBody UsuarioCriacao dados) {
        return service.criar(dados);
    }

    @PutMapping("/{id}")
    public Usuario alterar(@PathVariable Long id, @Valid @RequestBody UsuarioAlteracao dados) {
        return service.alterar(id, dados);
    }

    /** Ativar, bloquear ou inativar: {"status": "ATIVO"} */
    @PatchMapping("/{id}/status")
    public Usuario alterarStatus(@PathVariable Long id, @Valid @RequestBody AlteracaoStatusUsuario dados) {
        return service.alterarStatus(id, dados.status());
    }

    @PatchMapping("/{id}/senha")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void alterarSenha(@PathVariable Long id, @Valid @RequestBody AlteracaoSenha dados) {
        service.alterarSenha(id, dados);
    }

    /** Exclusão lógica: status = INATIVO. */
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void excluir(@PathVariable Long id) {
        service.excluir(id);
    }
}
