package br.com.ecoconnect.api.service;

import br.com.ecoconnect.api.seguranca.ContextoAtual;
import br.com.ecoconnect.api.seguranca.ContextoUsuario;
import org.springframework.beans.factory.annotation.Value;

import br.com.ecoconnect.api.exception.RequisicaoInvalidaException;
import br.com.ecoconnect.api.repository.UsuarioRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * Identifica quem está fazendo a requisição, para a AUDITORIA.
 * Usa o usuário da sessão autenticada (FiltroAutenticacao). O cabeçalho X-Usuario-Id da versão
 * anterior só é aceito com ecoconnect.seguranca.cabecalho-legado=true.
 */
@Component
public class UsuarioAtual {

    public static final String CABECALHO = "X-Usuario-Id";

    private final UsuarioRepository usuarioRepository;

    /**
     * Compatibilidade com a versão anterior (sem login): aceitar o cabeçalho X-Usuario-Id.
     * Desligado por padrão, porque permitiria agir em nome de outra pessoa.
     */
    @Value("${ecoconnect.seguranca.cabecalho-legado:false}")
    private boolean aceitarCabecalhoLegado;

    public UsuarioAtual(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    /** id do usuário do cabeçalho, ou null se não informado (ou fora de uma requisição HTTP). */
    public Long id() {
        ContextoUsuario ctx = ContextoAtual.obter();
        if (ctx != null) return ctx.idUsuario();
        HttpServletRequest req = requisicao();
        if (req == null || !aceitarCabecalhoLegado) return null;
        String valor = req.getHeader(CABECALHO);
        if (valor == null || valor.isBlank()) return null;
        Long id;
        try {
            id = Long.valueOf(valor.trim());
        } catch (NumberFormatException e) {
            throw new RequisicaoInvalidaException("Cabeçalho " + CABECALHO + " deve ser um número.");
        }
        if (!usuarioRepository.existsById(id)) {
            throw new RequisicaoInvalidaException("Cabeçalho " + CABECALHO + ": usuário " + id + " não existe.");
        }
        return id;
    }

    /** IP de origem (considera proxy reverso). */
    public String ip() {
        HttpServletRequest req = requisicao();
        if (req == null) return null;
        String encaminhado = req.getHeader("X-Forwarded-For");
        String ip = (encaminhado != null && !encaminhado.isBlank()) ? encaminhado.split(",")[0].trim() : req.getRemoteAddr();
        return ip != null && ip.length() > 45 ? ip.substring(0, 45) : ip;
    }

    private static HttpServletRequest requisicao() {
        if (RequestContextHolder.getRequestAttributes() instanceof ServletRequestAttributes attrs) {
            return attrs.getRequest();
        }
        return null;
    }
}
