package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.Agendamento;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `agendamento` (Spring Data JPA). */
public interface AgendamentoRepository extends JpaRepository<Agendamento, Long> {
}
