package br.com.ecoconnect.api.controller.catalogo;

import br.com.ecoconnect.api.controller.base.CrudController;
import br.com.ecoconnect.api.model.entity.Especialidade;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.catalogo.EspecialidadeService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Especialidades profissionais (catálogo). Exclusão física: o banco bloqueia se estiver em uso. */
@RestController
@RequestMapping("/api/especialidades")
public class EspecialidadeController extends CrudController<Especialidade, Integer> {

    private final EspecialidadeService service;

    public EspecialidadeController(EspecialidadeService service) {
        this.service = service;
    }

    @Override
    protected CrudService<Especialidade, Integer> service() {
        return service;
    }
}
