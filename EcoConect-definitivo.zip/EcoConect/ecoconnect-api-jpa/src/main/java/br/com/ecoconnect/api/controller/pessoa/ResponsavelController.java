package br.com.ecoconnect.api.controller.pessoa;

import br.com.ecoconnect.api.controller.base.CrudController;
import br.com.ecoconnect.api.dto.RelatorioResponsavelDTO;
import br.com.ecoconnect.api.model.entity.Responsavel;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.pessoa.ResponsavelService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Responsáveis pelas crianças. */
@RestController
@RequestMapping("/api/responsaveis")
public class ResponsavelController extends CrudController<Responsavel, Long> {

    private final ResponsavelService service;

    public ResponsavelController(ResponsavelService service) {
        this.service = service;
    }

    @Override
    protected CrudService<Responsavel, Long> service() {
        return service;
    }

    /** Relatórios liberados para este responsável. */
    @GetMapping("/{id}/relatorios")
    public List<RelatorioResponsavelDTO> relatorios(@PathVariable Long id) {
        return service.relatoriosLiberados(id);
    }
}
