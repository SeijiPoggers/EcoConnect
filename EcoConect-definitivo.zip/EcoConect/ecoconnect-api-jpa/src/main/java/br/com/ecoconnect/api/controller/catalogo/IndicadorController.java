package br.com.ecoconnect.api.controller.catalogo;

import br.com.ecoconnect.api.controller.base.CrudController;
import br.com.ecoconnect.api.model.entity.Indicador;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.catalogo.IndicadorService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Indicadores de evolução (catálogo). */
@RestController
@RequestMapping("/api/indicadores")
public class IndicadorController extends CrudController<Indicador, Long> {

    private final IndicadorService service;

    public IndicadorController(IndicadorService service) {
        this.service = service;
    }

    @Override
    protected CrudService<Indicador, Long> service() {
        return service;
    }
}
