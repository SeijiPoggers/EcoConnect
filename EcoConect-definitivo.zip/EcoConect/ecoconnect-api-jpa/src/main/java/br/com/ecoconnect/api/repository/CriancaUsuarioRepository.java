package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.CriancaUsuario;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CriancaUsuarioRepository extends JpaRepository<CriancaUsuario, Long> {

    Optional<CriancaUsuario> findByIdUsuario(Long idUsuario);
    boolean existsByIdUsuario(Long idUsuario);

}
