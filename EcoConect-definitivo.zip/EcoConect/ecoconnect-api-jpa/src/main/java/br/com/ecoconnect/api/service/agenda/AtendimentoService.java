package br.com.ecoconnect.api.service.agenda;

import br.com.ecoconnect.api.exception.ConflitoException;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Agendamento;
import br.com.ecoconnect.api.model.entity.Atendimento;
import br.com.ecoconnect.api.model.enums.StatusAgendamento;
import br.com.ecoconnect.api.repository.AgendamentoRepository;
import br.com.ecoconnect.api.repository.AtendimentoRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.Verificacoes;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;

import java.util.Set;

/**
 * ATENDIMENTO: atividade efetivamente realizada.
 *  - RI-10: só existe para agendamento REALIZADO (FK composta com status_agendamento_ref = 'REALIZADO');
 *  - RI-11: no máximo um atendimento por agendamento;
 *  - sem exclusão.
 */
@Service
public class AtendimentoService extends CrudService<Atendimento, Long> {

    private final AtendimentoRepository atendimentoRepository;
    private final AgendamentoRepository agendamentoRepository;
    private final Verificacoes verificacoes;

    public AtendimentoService(AtendimentoRepository repository, AuditoriaService auditoria,
                              AgendamentoRepository agendamentoRepository, Verificacoes verificacoes) {
        super(repository, auditoria, "atendimento");
        this.atendimentoRepository = repository;
        this.agendamentoRepository = agendamentoRepository;
        this.verificacoes = verificacoes;
    }

    @Override
    protected void antesDeCriar(Atendimento at) {
        Agendamento ag = agendamentoRepository.findById(at.getIdAgendamento())
                .orElseThrow(() -> new NaoEncontradoException("agendamento", at.getIdAgendamento()));
        if (ag.getStatus() != StatusAgendamento.REALIZADO) {
            throw new RegraNegocioException("Só é possível registrar atendimento de agendamento REALIZADO (status atual: "
                    + ag.getStatus() + ").");
        }
        if (atendimentoRepository.existsByIdAgendamento(at.getIdAgendamento())) {
            throw new ConflitoException("Este agendamento já tem atendimento registrado.");
        }
        verificacoes.usuarioDaEquipe(at.getIdUsuarioRegistro(), "Quem registra o atendimento");
        at.setStatusAgendamentoRef(StatusAgendamento.REALIZADO);
        validarHorario(at);
    }

    @Override
    protected Set<String> camposProtegidos() {
        return Set.of("idAgendamento", "statusAgendamentoRef", "idUsuarioRegistro");
    }

    @Override
    protected void antesDeSalvarAtualizacao(Atendimento at) {
        validarHorario(at);
    }

    private static void validarHorario(Atendimento at) {
        if (at.getDataHoraFimReal() != null && at.getDataHoraFimReal().isBefore(at.getDataHoraInicioReal())) {
            throw new RegraNegocioException("O fim real do atendimento não pode ser antes do início.");
        }
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.PROIBIDA;
    }

    // ------------------------------------------------------------------ escopo por pessoa
    @Override
    protected Long criancaDoRegistro(Atendimento at) {
        return escopo() == null ? null : escopo().criancaDoAgendamento(at.getIdAgendamento());
    }

    @Override
    protected boolean registroDePessoa() {
        return true;
    }
}
