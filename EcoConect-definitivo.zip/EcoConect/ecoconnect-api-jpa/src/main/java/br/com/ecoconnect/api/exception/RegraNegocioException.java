package br.com.ecoconnect.api.exception;

/** Operação válida em formato, mas proibida por uma regra do EcoConnect (HTTP 422). */
public class RegraNegocioException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public RegraNegocioException(String mensagem) {
        super(mensagem);
    }
}
