package br.com.ecoconnect.api.exception;

/** Conflito com dados já existentes, como e-mail repetido (HTTP 409). */
public class ConflitoException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ConflitoException(String mensagem) {
        super(mensagem);
    }
}
