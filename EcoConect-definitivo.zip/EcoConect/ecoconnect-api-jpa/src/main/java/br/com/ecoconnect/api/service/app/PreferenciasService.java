package br.com.ecoconnect.api.service.app;

import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.PreferenciaInterface;
import br.com.ecoconnect.api.repository.PreferenciaInterfaceRepository;
import java.util.Set;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Preferências de acessibilidade da interface, guardadas por usuário no banco (não no navegador). */
@Service
public class PreferenciasService {

    private static final Set<String> FONTES = Set.of("PADRAO", "GRANDE", "MUITO_GRANDE");
    private final PreferenciaInterfaceRepository repository;

    public PreferenciasService(PreferenciaInterfaceRepository repository) {
        this.repository = repository;
    }

    @Transactional(readOnly = true)
    public PreferenciaInterface obter(Long idUsuario) {
        return repository.findById(idUsuario).orElseGet(() -> {
            PreferenciaInterface p = new PreferenciaInterface();
            p.setIdUsuario(idUsuario);
            p.setBaixoEstimulo(false);
            p.setTamanhoFonte("PADRAO");
            p.setAltoContraste(false);
            p.setEspacamentoLeitura(false);
            p.setReduzirMovimento(false);
            return p;
        });
    }

    @Transactional
    public PreferenciaInterface salvar(Long idUsuario, PreferenciaInterface dados) {
        String fonte = dados.getTamanhoFonte() == null ? "PADRAO" : dados.getTamanhoFonte();
        if (!FONTES.contains(fonte)) throw new RegraNegocioException("Tamanho de fonte inválido. Aceitos: " + FONTES);
        PreferenciaInterface p = repository.findById(idUsuario).orElseGet(PreferenciaInterface::new);
        p.setIdUsuario(idUsuario);
        p.setBaixoEstimulo(Boolean.TRUE.equals(dados.getBaixoEstimulo()));
        p.setTamanhoFonte(fonte);
        p.setAltoContraste(Boolean.TRUE.equals(dados.getAltoContraste()));
        p.setEspacamentoLeitura(Boolean.TRUE.equals(dados.getEspacamentoLeitura()));
        p.setReduzirMovimento(Boolean.TRUE.equals(dados.getReduzirMovimento()));
        return repository.saveAndFlush(p);
    }
}
