package br.com.ecoconnect.api.controller.agenda;

import br.com.ecoconnect.api.controller.base.LeituraController;
import br.com.ecoconnect.api.dto.NovaVersaoRelatorio;
import br.com.ecoconnect.api.model.entity.RelatorioAtendimento;
import br.com.ecoconnect.api.service.agenda.RelatorioAtendimentoService;
import br.com.ecoconnect.api.service.base.CrudService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/** Relatórios de atendimento. Sem DELETE. */
@RestController
@RequestMapping("/api/relatorios-atendimento")
public class RelatorioAtendimentoController extends LeituraController<RelatorioAtendimento, Long> {

    private final RelatorioAtendimentoService service;

    public RelatorioAtendimentoController(RelatorioAtendimentoService service) {
        this.service = service;
    }

    @Override
    protected CrudService<RelatorioAtendimento, Long> service() {
        return service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public RelatorioAtendimento criar(@Valid @RequestBody RelatorioAtendimento dados) {
        return service.criar(dados);
    }

    @PutMapping("/{id}")
    public RelatorioAtendimento editar(@PathVariable Long id, @Valid @RequestBody RelatorioAtendimento dados) {
        return service.atualizar(id, dados);
    }

    @PatchMapping("/{id}/finalizacao")
    public RelatorioAtendimento finalizar(@PathVariable Long id) {
        return service.finalizar(id);
    }

    @PatchMapping("/{id}/liberacao")
    public RelatorioAtendimento liberar(@PathVariable Long id) {
        return service.liberar(id);
    }

    @PostMapping("/{id}/nova-versao")
    @ResponseStatus(HttpStatus.CREATED)
    public RelatorioAtendimento novaVersao(@PathVariable Long id, @Valid @RequestBody NovaVersaoRelatorio dados) {
        return service.novaVersao(id, dados);
    }
}
