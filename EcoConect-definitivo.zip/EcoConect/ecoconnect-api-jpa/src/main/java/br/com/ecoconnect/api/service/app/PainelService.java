package br.com.ecoconnect.api.service.app;

import br.com.ecoconnect.api.seguranca.ContextoAtual;
import br.com.ecoconnect.api.seguranca.ContextoUsuario;
import br.com.ecoconnect.api.seguranca.EscopoAcesso;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Painel inicial. Todos os números são calculados no banco, a cada acesso, e respeitam o
 * escopo do usuário (o profissional só conta as pessoas que acompanha; a família, as suas;
 * a instituição, as suas solicitações).
 */
@Service
public class PainelService {

    private final Consultas consultas;
    private final EscopoAcesso escopo;
    private final ComunicacaoService comunicacao;

    public PainelService(Consultas consultas, EscopoAcesso escopo, ComunicacaoService comunicacao) {
        this.consultas = consultas;
        this.escopo = escopo;
        this.comunicacao = comunicacao;
    }

    @Transactional(readOnly = true)
    public Map<String, Object> painel() {
        ContextoUsuario ctx = ContextoAtual.exigir();
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("perfil", ctx.perfil());
        r.put("nome", ctx.nome());
        r.put("geradoEm", LocalDateTime.now().withNano(0));
        List<Map<String, Object>> cartoes = new ArrayList<>();
        r.put("cartoes", cartoes);
        Map<String, Object> contadores = comunicacao.contadores();
        r.put("contadores", contadores);
        r.put("notificacoes", ((List<?>) comunicacao.notificacoes(true).get("itens")).stream().limit(5).toList());
        r.put("demonstracao", consultas.numero("SELECT COUNT(*) FROM registro_demonstracao") > 0);

        if (ctx.adminInstitucional()) {
            painelInstitucional(ctx, r, cartoes);
            return r;
        }
        List<Long> pessoas = new ArrayList<>(escopo.criancas());
        boolean todos = ctx.administrador();
        String filtroPessoa = todos ? "1 = 1" : "id_crianca IN (" + Consultas.marcadores(pessoas) + ")";
        String filtroA = todos ? "1 = 1" : "a.id_crianca IN (" + Consultas.marcadores(pessoas) + ")";
        Object[] argsPessoa = todos ? new Object[0] : pessoas.toArray();

        long totalPessoas = todos ? consultas.numero("SELECT COUNT(*) FROM crianca") : pessoas.size();
        long emAcompanhamento = consultas.numero("SELECT COUNT(*) FROM crianca WHERE situacao_ecocura = 'ATIVA' AND " + filtroPessoa, argsPessoa);
        long sessoes = consultas.numero("SELECT COUNT(*) FROM atendimento t JOIN agendamento a ON a.id_agendamento = t.id_agendamento WHERE "
                + filtroA, argsPessoa);
        long sessoesMes = consultas.numero("SELECT COUNT(*) FROM atendimento t JOIN agendamento a ON a.id_agendamento = t.id_agendamento "
                + "WHERE t.data_hora_inicio_real >= ? AND " + filtroA, concat(LocalDate.now().withDayOfMonth(1).atStartOfDay(), argsPessoa));
        long proximas = consultas.numero("SELECT COUNT(*) FROM agendamento WHERE status = 'CONFIRMADO' AND data_hora_inicio >= NOW() "
                + "AND data_hora_inicio < ? AND " + filtroPessoa, concat(LocalDateTime.now().plusDays(7), argsPessoa));
        long pedidosAgenda = consultas.numero("SELECT COUNT(*) FROM agendamento WHERE status IN ('SOLICITADO','EM_ANALISE') AND "
                + filtroPessoa, argsPessoa);

        if (ctx.familia()) {
            cartoes.add(cartao("pessoas", ctx.responsavel() ? "Pessoas que você acompanha" : "Seu acompanhamento", totalPessoas, null, "#/pessoas"));
            cartoes.add(cartao("proximas", "Próximas sessões (7 dias)", proximas, null, "#/agenda"));
            cartoes.add(cartao("pedidos", "Pedidos de horário aguardando", pedidosAgenda, null, "#/agenda"));
            cartoes.add(cartao("mensagens", "Mensagens não lidas", contadores.get("mensagens"), null, "#/mensagens"));
            r.put("relatoriosLiberados", consultas.lista("SELECT r.id_relatorio AS idRelatorio, r.titulo, c.nome_completo AS pessoa, "
                    + Consultas.dt("r.data_finalizacao") + " AS data FROM relatorio_atendimento r JOIN atendimento t ON t.id_atendimento = r.id_atendimento "
                    + "JOIN agendamento a ON a.id_agendamento = t.id_agendamento JOIN crianca c ON c.id_crianca = a.id_crianca "
                    + "WHERE r.situacao = 'LIBERADO_RESPONSAVEL' AND " + filtroA + " ORDER BY r.data_finalizacao DESC LIMIT 5", argsPessoa));
        } else {
            cartoes.add(cartao("pessoas", todos ? "Pessoas cadastradas" : "Pessoas que você acompanha", totalPessoas, null, "#/pessoas"));
            cartoes.add(cartao("acompanhamento", "Em acompanhamento ativo", emAcompanhamento, null, "#/pessoas"));
            cartoes.add(cartao("sessoes", "Sessões realizadas", sessoes, sessoesMes + " neste mês", "#/relatorios"));
            cartoes.add(cartao("proximas", "Próximas sessões (7 dias)", proximas, null, "#/agenda"));
            cartoes.add(cartao("pedidos", "Pedidos de horário pendentes", pedidosAgenda, null, "#/agenda"));
        }
        if (todos) {
            cartoes.add(cartao("solicitacoes", "Solicitações a instituições", consultas.numero("SELECT COUNT(*) FROM solicitacao_atendimento"),
                    consultas.numero("SELECT COUNT(*) FROM solicitacao_atendimento WHERE situacao IN ('ENVIADA','EM_ANALISE')") + " pendentes",
                    "#/solicitacoes"));
            cartoes.add(cartao("instituicoes", "Instituições cadastradas", consultas.numero("SELECT COUNT(*) FROM instituicao WHERE ativa = 1"),
                    consultas.numero("SELECT COUNT(*) FROM instituicao WHERE ativa = 1 AND verificada = 1") + " verificadas", "#/rede"));
            cartoes.add(cartao("profissionais", "Profissionais ativos", consultas.numero("SELECT COUNT(*) FROM profissional p "
                    + "JOIN usuario u ON u.id_usuario = p.id_usuario WHERE p.ativo = 1 AND u.status = 'ATIVO'"), null, "#/profissionais"));
            cartoes.add(cartao("cadastros", "Contas aguardando ativação", consultas.numero("SELECT COUNT(*) FROM usuario WHERE status = 'PENDENTE_ATIVACAO'"),
                    null, "#/admin/usuarios"));
            cartoes.add(cartao("titulares", "Pedidos de privacidade abertos", consultas.numero("SELECT COUNT(*) FROM solicitacao_titular "
                    + "WHERE situacao IN ('ABERTA','EM_ANALISE')"), null, "#/admin/privacidade"));
            r.put("atividadesRecentes", consultas.lista("SELECT a.acao, a.tabela_afetada AS tabela, a.id_registro_afetado AS registro, "
                    + "u.nome_completo AS usuario, " + Consultas.dt("a.data_hora") + " AS dataHora FROM auditoria a "
                    + "LEFT JOIN usuario u ON u.id_usuario = a.id_usuario WHERE a.acao NOT IN ('LOGIN','LOGOUT','CONSULTA') "
                    + "ORDER BY a.data_hora DESC, a.id_auditoria DESC LIMIT 10"));
        } else if (ctx.profissional()) {
            cartoes.add(cartao("relatorios", "Relatórios em rascunho", consultas.numero("SELECT COUNT(*) FROM relatorio_atendimento r "
                    + "WHERE r.situacao = 'RASCUNHO' AND r.id_profissional_autor = ?", ctx.idProfissional()), null, "#/pessoas"));
            cartoes.add(cartao("mensagens", "Mensagens não lidas", contadores.get("mensagens"), null, "#/mensagens"));
            r.put("atividadesRecentes", consultas.lista("SELECT 'SESSAO' AS acao, c.nome_completo AS pessoa, rs.tipo_atendimento AS tipo, "
                    + Consultas.dt("t.data_hora_inicio_real") + " AS dataHora FROM atendimento t JOIN agendamento a ON a.id_agendamento = t.id_agendamento "
                    + "JOIN crianca c ON c.id_crianca = a.id_crianca LEFT JOIN registro_sessao rs ON rs.id_atendimento = t.id_atendimento "
                    + "WHERE t.id_usuario_registro = ? ORDER BY t.data_hora_inicio_real DESC LIMIT 8", ctx.idUsuario()));
        }
        r.put("proximasSessoes", consultas.lista("SELECT a.id_agendamento AS idAgendamento, a.id_crianca AS idCrianca, c.nome_completo AS pessoa, "
                + Consultas.dt("a.data_hora_inicio") + " AS inicio, (SELECT GROUP_CONCAT(u.nome_completo SEPARATOR ', ') "
                + "FROM agendamento_profissional ap JOIN profissional p ON p.id_profissional = ap.id_profissional "
                + "JOIN usuario u ON u.id_usuario = p.id_usuario WHERE ap.id_agendamento = a.id_agendamento) AS profissionais "
                + "FROM agendamento a JOIN crianca c ON c.id_crianca = a.id_crianca WHERE a.status = 'CONFIRMADO' "
                + "AND a.data_hora_inicio >= NOW() AND " + filtroA + " ORDER BY a.data_hora_inicio LIMIT 6", argsPessoa));
        r.put("sessoesPorMes", consultas.lista("SELECT DATE_FORMAT(t.data_hora_inicio_real, '%Y-%m') AS mes, COUNT(*) AS total "
                + "FROM atendimento t JOIN agendamento a ON a.id_agendamento = t.id_agendamento WHERE t.data_hora_inicio_real >= ? AND "
                + filtroA + " GROUP BY mes ORDER BY mes", concat(LocalDate.now().withDayOfMonth(1).minusMonths(5).atStartOfDay(), argsPessoa)));
        r.put("objetivos", consultas.lista("SELECT situacao, COUNT(*) AS total FROM objetivo WHERE " + filtroPessoa + " GROUP BY situacao",
                argsPessoa));
        return r;
    }

    private void painelInstitucional(ContextoUsuario ctx, Map<String, Object> r, List<Map<String, Object>> cartoes) {
        List<Long> inst = new ArrayList<>(ctx.instituicoes());
        String in = Consultas.marcadores(inst);
        Object[] args = inst.toArray();
        cartoes.add(cartao("recebidas", "Solicitações recebidas", consultas.numero("SELECT COUNT(*) FROM solicitacao_atendimento "
                + "WHERE id_instituicao IN (" + in + ")", args), null, "#/solicitacoes"));
        cartoes.add(cartao("pendentes", "Aguardando resposta", consultas.numero("SELECT COUNT(*) FROM solicitacao_atendimento "
                + "WHERE situacao IN ('ENVIADA','EM_ANALISE') AND id_instituicao IN (" + in + ")", args), null, "#/solicitacoes"));
        cartoes.add(cartao("vinculos", "Pessoas vinculadas", consultas.numero("SELECT COUNT(*) FROM crianca_instituicao "
                + "WHERE status = 'ATIVO' AND id_instituicao IN (" + in + ")", args), null, "#/rede/minha"));
        cartoes.add(cartao("vagas", "Vagas informadas", consultas.numero("SELECT COALESCE(SUM(vagas_disponiveis), 0) FROM instituicao "
                + "WHERE id_instituicao IN (" + in + ")", args), null, "#/rede/minha"));
        cartoes.add(cartao("mensagens", "Mensagens não lidas", r.get("contadores") instanceof Map<?, ?> m ? m.get("mensagens") : 0, null,
                "#/mensagens"));
        r.put("instituicoes", consultas.lista("SELECT id_instituicao AS idInstituicao, nome, vagas_disponiveis AS vagas, "
                + "aceita_solicitacoes AS aceitaSolicitacoes, verificada FROM instituicao WHERE id_instituicao IN (" + in + ") ORDER BY nome", args));
        r.put("ultimasSolicitacoes", consultas.lista("SELECT s.id_solicitacao AS idSolicitacao, i.nome AS instituicao, us.nome_completo AS solicitante, "
                + "s.situacao, " + Consultas.dt("s.data_criacao") + " AS dataCriacao FROM solicitacao_atendimento s "
                + "JOIN instituicao i ON i.id_instituicao = s.id_instituicao JOIN usuario us ON us.id_usuario = s.id_usuario_solicitante "
                + "WHERE s.id_instituicao IN (" + in + ") ORDER BY s.data_criacao DESC LIMIT 8", args));
    }

    private static Map<String, Object> cartao(String chave, String rotulo, Object valor, String detalhe, String link) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("chave", chave);
        m.put("rotulo", rotulo);
        m.put("valor", valor);
        m.put("detalhe", detalhe);
        m.put("link", link);
        return m;
    }

    private static Object[] concat(Object primeiro, Object[] resto) {
        Object[] r = new Object[resto.length + 1];
        r[0] = primeiro;
        System.arraycopy(resto, 0, r, 1, resto.length);
        return r;
    }
}
