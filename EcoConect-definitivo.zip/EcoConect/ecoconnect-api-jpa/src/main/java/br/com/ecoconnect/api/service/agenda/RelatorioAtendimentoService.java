package br.com.ecoconnect.api.service.agenda;

import br.com.ecoconnect.api.dto.NovaVersaoRelatorio;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Agendamento;
import br.com.ecoconnect.api.model.entity.Atendimento;
import br.com.ecoconnect.api.model.entity.AtendimentoProfissionalId;
import br.com.ecoconnect.api.model.entity.CriancaResponsavel;
import br.com.ecoconnect.api.model.entity.RelatorioAtendimento;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.SituacaoRelatorio;
import br.com.ecoconnect.api.model.enums.StatusVinculo;
import br.com.ecoconnect.api.model.enums.TipoNotificacao;
import br.com.ecoconnect.api.repository.AgendamentoRepository;
import br.com.ecoconnect.api.repository.AtendimentoProfissionalRepository;
import br.com.ecoconnect.api.repository.AtendimentoRepository;
import br.com.ecoconnect.api.repository.CriancaResponsavelRepository;
import br.com.ecoconnect.api.repository.RelatorioAtendimentoRepository;
import br.com.ecoconnect.api.repository.ResponsavelRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.NotificacaoService;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Set;

/**
 * RELATORIO_ATENDIMENTO.
 * Fluxo: RASCUNHO (editável) -> FINALIZADO -> LIBERADO_RESPONSAVEL.
 *  - RI-12: o autor precisa ter participado do atendimento (FK composta);
 *  - RI-13: o responsável só vê relatório liberado (ver /api/responsaveis/{id}/relatorios);
 *  - relatório finalizado/liberado não é editado: a correção cria nova versão e a anterior vira SUBSTITUIDO.
 * Observação: a modelagem cita id_usuario_liberacao e data_liberacao, mas essas colunas não existem
 * no banco entregue; quem liberou e quando fica registrado na AUDITORIA (ação LIBERACAO).
 */
@Service
public class RelatorioAtendimentoService extends CrudService<RelatorioAtendimento, Long> {

    private final AtendimentoRepository atendimentoRepository;
    private final AtendimentoProfissionalRepository participanteRepository;
    private final AgendamentoRepository agendamentoRepository;
    private final CriancaResponsavelRepository vinculoRepository;
    private final ResponsavelRepository responsavelRepository;
    private final NotificacaoService notificacaoService;

    public RelatorioAtendimentoService(RelatorioAtendimentoRepository repository, AuditoriaService auditoria,
                                       AtendimentoRepository atendimentoRepository,
                                       AtendimentoProfissionalRepository participanteRepository,
                                       AgendamentoRepository agendamentoRepository,
                                       CriancaResponsavelRepository vinculoRepository,
                                       ResponsavelRepository responsavelRepository,
                                       NotificacaoService notificacaoService) {
        super(repository, auditoria, "relatorio_atendimento");
        this.atendimentoRepository = atendimentoRepository;
        this.participanteRepository = participanteRepository;
        this.agendamentoRepository = agendamentoRepository;
        this.vinculoRepository = vinculoRepository;
        this.responsavelRepository = responsavelRepository;
        this.notificacaoService = notificacaoService;
    }

    @Override
    protected void antesDeCriar(RelatorioAtendimento r) {
        if (!atendimentoRepository.existsById(r.getIdAtendimento())) {
            throw new NaoEncontradoException("atendimento", r.getIdAtendimento());
        }
        if (!participanteRepository.existsById(new AtendimentoProfissionalId(r.getIdAtendimento(), r.getIdProfissionalAutor()))) {
            throw new RegraNegocioException("O profissional " + r.getIdProfissionalAutor()
                    + " não participou do atendimento " + r.getIdAtendimento() + " e não pode ser autor do relatório.");
        }
        r.setSituacao(SituacaoRelatorio.RASCUNHO);
        r.setNumeroVersao(1);
        r.setIdRelatorioSubstituido(null);
        r.setDataFinalizacao(null);
    }

    @Override
    protected void validarAtualizacao(RelatorioAtendimento atual, RelatorioAtendimento dados) {
        if (atual.getSituacao() != SituacaoRelatorio.RASCUNHO) {
            throw new RegraNegocioException("Só relatórios em RASCUNHO podem ser editados. Para corrigir, crie uma nova versão.");
        }
    }

    @Override
    protected Set<String> camposProtegidos() {
        return Set.of("idAtendimento", "idProfissionalAutor", "situacao", "numeroVersao",
                "idRelatorioSubstituido", "dataFinalizacao");
    }

    @Transactional
    public RelatorioAtendimento finalizar(Long id) {
        RelatorioAtendimento r = buscar(id);
        if (r.getSituacao() != SituacaoRelatorio.RASCUNHO) {
            throw new RegraNegocioException("Só relatórios em RASCUNHO podem ser finalizados.");
        }
        String antes = auditoria.json(r);
        r.setSituacao(SituacaoRelatorio.FINALIZADO);
        r.setDataFinalizacao(LocalDateTime.now());
        return salvarAlteracao(r, antes, AcaoAuditoria.ATUALIZACAO);
    }

    /** Libera ao responsável e notifica cada responsável com vínculo ATIVO e permissão de consulta. */
    @Transactional
    public RelatorioAtendimento liberar(Long id) {
        RelatorioAtendimento r = buscar(id);
        if (r.getSituacao() != SituacaoRelatorio.FINALIZADO) {
            throw new RegraNegocioException("Só relatórios FINALIZADOS podem ser liberados ao responsável.");
        }
        String antes = auditoria.json(r);
        r.setSituacao(SituacaoRelatorio.LIBERADO_RESPONSAVEL);
        RelatorioAtendimento salvo = salvarAlteracao(r, antes, AcaoAuditoria.LIBERACAO);

        Atendimento at = atendimentoRepository.findById(salvo.getIdAtendimento()).orElseThrow();
        Agendamento ag = agendamentoRepository.findById(at.getIdAgendamento()).orElseThrow();
        for (CriancaResponsavel v : vinculoRepository.findByIdCriancaAndStatusAndPodeConsultarDadosTrue(
                ag.getIdCrianca(), StatusVinculo.ATIVO)) {
            responsavelRepository.findById(v.getIdResponsavel()).ifPresent(resp ->
                    notificacaoService.notificar(resp.getIdUsuario(), TipoNotificacao.RELATORIO_LIBERADO,
                            "Novo relatório disponível", "O relatório \"" + salvo.getTitulo() + "\" foi liberado.",
                            null, null, salvo.getIdRelatorio()));
        }
        return salvo;
    }

    /** Correção de relatório FINALIZADO ou LIBERADO: nova versão (RASCUNHO); a anterior vira SUBSTITUIDO. */
    @Transactional
    public RelatorioAtendimento novaVersao(Long id, NovaVersaoRelatorio dados) {
        RelatorioAtendimento anterior = buscar(id);
        if (anterior.getSituacao() != SituacaoRelatorio.FINALIZADO
                && anterior.getSituacao() != SituacaoRelatorio.LIBERADO_RESPONSAVEL) {
            throw new RegraNegocioException("Nova versão só para relatório FINALIZADO ou LIBERADO_RESPONSAVEL. "
                    + "Rascunhos são editados com PUT.");
        }
        String antes = auditoria.json(anterior);
        anterior.setSituacao(SituacaoRelatorio.SUBSTITUIDO);
        salvarAlteracao(anterior, antes, AcaoAuditoria.ATUALIZACAO);

        RelatorioAtendimento nova = new RelatorioAtendimento();
        nova.setIdAtendimento(anterior.getIdAtendimento());
        nova.setIdProfissionalAutor(anterior.getIdProfissionalAutor());
        nova.setTitulo(dados.titulo().trim());
        nova.setConteudo(dados.conteudo());
        nova.setSituacao(SituacaoRelatorio.RASCUNHO);
        nova.setNumeroVersao(anterior.getNumeroVersao() + 1);
        nova.setIdRelatorioSubstituido(anterior.getIdRelatorio());
        RelatorioAtendimento salva = repository.saveAndFlush(nova);
        auditoria.registrar(AcaoAuditoria.CRIACAO, tabela(), salva, null, salva);
        return salva;
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.PROIBIDA;
    }

    // ------------------------------------------------------------------ escopo por pessoa
    @Override
    protected Long criancaDoRegistro(RelatorioAtendimento r) {
        return escopo() == null ? null : escopo().criancaDoAtendimento(r.getIdAtendimento());
    }

    @Override
    protected boolean registroDePessoa() {
        return true;
    }
}
