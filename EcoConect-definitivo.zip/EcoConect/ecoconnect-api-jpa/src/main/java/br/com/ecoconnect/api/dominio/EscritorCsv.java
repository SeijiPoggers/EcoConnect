package br.com.ecoconnect.api.dominio;

import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * CSV para relatórios: separador ';' e BOM UTF-8 (abre corretamente no Excel em português),
 * aspas quando necessário e proteção contra injeção de fórmulas (=, +, -, @).
 */
public final class EscritorCsv {

    private final StringBuilder sb = new StringBuilder("\uFEFF");

    public EscritorCsv linha(List<?> valores) {
        for (int i = 0; i < valores.size(); i++) {
            if (i > 0) sb.append(';');
            sb.append(celula(valores.get(i)));
        }
        sb.append("\r\n");
        return this;
    }

    public EscritorCsv linha(Object... valores) {
        return linha(java.util.Arrays.asList(valores));
    }

    public byte[] bytes() {
        return sb.toString().getBytes(StandardCharsets.UTF_8);
    }

    @Override
    public String toString() {
        return sb.toString();
    }

    static String celula(Object v) {
        if (v == null) return "";
        String s = v instanceof Boolean b ? (b ? "sim" : "não") : String.valueOf(v);
        if (!s.isEmpty() && "=+-@\t\r".indexOf(s.charAt(0)) >= 0) s = "'" + s;
        if (s.contains(";") || s.contains("\"") || s.contains("\n") || s.contains("\r")) {
            s = "\"" + s.replace("\"", "\"\"") + "\"";
        }
        return s;
    }
}
