package br.com.ecoconnect.api.service.app;

import br.com.ecoconnect.api.dominio.MapeadorFhir;
import br.com.ecoconnect.api.exception.NaoAutorizadoException;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.seguranca.ContextoAtual;
import br.com.ecoconnect.api.seguranca.ContextoUsuario;
import br.com.ecoconnect.api.seguranca.EscopoAcesso;
import br.com.ecoconnect.api.service.AuditoriaService;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Representação dos dados em HL7 FHIR R4 (Patient, Organization, Location, HealthcareService e
 * ServiceRequest), base para a interoperabilidade com a RNDS. Somente leitura; o Patient é
 * minimizado (sem CPF) e cada leitura de dados da pessoa é auditada.
 */
@Service
public class FhirService {

    private final Consultas consultas;
    private final EscopoAcesso escopo;
    private final SolicitacaoService solicitacaoService;
    private final AuditoriaService auditoria;

    public FhirService(Consultas consultas, EscopoAcesso escopo, SolicitacaoService solicitacaoService, AuditoriaService auditoria) {
        this.consultas = consultas;
        this.escopo = escopo;
        this.solicitacaoService = solicitacaoService;
        this.auditoria = auditoria;
    }

    public Map<String, Object> capacidades() {
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("resourceType", "CapabilityStatement");
        r.put("status", "active");
        r.put("date", LocalDate.now().toString());
        r.put("kind", "instance");
        r.put("software", Map.of("name", "EcoConect", "version", "1.0.0"));
        r.put("fhirVersion", "4.0.1");
        r.put("format", List.of("json"));
        List<Map<String, Object>> recursos = new ArrayList<>();
        for (String[] t : new String[][]{{"Organization", "Estabelecimentos do CNES (cnes-XXXXXXX) e instituições (inst-N)"},
                {"Location", "Endereço dos estabelecimentos do CNES"}, {"HealthcareService", "Serviços de uma instituição (?organization=inst-N)"},
                {"Patient", "Pessoa acompanhada, dados mínimos, somente para a equipe autorizada"},
                {"ServiceRequest", "Solicitação de atendimento a uma instituição"}}) {
            recursos.add(Map.of("type", t[0], "documentation", t[1], "interaction", List.of(Map.of("code", "read"))));
        }
        r.put("rest", List.of(Map.of("mode", "server", "resource", recursos)));
        return r;
    }

    @Transactional(readOnly = true)
    public Map<String, Object> organization(String id) {
        ContextoAtual.exigir();
        if (id.startsWith("cnes-")) {
            Map<String, Object> e = estabelecimento(id.substring(5));
            return MapeadorFhir.organization(str(e.get("codigoCnes")), str(e.get("nome")), str(e.get("telefone")), str(e.get("email")),
                    endereco(e), true);
        }
        if (id.startsWith("inst-")) {
            Map<String, Object> i = instituicao(id.substring(5));
            Map<String, Object> r = new LinkedHashMap<>();
            r.put("resourceType", "Organization");
            r.put("id", id);
            List<Map<String, Object>> ids = new ArrayList<>();
            ids.add(Map.of("system", MapeadorFhir.SISTEMA_ECOCONECT + ":instituicao", "value", str(i.get("idInstituicao"))));
            if (i.get("codigoCnes") != null) ids.add(Map.of("system", MapeadorFhir.SISTEMA_CNES, "value", str(i.get("codigoCnes"))));
            r.put("identifier", ids);
            r.put("active", RedeService.bool(i.get("ativa")));
            r.put("type", List.of(Map.of("text", RedeService.TIPOS_INSTITUICAO.getOrDefault(str(i.get("tipo")), str(i.get("tipo"))))));
            r.put("name", i.get("nome"));
            List<Map<String, Object>> telecom = new ArrayList<>();
            if (i.get("telefone") != null) telecom.add(Map.of("system", "phone", "value", str(i.get("telefone"))));
            if (i.get("email") != null) telecom.add(Map.of("system", "email", "value", str(i.get("email"))));
            if (!telecom.isEmpty()) r.put("telecom", telecom);
            r.put("address", List.of(endereco(i)));
            return r;
        }
        throw new NaoEncontradoException("Organization", id);
    }

    @Transactional(readOnly = true)
    public Map<String, Object> location(String id) {
        ContextoAtual.exigir();
        if (!id.startsWith("cnes-")) throw new NaoEncontradoException("Location", id);
        Map<String, Object> e = estabelecimento(id.substring(5));
        return MapeadorFhir.location(str(e.get("codigoCnes")), str(e.get("nome")), endereco(e), dbl(e.get("latitude")), dbl(e.get("longitude")));
    }

    @Transactional(readOnly = true)
    public Map<String, Object> servicos(String organizacao) {
        ContextoAtual.exigir();
        if (organizacao == null || !organizacao.startsWith("inst-")) throw new NaoEncontradoException("Organization", organizacao);
        Map<String, Object> i = instituicao(organizacao.substring(5));
        List<Map<String, Object>> recursos = new ArrayList<>();
        for (Map<String, Object> s : consultas.lista("SELECT id_servico AS id, nome, tipo_servico AS tipo, descricao, ativo "
                + "FROM instituicao_servico WHERE id_instituicao = ? AND ativo = 1", i.get("idInstituicao"))) {
            recursos.add(MapeadorFhir.healthcareService("serv-" + s.get("id"), "Organization/" + organizacao, str(s.get("nome")),
                    RedeService.TIPOS_SERVICO.getOrDefault(str(s.get("tipo")), str(s.get("tipo"))), str(s.get("descricao")), true));
        }
        return MapeadorFhir.bundle(recursos);
    }

    @Transactional(readOnly = true)
    public Map<String, Object> patient(Long idCrianca) {
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (!ctx.equipe()) throw new NaoAutorizadoException(403, "O recurso Patient é restrito à equipe de acompanhamento.");
        escopo.exigirCrianca(idCrianca);
        Map<String, Object> c = consultas.um("SELECT nome_completo AS nome, data_nascimento AS nascimento, sexo FROM crianca WHERE id_crianca = ?",
                idCrianca);
        if (c == null) throw new NaoEncontradoException("Patient", idCrianca);
        LocalDate nascimento = c.get("nascimento") instanceof java.sql.Date d ? d.toLocalDate()
                : c.get("nascimento") instanceof LocalDate l ? l : null;
        auditoria.registrarDados(AcaoAuditoria.CONSULTA, "crianca", idCrianca, idCrianca, null, Map.of("fhir", "Patient"));
        return MapeadorFhir.patient(idCrianca, str(c.get("nome")), nascimento, str(c.get("sexo")), null, false);
    }

    @Transactional(readOnly = true)
    public Map<String, Object> serviceRequest(Long idSolicitacao) {
        Map<String, Object> s = solicitacaoService.detalhe(idSolicitacao); // aplica as regras de acesso da solicitação
        String data = s.get("dataCriacao") == null ? null : str(s.get("dataCriacao"));
        return MapeadorFhir.serviceRequest(idSolicitacao, str(s.get("situacao")),
                s.get("idCrianca") == null ? null : ((Number) s.get("idCrianca")).longValue(),
                "Organization/inst-" + s.get("idInstituicao"), str(s.get("servico")), str(s.get("mensagem")), data);
    }

    /** Pacote com os recursos de uma solicitação (o que seria trocado com outro sistema). */
    @Transactional(readOnly = true)
    public Map<String, Object> pacoteDaSolicitacao(Long idSolicitacao) {
        Map<String, Object> sr = serviceRequest(idSolicitacao);
        List<Map<String, Object>> recursos = new ArrayList<>();
        recursos.add(sr);
        Object ref = ((List<?>) sr.get("performer")).isEmpty() ? null : ((Map<?, ?>) ((List<?>) sr.get("performer")).get(0)).get("reference");
        if (ref != null) recursos.add(organization(str(ref).substring("Organization/".length())));
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (sr.get("subject") instanceof Map<?, ?> subj && ctx.equipe()) {
            recursos.add(patient(Long.valueOf(str(subj.get("reference")).substring("Patient/".length()))));
        }
        Map<String, Object> b = MapeadorFhir.bundle(recursos);
        b.put("type", "collection");
        b.put("timestamp", LocalDateTime.now().withNano(0).toString());
        return b;
    }

    private Map<String, Object> estabelecimento(String cnes) {
        Map<String, Object> e = consultas.um("SELECT codigo_cnes AS codigoCnes, nome, telefone, email, logradouro, numero, bairro, "
                + "municipio, uf, cep, latitude, longitude FROM estabelecimento_sus WHERE codigo_cnes = ?", cnes);
        if (e == null) throw new NaoEncontradoException("Organization", "cnes-" + cnes);
        return e;
    }

    private Map<String, Object> instituicao(String id) {
        Long n;
        try {
            n = Long.valueOf(id);
        } catch (NumberFormatException ex) {
            throw new NaoEncontradoException("Organization", "inst-" + id);
        }
        Map<String, Object> i = consultas.um("SELECT id_instituicao AS idInstituicao, nome, tipo, codigo_cnes AS codigoCnes, telefone, email, "
                + "logradouro, numero, bairro, municipio, uf, cep, ativa FROM instituicao WHERE id_instituicao = ?", n);
        if (i == null) throw new NaoEncontradoException("Organization", "inst-" + id);
        return i;
    }

    private static Map<String, Object> endereco(Map<String, Object> e) {
        return MapeadorFhir.endereco(str(e.get("logradouro")), str(e.get("numero")), str(e.get("bairro")), str(e.get("municipio")),
                str(e.get("uf")), str(e.get("cep")));
    }

    private static String str(Object o) {
        return o == null ? null : o.toString();
    }

    private static Double dbl(Object o) {
        return o instanceof BigDecimal b ? b.doubleValue() : o instanceof Number n ? n.doubleValue() : null;
    }
}
