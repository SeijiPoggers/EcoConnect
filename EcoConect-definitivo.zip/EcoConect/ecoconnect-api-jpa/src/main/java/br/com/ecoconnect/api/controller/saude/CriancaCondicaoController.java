package br.com.ecoconnect.api.controller.saude;

import br.com.ecoconnect.api.controller.base.LeituraController;
import br.com.ecoconnect.api.dto.ValidacaoRequisicao;
import br.com.ecoconnect.api.model.entity.CriancaCondicao;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.saude.CriancaCondicaoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/** Condições de saúde das crianças. Sem DELETE (dado de saúde); use a validação REJEITADO. */
@RestController
@RequestMapping("/api/criancas-condicoes")
public class CriancaCondicaoController extends LeituraController<CriancaCondicao, Long> {

    private final CriancaCondicaoService service;

    public CriancaCondicaoController(CriancaCondicaoService service) {
        this.service = service;
    }

    @Override
    protected CrudService<CriancaCondicao, Long> service() {
        return service;
    }

    /** Registra a informação. Ela nasce com situacaoValidacao = DECLARADO. */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CriancaCondicao criar(@Valid @RequestBody CriancaCondicao dados) {
        return service.criar(dados);
    }

    /** Corrige um registro ainda não VALIDADO. */
    @PutMapping("/{id}")
    public CriancaCondicao atualizar(@PathVariable Long id, @Valid @RequestBody CriancaCondicao dados) {
        return service.atualizar(id, dados);
    }

    /** {"situacaoValidacao": "VALIDADO", "idUsuarioValidacao": 2} */
    @PatchMapping("/{id}/validacao")
    public CriancaCondicao validar(@PathVariable Long id, @Valid @RequestBody ValidacaoRequisicao dados) {
        return service.validar(id, dados.situacaoValidacao(), dados.idUsuarioValidacao());
    }
}
