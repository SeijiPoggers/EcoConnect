package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * Tabela `profissional` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 */
@Entity
@Table(name = "profissional")
public class Profissional implements Entidade<Long> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_profissional", nullable = false)
    private Long idProfissional;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_usuario", nullable = false)
    private Long idUsuario;

    @Size(max = 20)
    @Column(name = "conselho_profissional", length = 20)
    private String conselhoProfissional;

    @Size(max = 30)
    @Column(name = "registro_profissional", length = 30)
    private String registroProfissional;

    @Column(name = "ativo", nullable = false)
    private Boolean ativo;

    @PrePersist
    void aoInserir() {
        if (ativo == null) {
            ativo = Boolean.TRUE;
        }
    }

    public Long getIdProfissional() {
        return idProfissional;
    }

    public void setIdProfissional(Long idProfissional) {
        this.idProfissional = idProfissional;
    }

    public Long getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getConselhoProfissional() {
        return conselhoProfissional;
    }

    public void setConselhoProfissional(String conselhoProfissional) {
        this.conselhoProfissional = conselhoProfissional;
    }

    public String getRegistroProfissional() {
        return registroProfissional;
    }

    public void setRegistroProfissional(String registroProfissional) {
        this.registroProfissional = registroProfissional;
    }

    public Boolean getAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    @Override
    public Long chave() {
        return idProfissional;
    }

    @Override
    public void definirChave(Long id) {
        this.idProfissional = id;
    }
}
