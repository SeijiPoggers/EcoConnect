package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.InstituicaoServico;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InstituicaoServicoRepository extends JpaRepository<InstituicaoServico, Long> {

    List<InstituicaoServico> findByIdInstituicaoOrderByNomeAsc(Long idInstituicao);
    List<InstituicaoServico> findByAtivoTrue();

}
