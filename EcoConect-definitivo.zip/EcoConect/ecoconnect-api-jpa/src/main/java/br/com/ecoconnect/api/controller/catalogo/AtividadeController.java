package br.com.ecoconnect.api.controller.catalogo;

import br.com.ecoconnect.api.controller.base.CrudController;
import br.com.ecoconnect.api.model.entity.Atividade;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.catalogo.AtividadeService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Tipos de atividade dos atendimentos (catálogo). DELETE apenas desativa (ativo = 0). */
@RestController
@RequestMapping("/api/atividades")
public class AtividadeController extends CrudController<Atividade, Integer> {

    private final AtividadeService service;

    public AtividadeController(AtividadeService service) {
        this.service = service;
    }

    @Override
    protected CrudService<Atividade, Integer> service() {
        return service;
    }
}
