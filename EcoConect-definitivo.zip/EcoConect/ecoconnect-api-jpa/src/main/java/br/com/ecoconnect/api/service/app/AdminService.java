package br.com.ecoconnect.api.service.app;

import br.com.ecoconnect.api.dominio.Papeis;
import br.com.ecoconnect.api.dominio.Tokens;
import br.com.ecoconnect.api.exception.ConflitoException;
import br.com.ecoconnect.api.exception.NaoAutorizadoException;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Perfil;
import br.com.ecoconnect.api.model.entity.Profissional;
import br.com.ecoconnect.api.model.entity.Responsavel;
import br.com.ecoconnect.api.model.entity.Usuario;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.StatusUsuario;
import br.com.ecoconnect.api.repository.PerfilRepository;
import br.com.ecoconnect.api.repository.ProfissionalRepository;
import br.com.ecoconnect.api.repository.ResponsavelRepository;
import br.com.ecoconnect.api.repository.UsuarioRepository;
import br.com.ecoconnect.api.seguranca.ContextoAtual;
import br.com.ecoconnect.api.seguranca.ContextoUsuario;
import br.com.ecoconnect.api.seguranca.SessaoService;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.pessoa.ProfissionalEspecialidadeService;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Administração: contas de todos os perfis (com o cadastro complementar em uma única operação),
 * ativação, bloqueio, redefinição de senha (com troca obrigatória) e consulta da auditoria.
 */
@Service
public class AdminService {

    private final UsuarioRepository usuarioRepository;
    private final PerfilRepository perfilRepository;
    private final ResponsavelRepository responsavelRepository;
    private final ProfissionalRepository profissionalRepository;
    private final ProfissionalEspecialidadeService especialidadeService;
    private final PasswordEncoder passwordEncoder;
    private final SessaoService sessaoService;
    private final Consultas consultas;
    private final AuditoriaService auditoria;

    public AdminService(UsuarioRepository usuarioRepository, PerfilRepository perfilRepository, ResponsavelRepository responsavelRepository,
                        ProfissionalRepository profissionalRepository, ProfissionalEspecialidadeService especialidadeService,
                        PasswordEncoder passwordEncoder, SessaoService sessaoService, Consultas consultas, AuditoriaService auditoria) {
        this.usuarioRepository = usuarioRepository;
        this.perfilRepository = perfilRepository;
        this.responsavelRepository = responsavelRepository;
        this.profissionalRepository = profissionalRepository;
        this.especialidadeService = especialidadeService;
        this.passwordEncoder = passwordEncoder;
        this.sessaoService = sessaoService;
        this.consultas = consultas;
        this.auditoria = auditoria;
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> usuarios(String texto, String perfil, String status) {
        exigirAdministrador();
        StringBuilder sql = new StringBuilder("SELECT u.id_usuario AS idUsuario, u.nome_completo AS nome, u.email, u.telefone, p.nome AS perfil, "
                + "u.status, u.exige_troca_senha AS exigeTrocaSenha, " + Consultas.dt("u.data_cadastro") + " AS dataCadastro, "
                + Consultas.dt("u.data_ultimo_acesso") + " AS ultimoAcesso, r.id_responsavel AS idResponsavel, pr.id_profissional AS idProfissional, "
                + "cu.id_crianca AS idCriancaPropria, (SELECT GROUP_CONCAT(i.nome SEPARATOR ', ') FROM instituicao_membro m "
                + " JOIN instituicao i ON i.id_instituicao = m.id_instituicao WHERE m.id_usuario = u.id_usuario AND m.ativo = 1) AS instituicoes, "
                + "EXISTS (SELECT 1 FROM registro_demonstracao d WHERE d.tabela = 'usuario' AND CAST(d.id_registro AS UNSIGNED) = u.id_usuario) AS demonstracao "
                + "FROM usuario u JOIN perfil p ON p.id_perfil = u.id_perfil LEFT JOIN responsavel r ON r.id_usuario = u.id_usuario "
                + "LEFT JOIN profissional pr ON pr.id_usuario = u.id_usuario LEFT JOIN crianca_usuario cu ON cu.id_usuario = u.id_usuario WHERE 1 = 1");
        List<Object> args = new ArrayList<>();
        if (RedeService.vazio(texto) != null) {
            sql.append(" AND (LOWER(u.nome_completo) LIKE ? OR LOWER(u.email) LIKE ?)");
            String t = "%" + texto.trim().toLowerCase(Locale.ROOT) + "%";
            args.add(t);
            args.add(t);
        }
        if (RedeService.vazio(perfil) != null) {
            sql.append(" AND p.nome = ?");
            args.add(perfil.trim().toUpperCase(Locale.ROOT));
        }
        if (RedeService.vazio(status) != null) {
            sql.append(" AND u.status = ?");
            args.add(status.trim().toUpperCase(Locale.ROOT));
        }
        sql.append(" ORDER BY FIELD(u.status,'PENDENTE_ATIVACAO','ATIVO','BLOQUEADO','INATIVO'), u.nome_completo LIMIT 500");
        return consultas.lista(sql.toString(), args.toArray());
    }

    public record NovoUsuario(String nomeCompleto, String email, String telefone, String perfil, String senhaTemporaria, String cpf,
                              String conselhoProfissional, String registroProfissional, List<Integer> especialidades,
                              Long idInstituicao, Long idCrianca) {
    }

    @Transactional
    public Map<String, Object> criar(NovoUsuario d) {
        exigirAdministrador();
        String perfil = d.perfil() == null ? "" : d.perfil().trim().toUpperCase(Locale.ROOT);
        if (!Papeis.TODOS.contains(perfil)) throw new RegraNegocioException("Perfil inválido.");
        Perfil p = perfilRepository.findByNome(perfil).orElseThrow(() -> new RegraNegocioException("Perfil " + perfil + " não existe no banco."));
        String nome = PessoasService.texto(d.nomeCompleto(), 150);
        if (nome == null) throw new RegraNegocioException("Informe o nome completo.");
        String email = d.email() == null ? "" : d.email().trim().toLowerCase(Locale.ROOT);
        if (!email.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) throw new RegraNegocioException("E-mail inválido.");
        if (usuarioRepository.existsByEmail(email)) throw new ConflitoException("Já existe um usuário com o e-mail " + email + ".");
        String senha = RedeService.vazio(d.senhaTemporaria()) == null ? Tokens.senhaTemporaria() : d.senhaTemporaria();
        validarSenha(senha);
        if (Papeis.ADMIN_INSTITUCIONAL.equals(perfil) && d.idInstituicao() == null) {
            throw new RegraNegocioException("Informe a instituição administrada.");
        }
        if (Papeis.PESSOA_ACOMPANHADA.equals(perfil)) {
            if (d.idCrianca() == null) throw new RegraNegocioException("Informe qual pessoa acompanhada usará esta conta.");
            if (consultas.numero("SELECT COUNT(*) FROM crianca WHERE id_crianca = ?", d.idCrianca()) == 0) {
                throw new NaoEncontradoException("crianca", d.idCrianca());
            }
            if (consultas.numero("SELECT COUNT(*) FROM crianca_usuario WHERE id_crianca = ?", d.idCrianca()) > 0) {
                throw new ConflitoException("Esta pessoa já tem uma conta própria.");
            }
        }
        if (d.idInstituicao() != null && consultas.numero("SELECT COUNT(*) FROM instituicao WHERE id_instituicao = ?", d.idInstituicao()) == 0) {
            throw new NaoEncontradoException("instituicao", d.idInstituicao());
        }
        String cpf = d.cpf() == null ? null : d.cpf().replaceAll("\\D", "");
        if (cpf != null && cpf.isEmpty()) cpf = null;
        if (cpf != null && cpf.length() != 11) throw new RegraNegocioException("O CPF deve ter 11 dígitos.");

        Usuario u = new Usuario();
        u.setIdPerfil(p.getIdPerfil());
        u.setNomeCompleto(nome);
        u.setEmail(email);
        u.setTelefone(PessoasService.texto(d.telefone(), 20));
        u.setSenhaHash(passwordEncoder.encode(senha));
        u.setStatus(StatusUsuario.ATIVO);
        u.setExigeTrocaSenha(Boolean.TRUE);
        Usuario salvo = usuarioRepository.saveAndFlush(u);
        auditoria.registrar(AcaoAuditoria.CRIACAO, "usuario", salvo, null, salvo);
        Long id = salvo.getIdUsuario();
        switch (perfil) {
            case Papeis.RESPONSAVEL -> {
                Responsavel r = new Responsavel();
                r.setIdUsuario(id);
                r.setCpf(cpf);
                auditoria.registrar(AcaoAuditoria.CRIACAO, "responsavel", responsavelRepository.saveAndFlush(r), null, r);
            }
            case Papeis.PROFISSIONAL -> {
                Profissional pr = new Profissional();
                pr.setIdUsuario(id);
                pr.setConselhoProfissional(PessoasService.texto(d.conselhoProfissional(), 20));
                pr.setRegistroProfissional(PessoasService.texto(d.registroProfissional(), 30));
                pr.setAtivo(Boolean.TRUE);
                Profissional prs = profissionalRepository.saveAndFlush(pr);
                auditoria.registrar(AcaoAuditoria.CRIACAO, "profissional", prs, null, prs);
                boolean primeiro = true;
                if (d.especialidades() != null) {
                    for (Integer e : d.especialidades()) {
                        especialidadeService.adicionar(prs.getIdProfissional(), e, primeiro);
                        primeiro = false;
                    }
                }
                if (d.idInstituicao() != null) membro(d.idInstituicao(), id, Papeis.PROFISSIONAL);
            }
            case Papeis.ADMIN_INSTITUCIONAL -> membro(d.idInstituicao(), id, Papeis.ADMIN_INSTITUCIONAL);
            case Papeis.PESSOA_ACOMPANHADA -> {
                consultas.executar("INSERT INTO crianca_usuario (id_crianca, id_usuario) VALUES (?, ?)", d.idCrianca(), id);
                auditoria.registrarDados(AcaoAuditoria.CRIACAO, "crianca_usuario", d.idCrianca(), d.idCrianca(), null,
                        Map.of("idCrianca", d.idCrianca(), "idUsuario", id));
            }
            default -> {
            }
        }
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("idUsuario", id);
        r.put("email", email);
        r.put("perfil", perfil);
        r.put("senhaTemporaria", senha);
        r.put("mensagem", "Conta criada e ativa. Entregue a senha temporária à pessoa por um canal seguro: "
                + "ela será obrigada a trocá-la no primeiro acesso. A senha não será exibida novamente.");
        return r;
    }

    private void membro(Long idInstituicao, Long idUsuario, String papel) {
        long id = consultas.inserir("INSERT INTO instituicao_membro (id_instituicao, id_usuario, papel, ativo) VALUES (?, ?, ?, 1)",
                idInstituicao, idUsuario, papel);
        auditoria.registrarDados(AcaoAuditoria.CRIACAO, "instituicao_membro", id, null, null,
                Map.of("idInstituicao", idInstituicao, "idUsuario", idUsuario, "papel", papel));
    }

    public record NovoStatus(String status) {
    }

    @Transactional
    public Map<String, Object> alterarStatus(Long idUsuario, NovoStatus d) {
        ContextoUsuario ctx = exigirAdministrador();
        if (idUsuario.equals(ctx.idUsuario())) throw new RegraNegocioException("Você não pode alterar a situação da própria conta.");
        StatusUsuario status;
        try {
            status = StatusUsuario.valueOf(d.status() == null ? "" : d.status().trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            throw new RegraNegocioException("Situação inválida. Use PENDENTE_ATIVACAO, ATIVO, BLOQUEADO ou INATIVO.");
        }
        Usuario u = usuarioRepository.findById(idUsuario).orElseThrow(() -> new NaoEncontradoException("usuario", idUsuario));
        String antes = auditoria.json(u);
        u.setStatus(status);
        Usuario salvo = usuarioRepository.saveAndFlush(u);
        auditoria.registrar(AcaoAuditoria.ATUALIZACAO, "usuario", salvo, antes, salvo);
        if (status != StatusUsuario.ATIVO) sessaoService.revogarTodas(idUsuario, null);
        return Map.of("idUsuario", idUsuario, "status", status.name());
    }

    @Transactional
    public Map<String, Object> redefinirSenha(Long idUsuario) {
        ContextoUsuario ctx = exigirAdministrador();
        if (idUsuario.equals(ctx.idUsuario())) throw new RegraNegocioException("Para a sua própria senha, use Minha conta > Trocar senha.");
        Usuario u = usuarioRepository.findById(idUsuario).orElseThrow(() -> new NaoEncontradoException("usuario", idUsuario));
        String antes = auditoria.json(u);
        String senha = Tokens.senhaTemporaria();
        u.setSenhaHash(passwordEncoder.encode(senha));
        u.setExigeTrocaSenha(Boolean.TRUE);
        Usuario salvo = usuarioRepository.saveAndFlush(u);
        auditoria.registrar(AcaoAuditoria.ATUALIZACAO, "usuario", salvo, antes, salvo);
        sessaoService.revogarTodas(idUsuario, null);
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("idUsuario", idUsuario);
        r.put("senhaTemporaria", senha);
        r.put("mensagem", "Senha redefinida e sessões encerradas. A pessoa deverá trocar a senha no próximo acesso.");
        return r;
    }

    public record FiltroAuditoria(String acao, String tabela, Long idUsuario, Long idCrianca, LocalDate de, LocalDate ate, Integer pagina) {
    }

    @Transactional(readOnly = true)
    public Map<String, Object> auditoria(FiltroAuditoria f) {
        exigirAdministrador();
        StringBuilder where = new StringBuilder(" WHERE 1 = 1");
        List<Object> args = new ArrayList<>();
        if (RedeService.vazio(f.acao()) != null) {
            where.append(" AND a.acao = ?");
            args.add(f.acao().trim().toUpperCase(Locale.ROOT));
        }
        if (RedeService.vazio(f.tabela()) != null) {
            where.append(" AND a.tabela_afetada = ?");
            args.add(f.tabela().trim());
        }
        if (f.idUsuario() != null) {
            where.append(" AND a.id_usuario = ?");
            args.add(f.idUsuario());
        }
        if (f.idCrianca() != null) {
            where.append(" AND a.id_crianca = ?");
            args.add(f.idCrianca());
        }
        if (f.de() != null) {
            where.append(" AND a.data_hora >= ?");
            args.add(f.de().atStartOfDay());
        }
        if (f.ate() != null) {
            where.append(" AND a.data_hora < ?");
            args.add(f.ate().plusDays(1).atStartOfDay());
        }
        int pagina = f.pagina() == null || f.pagina() < 0 ? 0 : f.pagina();
        long total = consultas.numero("SELECT COUNT(*) FROM auditoria a" + where, args.toArray());
        List<Object> argsPagina = new ArrayList<>(args);
        argsPagina.add(pagina * 50);
        List<Map<String, Object>> itens = consultas.lista("SELECT a.id_auditoria AS idAuditoria, a.acao, a.tabela_afetada AS tabela, "
                + "a.id_registro_afetado AS registro, a.id_crianca AS idCrianca, u.nome_completo AS usuario, a.ip_origem AS ip, "
                + Consultas.dt("a.data_hora") + " AS dataHora, CAST(a.valores_anteriores AS CHAR) AS antes, CAST(a.valores_novos AS CHAR) AS depois "
                + "FROM auditoria a LEFT JOIN usuario u ON u.id_usuario = a.id_usuario" + where
                + " ORDER BY a.data_hora DESC, a.id_auditoria DESC LIMIT 50 OFFSET ?", argsPagina.toArray());
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("itens", itens);
        r.put("pagina", pagina);
        r.put("total", total);
        r.put("totalPaginas", (total + 49) / 50);
        return r;
    }

    private static void validarSenha(String senha) {
        if (senha == null || senha.length() < 8 || senha.length() > 72 || !senha.matches(".*[A-Za-z].*") || !senha.matches(".*\\d.*")) {
            throw new RegraNegocioException("A senha deve ter de 8 a 72 caracteres, com letras e números.");
        }
    }

    private ContextoUsuario exigirAdministrador() {
        ContextoUsuario ctx = ContextoAtual.exigir();
        if (!ctx.administrador()) throw new NaoAutorizadoException(403, "Somente o administrador acessa esta área.");
        return ctx;
    }
}
