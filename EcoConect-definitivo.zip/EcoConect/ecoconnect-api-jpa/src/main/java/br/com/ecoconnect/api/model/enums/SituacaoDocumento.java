package br.com.ecoconnect.api.model.enums;

/** Situação do documento. Valores idênticos ao ENUM do MySQL. */
public enum SituacaoDocumento {
    VIGENTE, SUBSTITUIDO, REMOVIDO_LOGICAMENTE
}
