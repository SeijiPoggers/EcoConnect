package br.com.ecoconnect.api.service.pessoa;

import br.com.ecoconnect.api.dto.AlteracaoSenha;
import br.com.ecoconnect.api.dto.LoginResposta;
import br.com.ecoconnect.api.dto.Pagina;
import br.com.ecoconnect.api.dto.UsuarioAlteracao;
import br.com.ecoconnect.api.dto.UsuarioCriacao;
import br.com.ecoconnect.api.exception.ConflitoException;
import br.com.ecoconnect.api.exception.NaoAutorizadoException;
import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Perfil;
import br.com.ecoconnect.api.model.entity.Responsavel;
import br.com.ecoconnect.api.model.entity.Profissional;
import br.com.ecoconnect.api.model.entity.Usuario;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.StatusUsuario;
import br.com.ecoconnect.api.repository.PerfilRepository;
import br.com.ecoconnect.api.repository.ProfissionalRepository;
import br.com.ecoconnect.api.repository.ResponsavelRepository;
import br.com.ecoconnect.api.repository.UsuarioRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.Verificacoes;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

/**
 * USUARIO: pessoa com login. Senha só como hash BCrypt (usuario.senha_hash), nunca devolvida no JSON.
 * DELETE não apaga: muda o status para INATIVO.
 */
@Service
public class UsuarioService extends CrudService<Usuario, Long> {

    private final UsuarioRepository usuarioRepository;
    private final PerfilRepository perfilRepository;
    private final ResponsavelRepository responsavelRepository;
    private final ProfissionalRepository profissionalRepository;
    private final PasswordEncoder passwordEncoder;

    public UsuarioService(UsuarioRepository repository, AuditoriaService auditoria, PerfilRepository perfilRepository,
                          ResponsavelRepository responsavelRepository, ProfissionalRepository profissionalRepository,
                          PasswordEncoder passwordEncoder) {
        super(repository, auditoria, "usuario");
        this.usuarioRepository = repository;
        this.perfilRepository = perfilRepository;
        this.responsavelRepository = responsavelRepository;
        this.profissionalRepository = profissionalRepository;
        this.passwordEncoder = passwordEncoder;
    }

    /** Nunca permite filtrar pela senha (o parâmetro senhaHash é ignorado). */
    @Override
    @Transactional(readOnly = true)
    public Pagina<Usuario> listar(Usuario filtro, Pageable pageable) {
        filtro.setSenhaHash(null);
        return super.listar(filtro, pageable);
    }

    @Transactional
    public Usuario criar(UsuarioCriacao dados) {
        perfil(dados.idPerfil());
        String email = normalizarEmail(dados.email());
        if (usuarioRepository.existsByEmail(email)) {
            throw new ConflitoException("Já existe um usuário com o e-mail " + email + ".");
        }
        validarSenha(dados.senha());
        Usuario u = new Usuario();
        u.setIdPerfil(dados.idPerfil());
        u.setNomeCompleto(dados.nomeCompleto().trim());
        u.setEmail(email);
        u.setTelefone(vazioParaNulo(dados.telefone()));
        u.setSenhaHash(passwordEncoder.encode(dados.senha()));
        u.setStatus(StatusUsuario.PENDENTE_ATIVACAO);
        Usuario salvo = repository.saveAndFlush(u);
        auditoria.registrar(AcaoAuditoria.CRIACAO, tabela(), salvo, null, salvo);
        return salvo;
    }

    @Transactional
    public Usuario alterar(Long id, UsuarioAlteracao dados) {
        Usuario u = buscar(id);
        String antes = auditoria.json(u);
        Perfil novoPerfil = perfil(dados.idPerfil());
        String email = normalizarEmail(dados.email());
        if (usuarioRepository.existsByEmailAndIdUsuarioNot(email, id)) {
            throw new ConflitoException("Já existe outro usuário com o e-mail " + email + ".");
        }
        // RI-02 / E.3: o perfil precisa continuar coerente com o cadastro complementar
        if (responsavelRepository.existsByIdUsuario(id) && !Verificacoes.RESPONSAVEL.equals(novoPerfil.getNome())) {
            throw new RegraNegocioException("Este usuário tem cadastro de responsável: o perfil deve continuar RESPONSAVEL.");
        }
        if (profissionalRepository.existsByIdUsuario(id) && !Verificacoes.PROFISSIONAL.equals(novoPerfil.getNome())) {
            throw new RegraNegocioException("Este usuário tem cadastro de profissional: o perfil deve continuar PROFISSIONAL.");
        }
        u.setIdPerfil(dados.idPerfil());
        u.setNomeCompleto(dados.nomeCompleto().trim());
        u.setEmail(email);
        u.setTelefone(vazioParaNulo(dados.telefone()));
        return salvarAlteracao(u, antes, AcaoAuditoria.ATUALIZACAO);
    }

    @Transactional
    public Usuario alterarStatus(Long id, StatusUsuario status) {
        Usuario u = buscar(id);
        String antes = auditoria.json(u);
        u.setStatus(status);
        return salvarAlteracao(u, antes, AcaoAuditoria.ATUALIZACAO);
    }

    @Transactional
    public void alterarSenha(Long id, AlteracaoSenha dados) {
        Usuario u = buscar(id);
        if (dados.senhaAtual() != null && !passwordEncoder.matches(dados.senhaAtual(), u.getSenhaHash())) {
            throw new NaoAutorizadoException(401, "Senha atual incorreta.");
        }
        validarSenha(dados.novaSenha());
        String antes = auditoria.json(u);
        u.setSenhaHash(passwordEncoder.encode(dados.novaSenha()));
        salvarAlteracao(u, antes, AcaoAuditoria.ATUALIZACAO);
    }

    /** Login: confere e-mail e senha, exige conta ATIVA, registra LOGIN ou LOGIN_FALHA na auditoria. */
    @Transactional(noRollbackFor = NaoAutorizadoException.class)
    public LoginResposta login(String emailInformado, String senha) {
        String email = normalizarEmail(emailInformado);
        Usuario u = usuarioRepository.findByEmail(email).orElse(null);
        if (u == null || !passwordEncoder.matches(senha, u.getSenhaHash())) {
            auditoria.registrarAcao(AcaoAuditoria.LOGIN_FALHA, u == null ? null : u.getIdUsuario(), "usuario",
                    u == null ? null : String.valueOf(u.getIdUsuario()));
            throw new NaoAutorizadoException(401, "E-mail ou senha incorretos.");
        }
        if (u.getStatus() != StatusUsuario.ATIVO) {
            auditoria.registrarAcao(AcaoAuditoria.LOGIN_FALHA, u.getIdUsuario(), "usuario", String.valueOf(u.getIdUsuario()));
            String motivo = switch (u.getStatus()) {
                case PENDENTE_ATIVACAO -> "Conta pendente de ativação.";
                case BLOQUEADO -> "Conta bloqueada.";
                default -> "Conta inativa.";
            };
            throw new NaoAutorizadoException(403, motivo);
        }
        u.setDataUltimoAcesso(LocalDateTime.now());
        usuarioRepository.save(u);
        auditoria.registrarAcao(AcaoAuditoria.LOGIN, u.getIdUsuario(), "usuario", String.valueOf(u.getIdUsuario()));
        String perfil = perfilRepository.findById(u.getIdPerfil()).map(Perfil::getNome).orElse("");
        Long idResponsavel = responsavelRepository.findByIdUsuario(u.getIdUsuario()).map(Responsavel::getIdResponsavel).orElse(null);
        Long idProfissional = profissionalRepository.findByIdUsuario(u.getIdUsuario()).map(Profissional::getIdProfissional).orElse(null);
        return new LoginResposta(u, perfil, idResponsavel, idProfissional);
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.LOGICA;
    }

    @Override
    protected void aplicarExclusaoLogica(Usuario u) {
        u.setStatus(StatusUsuario.INATIVO);
    }

    // ------------------------------------------------------------------

    private Perfil perfil(Integer idPerfil) {
        return perfilRepository.findById(idPerfil).orElseThrow(() -> new NaoEncontradoException("perfil", idPerfil));
    }

    private static void validarSenha(String senha) {
        if (senha == null || senha.length() < 8 || !senha.matches(".*[A-Za-z].*") || !senha.matches(".*\\d.*")) {
            throw new RegraNegocioException("A senha deve ter pelo menos 8 caracteres, com letras e números.");
        }
    }

    private static String normalizarEmail(String email) {
        return email == null ? null : email.trim().toLowerCase();
    }

    private static String vazioParaNulo(String s) {
        return s == null || s.isBlank() ? null : s.trim();
    }
}
