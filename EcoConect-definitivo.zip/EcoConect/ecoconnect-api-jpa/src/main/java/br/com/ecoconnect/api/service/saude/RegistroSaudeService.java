package br.com.ecoconnect.api.service.saude;

import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.Entidade;
import br.com.ecoconnect.api.model.entity.RegistroDeSaude;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.SituacaoValidacao;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.Verificacoes;
import br.com.ecoconnect.api.service.base.CrudService;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

/**
 * Regras comuns de CRIANCA_DIAGNOSTICO, CRIANCA_CONDICAO e HISTORICO_SAUDE:
 *  - RI-04: toda informação nasce DECLARADO; a validação é feita depois, por alguém da equipe;
 *  - RI-05: guarda autor e data de registro;
 *  - RI-07: documento comprobatório deve ser da mesma criança;
 *  - registro VALIDADO não é alterado (registre um novo);
 *  - RI-20: não há exclusão física.
 */
public abstract class RegistroSaudeService<E extends Entidade<Long> & RegistroDeSaude> extends CrudService<E, Long> {

    protected final Verificacoes verificacoes;

    protected RegistroSaudeService(JpaRepository<E, Long> repository, AuditoriaService auditoria, String tabela,
                                   Verificacoes verificacoes) {
        super(repository, auditoria, tabela);
        this.verificacoes = verificacoes;
    }

    @Override
    protected void antesDeCriar(E e) {
        verificacoes.crianca(e.getIdCrianca());
        verificacoes.usuarioAtivo(e.getIdUsuarioRegistro(), "Quem registra");
        verificacoes.documentoDaCrianca(e.getIdDocumento(), e.getIdCrianca());
        e.setSituacaoValidacao(SituacaoValidacao.DECLARADO);
        e.setIdUsuarioValidacao(null);
        e.setDataValidacao(null);
        validarEspecifico(e);
    }

    @Override
    protected void validarAtualizacao(E atual, E dados) {
        if (atual.getSituacaoValidacao() == SituacaoValidacao.VALIDADO) {
            throw new RegraNegocioException("Registro já VALIDADO não pode ser alterado. Registre uma nova informação.");
        }
    }

    @Override
    protected Set<String> camposProtegidos() {
        Set<String> campos = new HashSet<>(Set.of("idCrianca", "idUsuarioRegistro",
                "situacaoValidacao", "idUsuarioValidacao", "dataValidacao"));
        campos.addAll(camposProtegidosExtras());
        return campos;
    }

    @Override
    protected void antesDeSalvarAtualizacao(E e) {
        verificacoes.documentoDaCrianca(e.getIdDocumento(), e.getIdCrianca());
        validarEspecifico(e);
    }

    /** Muda a situação de validação; registra quem e quando (auditoria VALIDACAO). */
    @Transactional
    public E validar(Long id, SituacaoValidacao situacao, Long idUsuarioValidacao) {
        E e = buscar(id);
        if (situacao == SituacaoValidacao.DECLARADO) {
            throw new RegraNegocioException("Use EM_VALIDACAO, VALIDADO ou REJEITADO.");
        }
        if (e.getSituacaoValidacao() == SituacaoValidacao.VALIDADO || e.getSituacaoValidacao() == SituacaoValidacao.REJEITADO) {
            throw new RegraNegocioException("Este registro já foi " + e.getSituacaoValidacao() + ".");
        }
        verificacoes.usuarioDaEquipe(idUsuarioValidacao, "Quem valida");
        String antes = auditoria.json(e);
        e.setSituacaoValidacao(situacao);
        e.setIdUsuarioValidacao(idUsuarioValidacao);
        e.setDataValidacao(LocalDateTime.now());
        return salvarAlteracao(e, antes, AcaoAuditoria.VALIDACAO);
    }

    /** Validações próprias de cada tabela (catálogo ativo, datas etc.). */
    protected void validarEspecifico(E e) {
    }

    protected Set<String> camposProtegidosExtras() {
        return Set.of();
    }
}
