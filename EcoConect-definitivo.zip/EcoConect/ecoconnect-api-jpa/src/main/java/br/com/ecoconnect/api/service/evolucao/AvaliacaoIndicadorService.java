package br.com.ecoconnect.api.service.evolucao;

import br.com.ecoconnect.api.exception.NaoEncontradoException;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.model.entity.AvaliacaoIndicador;
import br.com.ecoconnect.api.model.entity.Indicador;
import br.com.ecoconnect.api.model.entity.ObjetivoIndicadorId;
import br.com.ecoconnect.api.model.enums.AcaoAuditoria;
import br.com.ecoconnect.api.model.enums.SituacaoAvaliacao;
import br.com.ecoconnect.api.model.enums.TipoMedida;
import br.com.ecoconnect.api.repository.AtendimentoRepository;
import br.com.ecoconnect.api.repository.AvaliacaoIndicadorRepository;
import br.com.ecoconnect.api.repository.IndicadorRepository;
import br.com.ecoconnect.api.repository.ObjetivoIndicadorRepository;
import br.com.ecoconnect.api.service.AuditoriaService;
import br.com.ecoconnect.api.service.Verificacoes;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.base.ModoExclusao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * AVALIACAO_INDICADOR: cada medição periódica.
 *  - RI-14: só se avalia indicador vinculado ao objetivo (FK composta);
 *  - RI-15: avaliações são inseridas, nunca sobrescritas: correção por substituição.
 */
@Service
public class AvaliacaoIndicadorService extends CrudService<AvaliacaoIndicador, Long> {

    private final AvaliacaoIndicadorRepository avaliacaoRepository;
    private final ObjetivoIndicadorRepository objetivoIndicadorRepository;
    private final IndicadorRepository indicadorRepository;
    private final AtendimentoRepository atendimentoRepository;
    private final Verificacoes verificacoes;

    public AvaliacaoIndicadorService(AvaliacaoIndicadorRepository repository, AuditoriaService auditoria,
                                     ObjetivoIndicadorRepository objetivoIndicadorRepository,
                                     IndicadorRepository indicadorRepository,
                                     AtendimentoRepository atendimentoRepository, Verificacoes verificacoes) {
        super(repository, auditoria, "avaliacao_indicador");
        this.avaliacaoRepository = repository;
        this.objetivoIndicadorRepository = objetivoIndicadorRepository;
        this.indicadorRepository = indicadorRepository;
        this.atendimentoRepository = atendimentoRepository;
        this.verificacoes = verificacoes;
    }

    @Override
    protected void antesDeCriar(AvaliacaoIndicador a) {
        if (!objetivoIndicadorRepository.existsById(new ObjetivoIndicadorId(a.getIdObjetivo(), a.getIdIndicador()))) {
            throw new RegraNegocioException("O indicador " + a.getIdIndicador() + " não está vinculado ao objetivo "
                    + a.getIdObjetivo() + ".");
        }
        verificacoes.profissionalAtivo(a.getIdProfissionalAvaliador());
        if (a.getIdAtendimento() != null && !atendimentoRepository.existsById(a.getIdAtendimento())) {
            throw new NaoEncontradoException("atendimento", a.getIdAtendimento());
        }
        Verificacoes.naoFutura(a.getDataAvaliacao(), "A data da avaliação");
        Indicador ind = indicadorRepository.findById(a.getIdIndicador())
                .orElseThrow(() -> new NaoEncontradoException("indicador", a.getIdIndicador()));
        if (ind.getTipoMedida() == TipoMedida.NUMERICA && a.getValorNumerico() == null) {
            throw new RegraNegocioException("O indicador " + ind.getNome() + " é NUMERICO: informe valorNumerico.");
        }
        if (ind.getTipoMedida() == TipoMedida.QUALITATIVA && (a.getValorQualitativo() == null || a.getValorQualitativo().isBlank())) {
            throw new RegraNegocioException("O indicador " + ind.getNome() + " é QUALITATIVO: informe valorQualitativo.");
        }
        a.setSituacao(SituacaoAvaliacao.VIGENTE);
        a.setIdAvaliacaoSubstituida(null);
    }

    /** Nova avaliação que corrige a anterior (mesmo objetivo e indicador); a anterior vira SUBSTITUIDA. */
    @Transactional
    public AvaliacaoIndicador substituir(Long id, AvaliacaoIndicador nova) {
        AvaliacaoIndicador anterior = buscar(id);
        if (anterior.getSituacao() != SituacaoAvaliacao.VIGENTE) {
            throw new RegraNegocioException("Só avaliações VIGENTES podem ser substituídas.");
        }
        nova.setIdObjetivo(anterior.getIdObjetivo());
        nova.setIdIndicador(anterior.getIdIndicador());
        String antes = auditoria.json(anterior);
        anterior.setSituacao(SituacaoAvaliacao.SUBSTITUIDA);
        salvarAlteracao(anterior, antes, AcaoAuditoria.ATUALIZACAO);

        AvaliacaoIndicador criada = criar(nova);
        criada.setIdAvaliacaoSubstituida(anterior.getIdAvaliacao());
        return repository.saveAndFlush(criada);
    }

    @Transactional(readOnly = true)
    public List<AvaliacaoIndicador> serie(Long idObjetivo, Long idIndicador) {
        return avaliacaoRepository.findByIdObjetivoAndIdIndicadorAndSituacaoOrderByDataAvaliacaoAsc(
                idObjetivo, idIndicador, SituacaoAvaliacao.VIGENTE);
    }

    @Override
    protected ModoExclusao modoExclusao() {
        return ModoExclusao.PROIBIDA;
    }

    // ------------------------------------------------------------------ escopo por pessoa
    @Override
    protected Long criancaDoRegistro(AvaliacaoIndicador a) {
        return escopo() == null ? null : escopo().criancaDoObjetivo(a.getIdObjetivo());
    }

    @Override
    protected boolean registroDePessoa() {
        return true;
    }
}
