package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.CriancaResponsavel;
import br.com.ecoconnect.api.model.enums.StatusVinculo;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `crianca_responsavel` (Spring Data JPA). */
public interface CriancaResponsavelRepository extends JpaRepository<CriancaResponsavel, Long> {

    boolean existsByIdCriancaAndIdResponsavel(Long idCrianca, Long idResponsavel);
    boolean existsByIdCriancaAndIdResponsavelAndStatus(Long idCrianca, Long idResponsavel, StatusVinculo status);
    boolean existsByIdCriancaAndIdResponsavelAndStatusAndPodeSolicitarAgendamentoTrue(Long idCrianca, Long idResponsavel, StatusVinculo status);
    boolean existsByIdCriancaAndResponsavelPrincipalTrueAndStatus(Long idCrianca, StatusVinculo status);
    boolean existsByIdCriancaAndResponsavelPrincipalTrueAndStatusAndIdCriancaResponsavelNot(Long idCrianca, StatusVinculo status, Long idCriancaResponsavel);
    List<CriancaResponsavel> findByIdCriancaAndStatusAndPodeConsultarDadosTrue(Long idCrianca, StatusVinculo status);
}
