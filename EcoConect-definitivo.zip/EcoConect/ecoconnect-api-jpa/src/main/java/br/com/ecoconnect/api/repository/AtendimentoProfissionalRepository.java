package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.AtendimentoProfissional;
import br.com.ecoconnect.api.model.entity.AtendimentoProfissionalId;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `atendimento_profissional` (Spring Data JPA). */
public interface AtendimentoProfissionalRepository extends JpaRepository<AtendimentoProfissional, AtendimentoProfissionalId> {

    List<AtendimentoProfissional> findByIdAtendimento(Long idAtendimento);
}
