package br.com.ecoconnect.api.model.entity;

import br.com.ecoconnect.api.model.enums.SituacaoAvaliacao;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Tabela `avaliacao_indicador` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 * CHECK chk_ai_valor: ((valor_numerico is not null) or (valor_qualitativo is not null))
 */
@Entity
@Table(name = "avaliacao_indicador")
public class AvaliacaoIndicador implements Entidade<Long> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_avaliacao", nullable = false)
    private Long idAvaliacao;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_objetivo", nullable = false)
    private Long idObjetivo;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_indicador", nullable = false)
    private Long idIndicador;

    @NotNull(message = "campo obrigatório")
    @Column(name = "id_profissional_avaliador", nullable = false)
    private Long idProfissionalAvaliador;

    @Column(name = "id_atendimento")
    private Long idAtendimento;

    @NotNull(message = "campo obrigatório")
    @Column(name = "data_avaliacao", nullable = false)
    private LocalDate dataAvaliacao;

    @Column(name = "valor_numerico", precision = 10, scale = 2)
    private BigDecimal valorNumerico;

    @Size(max = 255)
    @Column(name = "valor_qualitativo", length = 255)
    private String valorQualitativo;

    @Size(max = 500)
    @Column(name = "observacao", length = 500)
    private String observacao;

    @Enumerated(EnumType.STRING)
    @Column(name = "situacao", nullable = false)
    private SituacaoAvaliacao situacao;

    @Column(name = "id_avaliacao_substituida")
    private Long idAvaliacaoSubstituida;

    @Column(name = "data_registro", nullable = false)
    private LocalDateTime dataRegistro;

    @PrePersist
    void aoInserir() {
        if (situacao == null) {
            situacao = SituacaoAvaliacao.VIGENTE;
        }
        if (dataRegistro == null) {
            dataRegistro = LocalDateTime.now();
        }
    }

    public Long getIdAvaliacao() {
        return idAvaliacao;
    }

    public void setIdAvaliacao(Long idAvaliacao) {
        this.idAvaliacao = idAvaliacao;
    }

    public Long getIdObjetivo() {
        return idObjetivo;
    }

    public void setIdObjetivo(Long idObjetivo) {
        this.idObjetivo = idObjetivo;
    }

    public Long getIdIndicador() {
        return idIndicador;
    }

    public void setIdIndicador(Long idIndicador) {
        this.idIndicador = idIndicador;
    }

    public Long getIdProfissionalAvaliador() {
        return idProfissionalAvaliador;
    }

    public void setIdProfissionalAvaliador(Long idProfissionalAvaliador) {
        this.idProfissionalAvaliador = idProfissionalAvaliador;
    }

    public Long getIdAtendimento() {
        return idAtendimento;
    }

    public void setIdAtendimento(Long idAtendimento) {
        this.idAtendimento = idAtendimento;
    }

    public LocalDate getDataAvaliacao() {
        return dataAvaliacao;
    }

    public void setDataAvaliacao(LocalDate dataAvaliacao) {
        this.dataAvaliacao = dataAvaliacao;
    }

    public BigDecimal getValorNumerico() {
        return valorNumerico;
    }

    public void setValorNumerico(BigDecimal valorNumerico) {
        this.valorNumerico = valorNumerico;
    }

    public String getValorQualitativo() {
        return valorQualitativo;
    }

    public void setValorQualitativo(String valorQualitativo) {
        this.valorQualitativo = valorQualitativo;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public SituacaoAvaliacao getSituacao() {
        return situacao;
    }

    public void setSituacao(SituacaoAvaliacao situacao) {
        this.situacao = situacao;
    }

    public Long getIdAvaliacaoSubstituida() {
        return idAvaliacaoSubstituida;
    }

    public void setIdAvaliacaoSubstituida(Long idAvaliacaoSubstituida) {
        this.idAvaliacaoSubstituida = idAvaliacaoSubstituida;
    }

    public LocalDateTime getDataRegistro() {
        return dataRegistro;
    }

    public void setDataRegistro(LocalDateTime dataRegistro) {
        this.dataRegistro = dataRegistro;
    }

    @Override
    public Long chave() {
        return idAvaliacao;
    }

    @Override
    public void definirChave(Long id) {
        this.idAvaliacao = id;
    }
}
