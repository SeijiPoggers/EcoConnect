package br.com.ecoconnect.api.controller.saude;

import br.com.ecoconnect.api.controller.base.LeituraController;
import br.com.ecoconnect.api.dto.ConferenciaDocumento;
import br.com.ecoconnect.api.model.entity.Documento;
import br.com.ecoconnect.api.service.base.CrudService;
import br.com.ecoconnect.api.service.saude.DocumentoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/** Documentos da criança (metadados). Sem PUT: correção por substituição. */
@RestController
@RequestMapping("/api/documentos")
public class DocumentoController extends LeituraController<Documento, Long> {

    private final DocumentoService service;

    public DocumentoController(DocumentoService service) {
        this.service = service;
    }

    @Override
    protected CrudService<Documento, Long> service() {
        return service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Documento criar(@Valid @RequestBody Documento dados) {
        return service.criar(dados);
    }

    @PostMapping("/{id}/substituicao")
    @ResponseStatus(HttpStatus.CREATED)
    public Documento substituir(@PathVariable Long id, @Valid @RequestBody Documento dados) {
        return service.substituir(id, dados);
    }

    /** {"situacaoValidacao": "CONFERIDO", "idUsuario": 2} */
    @PatchMapping("/{id}/conferencia")
    public Documento conferir(@PathVariable Long id, @Valid @RequestBody ConferenciaDocumento dados) {
        return service.conferir(id, dados.situacaoValidacao(), dados.idUsuario());
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void excluir(@PathVariable Long id) {
        service.excluir(id);
    }
}
