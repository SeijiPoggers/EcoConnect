package br.com.ecoconnect.api.model.enums;

/** Situação do relatório de atendimento. Valores idênticos ao ENUM do MySQL. */
public enum SituacaoRelatorio {
    RASCUNHO, FINALIZADO, LIBERADO_RESPONSAVEL, SUBSTITUIDO
}
