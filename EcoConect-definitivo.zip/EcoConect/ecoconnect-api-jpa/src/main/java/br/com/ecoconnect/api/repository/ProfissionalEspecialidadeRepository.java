package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.ProfissionalEspecialidade;
import br.com.ecoconnect.api.model.entity.ProfissionalEspecialidadeId;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `profissional_especialidade` (Spring Data JPA). */
public interface ProfissionalEspecialidadeRepository extends JpaRepository<ProfissionalEspecialidade, ProfissionalEspecialidadeId> {

    List<ProfissionalEspecialidade> findByIdProfissional(Long idProfissional);
}
