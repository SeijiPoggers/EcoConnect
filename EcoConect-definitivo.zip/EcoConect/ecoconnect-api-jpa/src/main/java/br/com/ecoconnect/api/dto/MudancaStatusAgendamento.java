package br.com.ecoconnect.api.dto;

import br.com.ecoconnect.api.model.enums.StatusAgendamento;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

/**
 * Mudança de status/horário do agendamento.
 * dataHoraInicio/dataHoraFim: usados ao CONFIRMAR ou remarcar (se vazios na confirmação, vale o horário solicitado).
 */
public record MudancaStatusAgendamento(
        @NotNull(message = "campo obrigatório") StatusAgendamento status,
        @NotNull(message = "campo obrigatório") Long idUsuario,
        LocalDateTime dataHoraInicio,
        LocalDateTime dataHoraFim,
        @Size(max = 500) String motivo) {
}
