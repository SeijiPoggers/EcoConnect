package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.CriancaDiagnostico;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `crianca_diagnostico` (Spring Data JPA). */
public interface CriancaDiagnosticoRepository extends JpaRepository<CriancaDiagnostico, Long> {

    boolean existsByIdCriancaDiagnosticoAndIdCrianca(Long idCriancaDiagnostico, Long idCrianca);
}
