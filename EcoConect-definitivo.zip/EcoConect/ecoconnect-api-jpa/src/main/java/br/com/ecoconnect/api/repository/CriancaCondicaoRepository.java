package br.com.ecoconnect.api.repository;

import br.com.ecoconnect.api.model.entity.CriancaCondicao;
import org.springframework.data.jpa.repository.JpaRepository;

/** Acesso à tabela `crianca_condicao` (Spring Data JPA). */
public interface CriancaCondicaoRepository extends JpaRepository<CriancaCondicao, Long> {
}
