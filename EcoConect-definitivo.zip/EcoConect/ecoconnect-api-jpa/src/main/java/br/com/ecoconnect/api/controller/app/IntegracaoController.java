package br.com.ecoconnect.api.controller.app;

import br.com.ecoconnect.api.exception.RegraNegocioException;
import br.com.ecoconnect.api.service.app.FhirService;
import br.com.ecoconnect.api.service.app.RndsService;
import br.com.ecoconnect.api.service.app.SusService;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/** Integração com o SUS: catálogo do CNES, guia de acesso, recursos HL7 FHIR R4 e situação da RNDS. */
@RestController
public class IntegracaoController {

    private static final MediaType FHIR = MediaType.parseMediaType("application/fhir+json");

    private final SusService sus;
    private final FhirService fhir;
    private final RndsService rnds;

    public IntegracaoController(SusService sus, FhirService fhir, RndsService rnds) {
        this.sus = sus;
        this.fhir = fhir;
        this.rnds = rnds;
    }

    @GetMapping("/api/sus/estabelecimentos")
    public List<Map<String, Object>> estabelecimentos(@RequestParam(name = "uf", required = false) String uf,
                                                      @RequestParam(name = "municipio", required = false) String municipio,
                                                      @RequestParam(name = "categoria", required = false) String categoria,
                                                      @RequestParam(name = "texto", required = false) String texto) {
        return sus.estabelecimentos(uf, municipio, categoria, texto);
    }

    @GetMapping("/api/sus/estabelecimentos/{cnes}")
    public Map<String, Object> estabelecimento(@PathVariable("cnes") String cnes) {
        return sus.estabelecimento(cnes);
    }

    @GetMapping("/api/sus/municipios")
    public List<Map<String, Object>> municipios() {
        return sus.municipios();
    }

    @GetMapping("/api/sus/guia")
    public Map<String, Object> guia() {
        return sus.guia();
    }

    @GetMapping("/api/sus/catalogo")
    public Map<String, Object> catalogo() {
        return sus.situacaoCatalogo();
    }

    @PostMapping(value = "/api/sus/importacao", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, Object> importar(@RequestParam("arquivo") MultipartFile arquivo,
                                        @RequestParam(name = "uf", required = false) String uf) throws IOException {
        if (arquivo == null || arquivo.isEmpty()) throw new RegraNegocioException("Escolha o arquivo do CNES (.csv).");
        try (InputStream in = arquivo.getInputStream()) {
            return sus.importar(in, arquivo.getOriginalFilename(), uf);
        }
    }

    @GetMapping("/api/fhir/metadata")
    public ResponseEntity<Map<String, Object>> metadata() {
        return ResponseEntity.ok().contentType(FHIR).body(fhir.capacidades());
    }

    @GetMapping("/api/fhir/Organization/{id}")
    public ResponseEntity<Map<String, Object>> organization(@PathVariable("id") String id) {
        return ResponseEntity.ok().contentType(FHIR).body(fhir.organization(id));
    }

    @GetMapping("/api/fhir/Location/{id}")
    public ResponseEntity<Map<String, Object>> location(@PathVariable("id") String id) {
        return ResponseEntity.ok().contentType(FHIR).body(fhir.location(id));
    }

    @GetMapping("/api/fhir/HealthcareService")
    public ResponseEntity<Map<String, Object>> servicos(@RequestParam(name = "organization") String organizacao) {
        return ResponseEntity.ok().contentType(FHIR).body(fhir.servicos(organizacao));
    }

    @GetMapping("/api/fhir/Patient/{id}")
    public ResponseEntity<Map<String, Object>> patient(@PathVariable("id") Long id) {
        return ResponseEntity.ok().contentType(FHIR).body(fhir.patient(id));
    }

    @GetMapping("/api/fhir/ServiceRequest/{id}")
    public ResponseEntity<Map<String, Object>> serviceRequest(@PathVariable("id") Long id) {
        return ResponseEntity.ok().contentType(FHIR).body(fhir.serviceRequest(id));
    }

    @GetMapping("/api/fhir/ServiceRequest/{id}/pacote")
    public ResponseEntity<Map<String, Object>> pacote(@PathVariable("id") Long id) {
        return ResponseEntity.ok().contentType(FHIR).body(fhir.pacoteDaSolicitacao(id));
    }

    @GetMapping("/api/rnds/situacao")
    public Map<String, Object> rnds() {
        return rnds.situacao();
    }

    @PostMapping("/api/rnds/teste-autenticacao")
    public Map<String, Object> testarRnds() {
        return rnds.testarAutenticacao();
    }
}
