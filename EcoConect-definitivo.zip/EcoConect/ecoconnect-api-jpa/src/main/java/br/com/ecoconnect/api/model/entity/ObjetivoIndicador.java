package br.com.ecoconnect.api.model.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Tabela `objetivo_indicador` do banco ecoconnect.
 * Mapeamento gerado a partir do script EcoConnect_backup_final.sql (nomes e tipos idênticos).
 */
@Entity
@Table(name = "objetivo_indicador")
@IdClass(ObjetivoIndicadorId.class)
public class ObjetivoIndicador {

    @Id
    @Column(name = "id_objetivo", nullable = false)
    private Long idObjetivo;

    @Id
    @Column(name = "id_indicador", nullable = false)
    private Long idIndicador;

    @Column(name = "valor_referencia_inicial", precision = 10, scale = 2)
    private BigDecimal valorReferenciaInicial;

    @Column(name = "meta_valor", precision = 10, scale = 2)
    private BigDecimal metaValor;

    @Size(max = 300)
    @Column(name = "descricao_meta", length = 300)
    private String descricaoMeta;

    @Column(name = "data_vinculo", nullable = false)
    private LocalDateTime dataVinculo;

    @PrePersist
    void aoInserir() {
        if (dataVinculo == null) {
            dataVinculo = LocalDateTime.now();
        }
    }

    public Long getIdObjetivo() {
        return idObjetivo;
    }

    public void setIdObjetivo(Long idObjetivo) {
        this.idObjetivo = idObjetivo;
    }

    public Long getIdIndicador() {
        return idIndicador;
    }

    public void setIdIndicador(Long idIndicador) {
        this.idIndicador = idIndicador;
    }

    public BigDecimal getValorReferenciaInicial() {
        return valorReferenciaInicial;
    }

    public void setValorReferenciaInicial(BigDecimal valorReferenciaInicial) {
        this.valorReferenciaInicial = valorReferenciaInicial;
    }

    public BigDecimal getMetaValor() {
        return metaValor;
    }

    public void setMetaValor(BigDecimal metaValor) {
        this.metaValor = metaValor;
    }

    public String getDescricaoMeta() {
        return descricaoMeta;
    }

    public void setDescricaoMeta(String descricaoMeta) {
        this.descricaoMeta = descricaoMeta;
    }

    public LocalDateTime getDataVinculo() {
        return dataVinculo;
    }

    public void setDataVinculo(LocalDateTime dataVinculo) {
        this.dataVinculo = dataVinculo;
    }
}
