// Gestão de profissionais: especialidades, instituições, pessoas acompanhadas e agenda.
import { api } from '../api.js';
import { h, cabecalho, cartao, avisar, janelaFormulario, tabela, situacao, dataBR, dataHoraBR, vazio, botao, listaDefinicoes, etiqueta, erroParaTexto, sim } from '../ui.js';

export async function lista(el, { app }) {
  el.append(cabecalho('Profissionais', app.perfil('ADMIN_INSTITUCIONAL') ? 'Profissionais vinculados à sua instituição.' : 'Equipe de acompanhamento do EcoConect.',
    app.perfil('ADMINISTRADOR') ? [h('a', { href: '#/admin/usuarios?novo=PROFISSIONAL', class: 'botao' }, 'Cadastrar profissional')] : null));
  const itens = await api('/api/app/profissionais');
  el.append(cartao(null, tabela([
    { titulo: 'Nome', valor: (p) => h('a', { href: `#/profissionais/${p.idProfissional}` }, p.nome) },
    { titulo: 'Especialidades', valor: (p) => p.especialidades }, { titulo: 'Registro', valor: (p) => [p.conselho, p.registro].filter(Boolean).join(' ') },
    { titulo: 'Instituições', valor: (p) => p.instituicoes }, { titulo: 'Pessoas', valor: (p) => p.pessoas },
    { titulo: 'Próximas sessões', valor: (p) => p.proximasSessoes },
    { titulo: 'Situação', valor: (p) => (sim(p.ativo) ? situacao('usuario', p.situacaoConta) : etiqueta('Inativo')) }], itens, { vazioTexto: 'Nenhum profissional cadastrado.' })));
}

export async function detalhe(el, { params, app }) {
  const p = await api(`/api/app/profissionais/${params.id}`);
  const recarregar = () => app.navegar(`#/profissionais/${params.id}`);
  el.append(cabecalho(p.nome, p.especialidades || 'Profissional', p.podeEditar ? [botao('Editar registro', () => janelaFormulario('Editar profissional', [
    { nome: 'conselho', rotulo: 'Conselho profissional', max: 20, exemplo: 'CRP, CRFa, CREFITO...' }, { nome: 'registro', rotulo: 'Número de registro', max: 30 },
    { nome: 'ativo', rotulo: 'Profissional ativo', tipo: 'marcacao' }], { ...p, ativo: sim(p.ativo) }, async (d) => {
    await api(`/api/app/profissionais/${params.id}`, { metodo: 'PUT', corpo: d }); avisar('Profissional atualizado.'); recarregar();
  }), 'secundario')] : null, [{ texto: 'Profissionais', link: '#/profissionais' }, { texto: p.nome }]));
  el.append(h('div', { class: 'grade-2' },
    cartao('Dados', listaDefinicoes([['Registro', [p.conselho, p.registro].filter(Boolean).join(' ')], ['Instituições', p.instituicoes],
      ['Situação da conta', situacao('usuario', p.situacaoConta)], ['Ativo no acompanhamento', sim(p.ativo) ? 'Sim' : 'Não']])),
    cartao('Especialidades', p.listaEspecialidades.length ? h('ul', { class: 'lista-simples' }, p.listaEspecialidades.map((e) => h('li', null,
      h('span', null, e.nome, ' ', sim(e.principal) ? etiqueta('Principal', 'info') : null),
      p.podeEditar ? botao('Remover', async () => {
        try { await api(`/api/app/profissionais/${params.id}/especialidades/${e.idEspecialidade}`, { metodo: 'DELETE' }); avisar('Especialidade removida.'); recarregar(); }
        catch (err) { avisar(erroParaTexto(err), 'erro'); }
      }, 'texto pequeno') : null))) : vazio('Nenhuma especialidade informada.'),
    p.podeEditar ? botao('Adicionar especialidade', async () => {
      const lista = (await api('/api/especialidades', { consulta: { size: 200, sort: 'nome' } })).conteudo;
      janelaFormulario('Adicionar especialidade', [{ nome: 'idEspecialidade', rotulo: 'Especialidade', tipo: 'selecao', obrigatorio: true, opcoes: lista.map((e) => [e.idEspecialidade, e.nome]) },
        { nome: 'principal', rotulo: 'Principal', tipo: 'marcacao' }], {}, async (d) => {
        await api(`/api/app/profissionais/${params.id}/especialidades`, { metodo: 'POST', corpo: { idEspecialidade: Number(d.idEspecialidade), principal: d.principal } });
        avisar('Especialidade adicionada.'); recarregar();
      });
    }, 'secundario') : null)));
  if (p.pessoasAcompanhadas) {
    el.append(h('div', { class: 'grade-2', style: 'margin-top:1rem' },
      cartao('Pessoas sob acompanhamento', tabela([{ titulo: 'Pessoa', valor: (x) => h('a', { href: `#/pessoas/${x.idCrianca}` }, x.nome) },
        { titulo: 'Função', valor: (x) => x.funcao }, { titulo: 'Desde', valor: (x) => dataBR(x.desde) }], p.pessoasAcompanhadas, { vazioTexto: 'Nenhuma pessoa.' })),
      cartao('Próximos atendimentos', p.agenda.length ? h('ul', { class: 'lista-simples' }, p.agenda.map((a) => h('li', null, h('span', null, a.pessoa), h('span', { class: 'suave' }, dataHoraBR(a.inicio)))))
        : vazio('Sem atendimentos confirmados.')),
      cartao('Atividades recentes', p.atividadesRecentes.length ? h('ul', { class: 'lista-simples' }, p.atividadesRecentes.map((a) => h('li', null,
        h('span', null, `${a.tipo || 'Sessão'} - ${a.pessoa}`), h('span', { class: 'suave' }, dataHoraBR(a.data))))) : vazio('Nenhuma sessão registrada.'))));
  }
}
