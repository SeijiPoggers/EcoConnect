// Administração: usuários, auditoria, pedidos de privacidade (LGPD) e integrações com o SUS.
import { api } from '../api.js';
import { h, cabecalho, cartao, formulario, avisar, confirmar, janela, janelaFormulario, tabela, situacao, dataHoraBR, vazio, botao, listaDefinicoes,
  etiqueta, erroParaTexto, ROTULOS, sim } from '../ui.js';

export async function usuarios(el, { consulta, app }) {
  const recarregar = () => app.navegar('#/admin/usuarios?' + new URLSearchParams({ texto: consulta.texto || '', perfil: consulta.perfil || '', status: consulta.status || '' }));
  el.append(cabecalho('Usuários', 'Contas de todos os perfis. Contas novas recebem uma senha temporária, que deve ser trocada no primeiro acesso.',
    [botao('Nova conta', () => novaConta(app))]));
  el.append(formulario([
    { nome: 'texto', rotulo: 'Nome ou e-mail' },
    { nome: 'perfil', rotulo: 'Perfil', tipo: 'selecao', opcoes: ROTULOS.perfil, vazio: 'Todos' },
    { nome: 'status', rotulo: 'Situação', tipo: 'selecao', opcoes: Object.fromEntries(Object.entries(ROTULOS.usuario).map(([k, v]) => [k, v[0]])), vazio: 'Todas' }
  ], consulta, { rotuloEnviar: 'Filtrar', aoEnviar: async (d) => app.navegar('#/admin/usuarios?' + new URLSearchParams(Object.entries(d).filter(([, v]) => v))) }));
  const itens = await api('/api/admin/usuarios', { consulta: { texto: consulta.texto, perfil: consulta.perfil, status: consulta.status } });
  el.append(cartao(null, tabela([
    { titulo: 'Nome', valor: (u) => h('span', null, u.nome, ' ', sim(u.demonstracao) ? etiqueta('Fictício', 'alerta') : null) },
    { titulo: 'E-mail', valor: (u) => u.email }, { titulo: 'Perfil', valor: (u) => ROTULOS.perfil[u.perfil] || u.perfil },
    { titulo: 'Situação', valor: (u) => h('span', { class: 'etiquetas' }, situacao('usuario', u.status), sim(u.exigeTrocaSenha) ? etiqueta('Troca de senha pendente', 'info') : null) },
    { titulo: 'Instituições', valor: (u) => u.instituicoes }, { titulo: 'Último acesso', valor: (u) => dataHoraBR(u.ultimoAcesso) },
    { titulo: 'Ações', valor: (u) => (u.idUsuario === app.usuario.idUsuario ? h('span', { class: 'suave pequeno' }, 'Você') : h('div', { class: 'acoes' },
      u.status !== 'ATIVO' ? botao(u.status === 'PENDENTE_ATIVACAO' ? 'Ativar' : 'Reativar', () => mudarStatus(u, 'ATIVO', recarregar), 'pequeno') : null,
      u.status === 'ATIVO' ? botao('Bloquear', () => mudarStatus(u, 'BLOQUEADO', recarregar), 'secundario pequeno') : null,
      botao('Senha temporária', async () => {
        if (!await confirmar(`Gerar uma senha temporária para ${u.nome}? As sessões abertas serão encerradas.`)) return;
        try { const r = await api(`/api/admin/usuarios/${u.idUsuario}/senha-temporaria`, { metodo: 'POST' }); mostrarSenha(r.senhaTemporaria, r.mensagem); recarregar(); }
        catch (e) { avisar(erroParaTexto(e), 'erro'); }
      }, 'texto pequeno'))) }], itens, { vazioTexto: 'Nenhum usuário encontrado.' })));
  if (consulta.novo) novaConta(app, consulta.novo);
}

async function mudarStatus(u, status, recarregar) {
  if (status !== 'ATIVO' && !await confirmar(`Bloquear ${u.nome}? A pessoa não conseguirá entrar até ser reativada.`, { perigo: true, rotulo: 'Bloquear' })) return;
  try { await api(`/api/admin/usuarios/${u.idUsuario}/status`, { metodo: 'PATCH', corpo: { status } }); avisar('Situação atualizada.'); recarregar(); }
  catch (e) { avisar(erroParaTexto(e), 'erro'); }
}

function mostrarSenha(senha, mensagem) {
  janela({ titulo: 'Senha temporária', conteudo: h('div', null, h('p', null, mensagem),
    h('p', { style: 'font-size:1.4rem;font-family:monospace;background:var(--superficie-2);padding:.75rem;border-radius:8px;text-align:center' }, senha)),
  acoes: [{ rotulo: 'Entendi', valor: true }] });
}

async function novaConta(app, perfilInicial) {
  const [instituicoes, pessoas, especialidades] = await Promise.all([api('/api/rede/instituicoes'), api('/api/app/pessoas'),
    api('/api/especialidades', { consulta: { size: 200, sort: 'nome' } })]);
  const campos = [
    { nome: 'perfil', rotulo: 'Perfil', tipo: 'selecao', obrigatorio: true, opcoes: ROTULOS.perfil },
    { nome: 'nomeCompleto', rotulo: 'Nome completo', obrigatorio: true, max: 150 },
    { nome: 'email', rotulo: 'E-mail', tipo: 'email', obrigatorio: true }, { nome: 'telefone', rotulo: 'Telefone', tipo: 'telefone' },
    { nome: 'senhaTemporaria', rotulo: 'Senha temporária', tipo: 'texto', ajuda: 'Deixe em branco para o sistema gerar uma senha segura.' },
    { nome: 'cpf', rotulo: 'CPF (responsável, opcional)', max: 14 },
    { nome: 'conselhoProfissional', rotulo: 'Conselho (profissional)', max: 20 }, { nome: 'registroProfissional', rotulo: 'Registro (profissional)', max: 30 },
    { nome: 'especialidades', rotulo: 'Especialidades (profissional)', tipo: 'multipla', comoLista: true, opcoes: especialidades.conteudo.map((e) => [e.idEspecialidade, e.nome]) },
    { nome: 'idInstituicao', rotulo: 'Instituição (administrador institucional ou profissional)', tipo: 'selecao', opcoes: instituicoes.map((i) => [i.idInstituicao, i.nome]), vazio: 'Nenhuma' },
    { nome: 'idCrianca', rotulo: 'Pessoa acompanhada (conta própria)', tipo: 'selecao', opcoes: pessoas.map((p) => [p.idCrianca, p.nomeCompleto]), vazio: 'Nenhuma' }
  ];
  janelaFormulario('Nova conta', campos, { perfil: perfilInicial || '' }, async (d) => {
    const corpo = { ...d, especialidades: (d.especialidades || []).map(Number), idInstituicao: d.idInstituicao ? Number(d.idInstituicao) : null,
      idCrianca: d.idCrianca ? Number(d.idCrianca) : null, cpf: d.cpf ? d.cpf.replace(/\D/g, '') : null };
    const r = await api('/api/admin/usuarios', { metodo: 'POST', corpo });
    mostrarSenha(r.senhaTemporaria, r.mensagem);
    app.navegar('#/admin/usuarios');
  }, { rotuloEnviar: 'Criar conta', antes: h('p', { class: 'suave' }, 'Preencha só os campos do perfil escolhido. O cadastro complementar (responsável, profissional ou vínculo) é criado junto.') });
}

export async function auditoria(el, { consulta, app }) {
  el.append(cabecalho('Auditoria', 'Registro permanente de logins, consultas a dados sensíveis, cadastros e alterações (somente leitura).'));
  const acoes = ['LOGIN', 'LOGIN_FALHA', 'LOGOUT', 'CONSULTA', 'CRIACAO', 'ATUALIZACAO', 'EXCLUSAO_LOGICA', 'VALIDACAO', 'LIBERACAO'];
  el.append(formulario([
    { nome: 'acao', rotulo: 'Ação', tipo: 'selecao', opcoes: acoes, vazio: 'Todas' }, { nome: 'tabela', rotulo: 'Tabela' },
    { nome: 'de', rotulo: 'De', tipo: 'data' }, { nome: 'ate', rotulo: 'Até', tipo: 'data' }
  ], consulta, { rotuloEnviar: 'Filtrar', aoEnviar: async (d) => app.navegar('#/admin/auditoria?' + new URLSearchParams(Object.entries(d).filter(([, v]) => v))) }));
  const pagina = Number(consulta.pagina || 0);
  const r = await api('/api/admin/auditoria', { consulta: { ...consulta, pagina } });
  const irPagina = (p) => app.navegar('#/admin/auditoria?' + new URLSearchParams({ ...consulta, pagina: p }));
  el.append(cartao(`${r.total} registro(s)`, tabela([
    { titulo: 'Quando', valor: (a) => dataHoraBR(a.dataHora) }, { titulo: 'Ação', valor: (a) => a.acao }, { titulo: 'Usuário', valor: (a) => a.usuario || 'Sistema/anônimo' },
    { titulo: 'Tabela', valor: (a) => `${a.tabela || ''}${a.registro ? ' #' + a.registro : ''}` }, { titulo: 'IP', valor: (a) => a.ip },
    { titulo: '', valor: (a) => (a.antes || a.depois ? botao('Detalhes', () => janela({ titulo: `Auditoria #${a.idAuditoria}`, conteudo: h('div', null,
      h('h3', null, 'Antes'), h('pre', { class: 'pre pequeno' }, formatarJson(a.antes)), h('h3', null, 'Depois'), h('pre', { class: 'pre pequeno' }, formatarJson(a.depois))) }), 'texto pequeno') : '') }],
  r.itens), h('div', { class: 'acoes', style: 'margin-top:1rem' },
    botao('Anterior', () => irPagina(pagina - 1), 'secundario pequeno', { disabled: pagina <= 0 }),
    h('span', { class: 'suave' }, `Página ${pagina + 1} de ${Math.max(1, r.totalPaginas)}`),
    botao('Próxima', () => irPagina(pagina + 1), 'secundario pequeno', { disabled: pagina + 1 >= r.totalPaginas }))));
}

function formatarJson(t) {
  if (!t) return '—';
  try { return JSON.stringify(JSON.parse(t), null, 2); } catch (e) { return t; }
}

export async function privacidade(el, { app }) {
  el.append(cabecalho('Pedidos de privacidade (LGPD)', 'Pedidos dos titulares: acesso, correção, exclusão, portabilidade e revogação.'));
  const itens = await api('/api/admin/privacidade');
  const TIPOS = { ACESSO: 'Acesso', CORRECAO: 'Correção', EXCLUSAO: 'Exclusão', PORTABILIDADE: 'Portabilidade', REVOGACAO_CONSENTIMENTO: 'Revogação', OUTRA: 'Outro' };
  el.append(cartao(null, tabela([
    { titulo: 'Aberto em', valor: (p) => dataHoraBR(p.dataCriacao) }, { titulo: 'Titular', valor: (p) => `${p.titular} (${p.email})` },
    { titulo: 'Tipo', valor: (p) => TIPOS[p.tipo] || p.tipo }, { titulo: 'Detalhe', valor: (p) => p.detalhe },
    { titulo: 'Situação', valor: (p) => situacao('titular', p.situacao) },
    { titulo: '', valor: (p) => (['ABERTA', 'EM_ANALISE'].includes(p.situacao) ? botao('Responder', () => janelaFormulario('Responder pedido', [
      { nome: 'situacao', rotulo: 'Situação', tipo: 'selecao', obrigatorio: true, opcoes: [['EM_ANALISE', 'Em análise'], ['ATENDIDA', 'Atendido'], ['RECUSADA', 'Recusado']] },
      { nome: 'resposta', rotulo: 'Resposta ao titular', tipo: 'area', max: 1000, largo: true },
      p.tipo === 'EXCLUSAO' ? { nome: 'anonimizarConta', rotulo: 'Anonimizar a conta agora (remove nome, e-mail e telefone e encerra o acesso)', tipo: 'marcacao', largo: true } : null
    ].filter(Boolean), {}, async (d) => {
      await api(`/api/admin/privacidade/${p.id}/resposta`, { metodo: 'POST', corpo: d }); avisar('Pedido atualizado.'); app.navegar('#/admin/privacidade');
    }, { antes: h('p', { class: 'suave' }, 'Dados de saúde não são apagados (dever de guarda). Em pedidos de exclusão, a conta pode ser anonimizada.') }), 'secundario pequeno') : p.resposta) }],
  itens, { vazioTexto: 'Nenhum pedido.' })));
}

export async function integracoes(el, { app }) {
  const [catalogo, rnds] = await Promise.all([api('/api/sus/catalogo'), api('/api/rnds/situacao')]);
  el.append(cabecalho('Integrações com o SUS', 'Catálogo de estabelecimentos (CNES/DATASUS), recursos HL7 FHIR R4 e situação da RNDS.'));
  const resultado = h('div', { role: 'status' });
  el.append(h('div', { class: 'grade-2' },
    cartao('Catálogo do CNES', tabela([{ titulo: 'Origem', valor: (f) => (f.fonte === 'DEMONSTRACAO' ? 'Demonstração (fictício)' : 'Arquivo oficial do CNES') },
      { titulo: 'Estabelecimentos', valor: (f) => f.total }, { titulo: 'Atualização', valor: (f) => dataHoraBR(f.ultimaAtualizacao) }], catalogo.porFonte, { vazioTexto: 'Catálogo vazio.' }),
    h('p', { class: 'suave pequeno', style: 'margin-top:.75rem' }, catalogo.comoAtualizar),
    formulario([{ nome: 'arquivo', rotulo: 'Arquivo do CNES (.csv)', tipo: 'arquivo', aceita: '.csv,.txt', obrigatorio: true, largo: true },
      { nome: 'uf', rotulo: 'Importar somente a UF (recomendado para o arquivo nacional)', max: 2, exemplo: 'SP' }], {}, {
      rotuloEnviar: 'Importar arquivo', aoEnviar: async (d) => {
        if (!d.arquivo) throw new Error('Escolha o arquivo.');
        const fd = new FormData();
        fd.append('arquivo', d.arquivo);
        if (d.uf) fd.append('uf', d.uf.toUpperCase());
        resultado.replaceChildren(h('p', { class: 'aviso info' }, 'Importando... arquivos grandes podem levar alguns minutos.'));
        const r = await api('/api/sus/importacao', { metodo: 'POST', formulario: fd });
        resultado.replaceChildren(h('div', { class: 'aviso ok' }, listaDefinicoes([['Linhas lidas', r.linhasLidas], ['Estabelecimentos gravados', r.estabelecimentosGravados],
          ['Ignorados (categoria/UF)', r.ignoradosPorCategoriaOuUf], ['Sem município', r.ignoradosSemMunicipio], ['Linhas inválidas', r.linhasInvalidas],
          ['Avisos', (r.avisos || []).join(' | ')]])));
        avisar('Importação concluída.');
      } }), resultado),
    cartao('RNDS - Rede Nacional de Dados em Saúde', h('p', { class: rnds.configurada ? 'aviso ok' : 'aviso alerta' }, rnds.situacao),
      listaDefinicoes([['Habilitada', rnds.habilitada ? 'Sim' : 'Não'], ['Configurada', rnds.configurada ? 'Sim' : 'Não'], ['Ambiente', rnds.ambiente]]),
      h('h3', { style: 'margin-top:1rem' }, 'Requisitos para ativar'), h('ul', { class: 'pequeno' }, rnds.requisitos.map((r) => h('li', null, r))),
      rnds.ultimoTeste ? h('p', { class: 'pequeno' }, `Último teste: ${rnds.ultimoTeste.mensagem}`) : null,
      botao('Testar autenticação', async () => {
        try { const r = await api('/api/rnds/teste-autenticacao', { metodo: 'POST' }); avisar(r.mensagem, r.sucesso ? 'ok' : 'erro'); app.navegar('#/admin/integracoes'); }
        catch (e) { avisar(erroParaTexto(e), 'erro'); }
      }, 'secundario', { disabled: !rnds.configurada })),
    cartao('HL7 FHIR R4', h('p', null, 'O EcoConect expõe os dados no padrão FHIR R4 (somente leitura), base para a interoperabilidade:'),
      h('ul', { class: 'pequeno' }, h('li', null, h('a', { href: '/api/fhir/metadata', target: '_blank', rel: 'noopener' }, '/api/fhir/metadata'), ' (capacidades)'),
        h('li', null, '/api/fhir/Organization/cnes-{código} e /api/fhir/Organization/inst-{id}'), h('li', null, '/api/fhir/Location/cnes-{código}'),
        h('li', null, '/api/fhir/HealthcareService?organization=inst-{id}'), h('li', null, '/api/fhir/Patient/{id} (equipe, dados mínimos, auditado)'),
        h('li', null, '/api/fhir/ServiceRequest/{id} e /api/fhir/ServiceRequest/{id}/pacote')))));
}
