// EcoConect - inicialização, rotas e estrutura da aplicação.
import { api } from './api.js';
import { h, anunciar, avisar, carregando, erroNaTela } from './ui.js';

const ICONE = () => {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('width', '28'); svg.setAttribute('height', '28'); svg.setAttribute('viewBox', '0 0 64 64'); svg.setAttribute('aria-hidden', 'true');
  const r = document.createElementNS(ns, 'rect');
  r.setAttribute('width', '64'); r.setAttribute('height', '64'); r.setAttribute('rx', '16'); r.setAttribute('fill', '#1d6b57');
  const p = document.createElementNS(ns, 'path');
  p.setAttribute('d', 'M20 40c0-11 8-20 22-22-1 14-9 24-22 22z'); p.setAttribute('fill', '#e6f4ec');
  svg.append(r, p);
  return svg;
};

// ------------------------------------------------------------------ estado compartilhado com as telas
export const app = {
  usuario: null,
  demonstracao: false,
  _catalogos: null,
  async catalogos() {
    if (!this._catalogos) this._catalogos = await api('/api/rede/catalogos');
    return this._catalogos;
  },
  navegar(destino) {
    if (location.hash === destino) rotear(); else location.hash = destino;
  },
  perfil(...perfis) { return !!this.usuario && perfis.includes(this.usuario.perfil); },
  get equipe() { return this.perfil('ADMINISTRADOR', 'PROFISSIONAL'); },
  get familia() { return this.perfil('RESPONSAVEL', 'PESSOA_ACOMPANHADA'); },
  atualizarContadores: () => atualizarContadores()
};

// ------------------------------------------------------------------ preferências de acessibilidade
export function aplicarPreferencias(p) {
  const c = document.documentElement.classList;
  c.toggle('baixo-estimulo', !!(p && p.baixoEstimulo));
  c.toggle('alto-contraste', !!(p && p.altoContraste));
  c.toggle('espacamento-leitura', !!(p && p.espacamentoLeitura));
  c.toggle('reduzir-movimento', !!(p && p.reduzirMovimento));
  c.toggle('fonte-grande', !!(p && p.tamanhoFonte === 'GRANDE'));
  c.toggle('fonte-muito-grande', !!(p && p.tamanhoFonte === 'MUITO_GRANDE'));
  try { localStorage.setItem('ecoconect.preferencias', JSON.stringify(p || {})); } catch (e) { /* apenas conveniência visual */ }
}

// ------------------------------------------------------------------ rotas
const tela = (modulo, funcao) => async () => (await import(`./telas/${modulo}.js`))[funcao];
const TODOS = ['ADMINISTRADOR', 'PROFISSIONAL', 'RESPONSAVEL', 'PESSOA_ACOMPANHADA', 'ADMIN_INSTITUCIONAL'];
const EQUIPE = ['ADMINISTRADOR', 'PROFISSIONAL'];
const EQUIPE_FAMILIA = ['ADMINISTRADOR', 'PROFISSIONAL', 'RESPONSAVEL', 'PESSOA_ACOMPANHADA'];
const ROTAS = [
  { padrao: 'entrar', publica: true, abrir: tela('entrada', 'login'), titulo: 'Entrar' },
  { padrao: 'cadastro', publica: true, abrir: tela('entrada', 'cadastro'), titulo: 'Criar conta' },
  { padrao: 'trocar-senha', abrir: tela('entrada', 'trocarSenha'), titulo: 'Defina sua senha', semEstrutura: true },
  { padrao: 'painel', abrir: tela('painel', 'painel'), titulo: 'Início', perfis: TODOS },
  { padrao: 'pessoas', abrir: tela('pessoas', 'lista'), titulo: 'Pessoas acompanhadas', perfis: TODOS },
  { padrao: 'pessoas/nova', abrir: tela('pessoas', 'nova'), titulo: 'Cadastrar pessoa', perfis: ['ADMINISTRADOR', 'PROFISSIONAL', 'RESPONSAVEL'] },
  { padrao: 'pessoas/:id', abrir: tela('pessoas', 'detalhe'), titulo: 'Pessoa acompanhada', perfis: TODOS },
  { padrao: 'sessoes/nova', abrir: tela('sessoes', 'nova'), titulo: 'Registrar sessão', perfis: EQUIPE },
  { padrao: 'sessoes/:id', abrir: tela('sessoes', 'detalhe'), titulo: 'Sessão', perfis: EQUIPE_FAMILIA },
  { padrao: 'agenda', abrir: tela('agenda', 'agenda'), titulo: 'Agenda', perfis: EQUIPE_FAMILIA },
  { padrao: 'profissionais', abrir: tela('profissionais', 'lista'), titulo: 'Profissionais', perfis: ['ADMINISTRADOR', 'PROFISSIONAL', 'ADMIN_INSTITUCIONAL'] },
  { padrao: 'profissionais/:id', abrir: tela('profissionais', 'detalhe'), titulo: 'Profissional', perfis: ['ADMINISTRADOR', 'PROFISSIONAL', 'ADMIN_INSTITUCIONAL'] },
  { padrao: 'rede', abrir: tela('rede', 'busca'), titulo: 'Rede de apoio', perfis: TODOS },
  { padrao: 'rede/recomendacoes', abrir: tela('rede', 'recomendacoes'), titulo: 'Recomendações', perfis: TODOS },
  { padrao: 'rede/minha', abrir: tela('rede', 'minha'), titulo: 'Minha instituição', perfis: ['ADMIN_INSTITUCIONAL', 'ADMINISTRADOR'] },
  { padrao: 'rede/nova', abrir: tela('rede', 'nova'), titulo: 'Cadastrar instituição', perfis: ['ADMINISTRADOR'] },
  { padrao: 'rede/:id', abrir: tela('rede', 'detalhe'), titulo: 'Instituição', perfis: TODOS },
  { padrao: 'solicitacoes', abrir: tela('solicitacoes', 'lista'), titulo: 'Solicitações de atendimento', perfis: TODOS },
  { padrao: 'solicitacoes/:id', abrir: tela('solicitacoes', 'detalhe'), titulo: 'Solicitação', perfis: TODOS },
  { padrao: 'mensagens', abrir: tela('mensagens', 'mensagens'), titulo: 'Mensagens', perfis: TODOS },
  { padrao: 'mensagens/:id', abrir: tela('mensagens', 'mensagens'), titulo: 'Mensagens', perfis: TODOS },
  { padrao: 'notificacoes', abrir: tela('conta', 'notificacoes'), titulo: 'Notificações', perfis: TODOS },
  { padrao: 'sus', abrir: tela('sus', 'sus'), titulo: 'Caminhos no SUS', perfis: TODOS },
  { padrao: 'relatorios', abrir: tela('relatorios', 'relatorios'), titulo: 'Relatórios', perfis: ['ADMINISTRADOR', 'PROFISSIONAL', 'ADMIN_INSTITUCIONAL'] },
  { padrao: 'conta', abrir: tela('conta', 'conta'), titulo: 'Minha conta', perfis: TODOS },
  { padrao: 'admin/usuarios', abrir: tela('admin', 'usuarios'), titulo: 'Usuários', perfis: ['ADMINISTRADOR'] },
  { padrao: 'admin/auditoria', abrir: tela('admin', 'auditoria'), titulo: 'Auditoria', perfis: ['ADMINISTRADOR'] },
  { padrao: 'admin/privacidade', abrir: tela('admin', 'privacidade'), titulo: 'Pedidos de privacidade', perfis: ['ADMINISTRADOR'] },
  { padrao: 'admin/integracoes', abrir: tela('admin', 'integracoes'), titulo: 'Integrações com o SUS', perfis: ['ADMINISTRADOR'] }
];

function lerHash() {
  const bruto = location.hash.replace(/^#\/?/, '');
  const [caminho, busca] = bruto.split('?');
  return { partes: caminho.split('/').filter(Boolean), consulta: Object.fromEntries(new URLSearchParams(busca || '')) };
}

function casar(padrao, partes) {
  const p = padrao.split('/');
  if (p.length !== partes.length) return null;
  const params = {};
  for (let i = 0; i < p.length; i++) {
    if (p[i].startsWith(':')) params[p[i].slice(1)] = decodeURIComponent(partes[i]);
    else if (p[i] !== partes[i]) return null;
  }
  return params;
}

function inicioDoPerfil() {
  if (!app.usuario) return '#/entrar';
  if (app.usuario.exigeTrocaSenha) return '#/trocar-senha';
  return '#/painel';
}

let renderizacao = 0;
async function rotear() {
  const { partes, consulta } = lerHash();
  if (!partes.length) { location.replace(inicioDoPerfil()); return; }
  let rota = null; let params = {};
  for (const r of ROTAS) { const p = casar(r.padrao, partes); if (p) { rota = r; params = p; break; } }
  if (!rota) { location.replace(inicioDoPerfil()); return; }
  if (!rota.publica && !app.usuario) { location.replace('#/entrar'); return; }
  if (rota.publica && app.usuario && !app.usuario.exigeTrocaSenha) { location.replace('#/painel'); return; }
  if (app.usuario && app.usuario.exigeTrocaSenha && rota.padrao !== 'trocar-senha') { location.replace('#/trocar-senha'); return; }
  if (rota.perfis && !rota.perfis.includes(app.usuario.perfil)) {
    avisar('Seu perfil não tem acesso a esta tela.', 'erro');
    location.replace('#/painel');
    return;
  }
  const minha = ++renderizacao;
  const destino = rota.publica || rota.semEstrutura ? montarTelaCheia() : montarEstrutura(partes);
  destino.replaceChildren(carregando());
  document.title = `${rota.titulo} · EcoConect`;
  try {
    const render = await rota.abrir();
    if (minha !== renderizacao) return;
    destino.replaceChildren();
    await render(destino, { params, consulta, app });
  } catch (e) {
    if (minha !== renderizacao) return;
    destino.replaceChildren(erroNaTela(e, rotear));
  }
  if (minha !== renderizacao) return;
  const titulo = destino.querySelector('h1');
  if (titulo) { titulo.setAttribute('tabindex', '-1'); titulo.focus({ preventScroll: false }); anunciar(titulo.textContent); }
  window.scrollTo(0, 0);
}

// ------------------------------------------------------------------ estrutura (topo + menu)
function montarTelaCheia() {
  const raiz = document.getElementById('raiz');
  raiz.replaceChildren();
  const main = h('main', { id: 'conteudo', tabindex: '-1' });
  raiz.append(main);
  return main;
}

function itensDoMenu() {
  const u = app.usuario;
  const itens = [{ rotulo: app.familia ? 'Início' : 'Painel', destino: '#/painel' }];
  if (u.perfil === 'PESSOA_ACOMPANHADA' && u.idCriancaPropria) itens.push({ rotulo: 'Meu acompanhamento', destino: `#/pessoas/${u.idCriancaPropria}` });
  else if (u.perfil === 'RESPONSAVEL') itens.push({ rotulo: 'Minha família', destino: '#/pessoas' });
  else if (u.perfil !== 'ADMIN_INSTITUCIONAL') itens.push({ rotulo: 'Pessoas acompanhadas', destino: '#/pessoas' });
  if (u.perfil === 'ADMIN_INSTITUCIONAL') itens.push({ rotulo: 'Minha instituição', destino: '#/rede/minha' });
  if (u.perfil !== 'ADMIN_INSTITUCIONAL') itens.push({ rotulo: 'Agenda', destino: '#/agenda' });
  if (['ADMINISTRADOR', 'PROFISSIONAL', 'ADMIN_INSTITUCIONAL'].includes(u.perfil)) itens.push({ rotulo: 'Profissionais', destino: '#/profissionais' });
  itens.push({ rotulo: 'Rede de apoio', destino: '#/rede' });
  itens.push({ rotulo: 'Solicitações', destino: '#/solicitacoes' });
  itens.push({ rotulo: 'Mensagens', destino: '#/mensagens' });
  itens.push({ rotulo: 'Caminhos no SUS', destino: '#/sus' });
  if (['ADMINISTRADOR', 'PROFISSIONAL', 'ADMIN_INSTITUCIONAL'].includes(u.perfil)) itens.push({ rotulo: 'Relatórios', destino: '#/relatorios' });
  const admin = u.perfil === 'ADMINISTRADOR' ? [
    { rotulo: 'Usuários', destino: '#/admin/usuarios' }, { rotulo: 'Auditoria', destino: '#/admin/auditoria' },
    { rotulo: 'Pedidos de privacidade', destino: '#/admin/privacidade' }, { rotulo: 'Integrações (CNES/RNDS)', destino: '#/admin/integracoes' }] : [];
  return { itens, admin };
}

let estruturaMontada = false;
function montarEstrutura(partes) {
  const raiz = document.getElementById('raiz');
  if (!estruturaMontada || !document.getElementById('conteudo') || !document.querySelector('.layout')) {
    const { itens, admin } = itensDoMenu();
    const lateral = h('nav', { class: 'lateral', id: 'menu', 'aria-label': 'Menu principal' },
      h('ul', null, itens.map((i) => h('li', null, h('a', { href: i.destino }, i.rotulo)))),
      admin.length ? [h('p', { class: 'secao' }, 'Administração'), h('ul', null, admin.map((i) => h('li', null, h('a', { href: i.destino }, i.rotulo))))] : null,
      h('p', { class: 'secao' }, 'Você'),
      h('ul', null, h('li', null, h('a', { href: '#/conta' }, 'Minha conta e acessibilidade')),
        h('li', null, h('a', { href: '#', onClick: (ev) => { ev.preventDefault(); sair(); } }, 'Sair'))));
    const alternar = h('button', { type: 'button', class: 'icone-botao menu-alternar', 'aria-expanded': 'false', 'aria-controls': 'menu',
      onClick: () => { const aberto = lateral.classList.toggle('aberta'); alternar.setAttribute('aria-expanded', String(aberto)); } }, 'Menu');
    const topo = h('header', { class: 'topo' }, alternar,
      h('a', { href: '#/painel', class: 'marca' }, ICONE(), h('span', null, 'EcoConect')),
      h('span', { class: 'espaco' }),
      h('a', { href: '#/mensagens', class: 'icone-botao', title: 'Mensagens' }, h('span', { class: 'rotulo-largo' }, 'Mensagens'),
        h('span', { class: 'sr-only' }, 'Mensagens'), h('span', { class: 'contador', id: 'contador-mensagens', hidden: true })),
      h('a', { href: '#/notificacoes', class: 'icone-botao', title: 'Notificações' }, h('span', { class: 'rotulo-largo' }, 'Avisos'),
        h('span', { class: 'sr-only' }, 'Notificações'), h('span', { class: 'contador', id: 'contador-notificacoes', hidden: true })),
      h('a', { href: '#/conta', class: 'icone-botao', title: 'Minha conta' }, h('span', null, primeiroNome(app.usuario.nome))));
    const faixa = app.demonstracao ? h('div', { class: 'faixa-demo', role: 'note' },
      'Ambiente de demonstração: as pessoas, instituições e estabelecimentos exibidos são fictícios.') : null;
    raiz.replaceChildren(topo, faixa || '', h('div', { class: 'layout' }, lateral, h('main', { id: 'conteudo', class: 'conteudo', tabindex: '-1' })));
    estruturaMontada = true;
    atualizarContadores();
  }
  const atual = '#/' + partes.join('/');
  document.querySelectorAll('.lateral a').forEach((a) => {
    const destino = a.getAttribute('href');
    const ativo = destino !== '#' && (atual === destino || (atual.startsWith(destino + '/') && destino !== '#/rede'));
    if (ativo || (destino === '#/rede' && (atual === '#/rede' || /^#\/rede\/(\d+|recomendacoes)/.test(atual)))) a.setAttribute('aria-current', 'page');
    else a.removeAttribute('aria-current');
  });
  document.getElementById('menu').classList.remove('aberta');
  return document.getElementById('conteudo');
}

function primeiroNome(nome) {
  return (nome || '').split(' ')[0] || 'Conta';
}

async function atualizarContadores() {
  if (!app.usuario || app.usuario.exigeTrocaSenha || document.hidden) return;
  try {
    const c = await api('/api/app/contadores');
    for (const [id, valor] of [['contador-mensagens', c.mensagens], ['contador-notificacoes', c.notificacoes]]) {
      const el = document.getElementById(id);
      if (!el) continue;
      el.textContent = valor > 99 ? '99+' : String(valor);
      el.hidden = !valor;
      el.setAttribute('aria-label', `${valor} não lidas`);
    }
  } catch (e) { /* silencioso: o erro aparece quando a pessoa abrir a tela */ }
}

// ------------------------------------------------------------------ sessão
export async function entrar(usuario) {
  app.usuario = usuario;
  estruturaMontada = false;
  aplicarPreferencias(usuario.preferencias);
  location.hash = usuario.exigeTrocaSenha ? '#/trocar-senha' : '#/painel';
}

export async function sair(mensagem) {
  try { await api('/api/auth/logout', { metodo: 'POST' }); } catch (e) { /* a sessão já pode ter expirado */ }
  app.usuario = null;
  estruturaMontada = false;
  if (mensagem) avisar(mensagem);
  location.hash = '#/entrar';
}

window.addEventListener('ecoconect:sessao-expirada', () => {
  if (!app.usuario) return;
  app.usuario = null;
  estruturaMontada = false;
  avisar('Sua sessão terminou. Entre novamente para continuar.', 'erro');
  location.hash = '#/entrar';
});
window.addEventListener('ecoconect:trocar-senha', () => {
  if (app.usuario) { app.usuario.exigeTrocaSenha = true; location.hash = '#/trocar-senha'; }
});

async function iniciar() {
  try {
    const p = JSON.parse(localStorage.getItem('ecoconect.preferencias') || 'null');
    if (p) aplicarPreferencias(p);
  } catch (e) { /* ignora */ }
  document.addEventListener('click', (ev) => {
    const pular = ev.target.closest('[data-pular-conteudo]');
    if (pular) { ev.preventDefault(); const m = document.getElementById('conteudo'); if (m) m.focus(); }
  });
  try {
    const saude = await api('/api/saude');
    app.demonstracao = !!saude.demonstracao;
  } catch (e) {
    document.getElementById('raiz').replaceChildren(h('main', { class: 'conteudo' }, h('h1', null, 'O EcoConect não conseguiu iniciar'),
      erroNaTela(e, () => location.reload()), h('p', null, 'Se você administra a instalação, execute o healthcheck para ver o que falta.')));
    return;
  }
  try {
    const eu = await api('/api/auth/me');
    app.usuario = eu;
    aplicarPreferencias(eu.preferencias);
  } catch (e) {
    app.usuario = null;
  }
  window.addEventListener('hashchange', rotear);
  setInterval(atualizarContadores, 60000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) atualizarContadores(); });
  rotear();
}

iniciar();
