// Solicitações de atendimento às instituições (família/equipe pedem; instituição responde).
import { api } from '../api.js';
import { h, cabecalho, cartao, avisar, confirmar, janelaFormulario, tabela, situacao, dataHoraBR, vazio, botao, link, listaDefinicoes, erroParaTexto } from '../ui.js';

export async function lista(el, { consulta, app }) {
  const institucional = app.perfil('ADMIN_INSTITUCIONAL');
  el.append(cabecalho('Solicitações de atendimento', institucional ? 'Pedidos recebidos pela sua instituição.' : 'Pedidos enviados às instituições da rede de apoio.',
    institucional ? null : [link('Buscar instituições', '#/rede', 'botao')]));
  const filtro = h('select', { id: 'filtro-sit', onChange: (ev) => app.navegar('#/solicitacoes' + (ev.target.value ? '?situacao=' + ev.target.value : '')) },
    h('option', { value: '' }, 'Todas'), [['ENVIADA', 'Enviadas'], ['EM_ANALISE', 'Em análise'], ['ACEITA', 'Aceitas'], ['RECUSADA', 'Recusadas'],
      ['CONCLUIDA', 'Concluídas'], ['CANCELADA', 'Canceladas']].map(([v, r]) => h('option', { value: v, selected: consulta.situacao === v }, r)));
  el.append(h('div', { class: 'filtros' }, h('div', { class: 'campo' }, h('label', { for: 'filtro-sit' }, 'Situação'), filtro)));
  const itens = await api('/api/app/solicitacoes', { consulta: { situacao: consulta.situacao, idInstituicao: consulta.instituicao } });
  el.append(cartao(null, tabela([
    { titulo: 'Enviada em', valor: (s) => dataHoraBR(s.dataCriacao) },
    { titulo: institucional ? 'Solicitante' : 'Instituição', valor: (s) => h('a', { href: `#/solicitacoes/${s.idSolicitacao}` }, institucional ? s.solicitante : s.instituicao) },
    { titulo: 'Pessoa', valor: (s) => s.pessoa }, { titulo: 'Serviço', valor: (s) => s.servico },
    { titulo: 'Situação', valor: (s) => situacao('solicitacao', s.situacao) }], itens, { vazioTexto: 'Nenhuma solicitação por aqui.' })));
}

export async function detalhe(el, { params, app }) {
  const s = await api(`/api/app/solicitacoes/${params.id}`);
  const cat = await app.catalogos();
  const recarregar = () => app.navegar(`#/solicitacoes/${s.idSolicitacao}`);
  const acoes = [];
  if (s.idConversa) acoes.push(link('Abrir conversa', `#/mensagens/${s.idConversa}`, 'botao secundario'));
  if (s.podeResponder) acoes.push(botao('Responder', () => responder(s, recarregar)));
  if (s.podeCancelar) acoes.push(botao('Cancelar solicitação', async () => {
    if (!await confirmar('Cancelar esta solicitação? A instituição será avisada.', { perigo: true, rotulo: 'Cancelar solicitação' })) return;
    try { await api(`/api/app/solicitacoes/${s.idSolicitacao}/cancelamento`, { metodo: 'POST' }); avisar('Solicitação cancelada.'); recarregar(); }
    catch (e) { avisar(erroParaTexto(e), 'erro'); }
  }, 'secundario perigo'));
  el.append(cabecalho(`Solicitação para ${s.instituicao}`, `Enviada em ${dataHoraBR(s.dataCriacao)} por ${s.solicitante}`, acoes,
    [{ texto: 'Solicitações', link: '#/solicitacoes' }, { texto: '#' + s.idSolicitacao }]));
  const n = s.necessidades;
  const rot = (cod, voc) => (cod ? cod.split(',').map((c) => voc[c] || c).join(', ') : null);
  el.append(h('div', { class: 'grade-2' },
    cartao('Pedido', listaDefinicoes([['Situação', situacao('solicitacao', s.situacao)], ['Instituição', h('a', { href: `#/rede/${s.idInstituicao}` }, s.instituicao)],
      ['Serviço', s.servico], ['Pessoa', s.pessoa ? `${s.pessoa}${s.idadePessoa !== null ? ' (' + s.idadePessoa + ' anos)' : ''}` : null],
      ['Forma de contato', { MENSAGEM_NA_PLATAFORMA: 'Mensagem na plataforma', EMAIL: 'E-mail', TELEFONE: 'Telefone' }[s.formaContato]],
      ['Mensagem', h('span', { class: 'pre' }, s.mensagem)], ['Resposta', s.resposta ? h('span', { class: 'pre' }, s.resposta) : null],
      ['Respondida por', s.respondidaPor ? `${s.respondidaPor} em ${dataHoraBR(s.dataResposta)}` : null]])),
    n ? cartao('Necessidades informadas', listaDefinicoes([['Condições', rot(n.condicoes, cat.condicoes)], ['Necessidades', n.necessidades],
      ['Sensorial', rot(n.sensorial, cat.sensorial)], ['Comunicação', cat.comunicacao[n.comunicacao] || n.comunicacao],
      ['Acessibilidade', rot(n.acessibilidade, cat.acessibilidade)], ['Local', n.municipio ? `${n.municipio}/${n.uf || ''}` : null]]),
    h('p', { class: 'suave pequeno', style: 'margin-top:.75rem' }, 'Dados de saúde e registros de sessões não são compartilhados com a instituição.')) : null));
}

function responder(s, recarregar) {
  const opcoes = { ENVIADA: [['EM_ANALISE', 'Em análise'], ['ACEITA', 'Aceitar'], ['RECUSADA', 'Recusar']], EM_ANALISE: [['ACEITA', 'Aceitar'], ['RECUSADA', 'Recusar']],
    ACEITA: [['CONCLUIDA', 'Concluir atendimento']] }[s.situacao] || [];
  janelaFormulario('Responder solicitação', [
    { nome: 'situacao', rotulo: 'Resposta', tipo: 'selecao', obrigatorio: true, opcoes, largo: true },
    { nome: 'resposta', rotulo: 'Mensagem para quem pediu', tipo: 'area', max: 1000, largo: true,
      ajuda: 'Obrigatória ao recusar. Se possível, indique outro serviço. A mensagem também vai para a conversa.' }
  ], {}, async (d) => {
    await api(`/api/app/solicitacoes/${s.idSolicitacao}/resposta`, { metodo: 'POST', corpo: d });
    avisar('Resposta enviada. Quem pediu foi avisado.');
    recarregar();
  }, { rotuloEnviar: 'Enviar resposta', antes: h('p', { class: 'suave' }, 'Ao aceitar, a pessoa fica vinculada à instituição.') });
}
