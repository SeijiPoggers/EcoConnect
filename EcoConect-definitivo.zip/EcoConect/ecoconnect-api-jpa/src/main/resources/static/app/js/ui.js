// Componentes de interface sem bibliotecas externas. Todo texto é inserido com textContent
// (nunca innerHTML), o que impede a execução de código vindo dos dados (proteção contra XSS).
import { ErroApi } from './api.js';

const BOOLEANOS = new Set(['disabled', 'checked', 'required', 'hidden', 'selected', 'multiple', 'readonly', 'open', 'autofocus']);

export function h(tag, atributos, ...filhos) {
  const el = document.createElement(tag);
  if (atributos) {
    for (const [k, v] of Object.entries(atributos)) {
      if (v === undefined || v === null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k === 'for') el.htmlFor = v;
      else if (k === 'value') el.value = v;
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (BOOLEANOS.has(k)) { if (v) el.setAttribute(k, ''); if (k === 'checked' || k === 'selected') el[k] = !!v; }
      else el.setAttribute(k, v === true ? '' : String(v));
    }
  }
  anexar(el, filhos);
  return el;
}

function anexar(el, filhos) {
  for (const f of filhos) {
    if (f === null || f === undefined || f === false) continue;
    if (Array.isArray(f)) anexar(el, f);
    else el.append(f instanceof Node ? f : document.createTextNode(String(f)));
  }
}

let sequencia = 0;
export const novoId = (prefixo = 'id') => `${prefixo}-${++sequencia}`;

// ------------------------------------------------------------------ avisos
export function anunciar(texto) {
  const r = document.getElementById('anuncios');
  if (!r) return;
  r.textContent = '';
  setTimeout(() => { r.textContent = texto; }, 50);
}

export function avisar(texto, tipo = 'ok') {
  const area = document.getElementById('toasts');
  const t = h('div', { class: 'toast' + (tipo === 'erro' ? ' erro' : ''), role: tipo === 'erro' ? 'alert' : 'status' },
    h('span', null, texto), h('button', { type: 'button', onClick: () => t.remove() }, 'Fechar'));
  area.append(t);
  const tempo = document.documentElement.classList.contains('baixo-estimulo') ? 9000 : 6000;
  setTimeout(() => t.remove(), tipo === 'erro' ? tempo + 4000 : tempo);
}

export function erroParaTexto(e) {
  return e instanceof ErroApi || e instanceof Error ? e.message : String(e);
}

// ------------------------------------------------------------------ janelas
export function janela({ titulo, conteudo, acoes = [], aoAbrir } = {}) {
  return new Promise((resolver) => {
    const anterior = document.activeElement;
    const idTitulo = novoId('janela');
    const d = h('dialog', { class: 'janela', 'aria-labelledby': idTitulo });
    const fechar = (valor) => { d.close(); d.remove(); if (anterior && anterior.focus) anterior.focus(); resolver(valor); };
    const rodape = acoes.length ? h('div', { class: 'janela-rodape' }, acoes.map((a) =>
      h('button', { type: 'button', class: 'botao ' + (a.classe || ''), onClick: async () => {
        if (a.aoClicar) { const r = await a.aoClicar(); if (r === false) return; }
        fechar(a.valor);
      } }, a.rotulo))) : null;
    d.append(
      h('div', { class: 'janela-topo' }, h('h2', { id: idTitulo }, titulo),
        h('button', { type: 'button', class: 'botao texto', onClick: () => fechar(undefined) }, 'Fechar')),
      h('div', { class: 'janela-corpo' }, conteudo), rodape);
    d.addEventListener('cancel', (ev) => { ev.preventDefault(); fechar(undefined); });
    document.body.append(d);
    d.showModal();
    d._fechar = fechar;
    if (aoAbrir) aoAbrir(d, fechar);
  });
}

export function confirmar(texto, { titulo = 'Confirmar', rotulo = 'Confirmar', perigo = false } = {}) {
  return janela({ titulo, conteudo: h('p', null, texto), acoes: [
    { rotulo: 'Voltar', classe: 'secundario', valor: false },
    { rotulo, classe: perigo ? 'perigo' : '', valor: true }] }).then((v) => v === true);
}

/** Janela com um formulário; resolve com o resultado de aoEnviar (ou undefined se cancelada). */
export function janelaFormulario(titulo, campos, valores, aoEnviar, { rotuloEnviar = 'Salvar', antes } = {}) {
  return new Promise((resolver) => {
    let fecharJanela;
    const form = formulario(campos, valores, {
      rotuloEnviar,
      cancelar: () => fecharJanela(undefined),
      aoEnviar: async (dados) => { const r = await aoEnviar(dados); fecharJanela(r === undefined ? true : r); }
    });
    const conteudo = antes ? h('div', null, antes, form) : form;
    janela({ titulo, conteudo, aoAbrir: (d, fechar) => {
      fecharJanela = fechar;
      const primeiro = d.querySelector('input:not([type=hidden]), select, textarea');
      if (primeiro) primeiro.focus();
    } }).then(resolver);
  });
}

// ------------------------------------------------------------------ formulários
function opcoesDe(opcoes) {
  if (!opcoes) return [];
  if (Array.isArray(opcoes)) return opcoes.map((o) => (Array.isArray(o) ? o : [o, o]));
  return Object.entries(opcoes);
}

function valorInicial(campo, valores) {
  const v = valores ? valores[campo.nome] : undefined;
  return v === undefined || v === null ? (campo.padrao ?? '') : v;
}

export function campo(c, valores) {
  const id = novoId(c.nome);
  const idAjuda = c.ajuda ? id + '-ajuda' : null;
  const idErro = id + '-erro';
  const descrito = [idAjuda, idErro].filter(Boolean).join(' ');
  const v = valorInicial(c, valores);
  const comuns = { id, name: c.nome, required: c.obrigatorio, 'aria-describedby': descrito, disabled: c.desabilitado };
  let controle;
  const tipo = c.tipo || 'texto';
  if (tipo === 'area') {
    controle = h('textarea', { ...comuns, maxlength: c.max, rows: c.linhas || 4, placeholder: c.exemplo });
    controle.value = v;
  } else if (tipo === 'selecao') {
    controle = h('select', comuns, c.semVazio ? null : h('option', { value: '' }, c.vazio || 'Selecione'),
      opcoesDe(c.opcoes).map(([valor, rotulo]) => h('option', { value: valor, selected: String(v) === String(valor) }, rotulo)));
  } else if (tipo === 'marcacao') {
    controle = h('input', { ...comuns, type: 'checkbox', checked: v === true || v === 1 || v === 'true' });
    return h('div', { class: 'campo' + (c.largo ? ' largo' : '') },
      h('label', { class: 'marcacao', for: id }, controle, c.rotulo),
      c.ajuda ? h('span', { class: 'ajuda', id: idAjuda }, c.ajuda) : null, h('span', { class: 'erro', id: idErro }));
  } else if (tipo === 'multipla') {
    const marcados = new Set(Array.isArray(v) ? v.map(String) : String(v || '').split(',').filter(Boolean));
    return h('fieldset', { class: 'campo' + (c.largo !== false ? ' largo' : ''), 'data-multipla': c.nome, 'aria-describedby': descrito },
      h('legend', null, c.rotulo),
      c.ajuda ? h('span', { class: 'ajuda', id: idAjuda }, c.ajuda) : null,
      h('div', { class: 'opcoes' }, opcoesDe(c.opcoes).map(([valor, rotulo]) =>
        h('label', null, h('input', { type: 'checkbox', name: c.nome, value: valor, checked: marcados.has(String(valor)) }), rotulo))),
      h('span', { class: 'erro', id: idErro }));
  } else {
    const tipos = { texto: 'text', email: 'email', senha: 'password', data: 'date', datahora: 'datetime-local', numero: 'number',
      telefone: 'tel', hora: 'time', arquivo: 'file', oculto: 'hidden' };
    let valor = v;
    if (tipo === 'datahora' && typeof v === 'string') valor = v.slice(0, 16);
    controle = h('input', { ...comuns, type: tipos[tipo] || 'text', maxlength: c.max, min: c.minimo, max: c.maximo, step: c.passo,
      autocomplete: c.autocomplete, placeholder: c.exemplo, accept: c.aceita, inputmode: c.modo });
    if (tipo !== 'arquivo') controle.value = valor;
    if (tipo === 'oculto') return controle;
  }
  return h('div', { class: 'campo' + (c.largo ? ' largo' : '') },
    h('label', { for: id }, c.rotulo, c.obrigatorio ? h('span', { 'aria-hidden': 'true' }, ' *') : null),
    c.ajuda ? h('span', { class: 'ajuda', id: idAjuda }, c.ajuda) : null, controle, h('span', { class: 'erro', id: idErro }));
}

export function lerFormulario(form, campos) {
  const dados = {};
  for (const c of campos) {
    if (c.tipo === 'multipla') {
      const marcados = [...form.querySelectorAll(`input[name="${c.nome}"]:checked`)].map((i) => i.value);
      dados[c.nome] = c.comoLista ? marcados : marcados.join(',');
      continue;
    }
    const el = form.elements[c.nome];
    if (!el) continue;
    if (c.tipo === 'marcacao') { dados[c.nome] = el.checked; continue; }
    if (c.tipo === 'arquivo') { dados[c.nome] = el.files && el.files[0] ? el.files[0] : null; continue; }
    let v = el.value;
    if (typeof v === 'string') v = v.trim();
    if (v === '') { dados[c.nome] = null; continue; }
    if (c.tipo === 'numero') v = Number(v);
    if (c.tipo === 'datahora' && v.length === 16) v += ':00';
    dados[c.nome] = v;
  }
  return dados;
}

export function formulario(campos, valores = {}, { aoEnviar, rotuloEnviar = 'Salvar', cancelar, extras } = {}) {
  const resumoErro = h('div', { class: 'aviso perigo', role: 'alert', hidden: true, tabindex: '-1' });
  const botao = h('button', { type: 'submit', class: 'botao' }, rotuloEnviar);
  const form = h('form', { novalidate: true },
    resumoErro,
    h('div', { class: 'campos' }, campos.map((c) => campo(c, valores))),
    extras || null,
    h('div', { class: 'acoes direita', style: 'margin-top:1rem' },
      cancelar ? h('button', { type: 'button', class: 'botao secundario', onClick: cancelar }, 'Cancelar') : null, botao));
  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    limparErros(form, resumoErro);
    const faltando = campos.filter((c) => c.obrigatorio && c.tipo !== 'marcacao' && c.tipo !== 'multipla'
      && form.elements[c.nome] && !String(form.elements[c.nome].value || '').trim());
    if (faltando.length) {
      for (const c of faltando) marcarErro(form, c.nome, 'Preencha este campo.');
      mostrarResumo(resumoErro, `Preencha os campos obrigatórios: ${faltando.map((c) => c.rotulo).join(', ')}.`);
      return;
    }
    botao.disabled = true;
    const textoOriginal = botao.textContent;
    botao.textContent = 'Salvando…';
    try {
      await aoEnviar(lerFormulario(form, campos), form);
    } catch (e) {
      if (e instanceof ErroApi && e.campos) for (const [nome, msg] of Object.entries(e.campos)) marcarErro(form, nome, msg);
      mostrarResumo(resumoErro, erroParaTexto(e));
    } finally {
      botao.disabled = false;
      botao.textContent = textoOriginal;
    }
  });
  return form;
}

function limparErros(form, resumo) {
  resumo.hidden = true;
  form.querySelectorAll('[aria-invalid]').forEach((el) => el.removeAttribute('aria-invalid'));
  form.querySelectorAll('.erro').forEach((el) => { el.textContent = ''; });
}

function marcarErro(form, nome, msg) {
  const el = form.elements[nome];
  const alvo = el && el.length && !el.tagName ? el[0] : el;
  if (!alvo) return;
  alvo.setAttribute('aria-invalid', 'true');
  const caixa = alvo.closest('.campo');
  const erro = caixa && caixa.querySelector('.erro');
  if (erro) erro.textContent = msg;
}

function mostrarResumo(resumo, texto) {
  resumo.textContent = texto;
  resumo.hidden = false;
  resumo.focus();
}

// ------------------------------------------------------------------ blocos de tela
export function cabecalho(titulo, subtitulo, acoes, trilha) {
  return h('div', null,
    trilha ? h('nav', { class: 'trilha', 'aria-label': 'Você está em' }, trilha.map((t, i) =>
      [i ? ' › ' : null, t.link ? h('a', { href: t.link }, t.texto) : h('span', null, t.texto)])) : null,
    h('div', { class: 'cabecalho-pagina' },
      h('div', null, h('h1', { tabindex: '-1' }, titulo), subtitulo ? h('p', null, subtitulo) : null),
      acoes ? h('div', { class: 'acoes' }, acoes) : null));
}

export function cartao(titulo, ...conteudo) {
  return h('section', { class: 'cartao' }, titulo ? h('h2', null, titulo) : null, conteudo);
}

export function botao(rotulo, aoClicar, classe = '', extras = {}) {
  return h('button', { type: 'button', class: 'botao ' + classe, onClick: aoClicar, ...extras }, rotulo);
}

export function link(rotulo, destino, classe = 'botao') {
  return h('a', { href: destino, class: classe }, rotulo);
}

export function etiqueta(texto, tipo = '') {
  return h('span', { class: 'etiqueta ' + tipo }, texto);
}

export function vazio(texto, acao) {
  return h('div', { class: 'vazio' }, h('p', null, texto), acao || null);
}

export function carregando(texto = 'Carregando…') {
  return h('p', { class: 'carregando', role: 'status' }, texto);
}

export function erroNaTela(e, tentar) {
  return h('div', { class: 'aviso perigo', role: 'alert' }, h('p', null, erroParaTexto(e)),
    tentar ? botao('Tentar de novo', tentar, 'secundario pequeno') : null);
}

export function tabela(colunas, linhas, { vazioTexto = 'Nada para mostrar.', legenda } = {}) {
  if (!linhas || !linhas.length) return vazio(vazioTexto);
  return h('div', { class: 'tabela-rolagem' }, h('table', { class: 'tabela responsiva' },
    legenda ? h('caption', { class: 'sr-only' }, legenda) : null,
    h('thead', null, h('tr', null, colunas.map((c) => h('th', { scope: 'col' }, c.titulo)))),
    h('tbody', null, linhas.map((l) => h('tr', null, colunas.map((c) => {
      const v = c.valor(l);
      return h('td', { 'data-rotulo': c.titulo }, v === null || v === undefined || v === '' ? '—' : v);
    }))))));
}

/** Abas acessíveis (setas do teclado mudam a aba). */
export function abas(itens, ativa, aoMudar) {
  const lista = h('div', { class: 'abas', role: 'tablist' });
  const botoes = itens.map((it) => h('button', { type: 'button', role: 'tab', id: 'aba-' + it.chave,
    'aria-selected': String(it.chave === ativa), tabindex: it.chave === ativa ? '0' : '-1', onClick: () => aoMudar(it.chave) }, it.rotulo));
  lista.append(...botoes);
  lista.addEventListener('keydown', (ev) => {
    const i = botoes.indexOf(document.activeElement);
    if (i < 0) return;
    let j = null;
    if (ev.key === 'ArrowRight') j = (i + 1) % botoes.length;
    if (ev.key === 'ArrowLeft') j = (i - 1 + botoes.length) % botoes.length;
    if (j !== null) { ev.preventDefault(); botoes[j].focus(); aoMudar(itens[j].chave); }
  });
  return lista;
}

export function listaDefinicoes(pares) {
  return h('dl', { class: 'dl' }, pares.filter((p) => p).map(([t, d]) => [h('dt', null, t), h('dd', null, d === null || d === undefined || d === '' ? '—' : d)]));
}

export function graficoBarras(itens, { rotulo = (i) => i.rotulo, valor = (i) => i.valor, descricao = 'Gráfico de barras' } = {}) {
  if (!itens.length) return vazio('Ainda não há dados para o gráfico.');
  const maximo = Math.max(1, ...itens.map(valor));
  return h('figure', { style: 'margin:0' },
    h('div', { class: 'barras', role: 'img', 'aria-label': descricao + ': ' + itens.map((i) => `${rotulo(i)} ${valor(i)}`).join(', ') },
      itens.map((i) => h('div', { class: 'coluna' }, h('span', { class: 'numero' }, valor(i)),
        h('span', { class: 'barra', style: `height:${Math.round((valor(i) / maximo) * 100)}%` }), h('span', { class: 'eixo' }, rotulo(i))))));
}

// ------------------------------------------------------------------ formatação
const DIAS = ['domingo', 'segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sábado'];
const MESES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];

export function paraData(v) {
  if (!v) return null;
  if (v instanceof Date) return v;
  const s = String(v);
  const [d, t] = s.split('T');
  const [a, m, dia] = d.split('-').map(Number);
  if (!a) return null;
  const [hh, mm] = (t || '00:00').split(':').map(Number);
  return new Date(a, m - 1, dia, hh || 0, mm || 0);
}

export function dataBR(v) {
  const d = paraData(v);
  return d ? d.toLocaleDateString('pt-BR') : '';
}

export function horaBR(v) {
  const d = paraData(v);
  return d ? d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : '';
}

export function dataHoraBR(v) {
  const d = paraData(v);
  return d ? `${d.toLocaleDateString('pt-BR')} às ${horaBR(v)}` : '';
}

export function dataExtensa(v) {
  const d = paraData(v);
  return d ? `${DIAS[d.getDay()]}, ${d.getDate()} de ${MESES[d.getMonth()]}` : '';
}

export function isoData(d) {
  const z = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
}

export function mesRotulo(aaaamm) {
  const [a, m] = String(aaaamm).split('-').map(Number);
  return `${MESES[(m || 1) - 1]}/${String(a).slice(2)}`;
}

export const sim = (v) => v === true || v === 1 || v === '1' || v === 'true';

export const ROTULOS = {
  agendamento: { SOLICITADO: ['Pedido de horário', 'alerta'], EM_ANALISE: ['Em análise', 'info'], CONFIRMADO: ['Confirmado', 'ok'],
    RECUSADO: ['Recusado', 'perigo'], CANCELADO: ['Cancelado', 'perigo'], AUSENTE: ['Ausência', 'alerta'], REALIZADO: ['Realizado', 'info'] },
  solicitacao: { ENVIADA: ['Enviada', 'alerta'], EM_ANALISE: ['Em análise', 'info'], ACEITA: ['Aceita', 'ok'], RECUSADA: ['Recusada', 'perigo'],
    CANCELADA: ['Cancelada', ''], CONCLUIDA: ['Concluída', 'ok'] },
  pessoa: { EM_ANALISE: ['Em análise', 'info'], AGUARDANDO_VAGA: ['Aguardando vaga', 'alerta'], ATIVA: ['Em acompanhamento', 'ok'],
    CICLO_ENCERRADO: ['Ciclo encerrado', ''], INATIVA: ['Inativa', ''] },
  usuario: { PENDENTE_ATIVACAO: ['Aguardando ativação', 'alerta'], ATIVO: ['Ativo', 'ok'], BLOQUEADO: ['Bloqueado', 'perigo'], INATIVO: ['Inativo', ''] },
  perfil: { ADMINISTRADOR: 'Administrador', PROFISSIONAL: 'Profissional', RESPONSAVEL: 'Responsável / família',
    ADMIN_INSTITUCIONAL: 'Administrador institucional', PESSOA_ACOMPANHADA: 'Pessoa acompanhada' },
  titular: { ABERTA: ['Aberto', 'alerta'], EM_ANALISE: ['Em análise', 'info'], ATENDIDA: ['Atendido', 'ok'], RECUSADA: ['Recusado', 'perigo'] },
  relatorio: { RASCUNHO: ['Rascunho', 'alerta'], FINALIZADO: ['Finalizado', 'info'], LIBERADO_RESPONSAVEL: ['Liberado à família', 'ok'], SUBSTITUIDO: ['Substituído', ''] }
};

export function situacao(grupo, valor) {
  const r = ROTULOS[grupo] && ROTULOS[grupo][valor];
  if (!r) return etiqueta(valor || '—');
  return Array.isArray(r) ? etiqueta(r[0], r[1]) : etiqueta(r);
}
