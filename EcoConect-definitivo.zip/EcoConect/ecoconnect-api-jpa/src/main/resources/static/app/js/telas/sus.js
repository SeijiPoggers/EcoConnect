// Caminhos no SUS: guia em linguagem simples e busca de UBS, CAPS e CER (dados do CNES).
import { api } from '../api.js';
import { h, cabecalho, cartao, vazio, etiqueta, formulario, listaDefinicoes, janela, erroParaTexto, avisar } from '../ui.js';

export async function sus(el, { consulta, app }) {
  const [guia, municipios] = await Promise.all([api('/api/sus/guia'), api('/api/sus/municipios')]);
  el.append(cabecalho('Caminhos no SUS', 'Onde procurar atendimento público e como funciona cada porta de entrada.'));
  el.append(h('p', { class: 'aviso info' }, guia.introducao));
  el.append(h('div', { class: 'grade-2' }, guia.portas.map((p) => cartao(p.nome, listaDefinicoes([['O que é', p.oQueE], ['Quando procurar', p.quandoProcurar], ['Como acessar', p.comoAcessar]])))));
  el.append(cartao('Situações comuns, passo a passo', guia.caminhos.map((c) => h('details', { style: 'margin:.5rem 0' }, h('summary', null, h('strong', null, c.situacao)),
    h('ol', null, c.passos.map((p) => h('li', null, p)))))));
  el.append(cartao('O que levar', h('ul', null, guia.documentos.map((d) => h('li', null, d)))));

  const opcoesMunicipio = municipios.map((m) => [`${m.uf}|${m.municipio}`, `${m.municipio}/${m.uf} (${m.total})`]);
  const form = formulario([
    { nome: 'local', rotulo: 'Município', tipo: 'selecao', opcoes: opcoesMunicipio, vazio: 'Todos' },
    { nome: 'categoria', rotulo: 'Tipo de serviço', tipo: 'selecao', vazio: 'Todos',
      opcoes: [['UBS', 'UBS (posto de saúde)'], ['CAPS_TODOS', 'CAPS (todos)'], ['CAPS_INFANTIL', 'CAPS infantojuvenil'], ['CER', 'Centro Especializado em Reabilitação'], ['POLICLINICA', 'Policlínica']] },
    { nome: 'texto', rotulo: 'Nome ou bairro' }
  ], { local: consulta.local, categoria: consulta.categoria, texto: consulta.texto }, { rotuloEnviar: 'Buscar no SUS', aoEnviar: async (d) => {
    const q = new URLSearchParams();
    for (const [k, v] of Object.entries(d)) if (v) q.set(k, v);
    app.navegar('#/sus?' + q.toString());
  } });
  const resultado = h('div');
  el.append(cartao('Encontrar um serviço do SUS', municipios.length ? form : h('p', { class: 'aviso alerta' },
    'O catálogo de estabelecimentos do SUS está vazio. A administração pode importar o arquivo oficial do CNES em Administração > Integrações.'), resultado));
  if (!municipios.length) return;
  const [uf, municipio] = (consulta.local || '|').split('|');
  try {
    const lista = await api('/api/sus/estabelecimentos', { consulta: { uf, municipio, categoria: consulta.categoria, texto: consulta.texto } });
    resultado.append(h('p', { role: 'status', class: 'suave' }, `${lista.length} estabelecimento(s).`),
      lista.length ? h('ul', { class: 'lista-simples' }, lista.map((e) => h('li', null,
        h('span', null, h('strong', null, e.nome), ' ', e.demonstracao ? etiqueta('Fictício', 'alerta') : null, h('br'),
          h('span', { class: 'pequeno suave' }, `${e.categoriaRotulo} · ${[e.logradouro, e.numero, e.bairro].filter(Boolean).join(', ')} · ${e.municipio}/${e.uf}`)),
        h('button', { type: 'button', class: 'botao secundario pequeno', onClick: () => detalhe(e.codigoCnes) }, 'Ver como acessar')))) : vazio('Nenhum estabelecimento com esses filtros.'));
  } catch (e) { resultado.append(h('div', { class: 'aviso perigo', role: 'alert' }, erroParaTexto(e))); }
}

async function detalhe(cnes) {
  try {
    const e = await api(`/api/sus/estabelecimentos/${cnes}`);
    const o = e.orientacao;
    janela({ titulo: e.nome, conteudo: h('div', null, e.demonstracao ? h('p', { class: 'aviso alerta' }, 'Estabelecimento fictício, para demonstração.') : null,
      listaDefinicoes([['Tipo', e.categoriaRotulo], ['Endereço', [e.logradouro, e.numero, e.bairro].filter(Boolean).join(', ') + ` - ${e.municipio}/${e.uf}`],
        ['Telefone', e.telefone], ['Código CNES', e.codigoCnes], ['O que é', o.oQueE], ['Quando procurar', o.quandoProcurar], ['Como acessar', o.comoAcessar]]),
      h('p', { class: 'suave pequeno', style: 'margin-top:1rem' }, 'Dados do Cadastro Nacional de Estabelecimentos de Saúde (CNES). Confirme horários por telefone.')) });
  } catch (err) { avisar(erroParaTexto(err), 'erro'); }
}
