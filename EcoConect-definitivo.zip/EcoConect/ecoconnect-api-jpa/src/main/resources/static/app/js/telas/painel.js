// Painel inicial: indicadores calculados no servidor conforme o perfil.
import { api } from '../api.js';
import { h, cabecalho, cartao, vazio, dataHoraBR, dataExtensa, horaBR, graficoBarras, mesRotulo, situacao, link, etiqueta } from '../ui.js';

const ACOES = {
  ADMINISTRADOR: [['Cadastrar pessoa', '#/pessoas/nova'], ['Ver agenda', '#/agenda'], ['Usuários', '#/admin/usuarios']],
  PROFISSIONAL: [['Registrar sessão', '#/sessoes/nova'], ['Ver agenda', '#/agenda']],
  RESPONSAVEL: [['Buscar apoio', '#/rede'], ['Pedir horário', '#/agenda']],
  PESSOA_ACOMPANHADA: [['Buscar apoio', '#/rede'], ['Minha agenda', '#/agenda']],
  ADMIN_INSTITUCIONAL: [['Responder solicitações', '#/solicitacoes'], ['Minha instituição', '#/rede/minha']]
};

export async function painel(el, { app }) {
  const p = await api('/api/app/painel');
  const saudacao = new Date().getHours() < 12 ? 'Bom dia' : new Date().getHours() < 18 ? 'Boa tarde' : 'Boa noite';
  el.append(cabecalho(`${saudacao}, ${(p.nome || '').split(' ')[0]}`, 'Veja o que precisa da sua atenção hoje.',
    (ACOES[p.perfil] || []).map(([r, d], i) => link(r, d, 'botao' + (i ? ' secundario' : '')))));

  el.append(h('div', { class: 'grade' }, p.cartoes.map((c) => h('a', { class: 'cartao indicador', href: c.link || '#/painel' },
    h('span', { class: 'valor' }, c.valor ?? 0), h('span', { class: 'rotulo' }, c.rotulo), c.detalhe ? h('span', { class: 'detalhe' }, c.detalhe) : null))));

  const colunas = [];
  if (p.proximasSessoes) {
    colunas.push(cartao('Próximas sessões', p.proximasSessoes.length ? h('ul', { class: 'lista-simples' }, p.proximasSessoes.map((s) =>
      h('li', null, h('span', null, h('strong', null, dataExtensa(s.inicio)), ' às ', horaBR(s.inicio), h('br'), h('a', { href: `#/pessoas/${s.idCrianca}` }, s.pessoa)),
        h('span', { class: 'suave pequeno' }, s.profissionais || '')))) : vazio('Nenhuma sessão confirmada nos próximos dias.', link('Abrir agenda', '#/agenda', 'botao secundario pequeno'))));
  }
  colunas.push(cartao('Avisos não lidos', p.notificacoes && p.notificacoes.length ? h('ul', { class: 'lista-simples' }, p.notificacoes.map((n) =>
    h('li', null, h('span', null, h('strong', null, n.titulo), h('br'), h('span', { class: 'pequeno' }, n.mensagem)), h('span', { class: 'suave pequeno' }, dataHoraBR(n.dataCriacao)))))
    : vazio('Você está em dia com os avisos.'), h('p', null, link('Ver todos os avisos', '#/notificacoes', ''))));
  if (p.relatoriosLiberados) {
    colunas.push(cartao('Relatórios liberados para você', p.relatoriosLiberados.length ? h('ul', { class: 'lista-simples' }, p.relatoriosLiberados.map((r) =>
      h('li', null, h('span', null, h('strong', null, r.titulo), h('br'), h('span', { class: 'suave pequeno' }, r.pessoa)), h('span', { class: 'suave pequeno' }, dataHoraBR(r.data)))))
      : vazio('Quando a equipe liberar um relatório, ele aparece aqui e no acompanhamento.')));
  }
  if (p.sessoesPorMes) {
    colunas.push(cartao('Sessões realizadas nos últimos meses', graficoBarras(p.sessoesPorMes.map((s) => ({ rotulo: mesRotulo(s.mes), valor: Number(s.total) })),
      { descricao: 'Sessões por mês' })));
  }
  if (p.objetivos && p.objetivos.length) {
    const nomes = { EM_ANDAMENTO: 'Em andamento', CICLO_ENCERRADO: 'Concluídos', CANCELADO: 'Cancelados' };
    colunas.push(cartao('Objetivos terapêuticos', h('ul', { class: 'lista-simples' }, p.objetivos.map((o) => h('li', null, nomes[o.situacao] || o.situacao, h('strong', null, o.total))))));
  }
  if (p.atividadesRecentes) {
    colunas.push(cartao(app.perfil('ADMINISTRADOR') ? 'Atividades recentes no sistema' : 'Suas últimas sessões registradas',
      p.atividadesRecentes.length ? h('ul', { class: 'lista-simples pequeno' }, p.atividadesRecentes.map((a) => h('li', null,
        h('span', null, a.pessoa ? `${a.tipo || 'Sessão'} - ${a.pessoa}` : `${rotuloAcao(a.acao)} em ${a.tabela}${a.usuario ? ' por ' + a.usuario : ''}`),
        h('span', { class: 'suave' }, dataHoraBR(a.dataHora))))) : vazio('Nenhuma atividade ainda.')));
  }
  if (p.instituicoes) {
    colunas.push(cartao('Suas instituições', h('ul', { class: 'lista-simples' }, p.instituicoes.map((i) => h('li', null,
      h('a', { href: `#/rede/${i.idInstituicao}` }, i.nome), h('span', { class: 'etiquetas' },
        etiqueta(i.vagas === null || i.vagas === undefined ? 'Vagas não informadas' : `${i.vagas} vaga(s)`, i.vagas === 0 ? 'alerta' : ''),
        i.aceitaSolicitacoes ? etiqueta('Recebendo solicitações', 'ok') : etiqueta('Solicitações pausadas', 'alerta')))))));
  }
  if (p.ultimasSolicitacoes) {
    colunas.push(cartao('Últimas solicitações recebidas', p.ultimasSolicitacoes.length ? h('ul', { class: 'lista-simples' }, p.ultimasSolicitacoes.map((s) =>
      h('li', null, h('a', { href: `#/solicitacoes/${s.idSolicitacao}` }, s.solicitante), situacao('solicitacao', s.situacao)))) : vazio('Nenhuma solicitação ainda.')));
  }
  el.append(h('div', { class: 'grade-2' }, colunas));
}

function rotuloAcao(a) {
  return { CRIACAO: 'Cadastro', ATUALIZACAO: 'Alteração', EXCLUSAO_LOGICA: 'Inativação', VALIDACAO: 'Validação', LIBERACAO: 'Liberação' }[a] || a;
}
