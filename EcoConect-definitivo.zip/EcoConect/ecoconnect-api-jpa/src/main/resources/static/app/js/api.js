// Comunicação com a API do EcoConect (mesma origem, sessão em cookie HttpOnly).
// Toda gravação envia o cabeçalho X-Requested-With, exigido pelo servidor contra CSRF.

export class ErroApi extends Error {
  constructor(status, mensagem, campos) {
    super(mensagem);
    this.status = status;
    this.campos = campos || null;
  }
}

function montarUrl(caminho, consulta) {
  if (!consulta) return caminho;
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(consulta)) {
    if (v === undefined || v === null || v === '') continue;
    p.append(k, v);
  }
  const s = p.toString();
  return s ? caminho + (caminho.includes('?') ? '&' : '?') + s : caminho;
}

export async function api(caminho, { metodo = 'GET', corpo, consulta, formulario } = {}) {
  const headers = { Accept: 'application/json', 'X-Requested-With': 'EcoConect' };
  let body;
  if (formulario) body = formulario;
  else if (corpo !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(corpo); }
  let resposta;
  try {
    resposta = await fetch(montarUrl(caminho, consulta), { method: metodo, headers, body, credentials: 'same-origin' });
  } catch (e) {
    throw new ErroApi(0, 'Não foi possível falar com o servidor. Verifique se o EcoConect está em execução.');
  }
  if (resposta.status === 204) return null;
  const tipo = resposta.headers.get('Content-Type') || '';
  const dados = tipo.includes('json') ? await resposta.json().catch(() => null) : await resposta.text();
  if (!resposta.ok) {
    const mensagem = (dados && dados.mensagem) || (typeof dados === 'string' && dados.length < 300 && dados) || `Erro ${resposta.status}`;
    if (resposta.status === 401 && !caminho.startsWith('/api/auth/login')) {
      window.dispatchEvent(new CustomEvent('ecoconect:sessao-expirada', { detail: mensagem }));
    }
    if (resposta.status === 403 && dados && dados.erro === 'Troca de senha obrigatória') {
      window.dispatchEvent(new CustomEvent('ecoconect:trocar-senha'));
    }
    throw new ErroApi(resposta.status, mensagem, dados && dados.campos);
  }
  return dados;
}

/** Baixa um arquivo (CSV/JSON) gerado pela API, mantendo a sessão. */
export async function baixar(caminho, consulta, nomePadrao = 'arquivo') {
  let resposta;
  try {
    resposta = await fetch(montarUrl(caminho, consulta), {
      headers: { 'X-Requested-With': 'EcoConect' }, credentials: 'same-origin'
    });
  } catch (e) {
    throw new ErroApi(0, 'Não foi possível falar com o servidor.');
  }
  if (!resposta.ok) {
    const dados = await resposta.json().catch(() => null);
    throw new ErroApi(resposta.status, (dados && dados.mensagem) || `Erro ${resposta.status}`);
  }
  const disp = resposta.headers.get('Content-Disposition') || '';
  const m = /filename\*=UTF-8''([^;]+)|filename="?([^";]+)"?/i.exec(disp);
  const nome = m ? decodeURIComponent(m[1] || m[2]) : nomePadrao;
  const blob = await resposta.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = nome;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  return nome;
}
