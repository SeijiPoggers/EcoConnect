// Registro e consulta de sessões terapêuticas (registro estruturado + relatório opcional).
import { api } from '../api.js';
import { h, cabecalho, cartao, formulario, avisar, confirmar, janelaFormulario, situacao, dataHoraBR, vazio, botao, link, listaDefinicoes, erroParaTexto, etiqueta } from '../ui.js';

const TIPOS = ['Equoterapia', 'Psicoterapia', 'Psicoterapia on-line', 'Fonoaudiologia', 'Terapia ocupacional', 'Psicopedagogia',
  'Fisioterapia', 'Avaliação', 'Orientação à família', 'Grupo terapêutico'];

function agoraLocal(minutos = 0) {
  const d = new Date(Date.now() + minutos * 60000);
  d.setSeconds(0, 0);
  const z = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}T${z(d.getHours())}:${z(d.getMinutes())}`;
}

export async function nova(el, { consulta, app }) {
  const [pessoas, atividades] = await Promise.all([api('/api/app/pessoas'), api('/api/atividades', { consulta: { ativo: true, size: 200, sort: 'nome' } })]);
  let agendamento = null;
  if (consulta.agendamento) agendamento = await api(`/api/app/agenda/${consulta.agendamento}`);
  const idPessoa = agendamento ? agendamento.idCrianca : consulta.pessoa ? Number(consulta.pessoa) : null;
  let profissionais = [];
  if (idPessoa) {
    const d = await api(`/api/app/pessoas/${idPessoa}`);
    profissionais = (d.profissionais || []).filter((p) => p.status === 'ATIVO');
  }
  el.append(cabecalho('Registrar sessão', 'Registre o que foi trabalhado. O sistema não gera diagnósticos nem conclusões clínicas.', null,
    [{ texto: 'Pessoas', link: '#/pessoas' }, idPessoa ? { texto: 'Pessoa', link: `#/pessoas/${idPessoa}?aba=acompanhamento` } : null, { texto: 'Nova sessão' }].filter(Boolean)));
  if (agendamento) el.append(h('div', { class: 'aviso info' }, `Sessão do agendamento de ${dataHoraBR(agendamento.inicio || agendamento.inicioSolicitado)} com ${agendamento.pessoa}.`));
  const sugestoes = h('datalist', { id: 'tipos-atendimento' }, TIPOS.map((t) => h('option', { value: t })));
  const campos = [
    { nome: 'idCrianca', rotulo: 'Pessoa acompanhada', tipo: 'selecao', obrigatorio: true, opcoes: pessoas.map((p) => [p.idCrianca, p.nomeCompleto]), desabilitado: !!agendamento, largo: true },
    { nome: 'inicio', rotulo: 'Início', tipo: 'datahora', obrigatorio: true },
    { nome: 'fim', rotulo: 'Fim', tipo: 'datahora' },
    { nome: 'tipoAtendimento', rotulo: 'Tipo de atendimento', obrigatorio: true, max: 80, exemplo: 'Ex.: Equoterapia' },
    { nome: 'idsProfissionais', rotulo: 'Outros profissionais que participaram', tipo: 'multipla', comoLista: true,
      opcoes: profissionais.filter((p) => p.idProfissional !== app.usuario.idProfissional).map((p) => [p.idProfissional, p.nome]),
      ajuda: app.usuario.idProfissional ? 'Você já entra como participante.' : 'Escolha pelo menos um profissional.' },
    { nome: 'atividades', rotulo: 'Atividades realizadas', tipo: 'multipla', comoLista: true, opcoes: atividades.conteudo.map((a) => [a.idAtividade, a.nome]) },
    { nome: 'objetivosTrabalhados', rotulo: 'Objetivos trabalhados', tipo: 'area', largo: true },
    { nome: 'evolucaoObservada', rotulo: 'Evolução observada', tipo: 'area', largo: true },
    { nome: 'dificuldadesObservadas', rotulo: 'Dificuldades observadas', tipo: 'area', largo: true },
    { nome: 'recomendacoes', rotulo: 'Recomendações', tipo: 'area', largo: true },
    { nome: 'proximosPassos', rotulo: 'Próximos passos', tipo: 'area', largo: true },
    { nome: 'observacoesGerais', rotulo: 'Anotações internas da equipe', tipo: 'area', largo: true, ajuda: 'Não aparecem para a família.' },
    { nome: 'relatorioTitulo', rotulo: 'Título do relatório (opcional)', max: 150, largo: true },
    { nome: 'relatorioConteudo', rotulo: 'Relatório para a família (opcional)', tipo: 'area', largo: true, linhas: 5,
      ajuda: 'Escreva em linguagem simples. O relatório só aparece para a família se você marcar a opção abaixo.' },
    { nome: 'liberarParaFamilia', rotulo: 'Liberar o relatório para a família agora', tipo: 'marcacao', largo: true }
  ];
  const valores = { idCrianca: idPessoa || '', inicio: agendamento ? (agendamento.inicio || agendamento.inicioSolicitado) : agoraLocal(-50),
    fim: agendamento ? (agendamento.fim || agendamento.fimSolicitado) : agoraLocal(0) };
  const form = formulario(campos, valores, {
    rotuloEnviar: 'Salvar sessão', cancelar: () => history.back(),
    aoEnviar: async (d) => {
      const corpo = {
        idCrianca: agendamento ? agendamento.idCrianca : Number(d.idCrianca), idAgendamento: agendamento ? agendamento.idAgendamento : null,
        inicio: d.inicio, fim: d.fim, tipoAtendimento: d.tipoAtendimento, idsProfissionais: (d.idsProfissionais || []).map(Number),
        atividades: (d.atividades || []).map((a) => ({ idAtividade: Number(a) })), objetivosTrabalhados: d.objetivosTrabalhados,
        evolucaoObservada: d.evolucaoObservada, dificuldadesObservadas: d.dificuldadesObservadas, recomendacoes: d.recomendacoes,
        proximosPassos: d.proximosPassos, observacoesGerais: d.observacoesGerais,
        relatorio: d.relatorioConteudo ? { titulo: d.relatorioTitulo, conteudo: d.relatorioConteudo, liberarParaFamilia: d.liberarParaFamilia } : null
      };
      const r = await api('/api/app/sessoes', { metodo: 'POST', corpo });
      avisar('Sessão registrada.');
      app.navegar(`#/sessoes/${r.idAtendimento}`);
    }
  });
  form.elements.tipoAtendimento.setAttribute('list', 'tipos-atendimento');
  if (!idPessoa && !agendamento) {
    form.elements.idCrianca.addEventListener('change', () => {
      if (form.elements.idCrianca.value) app.navegar(`#/sessoes/nova?pessoa=${form.elements.idCrianca.value}`);
    });
  }
  el.append(cartao(null, sugestoes, form));
}

export async function detalhe(el, { params, app }) {
  const s = await api(`/api/app/sessoes/${params.id}`);
  el.append(cabecalho(s.tipoAtendimento || 'Sessão', `${s.pessoa} · ${dataHoraBR(s.inicio)}`, app.equipe ? [botao('Editar registro', () => editar(s, app), 'secundario')] : null,
    [{ texto: s.pessoa, link: `#/pessoas/${s.idCrianca}?aba=acompanhamento` }, { texto: 'Sessão' }]));
  el.append(h('div', { class: 'grade-2' },
    cartao('Registro da sessão', listaDefinicoes([['Início', dataHoraBR(s.inicio)], ['Fim', dataHoraBR(s.fim)],
      ['Profissionais', (s.profissionais || []).map((p) => p.nome).join(', ')],
      ['Atividades', (s.atividades || []).map((a) => a.nome + (a.duracaoMinutos ? ` (${a.duracaoMinutos} min)` : '')).join(', ')],
      ['Objetivos trabalhados', texto(s.objetivosTrabalhados)], ['Evolução observada', texto(s.evolucaoObservada)],
      ['Dificuldades observadas', texto(s.dificuldadesObservadas)], ['Recomendações', texto(s.recomendacoes)], ['Próximos passos', texto(s.proximosPassos)],
      s.observacoesGerais !== undefined ? ['Anotações internas', texto(s.observacoesGerais)] : null,
      ['Registrado por', `${s.registradoPor || ''} em ${dataHoraBR(s.dataRegistro)}`],
      s.atualizadoPor ? ['Última alteração', `${s.atualizadoPor} em ${dataHoraBR(s.dataAtualizacao)}`] : null])),
    cartao('Relatórios', (s.relatorios || []).length ? s.relatorios.map((r) => h('article', { style: 'border-top:1px solid var(--superficie-2);padding:.75rem 0' },
      h('div', { class: 'acoes', style: 'justify-content:space-between' }, h('h3', { style: 'margin:0' }, r.titulo), situacao('relatorio', r.situacao)),
      h('p', { class: 'suave pequeno' }, `${r.autor} · versão ${r.versao} · ${dataHoraBR(r.dataElaboracao)}`), h('p', { class: 'pre' }, r.conteudo),
      app.equipe ? acoesRelatorio(r, s, app) : null)) : vazio(app.familia ? 'Nenhum relatório liberado para esta sessão.' : 'Nenhum relatório escrito.'))));
}

const texto = (t) => (t ? h('span', { class: 'pre' }, t) : null);

function acoesRelatorio(r, s, app) {
  const executar = async (pergunta, chamada) => {
    if (!await confirmar(pergunta)) return;
    try { await chamada(); avisar('Relatório atualizado.'); app.navegar(`#/sessoes/${s.idAtendimento}`); }
    catch (e) { avisar(erroParaTexto(e), 'erro'); }
  };
  return h('div', { class: 'acoes' },
    r.situacao === 'RASCUNHO' ? botao('Finalizar', () => executar('Depois de finalizado, o relatório só muda por nova versão. Finalizar?',
      () => api(`/api/relatorios-atendimento/${r.idRelatorio}/finalizacao`, { metodo: 'PATCH', corpo: {} })), 'secundario pequeno') : null,
    r.situacao === 'FINALIZADO' ? botao('Liberar para a família', () => executar('A família poderá ler este relatório. Liberar?',
      () => api(`/api/relatorios-atendimento/${r.idRelatorio}/liberacao`, { metodo: 'PATCH', corpo: {} })), 'secundario pequeno') : null);
}

function editar(s, app) {
  janelaFormulario('Editar registro da sessão', [
    { nome: 'tipoAtendimento', rotulo: 'Tipo de atendimento', obrigatorio: true, max: 80, largo: true },
    { nome: 'objetivosTrabalhados', rotulo: 'Objetivos trabalhados', tipo: 'area', largo: true },
    { nome: 'evolucaoObservada', rotulo: 'Evolução observada', tipo: 'area', largo: true },
    { nome: 'dificuldadesObservadas', rotulo: 'Dificuldades observadas', tipo: 'area', largo: true },
    { nome: 'recomendacoes', rotulo: 'Recomendações', tipo: 'area', largo: true },
    { nome: 'proximosPassos', rotulo: 'Próximos passos', tipo: 'area', largo: true }
  ], s, async (d) => {
    await api(`/api/app/sessoes/${s.idAtendimento}`, { metodo: 'PUT', corpo: d });
    avisar('Registro atualizado. A alteração fica no histórico.');
    app.navegar(`#/sessoes/${s.idAtendimento}`);
  }, { antes: h('p', { class: 'suave' }, 'Toda alteração registra quem alterou e quando.') });
}
