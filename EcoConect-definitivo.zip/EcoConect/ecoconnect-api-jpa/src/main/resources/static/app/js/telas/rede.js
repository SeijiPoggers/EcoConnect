// Rede de apoio: busca de instituições, recomendações explicadas, detalhe, solicitação e gestão institucional.
import { api } from '../api.js';
import { h, cabecalho, cartao, formulario, avisar, confirmar, janelaFormulario, tabela, situacao, dataBR, vazio, botao, link, listaDefinicoes,
  etiqueta, erroParaTexto, sim } from '../ui.js';

function cartaoInstituicao(i, extra) {
  return h('article', { class: 'cartao' },
    h('div', { class: 'acoes', style: 'justify-content:space-between;align-items:flex-start' },
      h('h2', { style: 'margin:0' }, h('a', { href: `#/rede/${i.idInstituicao}` }, i.nome)),
      h('span', { class: 'etiquetas' }, sim(i.verificada) ? etiqueta('Verificada', 'ok') : null, sim(i.demonstracao) ? etiqueta('Fictícia', 'alerta') : null)),
    h('p', { class: 'suave pequeno' }, `${i.tipoRotulo} · ${i.municipio}/${i.uf}${i.bairro ? ' · ' + i.bairro : ''}`),
    i.descricao ? h('p', null, i.descricao) : null,
    h('div', { class: 'etiquetas' },
      sim(i.gratuito) ? etiqueta('Gratuito', 'ok') : null, sim(i.atendePeloSus) ? etiqueta('Atende pelo SUS', 'ok') : null,
      i.idadeMinima !== null || i.idadeMaxima !== null ? etiqueta(`Idade: ${i.idadeMinima ?? 0} a ${i.idadeMaxima ?? '∞'} anos`) : null,
      (i.servicosRotulos || []).map((s) => etiqueta(s, 'info')),
      i.vagas === 0 ? etiqueta('Sem vagas no momento', 'alerta') : i.vagas ? etiqueta(`${i.vagas} vaga(s)`) : null),
    extra || null);
}

export async function busca(el, { consulta, app }) {
  const cat = await app.catalogos();
  el.append(cabecalho('Rede de apoio', 'Instituições públicas, filantrópicas, privadas, ONGs e associações. Use os filtros ou peça recomendações.',
    [link('Recomendações para uma pessoa', '#/rede/recomendacoes', 'botao'), app.perfil('ADMINISTRADOR') ? link('Cadastrar instituição', '#/rede/nova', 'botao secundario') : null].filter(Boolean)));
  const f = { ...consulta };
  const campos = [
    { nome: 'texto', rotulo: 'Nome ou bairro' }, { nome: 'municipio', rotulo: 'Município' }, { nome: 'uf', rotulo: 'UF', max: 2 },
    { nome: 'condicao', rotulo: 'Condição atendida', tipo: 'selecao', opcoes: cat.condicoes, vazio: 'Todas' },
    { nome: 'tipoServico', rotulo: 'Serviço', tipo: 'selecao', opcoes: cat.tiposServico, vazio: 'Todos' },
    { nome: 'tipo', rotulo: 'Tipo de instituição', tipo: 'selecao', opcoes: cat.tiposInstituicao, vazio: 'Todos' },
    { nome: 'idade', rotulo: 'Idade da pessoa', tipo: 'numero', minimo: 0, maximo: 120 },
    { nome: 'modalidade', rotulo: 'Modalidade', tipo: 'selecao', opcoes: cat.modalidades, vazio: 'Todas' },
    { nome: 'acessibilidade', rotulo: 'Acessibilidade', tipo: 'selecao', opcoes: cat.acessibilidade, vazio: 'Qualquer' },
    { nome: 'gratuito', rotulo: 'Somente gratuitos', tipo: 'marcacao' }, { nome: 'sus', rotulo: 'Atende pelo SUS', tipo: 'marcacao' },
    { nome: 'comVagas', rotulo: 'Com vagas', tipo: 'marcacao' }
  ];
  const form = formulario(campos, { ...f, gratuito: f.gratuito === 'true', sus: f.sus === 'true', comVagas: f.comVagas === 'true' }, {
    rotuloEnviar: 'Buscar',
    aoEnviar: async (d) => {
      const q = new URLSearchParams();
      for (const [k, v] of Object.entries(d)) if (v !== null && v !== false && v !== '') q.set(k, v);
      app.navegar('#/rede?' + q.toString());
    }
  });
  el.append(h('details', { class: 'cartao', open: true }, h('summary', null, h('strong', null, 'Filtros')), form));
  const resultados = await api('/api/rede/instituicoes', { consulta });
  el.append(h('p', { role: 'status', class: 'suave', style: 'margin-top:1rem' }, `${resultados.length} instituição(ões) encontrada(s).`),
    resultados.length ? h('div', { class: 'grade-2' }, resultados.map((i) => cartaoInstituicao(i))) : vazio('Nenhuma instituição com esses filtros. Tente tirar algum filtro.'));
}

export async function recomendacoes(el, { consulta, app }) {
  const pessoas = app.perfil('ADMIN_INSTITUCIONAL') ? [] : await api('/api/app/pessoas');
  const escolhida = consulta.pessoa || (pessoas.length === 1 ? String(pessoas[0].idCrianca) : '');
  el.append(cabecalho('Recomendações de instituições', 'Comparamos o perfil de necessidades com os dados de cada instituição e explicamos o motivo de cada sugestão.', null,
    [{ texto: 'Rede de apoio', link: '#/rede' }, { texto: 'Recomendações' }]));
  const seletor = h('select', { id: 'rec-pessoa', onChange: (ev) => app.navegar('#/rede/recomendacoes' + (ev.target.value ? '?pessoa=' + ev.target.value : '')) },
    h('option', { value: '' }, 'Escolha uma pessoa'), pessoas.map((p) => h('option', { value: p.idCrianca, selected: String(p.idCrianca) === escolhida }, p.nomeCompleto)));
  el.append(h('div', { class: 'filtros' }, h('div', { class: 'campo' }, h('label', { for: 'rec-pessoa' }, 'Para quem?'), seletor)));
  if (!escolhida) { el.append(vazio(pessoas.length ? 'Escolha a pessoa para ver as recomendações.' : 'Cadastre uma pessoa e preencha o perfil de necessidades para receber recomendações.')); return; }
  const r = await api('/api/rede/recomendacoes', { consulta: { idCrianca: escolhida } });
  const c = r.criterios;
  el.append(h('div', { class: 'aviso info' }, h('strong', null, 'Como comparamos: '),
    [c.idade !== null ? `${c.idade} anos` : null, c.condicoes.length ? c.condicoes.join(', ') : null, c.local, c.somenteGratuito ? 'somente gratuitos' : null,
      c.modalidade, c.acessibilidade.length ? 'acessibilidade: ' + c.acessibilidade.join(', ') : null].filter(Boolean).join(' · ') || 'sem critérios informados',
    ' ', link('Ajustar o perfil de necessidades', `#/pessoas/${escolhida}?aba=necessidades`, '')));
  el.append(h('p', { class: 'aviso alerta' }, r.aviso));
  el.append(r.recomendacoes.length ? h('div', { class: 'grade-2' }, r.recomendacoes.map((i) => cartaoInstituicao(i, h('div', null,
    h('h3', { style: 'margin-top:.75rem' }, 'Por que foi recomendada'), h('ul', null, i.motivos.map((m) => h('li', null, m))),
    i.atencao.length ? [h('h3', null, 'Pontos de atenção'), h('ul', null, i.atencao.map((m) => h('li', null, m)))] : null,
    h('div', { class: 'acoes' }, link('Ver e solicitar atendimento', `#/rede/${i.idInstituicao}?pessoa=${escolhida}`, 'botao secundario pequeno'))))))
    : vazio('Nenhuma instituição combina com o perfil. Experimente a busca com menos filtros.', link('Buscar instituições', '#/rede', 'botao secundario')));
}

export async function detalhe(el, { params, consulta, app }) {
  const i = await api(`/api/rede/instituicoes/${params.id}`);
  const acoes = [];
  if (i.podeSolicitar && sim(i.aceitaSolicitacoes)) acoes.push(botao('Solicitar atendimento', () => solicitar(i, app, consulta.pessoa)));
  if (i.gestor) acoes.push(link('Painel da instituição', `#/rede/minha?instituicao=${i.idInstituicao}`, 'botao secundario'));
  el.append(cabecalho(i.nome, `${i.tipoRotulo} · ${i.municipio}/${i.uf}`, acoes, [{ texto: 'Rede de apoio', link: '#/rede' }, { texto: i.nome }]));
  if (sim(i.demonstracao)) el.append(h('div', { class: 'aviso alerta' }, 'Instituição fictícia, criada para demonstração do sistema.'));
  if (!sim(i.aceitaSolicitacoes)) el.append(h('div', { class: 'aviso alerta' }, 'Esta instituição não está recebendo solicitações pela plataforma no momento.'));
  el.append(h('div', { class: 'grade-2' },
    cartao('Sobre', i.descricao ? h('p', { class: 'pre' }, i.descricao) : null, listaDefinicoes([
      ['Endereço', [i.logradouro, i.numero, i.bairro].filter(Boolean).join(', ') + ` - ${i.municipio}/${i.uf}${i.cep ? ' - CEP ' + i.cep : ''}`],
      ['Telefone', i.telefone], ['E-mail', i.email], ['Site', i.site ? h('a', { href: i.site, rel: 'noopener noreferrer', target: '_blank' }, i.site) : null],
      ['Faixa etária', i.idadeMinima !== null || i.idadeMaxima !== null ? `${i.idadeMinima ?? 0} a ${i.idadeMaxima ?? 'sem limite'} anos` : 'Não informada'],
      ['Condições atendidas', (i.condicoesRotulos || []).join(', ')], ['Modalidades', (i.modalidadesRotulos || []).join(', ')],
      ['Acessibilidade', (i.acessibilidadeRotulos || []).join(', ')], ['Gratuidade', sim(i.gratuito) ? 'Atendimento gratuito' : 'Consulte valores'],
      ['SUS', sim(i.atendePeloSus) ? 'Atende pelo SUS' : 'Não informado'], ['Vagas', i.vagas === null || i.vagas === undefined ? 'Não informado' : String(i.vagas)],
      ['Código CNES', i.codigoCnes]])),
    cartao('Serviços oferecidos', i.servicos.length ? h('ul', { class: 'lista-simples' }, i.servicos.map((s) => h('li', null,
      h('span', null, h('strong', null, s.nome), h('br'), h('span', { class: 'suave pequeno' }, s.tipoRotulo + (s.descricao ? ' · ' + s.descricao : ''))),
      h('span', { class: 'etiquetas' }, sim(s.gratuito) ? etiqueta('Gratuito', 'ok') : null, sim(s.ativo) ? null : etiqueta('Inativo'))))) : vazio('Nenhum serviço cadastrado.'))));
  if (consulta.solicitar === '1' && i.podeSolicitar) solicitar(i, app, consulta.pessoa);
}

async function solicitar(i, app, pessoaPadrao) {
  let pessoas = [];
  try { pessoas = await api('/api/app/pessoas'); } catch (e) { /* equipe sem pessoas */ }
  janelaFormulario(`Solicitar atendimento - ${i.nome}`, [
    { nome: 'idCrianca', rotulo: 'Para quem é o atendimento', tipo: 'selecao', obrigatorio: app.familia, opcoes: pessoas.map((p) => [p.idCrianca, p.nomeCompleto]), largo: true },
    { nome: 'idServico', rotulo: 'Serviço de interesse', tipo: 'selecao', opcoes: i.servicos.filter((s) => sim(s.ativo)).map((s) => [s.idServico, s.nome]), vazio: 'Não sei / qualquer um' },
    { nome: 'formaContato', rotulo: 'Como prefere ser contatado', tipo: 'selecao', semVazio: true,
      opcoes: [['MENSAGEM_NA_PLATAFORMA', 'Mensagem aqui na plataforma'], ['EMAIL', 'E-mail'], ['TELEFONE', 'Telefone']] },
    { nome: 'mensagem', rotulo: 'Conte o que você procura', tipo: 'area', obrigatorio: true, max: 1000, largo: true,
      ajuda: 'A instituição verá também o perfil de necessidades da pessoa (sem dados de saúde ou das sessões).' }
  ], { idCrianca: pessoaPadrao || (pessoas.length === 1 ? pessoas[0].idCrianca : '') }, async (d) => {
    const r = await api('/api/app/solicitacoes', { metodo: 'POST', corpo: { idInstituicao: i.idInstituicao, idServico: d.idServico ? Number(d.idServico) : null,
      idCrianca: d.idCrianca ? Number(d.idCrianca) : null, mensagem: d.mensagem, formaContato: d.formaContato } });
    avisar(r.mensagemConfirmacao || 'Solicitação enviada.');
    app.navegar(`#/solicitacoes/${r.idSolicitacao}`);
  }, { rotuloEnviar: 'Enviar solicitação' });
}

const CAMPOS_INSTITUICAO = (cat, admin) => [
  { nome: 'nome', rotulo: 'Nome', obrigatorio: true, max: 150, largo: true },
  { nome: 'tipo', rotulo: 'Tipo', tipo: 'selecao', obrigatorio: true, opcoes: cat.tiposInstituicao },
  { nome: 'cnpj', rotulo: 'CNPJ', max: 18 }, { nome: 'codigoCnes', rotulo: 'Código CNES (se tiver)', max: 7 },
  { nome: 'descricao', rotulo: 'Descrição', tipo: 'area', largo: true },
  { nome: 'telefone', rotulo: 'Telefone', tipo: 'telefone' }, { nome: 'email', rotulo: 'E-mail', tipo: 'email' }, { nome: 'site', rotulo: 'Site', exemplo: 'https://' },
  { nome: 'logradouro', rotulo: 'Logradouro' }, { nome: 'numero', rotulo: 'Número' }, { nome: 'bairro', rotulo: 'Bairro' },
  { nome: 'municipio', rotulo: 'Município', obrigatorio: true }, { nome: 'uf', rotulo: 'UF', obrigatorio: true, max: 2 }, { nome: 'cep', rotulo: 'CEP', max: 9 },
  { nome: 'idadeMinima', rotulo: 'Idade mínima', tipo: 'numero', minimo: 0, maximo: 120 }, { nome: 'idadeMaxima', rotulo: 'Idade máxima', tipo: 'numero', minimo: 0, maximo: 120 },
  { nome: 'condicoesAtendidas', rotulo: 'Condições atendidas', tipo: 'multipla', opcoes: cat.condicoes },
  { nome: 'modalidades', rotulo: 'Modalidades', tipo: 'multipla', opcoes: cat.modalidades },
  { nome: 'recursosAcessibilidade', rotulo: 'Recursos de acessibilidade', tipo: 'multipla', opcoes: cat.acessibilidade },
  { nome: 'atendimentoGratuito', rotulo: 'Oferece atendimento gratuito', tipo: 'marcacao' }, { nome: 'atendePeloSus', rotulo: 'Atende pelo SUS', tipo: 'marcacao' },
  { nome: 'vagasDisponiveis', rotulo: 'Vagas disponíveis', tipo: 'numero', minimo: 0 }, { nome: 'aceitaSolicitacoes', rotulo: 'Recebe solicitações pela plataforma', tipo: 'marcacao', padrao: true },
  admin ? { nome: 'verificada', rotulo: 'Dados verificados pela equipe EcoConect', tipo: 'marcacao' } : null
].filter(Boolean);

function normalizarInstituicao(d) {
  for (const k of ['cnpj', 'cep', 'codigoCnes']) if (d[k]) d[k] = d[k].replace(/\D/g, '');
  if (d.uf) d.uf = d.uf.toUpperCase();
  return d;
}

export async function nova(el, { app }) {
  const cat = await app.catalogos();
  el.append(cabecalho('Cadastrar instituição', null, null, [{ texto: 'Rede de apoio', link: '#/rede' }, { texto: 'Nova instituição' }]));
  el.append(cartao(null, formulario(CAMPOS_INSTITUICAO(cat, true), { aceitaSolicitacoes: true }, { rotuloEnviar: 'Cadastrar', cancelar: () => history.back(),
    aoEnviar: async (d) => { const r = await api('/api/rede/instituicoes', { metodo: 'POST', corpo: normalizarInstituicao(d) }); avisar('Instituição cadastrada.'); app.navegar(`#/rede/minha?instituicao=${r.idInstituicao}`); } })));
}

export async function minha(el, { consulta, app }) {
  const cat = await app.catalogos();
  const ids = app.usuario.instituicoes || [];
  const id = consulta.instituicao || ids[0];
  if (!id) { el.append(cabecalho('Minha instituição'), vazio('Sua conta ainda não está vinculada a uma instituição. Fale com a administração do EcoConect.')); return; }
  const p = await api(`/api/rede/instituicoes/${id}/painel`);
  const i = p.instituicao;
  const recarregar = () => app.navegar(`#/rede/minha?instituicao=${id}`);
  el.append(cabecalho(i.nome, 'Painel da instituição: dados, serviços, vagas, solicitações e pessoas vinculadas.',
    [link('Ver página pública', `#/rede/${id}`, 'botao secundario'), link('Responder solicitações', `#/solicitacoes?instituicao=${id}`, 'botao')]));
  const porSituacao = Object.fromEntries((p.solicitacoesPorSituacao || []).map((s) => [s.situacao, s.total]));
  el.append(h('div', { class: 'grade' },
    h('div', { class: 'cartao indicador' }, h('span', { class: 'valor' }, p.pendentes), h('span', { class: 'rotulo' }, 'Solicitações aguardando resposta')),
    h('div', { class: 'cartao indicador' }, h('span', { class: 'valor' }, porSituacao.ACEITA || 0), h('span', { class: 'rotulo' }, 'Solicitações aceitas')),
    h('div', { class: 'cartao indicador' }, h('span', { class: 'valor' }, p.vinculosAtivos), h('span', { class: 'rotulo' }, 'Pessoas vinculadas')),
    h('div', { class: 'cartao indicador' }, h('span', { class: 'valor' }, i.vagas ?? '—'), h('span', { class: 'rotulo' }, 'Vagas informadas'))));
  el.append(h('div', { class: 'grade-2' },
    cartao('Vagas e solicitações', formulario([
      { nome: 'vagasDisponiveis', rotulo: 'Vagas disponíveis agora', tipo: 'numero', minimo: 0 },
      { nome: 'aceitaSolicitacoes', rotulo: 'Receber novas solicitações pela plataforma', tipo: 'marcacao' }
    ], { vagasDisponiveis: i.vagas, aceitaSolicitacoes: sim(i.aceitaSolicitacoes) }, { rotuloEnviar: 'Atualizar vagas', aoEnviar: async (d) => {
      await api(`/api/rede/instituicoes/${id}/vagas`, { metodo: 'PATCH', corpo: d }); avisar('Vagas atualizadas.'); recarregar();
    } })),
    cartao('Serviços', i.servicos.length ? h('ul', { class: 'lista-simples' }, i.servicos.map((s) => h('li', null,
      h('span', null, h('strong', null, s.nome), ' ', sim(s.ativo) ? null : etiqueta('Inativo'), h('br'), h('span', { class: 'pequeno suave' }, s.tipoRotulo)),
      botao('Editar', () => editarServico(id, s, cat, recarregar), 'texto pequeno')))) : vazio('Nenhum serviço cadastrado.'),
    botao('Adicionar serviço', () => editarServico(id, null, cat, recarregar), 'secundario'))));
  el.append(cartao('Pessoas vinculadas', h('p', { class: 'suave pequeno' }, 'A instituição vê apenas os dados informados na solicitação e no perfil de necessidades.'),
    tabela([{ titulo: 'Nome', valor: (v) => v.nome }, { titulo: 'Idade', valor: (v) => `${v.idade} anos` },
      { titulo: 'Condições informadas', valor: (v) => (v.condicoes || '').split(',').filter(Boolean).map((c) => cat.condicoes[c] || c).join(', ') },
      { titulo: 'Comunicação', valor: (v) => cat.comunicacao[v.comunicacaoPreferida] || v.comunicacaoPreferida },
      { titulo: 'Desde', valor: (v) => dataBR(v.dataInicio) }, { titulo: 'Situação', valor: (v) => (v.status === 'ATIVO' ? etiqueta('Ativo', 'ok') : etiqueta('Encerrado')) },
      { titulo: '', valor: (v) => (v.status === 'ATIVO' ? botao('Encerrar', async () => {
        if (!await confirmar(`Encerrar o vínculo de ${v.nome} com a instituição?`, { perigo: true, rotulo: 'Encerrar' })) return;
        try { await api(`/api/rede/instituicoes/${id}/vinculos/${v.idVinculo}`, { metodo: 'DELETE', consulta: { idCrianca: v.idCrianca } }); avisar('Vínculo encerrado.'); recarregar(); }
        catch (e) { avisar(erroParaTexto(e), 'erro'); }
      }, 'texto pequeno') : '') }], p.pessoasVinculadas, { vazioTexto: 'Nenhuma pessoa vinculada ainda.' })));
  const valores = { ...i, condicoesAtendidas: i.condicoes, recursosAcessibilidade: i.acessibilidade, atendimentoGratuito: sim(i.gratuito),
    vagasDisponiveis: i.vagas, atendePeloSus: sim(i.atendePeloSus), aceitaSolicitacoes: sim(i.aceitaSolicitacoes), verificada: sim(i.verificada) };
  el.append(cartao('Dados da instituição', formulario(CAMPOS_INSTITUICAO(cat, app.perfil('ADMINISTRADOR')), valores, { rotuloEnviar: 'Salvar dados', aoEnviar: async (d) => {
    await api(`/api/rede/instituicoes/${id}`, { metodo: 'PUT', corpo: normalizarInstituicao(d) }); avisar('Dados salvos.'); recarregar();
  } })));
  if (app.perfil('ADMINISTRADOR')) {
    el.append(cartao('Membros', tabela([{ titulo: 'Nome', valor: (m) => m.nome }, { titulo: 'E-mail', valor: (m) => m.email },
      { titulo: 'Papel', valor: (m) => (m.papel === 'ADMIN_INSTITUCIONAL' ? 'Administra a instituição' : 'Profissional') },
      { titulo: 'Situação', valor: (m) => (sim(m.ativo) ? etiqueta('Ativo', 'ok') : etiqueta('Inativo')) },
      { titulo: '', valor: (m) => (sim(m.ativo) ? botao('Remover', async () => {
        try { await api(`/api/rede/instituicoes/${id}/membros/${m.idMembro}`, { metodo: 'DELETE' }); avisar('Membro removido.'); recarregar(); } catch (e) { avisar(erroParaTexto(e), 'erro'); }
      }, 'texto pequeno') : '') }], i.membros || []),
    botao('Adicionar membro', () => janelaFormulario('Adicionar membro', [{ nome: 'email', rotulo: 'E-mail da conta', tipo: 'email', obrigatorio: true, largo: true,
      ajuda: 'A conta precisa ter o perfil Administrador institucional ou Profissional.' }], {}, async (d) => {
      await api(`/api/rede/instituicoes/${id}/membros`, { metodo: 'POST', corpo: d }); avisar('Membro adicionado.'); recarregar();
    }), 'secundario')));
  }
}

function editarServico(idInstituicao, s, cat, recarregar) {
  janelaFormulario(s ? 'Editar serviço' : 'Novo serviço', [
    { nome: 'nome', rotulo: 'Nome do serviço', obrigatorio: true, max: 120, largo: true },
    { nome: 'tipoServico', rotulo: 'Tipo', tipo: 'selecao', obrigatorio: true, opcoes: cat.tiposServico },
    { nome: 'descricao', rotulo: 'Descrição', tipo: 'area', max: 500, largo: true },
    { nome: 'gratuito', rotulo: 'Gratuito', tipo: 'marcacao' },
    s ? { nome: 'ativo', rotulo: 'Serviço ativo', tipo: 'marcacao' } : null
  ].filter(Boolean), s ? { ...s, gratuito: sim(s.gratuito), ativo: sim(s.ativo) } : {}, async (d) => {
    if (s) await api(`/api/rede/instituicoes/${idInstituicao}/servicos/${s.idServico}`, { metodo: 'PUT', corpo: d });
    else await api(`/api/rede/instituicoes/${idInstituicao}/servicos`, { metodo: 'POST', corpo: d });
    avisar('Serviço salvo.');
    recarregar();
  });
}
