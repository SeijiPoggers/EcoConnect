// Mensagens assíncronas entre usuários autorizados e instituições.
import { api } from '../api.js';
import { h, cabecalho, cartao, avisar, janelaFormulario, vazio, botao, dataHoraBR, erroParaTexto, formulario, sim } from '../ui.js';

export async function mensagens(el, { params, app }) {
  const conversas = await api('/api/app/conversas');
  el.append(cabecalho('Mensagens', 'Converse por escrito, no seu tempo. Ninguém fora da conversa lê as mensagens.', [botao('Nova conversa', () => nova(app))]));
  const lista = h('nav', { class: 'cartao', 'aria-label': 'Conversas' }, conversas.length ? h('ul', { class: 'lista-conversas' }, conversas.map((c) => h('li', null,
    h('a', { href: `#/mensagens/${c.idConversa}`, 'aria-current': String(params.id) === String(c.idConversa) ? 'true' : null },
      h('strong', null, c.assunto), Number(c.naoLidas) ? h('span', { class: 'contador', style: 'margin-left:.4rem' }, c.naoLidas) : null, h('br'),
      h('span', { class: 'pequeno suave' }, [c.participantes, c.pessoa].filter(Boolean).join(' · ')), h('br'),
      h('span', { class: 'pequeno' }, c.ultimaMensagem || ''), h('br'), h('span', { class: 'pequeno suave' }, dataHoraBR(c.atualizadaEm))))))
    : vazio('Nenhuma conversa ainda.'));
  const painel = h('section', { class: 'cartao', 'aria-live': 'polite' });
  el.append(h('div', { class: 'conversas' }, lista, painel));
  if (!params.id) { painel.append(vazio('Escolha uma conversa à esquerda ou comece uma nova.')); return; }
  const c = await api(`/api/app/conversas/${params.id}`);
  app.atualizarContadores();
  const area = h('div', { class: 'mensagens', tabindex: '0', 'aria-label': 'Mensagens da conversa' }, c.mensagens.map((m) => h('div', { class: 'mensagem' + (sim(m.minha) ? ' minha' : '') },
    h('div', { class: 'pre' }, m.conteudo), h('div', { class: 'meta' }, `${sim(m.minha) ? 'Você' : m.autor} · ${dataHoraBR(m.dataEnvio)}${sim(m.minha) && Number(m.lidaPor) ? ' · lida' : ''}`))));
  painel.append(h('h2', null, c.assunto), h('p', { class: 'suave pequeno' }, 'Participantes: ' + c.participantes.map((p) => p.nome).join(', ')
    + (c.pessoa ? ` · Sobre: ${c.pessoa}` : '') + (c.instituicao ? ` · ${c.instituicao}` : '')), area,
  formulario([{ nome: 'conteudo', rotulo: 'Sua mensagem', tipo: 'area', obrigatorio: true, max: 4000, largo: true, linhas: 3 }], {}, {
    rotuloEnviar: 'Enviar', aoEnviar: async (d) => { await api(`/api/app/conversas/${c.idConversa}/mensagens`, { metodo: 'POST', corpo: d }); avisar('Mensagem enviada.'); app.navegar(`#/mensagens/${c.idConversa}`); }
  }));
  area.scrollTop = area.scrollHeight;
}

async function nova(app) {
  let contatos;
  try { contatos = await api('/api/app/contatos'); } catch (e) { avisar(erroParaTexto(e), 'erro'); return; }
  let pessoas = [];
  if (!app.perfil('ADMIN_INSTITUCIONAL')) { try { pessoas = await api('/api/app/pessoas'); } catch (e) { /* opcional */ } }
  const perfis = { ADMINISTRADOR: 'administração', PROFISSIONAL: 'profissional', RESPONSAVEL: 'família', ADMIN_INSTITUCIONAL: 'instituição', PESSOA_ACOMPANHADA: 'pessoa acompanhada' };
  janelaFormulario('Nova conversa', [
    { nome: 'idsUsuarios', rotulo: 'Para quem', tipo: 'multipla', comoLista: true, opcoes: contatos.map((c) => [c.idUsuario, `${c.nome} (${perfis[c.perfil] || c.perfil})`]) },
    { nome: 'assunto', rotulo: 'Assunto', obrigatorio: true, max: 150, largo: true },
    pessoas.length ? { nome: 'idCrianca', rotulo: 'Sobre qual pessoa (opcional)', tipo: 'selecao', opcoes: pessoas.map((p) => [p.idCrianca, p.nomeCompleto]), vazio: 'Nenhuma em especial' } : null,
    { nome: 'mensagem', rotulo: 'Mensagem', tipo: 'area', obrigatorio: true, max: 4000, largo: true }
  ].filter(Boolean), {}, async (d) => {
    if (!d.idsUsuarios || !d.idsUsuarios.length) throw new Error('Escolha pelo menos uma pessoa para conversar.');
    const r = await api('/api/app/conversas', { metodo: 'POST', corpo: { assunto: d.assunto, idsUsuarios: d.idsUsuarios.map(Number),
      idCrianca: d.idCrianca ? Number(d.idCrianca) : null, mensagem: d.mensagem } });
    avisar('Conversa iniciada.');
    app.navegar(`#/mensagens/${r.idConversa}`);
  }, { rotuloEnviar: 'Enviar', antes: contatos.length ? null : h('p', { class: 'aviso alerta' }, 'Ainda não há contatos disponíveis para você.') });
}
