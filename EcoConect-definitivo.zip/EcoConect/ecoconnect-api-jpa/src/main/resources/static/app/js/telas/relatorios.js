// Relatórios exportados em CSV (abrem no Excel ou LibreOffice).
import { api, baixar } from '../api.js';
import { h, cabecalho, cartao, formulario, avisar, isoData } from '../ui.js';

export async function relatorios(el) {
  const tipos = await api('/api/relatorios');
  let pessoas = [];
  try { pessoas = await api('/api/app/pessoas'); } catch (e) { /* perfis sem pessoas */ }
  const hoje = new Date();
  const tresMeses = new Date(hoje.getFullYear(), hoje.getMonth() - 3, hoje.getDate());
  el.append(cabecalho('Relatórios', 'Gerados na hora a partir dos dados gravados, dentro do que o seu perfil pode ver. Cada exportação fica registrada na auditoria.'));
  el.append(h('div', { class: 'grade-2' }, tipos.map((t) => {
    const campos = [];
    if (t.usaPeriodo) campos.push({ nome: 'de', rotulo: 'De', tipo: 'data', obrigatorio: true }, { nome: 'ate', rotulo: 'Até', tipo: 'data', obrigatorio: true });
    if (t.codigo === 'historico-pessoa' || t.codigo === 'sessoes' || t.codigo === 'agendamentos') {
      campos.push({ nome: 'idCrianca', rotulo: 'Pessoa', tipo: 'selecao', obrigatorio: t.codigo === 'historico-pessoa', opcoes: pessoas.map((p) => [p.idCrianca, p.nomeCompleto]), vazio: 'Todas' });
    }
    return cartao(t.nome, h('p', { class: 'suave' }, t.descricao), formulario(campos, { de: isoData(tresMeses), ate: isoData(hoje) }, {
      rotuloEnviar: 'Baixar CSV', aoEnviar: async (d) => { const nome = await baixar(`/api/relatorios/${t.codigo}`, d, `${t.codigo}.csv`); avisar(`Arquivo ${nome} gerado.`); } }));
  })));
}
