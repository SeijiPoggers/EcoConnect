// Agenda: visão semanal, pedidos de horário, confirmação, remarcação, cancelamento e registro.
import { api } from '../api.js';
import { h, cabecalho, cartao, avisar, janela, janelaFormulario, situacao, dataHoraBR, dataExtensa, horaBR, vazio, botao, link, listaDefinicoes,
  erroParaTexto, isoData, paraData } from '../ui.js';

function inicioDaSemana(d) {
  const r = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const dia = (r.getDay() + 6) % 7;
  r.setDate(r.getDate() - dia);
  return r;
}

export async function agenda(el, { consulta, app }) {
  const base = consulta.semana ? paraData(consulta.semana) : inicioDaSemana(new Date());
  const fim = new Date(base); fim.setDate(fim.getDate() + 13);
  const meus = consulta.meus === '1';
  const pessoa = consulta.pessoa || '';
  const pessoas = await api('/api/app/pessoas');
  const itens = await api('/api/app/agenda', { consulta: { inicio: isoData(base), fim: isoData(fim), meus: meus || undefined, idCrianca: pessoa || undefined } });
  const irPara = (mudanca) => {
    const q = new URLSearchParams({ semana: isoData(mudanca.semana || base) });
    const m = mudanca.meus !== undefined ? mudanca.meus : meus;
    const p = mudanca.pessoa !== undefined ? mudanca.pessoa : pessoa;
    if (m) q.set('meus', '1');
    if (p) q.set('pessoa', p);
    app.navegar('#/agenda?' + q.toString());
  };
  const anterior = new Date(base); anterior.setDate(anterior.getDate() - 14);
  const proxima = new Date(base); proxima.setDate(proxima.getDate() + 14);
  el.append(cabecalho('Agenda', `De ${base.toLocaleDateString('pt-BR')} a ${fim.toLocaleDateString('pt-BR')}`,
    [botao(app.familia ? 'Pedir horário' : 'Novo agendamento', () => novo(app, pessoas, pessoa), '')]));
  const filtroPessoa = h('select', { id: 'filtro-pessoa', onChange: (ev) => irPara({ pessoa: ev.target.value }) },
    h('option', { value: '' }, 'Todas'), pessoas.map((p) => h('option', { value: p.idCrianca, selected: String(p.idCrianca) === pessoa }, p.nomeCompleto)));
  el.append(h('div', { class: 'filtros' },
    h('div', { class: 'acoes' }, botao('Semanas anteriores', () => irPara({ semana: anterior }), 'secundario pequeno'),
      botao('Hoje', () => irPara({ semana: inicioDaSemana(new Date()) }), 'secundario pequeno'),
      botao('Próximas semanas', () => irPara({ semana: proxima }), 'secundario pequeno')),
    h('div', { class: 'campo' }, h('label', { for: 'filtro-pessoa' }, 'Pessoa'), filtroPessoa),
    app.usuario.idProfissional ? h('label', { class: 'marcacao' }, h('input', { type: 'checkbox', checked: meus, onChange: (ev) => irPara({ meus: ev.target.checked }) }), 'Somente os meus atendimentos') : null));

  const porDia = new Map();
  for (const i of itens) {
    const dia = String(i.inicio).slice(0, 10);
    if (!porDia.has(dia)) porDia.set(dia, []);
    porDia.get(dia).push(i);
  }
  const dias = [];
  for (let d = new Date(base); d <= fim; d.setDate(d.getDate() + 1)) dias.push(isoData(d));
  const hoje = isoData(new Date());
  el.append(h('div', { class: 'grade', style: 'grid-template-columns:repeat(auto-fill,minmax(260px,1fr))' }, dias.map((dia) => {
    const lista = porDia.get(dia) || [];
    return h('section', { class: 'cartao', 'aria-label': dataExtensa(dia), style: dia === hoje ? 'border-color:var(--primaria);border-width:2px' : '' },
      h('h2', { style: 'font-size:1rem' }, dataExtensa(dia), dia === hoje ? ' (hoje)' : ''),
      lista.length ? h('ul', { class: 'lista-simples' }, lista.map((i) => h('li', null,
        h('button', { type: 'button', class: 'botao texto', style: 'text-align:left;padding:0;min-height:0', onClick: () => detalhe(i.idAgendamento, app) },
          `${horaBR(i.inicio)} · ${i.pessoa}`),
        situacao('agendamento', i.status)))) : h('p', { class: 'suave pequeno' }, 'Sem atendimentos.'));
  })));
  if (consulta.novo === '1') novo(app, pessoas, pessoa);
}

function novo(app, pessoas, pessoaPadrao) {
  const familia = app.familia;
  const campos = [
    { nome: 'idCrianca', rotulo: 'Pessoa', tipo: 'selecao', obrigatorio: true, opcoes: pessoas.map((p) => [p.idCrianca, p.nomeCompleto]), largo: true },
    { nome: 'inicio', rotulo: familia ? 'Horário desejado' : 'Início', tipo: 'datahora', obrigatorio: true },
    { nome: 'fim', rotulo: 'Fim (opcional)', tipo: 'datahora', ajuda: 'Se vazio, consideramos 50 minutos.' },
    { nome: 'observacao', rotulo: familia ? 'Observação para a equipe' : 'Observação', tipo: 'area', max: 500, largo: true }
  ];
  janelaFormulario(familia ? 'Pedir horário' : 'Novo agendamento', campos, { idCrianca: pessoaPadrao || (pessoas.length === 1 ? pessoas[0].idCrianca : '') }, async (d) => {
    const corpo = { idCrianca: Number(d.idCrianca), inicio: d.inicio, fim: d.fim, observacao: d.observacao, confirmar: !familia };
    const r = await api('/api/app/agenda', { metodo: 'POST', corpo });
    avisar(familia ? 'Pedido enviado. A equipe vai confirmar o horário.' : 'Agendamento confirmado.');
    app.navegar(`#/agenda?semana=${isoData(inicioDaSemana(paraData(r.inicio || r.inicioSolicitado)))}`);
  }, { rotuloEnviar: familia ? 'Enviar pedido' : 'Agendar',
    antes: familia ? h('p', { class: 'suave' }, 'O pedido fica como "Pedido de horário" até a equipe confirmar.') : h('p', { class: 'suave' }, 'O sistema avisa se a pessoa ou o profissional já tiver outro atendimento no mesmo horário.') });
}

async function detalhe(id, app) {
  let a;
  try { a = await api(`/api/app/agenda/${id}`); } catch (e) { avisar(erroParaTexto(e), 'erro'); return; }
  const recarregar = () => app.navegar(location.hash || '#/agenda');
  const executar = async (acao, extra = {}) => {
    await api(`/api/app/agenda/${id}/acao`, { metodo: 'POST', corpo: { acao, ...extra } });
    avisar('Agenda atualizada.');
    recarregar();
  };
  const comMotivo = (acao, titulo, obrigatorio = true) => janelaFormulario(titulo, [{ nome: 'motivo', rotulo: 'Motivo', tipo: 'area', max: 500, obrigatorio, largo: true }], {},
    (d) => executar(acao, { motivo: d.motivo }), { rotuloEnviar: titulo });
  const comHorario = (acao, titulo) => janelaFormulario(titulo, [
    { nome: 'inicio', rotulo: 'Início', tipo: 'datahora', obrigatorio: true }, { nome: 'fim', rotulo: 'Fim', tipo: 'datahora' },
    { nome: 'motivo', rotulo: 'Observação', tipo: 'area', max: 500, largo: true }],
  { inicio: a.inicio || a.inicioSolicitado, fim: a.fim || a.fimSolicitado }, (d) => executar(acao, d), { rotuloEnviar: titulo });
  const equipe = app.equipe;
  const passou = paraData(a.inicio || a.inicioSolicitado) < new Date();
  const acoes = [];
  if (equipe && ['SOLICITADO', 'EM_ANALISE'].includes(a.status)) {
    acoes.push(['Confirmar horário', () => comHorario('CONFIRMAR', 'Confirmar horário'), '']);
    if (a.status === 'SOLICITADO') acoes.push(['Colocar em análise', () => executar('EM_ANALISE'), 'secundario']);
    acoes.push(['Recusar', () => comMotivo('RECUSAR', 'Recusar pedido'), 'secundario perigo']);
  }
  if (equipe && a.status === 'CONFIRMADO') {
    if (passou) acoes.push(['Registrar sessão', () => app.navegar(`#/sessoes/nova?agendamento=${id}`), '']);
    acoes.push(['Remarcar', () => comHorario('REAGENDAR', 'Remarcar'), 'secundario']);
    if (passou) acoes.push(['Registrar ausência', () => comMotivo('AUSENTE', 'Registrar ausência', false), 'secundario']);
  }
  if (['SOLICITADO', 'EM_ANALISE', 'CONFIRMADO'].includes(a.status)) acoes.push(['Cancelar atendimento', () => comMotivo('CANCELAR', 'Cancelar atendimento'), 'secundario perigo']);
  const conteudo = h('div', null,
    listaDefinicoes([['Pessoa', h('a', { href: `#/pessoas/${a.idCrianca}` }, a.pessoa)], ['Situação', situacao('agendamento', a.status)],
      ['Horário', a.inicio ? `${dataHoraBR(a.inicio)}${a.fim ? ' até ' + horaBR(a.fim) : ''}` : `Pedido para ${dataHoraBR(a.inicioSolicitado)}`],
      ['Profissionais', (a.profissionais || []).map((p) => p.nome).join(', ')], ['Pedido por', `${a.solicitante} em ${dataHoraBR(a.dataSolicitacao)}`],
      ['Observação', a.observacao], a.confirmadoPor ? ['Confirmado por', a.confirmadoPor] : null,
      a.idAtendimento ? ['Sessão', link('Ver registro da sessão', `#/sessoes/${a.idAtendimento}`, '')] : null]),
    (a.historico || []).length ? h('details', { style: 'margin-top:1rem' }, h('summary', null, 'Histórico deste agendamento'),
      h('ul', { class: 'lista-simples pequeno' }, a.historico.map((x) => h('li', null, h('span', null, `${x.statusAnterior ? x.statusAnterior + ' → ' : ''}${x.statusNovo}${x.motivo ? ' · ' + x.motivo : ''}`),
        h('span', { class: 'suave' }, `${x.usuario} · ${dataHoraBR(x.dataHora)}`))))) : null);
  janela({ titulo: 'Atendimento', conteudo, acoes: acoes.map(([rotulo, fn, classe]) => ({ rotulo, classe, aoClicar: async () => { try { await fn(); } catch (e) { avisar(erroParaTexto(e), 'erro'); return false; } } })) });
}
