// Minha conta: dados, senha, acessibilidade, privacidade (LGPD) e notificações.
import { api, baixar } from '../api.js';
import { h, cabecalho, cartao, formulario, avisar, confirmar, janelaFormulario, tabela, situacao, dataHoraBR, vazio, botao, abas, listaDefinicoes, erroParaTexto } from '../ui.js';
import { aplicarPreferencias, app } from '../main.js';

export async function conta(el, { consulta }) {
  const ativa = consulta.aba || 'acessibilidade';
  el.append(cabecalho('Minha conta', 'Acessibilidade, senha e privacidade dos seus dados.'));
  const corpo = h('div');
  el.append(abas([{ chave: 'acessibilidade', rotulo: 'Acessibilidade' }, { chave: 'senha', rotulo: 'Senha' },
    { chave: 'privacidade', rotulo: 'Privacidade e dados' }], ativa, (c) => app.navegar(`#/conta?aba=${c}`)), corpo);
  if (ativa === 'senha') return senha(corpo);
  if (ativa === 'privacidade') return privacidade(corpo);
  return acessibilidade(corpo);
}

async function acessibilidade(el) {
  const p = await api('/api/app/preferencias');
  const opcoes = [
    ['baixoEstimulo', 'Modo de baixo estímulo', 'Cores mais neutras, sem sombras e sem animações. Avisos ficam mais tempo na tela.'],
    ['altoContraste', 'Alto contraste', 'Texto preto sobre fundo branco e bordas fortes.'],
    ['espacamentoLeitura', 'Leitura facilitada', 'Mais espaço entre letras, palavras e linhas (ajuda na dislexia).'],
    ['reduzirMovimento', 'Reduzir movimento', 'Desliga transições e efeitos de movimento.']
  ];
  const salvar = async (mudanca) => {
    Object.assign(p, mudanca);
    aplicarPreferencias(p);
    try {
      const salvo = await api('/api/app/preferencias', { metodo: 'PUT', corpo: p });
      if (app.usuario) app.usuario.preferencias = salvo;
      avisar('Preferência salva na sua conta.');
    } catch (e) { avisar(erroParaTexto(e), 'erro'); }
  };
  el.append(cartao('Como você prefere ver o EcoConect', h('p', { class: 'suave' }, 'As escolhas ficam guardadas na sua conta e valem em qualquer computador.'),
    opcoes.map(([chave, titulo, texto]) => {
      const id = 'pref-' + chave;
      return h('div', { class: 'interruptor' }, h('label', { for: id }, h('strong', null, titulo), h('span', { class: 'suave pequeno' }, texto)),
        h('input', { type: 'checkbox', id, role: 'switch', checked: !!p[chave], onChange: (ev) => salvar({ [chave]: ev.target.checked }) }));
    }),
    h('div', { class: 'interruptor' }, h('label', { for: 'pref-fonte' }, h('strong', null, 'Tamanho do texto')),
      h('select', { id: 'pref-fonte', style: 'max-width:220px', onChange: (ev) => salvar({ tamanhoFonte: ev.target.value }) },
        [['PADRAO', 'Padrão'], ['GRANDE', 'Grande'], ['MUITO_GRANDE', 'Muito grande']].map(([v, r]) => h('option', { value: v, selected: p.tamanhoFonte === v }, r))))));
}

function senha(el) {
  const campos = [
    { nome: 'senhaAtual', rotulo: 'Senha atual', tipo: 'senha', obrigatorio: true, autocomplete: 'current-password' },
    { nome: 'novaSenha', rotulo: 'Nova senha', tipo: 'senha', obrigatorio: true, autocomplete: 'new-password', ajuda: 'Pelo menos 8 caracteres, com letras e números.' },
    { nome: 'confirmacao', rotulo: 'Repita a nova senha', tipo: 'senha', obrigatorio: true, autocomplete: 'new-password' }
  ];
  const form = formulario(campos, {}, { rotuloEnviar: 'Trocar senha', aoEnviar: async (d) => {
    if (d.novaSenha !== d.confirmacao) throw new Error('As duas senhas novas não são iguais.');
    const r = await api('/api/auth/senha', { metodo: 'POST', corpo: { senhaAtual: d.senhaAtual, novaSenha: d.novaSenha } });
    avisar(r.mensagem || 'Senha alterada.');
    form.reset();
  } });
  el.append(cartao('Trocar senha', h('p', { class: 'suave' }, 'Ao trocar a senha, as outras sessões abertas são encerradas.'), form));
}

async function privacidade(el) {
  const r = await api('/api/app/privacidade');
  el.append(cartao('Seus dados',
    listaDefinicoes([['Nome', r.conta.nome], ['E-mail', r.conta.email], ['Telefone', r.conta.telefone], ['Perfil', r.conta.perfil],
      ['Conta criada em', dataHoraBR(r.conta.dataCadastro)], ['Último acesso', dataHoraBR(r.conta.ultimoAcesso)]]),
    h('div', { class: 'acoes', style: 'margin-top:1rem' },
      botao('Baixar meus dados (JSON)', async () => {
        try { await baixar('/api/app/privacidade/exportacao', null, 'meus-dados-ecoconect.json'); avisar('Arquivo gerado.'); } catch (e) { avisar(erroParaTexto(e), 'erro'); }
      }),
      botao('Fazer um pedido sobre meus dados', () => novoPedido(), 'secundario'))));
  el.append(cartao('Como cuidamos dos seus dados', h('ul', null, r.informacoes.map((i) => h('li', null, i)))));
  if (r.consentimentos.length) {
    el.append(cartao('Consentimentos que você registrou', tabela([
      { titulo: 'Pessoa', valor: (c) => c.pessoa }, { titulo: 'Finalidade', valor: (c) => c.finalidade },
      { titulo: 'Situação', valor: (c) => c.situacao === 'REGISTRADA' ? 'Ativo' : c.situacao === 'REVOGADA' ? 'Revogado' : c.situacao },
      { titulo: 'Desde', valor: (c) => dataHoraBR(c.dataAutorizacao) },
      { titulo: 'Ação', valor: (c) => c.situacao === 'REGISTRADA' ? botao('Revogar', async () => {
        if (!await confirmar('Ao revogar, a equipe será avisada e avaliará se o acompanhamento pode continuar por outra base legal. Deseja revogar?', { perigo: true, rotulo: 'Revogar' })) return;
        try { await api(`/api/app/privacidade/consentimentos/${c.idConsentimento}/revogacao`, { metodo: 'POST' }); avisar('Consentimento revogado.'); app.navegar('#/conta?aba=privacidade'); }
        catch (e) { avisar(erroParaTexto(e), 'erro'); }
      }, 'secundario pequeno perigo') : '' }])));
  }
  el.append(cartao('Seus pedidos', r.pedidos.length ? tabela([
    { titulo: 'Tipo', valor: (p) => TIPOS[p.tipo] || p.tipo }, { titulo: 'Situação', valor: (p) => situacao('titular', p.situacao) },
    { titulo: 'Aberto em', valor: (p) => dataHoraBR(p.dataCriacao) }, { titulo: 'Resposta', valor: (p) => p.resposta }], r.pedidos)
    : vazio('Você ainda não fez pedidos.')));
}

const TIPOS = { ACESSO: 'Acesso aos dados', CORRECAO: 'Correção de dados', EXCLUSAO: 'Exclusão / anonimização', PORTABILIDADE: 'Portabilidade',
  REVOGACAO_CONSENTIMENTO: 'Revogação de consentimento', OUTRA: 'Outro pedido' };

function novoPedido() {
  janelaFormulario('Pedido sobre meus dados', [
    { nome: 'tipo', rotulo: 'O que você precisa?', tipo: 'selecao', obrigatorio: true, opcoes: TIPOS, largo: true },
    { nome: 'detalhe', rotulo: 'Detalhes (opcional)', tipo: 'area', max: 1000, largo: true }
  ], {}, async (d) => {
    await api('/api/app/privacidade/pedidos', { metodo: 'POST', corpo: d });
    avisar('Pedido registrado. A administração responderá por aqui.');
    app.navegar('#/conta?aba=privacidade');
  }, { rotuloEnviar: 'Enviar pedido', antes: h('p', { class: 'suave' }, 'Pedidos de exclusão anonimizam a conta; o histórico de saúde é guardado pelo dever legal de guarda.') });
}

export async function notificacoes(el) {
  const carregar = async () => {
    const r = await api('/api/app/notificacoes');
    el.replaceChildren(cabecalho('Avisos', r.naoLidas ? `${r.naoLidas} aviso(s) não lido(s).` : 'Nenhum aviso pendente.',
      r.naoLidas ? [botao('Marcar todos como lidos', async () => { await api('/api/app/notificacoes/leitura', { metodo: 'POST' }); app.atualizarContadores(); carregar(); }, 'secundario')] : null),
      r.itens.length ? h('ul', { class: 'lista-simples cartao' }, r.itens.map((n) => h('li', null,
        h('div', null, h('strong', null, n.titulo), n.dataLeitura ? null : h('span', { class: 'etiqueta alerta', style: 'margin-left:.5rem' }, 'novo'),
          h('p', { style: 'margin:.2rem 0 0' }, n.mensagem), h('span', { class: 'suave pequeno' }, dataHoraBR(n.dataCriacao))),
        n.dataLeitura ? null : botao('Marcar como lido', async () => { await api(`/api/app/notificacoes/${n.idNotificacao}/leitura`, { metodo: 'PATCH' }); app.atualizarContadores(); carregar(); }, 'texto pequeno'))))
        : h('div', { class: 'cartao' }, vazio('Você ainda não recebeu avisos.')));
  };
  await carregar();
}
