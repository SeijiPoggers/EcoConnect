// Entrada: login, cadastro público de famílias e troca obrigatória de senha.
import { api } from '../api.js';
import { h, formulario, avisar, link } from '../ui.js';
import { entrar, app, sair } from '../main.js';

const CONTAS_DEMO = [
  ['ana.ribeiro@demo.ecoconect.local', 'Profissional (psicóloga)'],
  ['mariana.alves@demo.ecoconect.local', 'Responsável (mãe do Theo)'],
  ['lucas.martins@demo.ecoconect.local', 'Pessoa acompanhada (adulto com TDAH e dislexia)'],
  ['roberta.lima@demo.ecoconect.local', 'Administradora de instituição'],
  ['carlos.souza@demo.ecoconect.local', 'Profissional (fonoaudiólogo)']
];

function moldura(conteudo) {
  return h('div', { class: 'entrada' },
    h('section', { class: 'apresentacao' },
      h('p', { class: 'decorativo', style: 'font-weight:700;letter-spacing:.08em;text-transform:uppercase;margin:0' }, 'EcoConect'),
      h('h1', null, 'Cuidado organizado, rede de apoio por perto.'),
      h('p', null, 'Acompanhamento terapêutico e conexão com instituições e com o SUS para pessoas neurodivergentes, famílias e profissionais.'),
      h('ul', null, h('li', null, 'Histórico de sessões e evolução em um só lugar.'), h('li', null, 'Busca de instituições com explicação de cada recomendação.'),
        h('li', null, 'Contato por mensagem escrita, sem precisar ligar.'), h('li', null, 'Modo de baixo estímulo, letras maiores e alto contraste.')),
      h('p', { class: 'pequeno' }, h('a', { href: '/' }, 'Conheça o projeto'))),
    h('div', { class: 'painel-form' }, conteudo));
}

export async function login(el) {
  const campos = [
    { nome: 'email', rotulo: 'E-mail', tipo: 'email', obrigatorio: true, autocomplete: 'username', largo: true },
    { nome: 'senha', rotulo: 'Senha', tipo: 'senha', obrigatorio: true, autocomplete: 'current-password', largo: true }
  ];
  const form = formulario(campos, {}, {
    rotuloEnviar: 'Entrar',
    aoEnviar: async (dados) => {
      const usuario = await api('/api/auth/login', { metodo: 'POST', corpo: dados });
      await entrar(usuario);
    }
  });
  const demo = app.demonstracao ? h('section', { class: 'cartao', 'aria-labelledby': 'titulo-demo' },
    h('h2', { id: 'titulo-demo' }, 'Contas de demonstração (fictícias)'),
    h('p', { class: 'pequeno' }, 'Senha de todas: ', h('strong', null, 'EcoDemo2026'), '. O administrador usa o e-mail e a senha definidos na instalação.'),
    h('ul', { class: 'lista-simples pequeno' }, CONTAS_DEMO.map(([email, papel]) => h('li', null,
      h('button', { type: 'button', class: 'botao texto pequeno', onClick: () => {
        form.elements.email.value = email; form.elements.senha.value = 'EcoDemo2026'; form.elements.senha.focus();
      } }, email), h('span', { class: 'suave' }, papel))))) : null;
  el.append(moldura([h('section', { class: 'cartao' }, h('h2', null, 'Entrar no EcoConect'), form,
    h('p', { class: 'pequeno', style: 'margin-top:1rem' }, 'É de uma família e ainda não tem conta? ', link('Criar conta', '#/cadastro', ''))), demo]));
}

export async function cadastro(el) {
  const campos = [
    { nome: 'perfil', rotulo: 'Quem vai usar a conta', tipo: 'selecao', obrigatorio: true, semVazio: true, largo: true,
      opcoes: [['RESPONSAVEL', 'Sou familiar ou responsável'], ['PESSOA_ACOMPANHADA', 'Sou a pessoa acompanhada (maior de idade)']] },
    { nome: 'nomeCompleto', rotulo: 'Nome completo', obrigatorio: true, max: 150, autocomplete: 'name', largo: true },
    { nome: 'email', rotulo: 'E-mail', tipo: 'email', obrigatorio: true, autocomplete: 'email' },
    { nome: 'telefone', rotulo: 'Telefone (opcional)', tipo: 'telefone', autocomplete: 'tel' },
    { nome: 'senha', rotulo: 'Senha', tipo: 'senha', obrigatorio: true, autocomplete: 'new-password', ajuda: 'Pelo menos 8 caracteres, com letras e números.' },
    { nome: 'aceiteTermos', rotulo: 'Li e aceito o termo de uso e a política de privacidade (LGPD).', tipo: 'marcacao', largo: true,
      ajuda: 'Seus dados são usados só para o acompanhamento e a conexão com a rede de apoio. Você pode pedir a exportação ou a exclusão a qualquer momento.' }
  ];
  const resultado = h('div', { role: 'status' });
  const form = formulario(campos, { perfil: 'RESPONSAVEL' }, {
    rotuloEnviar: 'Criar conta',
    aoEnviar: async (dados) => {
      const r = await api('/api/auth/cadastro', { metodo: 'POST', corpo: dados });
      form.replaceWith(h('div', { class: 'aviso ok' }, r.mensagem));
      resultado.append(link('Voltar para a entrada', '#/entrar'));
    }
  });
  el.append(moldura(h('section', { class: 'cartao' }, h('h2', null, 'Criar conta'),
    h('p', { class: 'pequeno suave' }, 'Profissionais e instituições recebem o acesso da administração do EcoConect.'), form, resultado,
    h('p', { class: 'pequeno', style: 'margin-top:1rem' }, link('Já tenho conta', '#/entrar', '')))));
}

export async function trocarSenha(el) {
  const campos = [
    { nome: 'senhaAtual', rotulo: 'Senha atual (ou temporária)', tipo: 'senha', obrigatorio: true, autocomplete: 'current-password', largo: true },
    { nome: 'novaSenha', rotulo: 'Nova senha', tipo: 'senha', obrigatorio: true, autocomplete: 'new-password', largo: true,
      ajuda: 'Pelo menos 8 caracteres, com letras e números. Não use a mesma senha de outros sites.' },
    { nome: 'confirmacao', rotulo: 'Repita a nova senha', tipo: 'senha', obrigatorio: true, autocomplete: 'new-password', largo: true }
  ];
  const form = formulario(campos, {}, {
    rotuloEnviar: 'Salvar nova senha',
    aoEnviar: async (dados) => {
      if (dados.novaSenha !== dados.confirmacao) throw new Error('As duas senhas novas não são iguais.');
      const r = await api('/api/auth/senha', { metodo: 'POST', corpo: { senhaAtual: dados.senhaAtual, novaSenha: dados.novaSenha } });
      avisar(r.mensagem || 'Senha alterada.');
      await entrar(r);
    }
  });
  el.append(moldura(h('section', { class: 'cartao' }, h('h1', { style: 'font-size:1.3rem' }, 'Defina uma nova senha'),
    h('p', null, 'Por segurança, troque a senha temporária antes de usar o EcoConect.'), form,
    h('p', { class: 'pequeno', style: 'margin-top:1rem' }, h('a', { href: '#', onClick: (ev) => { ev.preventDefault(); sair(); } }, 'Sair')))));
}
