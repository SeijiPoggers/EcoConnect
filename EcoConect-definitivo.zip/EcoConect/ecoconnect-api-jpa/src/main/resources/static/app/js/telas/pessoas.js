// Pessoas acompanhadas: lista, cadastro e prontuário de acompanhamento (com abas).
import { api } from '../api.js';
import { h, cabecalho, cartao, formulario, avisar, confirmar, janelaFormulario, tabela, situacao, dataBR, dataHoraBR, vazio, botao, link,
  abas, listaDefinicoes, etiqueta, erroParaTexto, graficoBarras, sim } from '../ui.js';

const SEXOS = [['F', 'Feminino'], ['M', 'Masculino'], ['NAO_INFORMADO', 'Prefiro não informar']];
const SITUACOES = [['EM_ANALISE', 'Em análise'], ['AGUARDANDO_VAGA', 'Aguardando vaga'], ['ATIVA', 'Em acompanhamento'],
  ['CICLO_ENCERRADO', 'Ciclo encerrado'], ['INATIVA', 'Inativa']];

export async function lista(el, { app, consulta }) {
  const pode = app.perfil('ADMINISTRADOR', 'PROFISSIONAL', 'RESPONSAVEL');
  const titulo = app.perfil('RESPONSAVEL') ? 'Minha família' : 'Pessoas acompanhadas';
  el.append(cabecalho(titulo, app.perfil('ADMIN_INSTITUCIONAL') ? 'Pessoas que procuraram a sua instituição.'
    : 'Cada pessoa tem o seu perfil de necessidades, a equipe autorizada e o histórico de acompanhamento.',
    pode ? [link('Cadastrar pessoa', '#/pessoas/nova')] : null));
  const busca = h('input', { type: 'search', id: 'busca-pessoa', value: consulta.texto || '', placeholder: 'Digite parte do nome' });
  const resultado = h('div');
  el.append(h('div', { class: 'filtros', role: 'search' }, h('div', { class: 'campo' }, h('label', { for: 'busca-pessoa' }, 'Buscar pelo nome'), busca)), resultado);
  let espera;
  const carregar = async () => {
    try {
      const pessoas = await api('/api/app/pessoas', { consulta: { texto: busca.value } });
      resultado.replaceChildren(pessoas.length ? h('div', { class: 'grade' }, pessoas.map((p) => h('a', { class: 'cartao indicador', href: `#/pessoas/${p.idCrianca}` },
        h('strong', { style: 'font-size:1.05rem;color:var(--primaria-escura)' }, p.nomeCompleto),
        h('span', { class: 'suave' }, `${p.idade} anos`), h('span', { class: 'etiquetas' }, situacao('pessoa', p.situacao)),
        p.condicoes ? h('span', { class: 'pequeno' }, p.condicoes.split(',').join(' · ')) : null,
        p.proximoAtendimento ? h('span', { class: 'pequeno detalhe' }, 'Próxima sessão: ' + dataHoraBR(p.proximoAtendimento)) : null,
        p.profissionais ? h('span', { class: 'pequeno suave' }, 'Equipe: ' + p.profissionais) : null)))
        : vazio(busca.value ? 'Ninguém encontrado com esse nome.' : 'Nenhuma pessoa no seu acompanhamento ainda.', pode ? link('Cadastrar pessoa', '#/pessoas/nova', 'botao secundario') : null));
    } catch (e) { resultado.replaceChildren(h('div', { class: 'aviso perigo', role: 'alert' }, erroParaTexto(e))); }
  };
  busca.addEventListener('input', () => { clearTimeout(espera); espera = setTimeout(carregar, 300); });
  await carregar();
}

export async function nova(el, { app }) {
  const familia = app.perfil('RESPONSAVEL');
  el.append(cabecalho('Cadastrar pessoa acompanhada', 'Informe só o necessário. Dados de saúde podem ser acrescentados depois, com cuidado.', null,
    [{ texto: 'Pessoas', link: '#/pessoas' }, { texto: 'Cadastro' }]));
  const campos = [
    { nome: 'nomeCompleto', rotulo: 'Nome completo', obrigatorio: true, max: 150, largo: true },
    { nome: 'dataNascimento', rotulo: 'Data de nascimento', tipo: 'data', obrigatorio: true },
    { nome: 'sexo', rotulo: 'Sexo', tipo: 'selecao', opcoes: SEXOS, vazio: 'Não informar' },
    { nome: 'cpf', rotulo: 'CPF (opcional)', max: 14, modo: 'numeric', ajuda: 'Só se for necessário para encaminhamentos.' }
  ];
  if (familia) {
    campos.push({ nome: 'parentesco', rotulo: 'Seu parentesco com a pessoa', exemplo: 'Mãe, pai, avó, tutor...', max: 50 });
    campos.push({ nome: 'consentimentoAceito', rotulo: 'Autorizo o tratamento dos dados desta pessoa para o acompanhamento no EcoConect (LGPD).', tipo: 'marcacao', largo: true,
      ajuda: 'Você pode revogar esta autorização em Minha conta > Privacidade.' });
  } else {
    campos.push({ nome: 'situacao', rotulo: 'Situação', tipo: 'selecao', opcoes: SITUACOES, padrao: 'EM_ANALISE', semVazio: true });
  }
  el.append(cartao(null, formulario(campos, {}, {
    rotuloEnviar: 'Cadastrar', cancelar: () => app.navegar('#/pessoas'),
    aoEnviar: async (d) => {
      if (d.cpf) d.cpf = d.cpf.replace(/\D/g, '');
      const r = await api('/api/app/pessoas', { metodo: 'POST', corpo: d });
      avisar('Pessoa cadastrada.');
      app.navegar(`#/pessoas/${r.pessoa.idCrianca}?aba=necessidades`);
    }
  })));
}

export async function detalhe(el, { params, consulta, app }) {
  const id = params.id;
  const d = await api(`/api/app/pessoas/${id}`);
  const p = d.pessoa;
  const perm = d.permissoes || {};
  const itens = [{ chave: 'resumo', rotulo: 'Resumo' }, { chave: 'necessidades', rotulo: 'Necessidades' }];
  if (perm.verAcompanhamento) itens.push({ chave: 'acompanhamento', rotulo: 'Acompanhamento' }, { chave: 'rede', rotulo: 'Rede de cuidado' });
  if (perm.verHistoricoAlteracoes) itens.push({ chave: 'historico', rotulo: 'Histórico de alterações' });
  const ativa = itens.some((i) => i.chave === consulta.aba) ? consulta.aba : 'resumo';
  const acoes = [];
  if (perm.registrarSessao) acoes.push(link('Registrar sessão', `#/sessoes/nova?pessoa=${id}`));
  if (perm.verAcompanhamento) acoes.push(link(app.familia ? 'Pedir horário' : 'Agendar', `#/agenda?pessoa=${id}&novo=1`, 'botao secundario'));
  el.append(cabecalho(p.nomeCompleto, `${p.idade} anos · desde ${dataBR(p.dataCadastro)}`, acoes,
    app.perfil('PESSOA_ACOMPANHADA') ? null : [{ texto: 'Pessoas', link: '#/pessoas' }, { texto: p.nomeCompleto }]));
  const corpo = h('div', { role: 'tabpanel', 'aria-labelledby': 'aba-' + ativa });
  el.append(abas(itens, ativa, (c) => app.navegar(`#/pessoas/${id}?aba=${c}`)), corpo);
  const telas = { resumo, necessidades, acompanhamento, rede, historico };
  await telas[ativa](corpo, d, app);
}

// ------------------------------------------------------------------ abas
async function resumo(el, d, app) {
  const p = d.pessoa;
  const n = d.necessidades;
  const cat = await app.catalogos();
  const rotulos = (codigos, vocab) => (codigos ? codigos.split(',').map((c) => vocab[c] || c).join(', ') : null);
  el.append(h('div', { class: 'grade-2' },
    cartao('Dados da pessoa', listaDefinicoes([['Nome', p.nomeCompleto], ['Nascimento', dataBR(p.dataNascimento)], ['Idade', `${p.idade} anos`],
      ['Sexo', (SEXOS.find(([v]) => v === p.sexo) || [null, null])[1]], ['Situação', situacao('pessoa', p.situacao)],
      p.cpf !== undefined ? ['CPF', p.cpf ? p.cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4') : null] : null,
      ['Ingresso no acompanhamento', dataBR(p.dataIngresso)], ['Última atualização', dataHoraBR(p.dataAtualizacao)]]),
      d.permissoes.editarDados ? h('div', { class: 'acoes', style: 'margin-top:1rem' }, botao('Editar dados', () => editarPessoa(d, app), 'secundario')) : null),
    cartao('Resumo das necessidades', n ? listaDefinicoes([['Condições informadas', rotulos(n.condicoesInformadas, cat.condicoes)],
      ['Comunicação preferida', cat.comunicacao[n.comunicacaoPreferida] || n.comunicacaoPreferida],
      ['Preferências sensoriais', rotulos(n.preferenciasSensoriais, cat.sensorial)], ['Acessibilidade', rotulos(n.necessidadesAcessibilidade, cat.acessibilidade)],
      ['Local', n.municipio ? `${n.municipio}${n.uf ? '/' + n.uf : ''}` : null], ['Somente serviços gratuitos', n.somenteGratuito ? 'Sim' : 'Não']])
      : vazio('O perfil de necessidades ainda não foi preenchido.', d.permissoes.editarNecessidades ? link('Preencher agora', `#/pessoas/${p.idCrianca}?aba=necessidades`, 'botao secundario pequeno') : null),
      n ? h('div', { class: 'acoes', style: 'margin-top:1rem' }, link('Ver instituições recomendadas', `#/rede/recomendacoes?pessoa=${p.idCrianca}`, 'botao secundario')) : null)));
}

function editarPessoa(d, app) {
  const p = d.pessoa;
  const campos = [
    { nome: 'nomeCompleto', rotulo: 'Nome completo', obrigatorio: true, max: 150, largo: true },
    { nome: 'dataNascimento', rotulo: 'Data de nascimento', tipo: 'data', obrigatorio: true },
    { nome: 'sexo', rotulo: 'Sexo', tipo: 'selecao', opcoes: SEXOS, vazio: 'Não informar' },
    { nome: 'cpf', rotulo: 'CPF', max: 14 }
  ];
  if (app.equipe) campos.push({ nome: 'situacao', rotulo: 'Situação', tipo: 'selecao', opcoes: SITUACOES, semVazio: true });
  janelaFormulario('Editar dados', campos, { ...p, situacao: p.situacao }, async (dados) => {
    if (dados.cpf) dados.cpf = dados.cpf.replace(/\D/g, '');
    if (!app.equipe) dados.situacao = p.situacao;
    await api(`/api/app/pessoas/${p.idCrianca}`, { metodo: 'PUT', corpo: dados });
    avisar('Dados atualizados.');
    app.navegar(`#/pessoas/${p.idCrianca}?aba=resumo`);
  });
}

async function necessidades(el, d, app) {
  const cat = await app.catalogos();
  const n = d.necessidades || {};
  const campos = [
    { nome: 'condicoesInformadas', rotulo: 'Condições informadas', tipo: 'multipla', opcoes: cat.condicoes, ajuda: 'Marque só o que a família ou a pessoa quiser informar. Não é diagnóstico.' },
    { nome: 'necessidadesAcompanhamento', rotulo: 'O que a pessoa precisa no acompanhamento', tipo: 'area', max: 500, largo: true },
    { nome: 'comunicacaoPreferida', rotulo: 'Como prefere se comunicar', tipo: 'selecao', opcoes: cat.comunicacao, semVazio: true, padrao: 'SEM_PREFERENCIA' },
    { nome: 'modalidadePreferida', rotulo: 'Atendimento preferido', tipo: 'selecao', semVazio: true, padrao: 'SEM_PREFERENCIA',
      opcoes: [['SEM_PREFERENCIA', 'Sem preferência'], ['PRESENCIAL', 'Presencial'], ['ONLINE', 'On-line'], ['DOMICILIAR', 'No domicílio']] },
    { nome: 'preferenciasSensoriais', rotulo: 'Preferências sensoriais', tipo: 'multipla', opcoes: cat.sensorial },
    { nome: 'observacoesSensoriais', rotulo: 'Observações sensoriais', tipo: 'area', max: 500, largo: true, exemplo: 'Ex.: evita barulho de secador; gosta de luz baixa.' },
    { nome: 'necessidadesAcessibilidade', rotulo: 'Recursos de acessibilidade desejados', tipo: 'multipla', opcoes: cat.acessibilidade },
    { nome: 'municipio', rotulo: 'Município', max: 80 },
    { nome: 'uf', rotulo: 'UF', max: 2, exemplo: 'SP' },
    { nome: 'somenteGratuito', rotulo: 'Buscar somente serviços gratuitos', tipo: 'marcacao' },
    { nome: 'observacoesAcompanhamento', rotulo: 'Outras informações relevantes', tipo: 'area', max: 5000, largo: true }
  ];
  if (!d.permissoes.editarNecessidades) {
    el.append(cartao('Perfil de necessidades', d.necessidades ? listaDefinicoes(campos.map((c) => [c.rotulo,
      c.tipo === 'multipla' ? (n[c.nome] || '').split(',').filter(Boolean).map((x) => c.opcoes[x] || x).join(', ')
        : c.tipo === 'selecao' ? (c.opcoes[n[c.nome]] || (Array.isArray(c.opcoes) ? (c.opcoes.find(([v]) => v === n[c.nome]) || [])[1] : n[c.nome]))
          : c.tipo === 'marcacao' ? (n[c.nome] ? 'Sim' : 'Não') : n[c.nome]])) : vazio('Ainda não informado.')));
    return;
  }
  el.append(h('div', { class: 'aviso info' }, 'Estas informações ajudam a equipe e as instituições a acolher melhor. Nada aqui é obrigatório.'),
    cartao('Perfil de necessidades', formulario(campos, n, { rotuloEnviar: 'Salvar perfil', aoEnviar: async (dados) => {
      if (dados.uf) dados.uf = dados.uf.toUpperCase();
      await api(`/api/app/pessoas/${d.pessoa.idCrianca}/necessidades`, { metodo: 'PUT', corpo: dados });
      avisar('Perfil de necessidades salvo.');
      app.navegar(`#/pessoas/${d.pessoa.idCrianca}?aba=resumo`);
    } })));
}

async function acompanhamento(el, d, app) {
  const id = d.pessoa.idCrianca;
  const t = await api(`/api/app/pessoas/${id}/trajetoria`);
  if (t.aviso) el.append(h('p', { class: 'suave' }, t.aviso));
  // objetivos e indicadores
  const objetivos = cartao('Objetivos e evolução',
    t.objetivos && t.objetivos.length ? t.objetivos.map((o) => h('div', { style: 'border-top:1px solid var(--superficie-2);padding:.75rem 0' },
      h('div', { class: 'acoes', style: 'justify-content:space-between' }, h('h3', { style: 'margin:0' }, o.titulo),
        etiqueta(o.situacao === 'EM_ANDAMENTO' ? 'Em andamento' : o.situacao === 'CICLO_ENCERRADO' ? 'Concluído' : 'Cancelado', o.situacao === 'EM_ANDAMENTO' ? 'info' : '')),
      o.descricao ? h('p', null, o.descricao) : null,
      h('p', { class: 'suave pequeno' }, `Desde ${dataBR(o.dataInicio)}${o.dataPrevistaFim ? ' · previsão ' + dataBR(o.dataPrevistaFim) : ''} · definido por ${o.definidoPor}`),
      (o.indicadores || []).map((i) => indicador(i, o, d, app)),
      app.equipe && o.situacao === 'EM_ANDAMENTO' ? h('div', { class: 'acoes' },
        botao('Vincular indicador', () => vincularIndicador(o, d, app), 'secundario pequeno'),
        botao('Concluir objetivo', async () => {
          if (!await confirmar('Marcar este objetivo como concluído?')) return;
          try { await api(`/api/objetivos/${o.idObjetivo}/encerramento`, { metodo: 'PATCH', corpo: {} }); avisar('Objetivo concluído.'); app.navegar(`#/pessoas/${id}?aba=acompanhamento`); }
          catch (e) { avisar(erroParaTexto(e), 'erro'); }
        }, 'texto pequeno')) : null))
      : vazio('Nenhum objetivo terapêutico definido ainda.'),
    app.equipe ? h('div', { class: 'acoes', style: 'margin-top:.75rem' }, botao('Novo objetivo', () => novoObjetivo(d, app), 'secundario')) : null);
  // linha do tempo
  const itens = [...(t.itens || [])].sort((a, b) => String(b.data).localeCompare(String(a.data)));
  const agora = new Date().toISOString().slice(0, 16);
  const linha = cartao('Linha do tempo', itens.length ? h('ol', { class: 'linha-tempo' }, itens.map((i) => h('li', { class: String(i.data) > agora ? 'futuro' : '' },
    h('div', { class: 'quando' }, dataHoraBR(i.data)), itemLinha(i)))) : vazio('Ainda não há registros.'));
  el.append(h('div', { class: 'grade-2' }, linha, objetivos));
}

function itemLinha(i) {
  if (i.tipo === 'SESSAO') {
    return h('div', null, h('strong', null, h('a', { href: `#/sessoes/${i.id}` }, i.tipoAtendimento || 'Sessão')), ' ', etiqueta('Sessão', 'ok'),
      h('div', { class: 'detalhes pequeno' }, i.profissionais ? h('span', { class: 'suave' }, i.profissionais) : null,
        i.atividades ? h('span', null, 'Atividades: ' + i.atividades) : null,
        i.evolucaoObservada ? h('span', null, 'Evolução: ' + i.evolucaoObservada) : null,
        i.proximosPassos ? h('span', null, 'Próximos passos: ' + i.proximosPassos) : null));
  }
  if (i.tipo === 'AGENDAMENTO') {
    return h('div', null, h('strong', null, 'Agendamento '), situacao('agendamento', i.status),
      i.profissionais ? h('div', { class: 'pequeno suave' }, i.profissionais) : null);
  }
  if (i.tipo === 'RELATORIO') {
    return h('div', null, h('strong', null, i.idAtendimento ? h('a', { href: `#/sessoes/${i.idAtendimento}` }, i.titulo) : i.titulo), ' ',
      situacao('relatorio', i.situacao), h('div', { class: 'pequeno suave' }, i.autor ? 'Por ' + i.autor : ''));
  }
  return h('div', null, h('strong', null, i.titulo || i.tipoEvento || 'Registro'), ' ', etiqueta('Histórico de saúde', 'info'),
    i.descricao ? h('div', { class: 'pequeno' }, i.descricao) : null);
}

function indicador(i, o, d, app) {
  const av = i.avaliacoes || [];
  const numerico = i.tipoMedida === 'NUMERICA';
  const ultimo = av.length ? av[av.length - 1] : null;
  const progresso = numerico && i.meta && ultimo && ultimo.valorNumerico !== null
    ? Math.max(0, Math.min(100, Math.round(((Number(ultimo.valorNumerico) - Number(i.valorInicial || 0)) / (Number(i.meta) - Number(i.valorInicial || 0) || 1)) * 100))) : null;
  return h('div', { class: 'cartao', style: 'box-shadow:none;margin:.5rem 0' },
    h('div', { class: 'acoes', style: 'justify-content:space-between' }, h('strong', null, i.nome),
      numerico && i.meta ? h('span', { class: 'pequeno suave' }, `Início ${fmt(i.valorInicial)} · meta ${fmt(i.meta)} ${i.unidade || ''}`) : null),
    progresso !== null ? h('div', null, h('div', { class: 'progresso', role: 'progressbar', 'aria-valuenow': progresso, 'aria-valuemin': 0, 'aria-valuemax': 100,
      'aria-label': `Progresso até a meta: ${progresso}%` }, h('span', { style: `width:${progresso}%` })), h('span', { class: 'pequeno suave' }, `${progresso}% do caminho até a meta`)) : null,
    numerico && av.length ? graficoBarras(av.map((a) => ({ rotulo: dataBR(a.data).slice(0, 5), valor: Number(a.valorNumerico || 0) })), { descricao: 'Avaliações de ' + i.nome })
      : av.length ? h('ul', { class: 'lista-simples pequeno' }, av.map((a) => h('li', null, h('span', null, a.valorQualitativo), h('span', { class: 'suave' }, dataBR(a.data)))))
        : h('p', { class: 'suave pequeno' }, 'Sem avaliações ainda.'),
    app.equipe && o.situacao === 'EM_ANDAMENTO' ? botao('Registrar avaliação', () => novaAvaliacao(i, o, d, app), 'texto pequeno') : null);
}

const fmt = (v) => (v === null || v === undefined ? '—' : Number(v).toLocaleString('pt-BR'));

function profissionalDaAcao(d, app) {
  if (app.usuario.idProfissional) return null;
  const ativos = (d.profissionais || []).filter((p) => p.status === 'ATIVO');
  return { nome: 'idProfissional', rotulo: 'Profissional responsável', tipo: 'selecao', obrigatorio: true, opcoes: ativos.map((p) => [p.idProfissional, p.nome]),
    ajuda: ativos.length ? null : 'Autorize um profissional na aba Rede de cuidado.' };
}

function novoObjetivo(d, app) {
  const campos = [
    { nome: 'titulo', rotulo: 'Objetivo', obrigatorio: true, max: 150, largo: true, exemplo: 'Ex.: Ampliar a comunicação funcional' },
    { nome: 'descricao', rotulo: 'Descrição', tipo: 'area', largo: true },
    { nome: 'dataInicio', rotulo: 'Início', tipo: 'data', obrigatorio: true, padrao: new Date().toISOString().slice(0, 10) },
    { nome: 'dataPrevistaFim', rotulo: 'Previsão de término', tipo: 'data' }
  ];
  const prof = profissionalDaAcao(d, app);
  if (prof) campos.push(prof);
  janelaFormulario('Novo objetivo terapêutico', campos, {}, async (dados) => {
    const corpo = { idCrianca: d.pessoa.idCrianca, idProfissionalDefinidor: dados.idProfissional ? Number(dados.idProfissional) : app.usuario.idProfissional,
      titulo: dados.titulo, descricao: dados.descricao, dataInicio: dados.dataInicio, dataPrevistaFim: dados.dataPrevistaFim };
    await api('/api/objetivos', { metodo: 'POST', corpo });
    avisar('Objetivo criado.');
    app.navegar(`#/pessoas/${d.pessoa.idCrianca}?aba=acompanhamento`);
  });
}

async function vincularIndicador(o, d, app) {
  let lista;
  try { lista = (await api('/api/indicadores', { consulta: { ativo: true, size: 200, sort: 'nome' } })).conteudo; }
  catch (e) { avisar(erroParaTexto(e), 'erro'); return; }
  janelaFormulario('Vincular indicador ao objetivo', [
    { nome: 'idIndicador', rotulo: 'Indicador', tipo: 'selecao', obrigatorio: true, largo: true,
      opcoes: lista.map((i) => [i.idIndicador, `${i.nome}${i.unidadeMedida ? ' (' + i.unidadeMedida + ')' : ''}${i.tipoMedida === 'QUALITATIVA' ? ' - descritivo' : ''}`]) },
    { nome: 'valorReferenciaInicial', rotulo: 'Valor inicial (se numérico)', tipo: 'numero', passo: 'any' },
    { nome: 'metaValor', rotulo: 'Meta (se numérico)', tipo: 'numero', passo: 'any' },
    { nome: 'descricaoMeta', rotulo: 'Como saberemos que deu certo', tipo: 'area', max: 300, largo: true }
  ], {}, async (dados) => {
    dados.idIndicador = Number(dados.idIndicador);
    await api(`/api/objetivos/${o.idObjetivo}/indicadores`, { metodo: 'POST', corpo: dados });
    avisar('Indicador vinculado.');
    app.navegar(`#/pessoas/${d.pessoa.idCrianca}?aba=acompanhamento`);
  });
}

function novaAvaliacao(i, o, d, app) {
  const numerico = i.tipoMedida === 'NUMERICA';
  const campos = [
    { nome: 'dataAvaliacao', rotulo: 'Data', tipo: 'data', obrigatorio: true, padrao: new Date().toISOString().slice(0, 10) },
    numerico ? { nome: 'valorNumerico', rotulo: `Valor ${i.unidade ? '(' + i.unidade + ')' : ''}`, tipo: 'numero', obrigatorio: true, passo: 'any' }
      : { nome: 'valorQualitativo', rotulo: 'Como foi', obrigatorio: true, max: 255, largo: true },
    { nome: 'observacao', rotulo: 'Observação', tipo: 'area', max: 500, largo: true }
  ];
  const prof = profissionalDaAcao(d, app);
  if (prof) campos.push(prof);
  janelaFormulario(`Avaliar: ${i.nome}`, campos, {}, async (dados) => {
    const corpo = { idObjetivo: o.idObjetivo, idIndicador: i.idIndicador, dataAvaliacao: dados.dataAvaliacao, valorNumerico: dados.valorNumerico ?? null,
      valorQualitativo: dados.valorQualitativo ?? null, observacao: dados.observacao,
      idProfissionalAvaliador: dados.idProfissional ? Number(dados.idProfissional) : app.usuario.idProfissional };
    await api('/api/avaliacoes-indicador', { metodo: 'POST', corpo });
    avisar('Avaliação registrada.');
    app.navegar(`#/pessoas/${d.pessoa.idCrianca}?aba=acompanhamento`);
  });
}

async function rede(el, d, app) {
  const id = d.pessoa.idCrianca;
  const perm = d.permissoes;
  const recarregar = () => app.navegar(`#/pessoas/${id}?aba=rede`);
  el.append(cartao('Responsáveis', tabela([
    { titulo: 'Nome', valor: (r) => r.nome }, { titulo: 'Parentesco', valor: (r) => r.parentesco },
    { titulo: 'Permissões', valor: (r) => h('span', { class: 'etiquetas' }, sim(r.principal) ? etiqueta('Principal', 'info') : null,
      sim(r.podeConsultarDados) ? etiqueta('Consulta dados') : null, sim(r.podeSolicitarAgendamento) ? etiqueta('Pede horários') : null) },
    { titulo: 'Situação', valor: (r) => (r.status === 'ATIVO' ? etiqueta('Ativo', 'ok') : etiqueta('Revogado')) },
    { titulo: '', valor: (r) => (perm.gerirResponsaveis && r.status === 'ATIVO' ? botao('Revogar', async () => {
      if (!await confirmar(`Revogar o acesso de ${r.nome} a esta pessoa?`, { perigo: true, rotulo: 'Revogar' })) return;
      try { await api(`/api/app/pessoas/${id}/responsaveis/${r.idVinculo}`, { metodo: 'DELETE' }); avisar('Vínculo revogado.'); recarregar(); }
      catch (e) { avisar(erroParaTexto(e), 'erro'); }
    }, 'texto pequeno') : '') }], d.responsaveis, { vazioTexto: 'Nenhum responsável vinculado.' }),
    perm.gerirResponsaveis ? h('div', { class: 'acoes', style: 'margin-top:.75rem' }, botao('Vincular responsável', () => janelaFormulario('Vincular responsável', [
      { nome: 'email', rotulo: 'E-mail da conta do responsável', tipo: 'email', obrigatorio: true, largo: true, ajuda: 'A pessoa precisa ter uma conta de responsável no EcoConect.' },
      { nome: 'parentesco', rotulo: 'Parentesco', obrigatorio: true, max: 50 },
      { nome: 'principal', rotulo: 'Responsável principal', tipo: 'marcacao' },
      { nome: 'podeConsultarDados', rotulo: 'Pode consultar os dados', tipo: 'marcacao', padrao: true },
      { nome: 'podeSolicitarAgendamento', rotulo: 'Pode pedir horários', tipo: 'marcacao', padrao: true }
    ], {}, async (dados) => { await api(`/api/app/pessoas/${id}/responsaveis`, { metodo: 'POST', corpo: dados }); avisar('Responsável vinculado.'); recarregar(); }), 'secundario')) : null));

  el.append(cartao('Profissionais autorizados', tabela([
    { titulo: 'Profissional', valor: (p) => p.nome }, { titulo: 'Função', valor: (p) => p.funcao }, { titulo: 'Especialidades', valor: (p) => p.especialidades },
    { titulo: 'Desde', valor: (p) => dataBR(p.dataInicio) }, { titulo: 'Situação', valor: (p) => (p.status === 'ATIVO' ? etiqueta('Ativo', 'ok') : etiqueta('Encerrado')) },
    { titulo: '', valor: (p) => (perm.gerirProfissionais && p.status === 'ATIVO' ? botao('Encerrar', async () => {
      if (!await confirmar(`Encerrar a autorização de ${p.nome}? O histórico é mantido.`, { perigo: true, rotulo: 'Encerrar' })) return;
      try { await api(`/api/app/pessoas/${id}/profissionais/${p.idProfissional}`, { metodo: 'DELETE' }); avisar('Autorização encerrada.'); recarregar(); }
      catch (e) { avisar(erroParaTexto(e), 'erro'); }
    }, 'texto pequeno') : '') }], d.profissionais, { vazioTexto: 'Nenhum profissional autorizado.' }),
    perm.gerirProfissionais ? h('div', { class: 'acoes', style: 'margin-top:.75rem' }, botao('Autorizar profissional', async () => {
      let diretorio;
      try { diretorio = await api('/api/app/diretorio-profissionais'); } catch (e) { avisar(erroParaTexto(e), 'erro'); return; }
      janelaFormulario('Autorizar profissional', [
        { nome: 'idProfissional', rotulo: 'Profissional', tipo: 'selecao', obrigatorio: true, largo: true,
          opcoes: diretorio.map((p) => [p.idProfissional, `${p.nome}${p.especialidades ? ' - ' + p.especialidades : ''}`]) },
        { nome: 'funcao', rotulo: 'Função no acompanhamento', max: 80, exemplo: 'Ex.: psicóloga de referência' }
      ], {}, async (dados) => { dados.idProfissional = Number(dados.idProfissional); await api(`/api/app/pessoas/${id}/profissionais`, { metodo: 'POST', corpo: dados }); avisar('Profissional autorizado.'); recarregar(); });
    }, 'secundario')) : null));

  const inst = await api(`/api/app/pessoas/${id}/instituicoes`);
  el.append(cartao('Instituições de apoio', tabela([
    { titulo: 'Instituição', valor: (i) => h('a', { href: `#/rede/${i.idInstituicao}` }, i.nome) }, { titulo: 'Local', valor: (i) => `${i.municipio}/${i.uf}` },
    { titulo: 'Origem', valor: (i) => (i.origem === 'SOLICITACAO' ? 'Solicitação aceita' : 'Cadastro') }, { titulo: 'Desde', valor: (i) => dataBR(i.dataInicio) },
    { titulo: 'Situação', valor: (i) => (i.status === 'ATIVO' ? etiqueta('Ativo', 'ok') : etiqueta('Encerrado')) },
    { titulo: '', valor: (i) => ((app.equipe || app.perfil('RESPONSAVEL')) && i.status === 'ATIVO' ? botao('Encerrar', async () => {
      if (!await confirmar(`Encerrar o vínculo com ${i.nome}?`, { perigo: true, rotulo: 'Encerrar' })) return;
      try { await api(`/api/app/pessoas/${id}/instituicoes/${i.idVinculo}`, { metodo: 'DELETE' }); avisar('Vínculo encerrado.'); recarregar(); }
      catch (e) { avisar(erroParaTexto(e), 'erro'); }
    }, 'texto pequeno') : '') }], inst, { vazioTexto: 'Nenhuma instituição vinculada.' }),
    h('div', { class: 'acoes', style: 'margin-top:.75rem' }, link('Buscar instituições recomendadas', `#/rede/recomendacoes?pessoa=${id}`, 'botao secundario'),
      app.equipe || app.perfil('RESPONSAVEL') ? botao('Registrar vínculo existente', async () => {
        let todas;
        try { todas = await api('/api/rede/instituicoes'); } catch (e) { avisar(erroParaTexto(e), 'erro'); return; }
        janelaFormulario('Registrar vínculo com instituição', [
          { nome: 'idInstituicao', rotulo: 'Instituição', tipo: 'selecao', obrigatorio: true, largo: true, opcoes: todas.map((i) => [i.idInstituicao, `${i.nome} (${i.municipio}/${i.uf})`]) },
          { nome: 'observacao', rotulo: 'Observação', max: 300, largo: true }
        ], {}, async (dados) => { dados.idInstituicao = Number(dados.idInstituicao); await api(`/api/app/pessoas/${id}/instituicoes`, { metodo: 'POST', corpo: dados }); avisar('Vínculo registrado.'); recarregar(); });
      }, 'texto') : null)));

  if (d.consentimentos && d.consentimentos.length) {
    el.append(cartao('Consentimentos (LGPD)', tabela([{ titulo: 'Responsável', valor: (c) => c.responsavel }, { titulo: 'Finalidade', valor: (c) => c.finalidade },
      { titulo: 'Situação', valor: (c) => (c.situacao === 'REGISTRADA' ? etiqueta('Ativo', 'ok') : etiqueta(c.situacao === 'REVOGADA' ? 'Revogado' : c.situacao, 'alerta')) },
      { titulo: 'Data', valor: (c) => dataHoraBR(c.dataAutorizacao) }], d.consentimentos)));
  }
}

async function historico(el, d) {
  const itens = await api(`/api/app/pessoas/${d.pessoa.idCrianca}/historico-alteracoes`);
  const acoes = { CRIACAO: 'Cadastro', ATUALIZACAO: 'Alteração', EXCLUSAO_LOGICA: 'Inativação', VALIDACAO: 'Validação', LIBERACAO: 'Liberação', CONSULTA: 'Consulta' };
  el.append(cartao('Histórico de alterações', h('p', { class: 'suave' }, 'Registro automático de quem cadastrou, alterou ou consultou dados desta pessoa (auditoria).'),
    tabela([{ titulo: 'Quando', valor: (a) => dataHoraBR(a.dataHora) }, { titulo: 'Ação', valor: (a) => acoes[a.acao] || a.acao },
      { titulo: 'Registro', valor: (a) => `${a.tabela || ''}${a.idRegistro ? ' #' + a.idRegistro : ''}` }, { titulo: 'Por', valor: (a) => a.usuario }], itens)));
}
