-- =====================================================================
-- V4 - Vínculo da pessoa acompanhada com instituições, solicitações do
-- titular (LGPD, art. 18) e registro dos dados fictícios de demonstração.
-- Somente tabelas novas.
-- =====================================================================

-- Pessoa acompanhada vinculada a uma instituição de apoio (nasce de uma
-- solicitação ACEITA ou de um cadastro feito pela equipe/instituição).
CREATE TABLE IF NOT EXISTS crianca_instituicao (
    id_crianca_instituicao  INT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_crianca              INT UNSIGNED NOT NULL,
    id_instituicao          INT UNSIGNED NOT NULL,
    origem                  ENUM('SOLICITACAO','CADASTRO') COLLATE utf8mb4_unicode_ci NOT NULL,
    id_solicitacao          INT UNSIGNED DEFAULT NULL,
    status                  ENUM('ATIVO','ENCERRADO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ATIVO',
    data_inicio             DATE         NOT NULL,
    data_fim                DATE         DEFAULT NULL,
    observacao              VARCHAR(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    id_usuario_cadastro     INT UNSIGNED NOT NULL,
    data_cadastro           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_crianca_instituicao),
    UNIQUE KEY uk_crianca_instituicao (id_crianca, id_instituicao),
    KEY idx_ci_instituicao (id_instituicao, status),
    CONSTRAINT fk_ci_crianca FOREIGN KEY (id_crianca) REFERENCES crianca (id_crianca)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_ci_instituicao FOREIGN KEY (id_instituicao) REFERENCES instituicao (id_instituicao)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_ci_solicitacao FOREIGN KEY (id_solicitacao) REFERENCES solicitacao_atendimento (id_solicitacao)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_ci_usuario FOREIGN KEY (id_usuario_cadastro) REFERENCES usuario (id_usuario)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT chk_ci_datas CHECK (data_fim IS NULL OR data_fim >= data_inicio)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Pedidos do titular dos dados (acesso, correção, exclusão/anonimização, portabilidade...).
-- O atendimento é feito pelo administrador; nada é apagado automaticamente.
CREATE TABLE IF NOT EXISTS solicitacao_titular (
    id_solicitacao_titular  INT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_usuario              INT UNSIGNED NOT NULL,
    tipo                    ENUM('ACESSO','CORRECAO','EXCLUSAO','PORTABILIDADE','REVOGACAO_CONSENTIMENTO','OUTRA')
                            COLLATE utf8mb4_unicode_ci NOT NULL,
    detalhe                 VARCHAR(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    situacao                ENUM('ABERTA','EM_ANALISE','ATENDIDA','RECUSADA') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ABERTA',
    resposta                VARCHAR(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    id_usuario_resposta     INT UNSIGNED DEFAULT NULL,
    data_resposta           DATETIME     DEFAULT NULL,
    data_criacao            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_solicitacao_titular),
    KEY idx_st_usuario (id_usuario),
    KEY idx_st_situacao (situacao),
    CONSTRAINT fk_st_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_st_resposta FOREIGN KEY (id_usuario_resposta) REFERENCES usuario (id_usuario)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT chk_st_resposta CHECK (situacao NOT IN ('ATENDIDA','RECUSADA')
        OR (id_usuario_resposta IS NOT NULL AND data_resposta IS NOT NULL))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Lista dos registros criados pela carga de DEMONSTRAÇÃO (dados fictícios).
-- Permite identificá-los na interface e nunca confundi-los com dados reais.
CREATE TABLE IF NOT EXISTS registro_demonstracao (
    tabela        VARCHAR(64) COLLATE utf8mb4_unicode_ci NOT NULL,
    id_registro   VARCHAR(64) COLLATE utf8mb4_unicode_ci NOT NULL,
    data_criacao  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (tabela, id_registro)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
