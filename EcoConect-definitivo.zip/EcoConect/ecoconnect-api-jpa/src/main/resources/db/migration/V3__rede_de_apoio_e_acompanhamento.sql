-- =====================================================================
-- V3 - Frente B (rede de apoio, SUS, comunicação) e complementos da
-- Frente A (perfil de necessidades, profissionais autorizados, registro
-- estruturado de sessão). Somente tabelas novas.
-- Listas de códigos (ex.: 'TEA,TDAH') são guardadas como texto separado
-- por vírgula; os valores aceitos estão documentados na API (/api/rede/catalogos).
-- =====================================================================

CREATE TABLE IF NOT EXISTS instituicao (
    id_instituicao          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome                    VARCHAR(150) COLLATE utf8mb4_unicode_ci NOT NULL,
    tipo                    ENUM('PUBLICA','FILANTROPICA','PRIVADA','ONG','ASSOCIACAO','CLINICA_ESCOLA') COLLATE utf8mb4_unicode_ci NOT NULL,
    cnpj                    CHAR(14)     COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    codigo_cnes             VARCHAR(7)   COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    descricao               TEXT         COLLATE utf8mb4_unicode_ci,
    email                   VARCHAR(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    telefone                VARCHAR(20)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    site                    VARCHAR(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    logradouro              VARCHAR(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    numero                  VARCHAR(20)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    bairro                  VARCHAR(80)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    municipio               VARCHAR(80)  COLLATE utf8mb4_unicode_ci NOT NULL,
    uf                      CHAR(2)      COLLATE utf8mb4_unicode_ci NOT NULL,
    cep                     CHAR(8)      COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    latitude                DECIMAL(9,6) DEFAULT NULL,
    longitude               DECIMAL(9,6) DEFAULT NULL,
    idade_minima            TINYINT UNSIGNED DEFAULT NULL,
    idade_maxima            TINYINT UNSIGNED DEFAULT NULL,
    condicoes_atendidas     VARCHAR(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    modalidades             VARCHAR(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    recursos_acessibilidade VARCHAR(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    atendimento_gratuito    TINYINT(1)   NOT NULL DEFAULT 0,
    atende_pelo_sus         TINYINT(1)   NOT NULL DEFAULT 0,
    vagas_disponiveis       SMALLINT UNSIGNED DEFAULT NULL,
    aceita_solicitacoes     TINYINT(1)   NOT NULL DEFAULT 1,
    verificada              TINYINT(1)   NOT NULL DEFAULT 0,
    ativa                   TINYINT(1)   NOT NULL DEFAULT 1,
    dados_demonstracao      TINYINT(1)   NOT NULL DEFAULT 0,
    data_cadastro           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_instituicao),
    UNIQUE KEY uk_instituicao_cnpj (cnpj),
    KEY idx_instituicao_local (uf, municipio),
    CONSTRAINT chk_inst_idade CHECK (idade_maxima IS NULL OR idade_minima IS NULL OR idade_maxima >= idade_minima)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS instituicao_servico (
    id_servico      INT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_instituicao  INT UNSIGNED NOT NULL,
    nome            VARCHAR(120) COLLATE utf8mb4_unicode_ci NOT NULL,
    tipo_servico    ENUM('AVALIACAO_DIAGNOSTICA','PSICOLOGIA','FONOAUDIOLOGIA','TERAPIA_OCUPACIONAL','FISIOTERAPIA',
                         'PSICOPEDAGOGIA','EQUOTERAPIA','NEUROPEDIATRIA','PSIQUIATRIA','GRUPO_DE_APOIO',
                         'ORIENTACAO_FAMILIAR','APOIO_ESCOLAR','OUTRO') COLLATE utf8mb4_unicode_ci NOT NULL,
    descricao       VARCHAR(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    gratuito        TINYINT(1)   NOT NULL DEFAULT 0,
    ativo           TINYINT(1)   NOT NULL DEFAULT 1,
    PRIMARY KEY (id_servico),
    KEY idx_servico_instituicao (id_instituicao, ativo),
    CONSTRAINT fk_servico_instituicao FOREIGN KEY (id_instituicao) REFERENCES instituicao (id_instituicao)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Quem administra a instituição ou atua nela (o profissional também tem cadastro em PROFISSIONAL)
CREATE TABLE IF NOT EXISTS instituicao_membro (
    id_membro       INT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_instituicao  INT UNSIGNED NOT NULL,
    id_usuario      INT UNSIGNED NOT NULL,
    papel           ENUM('ADMIN_INSTITUCIONAL','PROFISSIONAL') COLLATE utf8mb4_unicode_ci NOT NULL,
    ativo           TINYINT(1)   NOT NULL DEFAULT 1,
    data_inicio     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_membro),
    UNIQUE KEY uk_membro (id_instituicao, id_usuario),
    KEY idx_membro_usuario (id_usuario, ativo),
    CONSTRAINT fk_membro_instituicao FOREIGN KEY (id_instituicao) REFERENCES instituicao (id_instituicao)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_membro_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Estabelecimentos públicos importados do CNES (dados abertos do DATASUS)
CREATE TABLE IF NOT EXISTS estabelecimento_sus (
    codigo_cnes         VARCHAR(7)   COLLATE utf8mb4_unicode_ci NOT NULL,
    nome                VARCHAR(200) COLLATE utf8mb4_unicode_ci NOT NULL,
    razao_social        VARCHAR(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    categoria           ENUM('UBS','CAPS','CAPS_INFANTIL','CAPS_AD','CER','POLICLINICA','HOSPITAL','OUTRO') COLLATE utf8mb4_unicode_ci NOT NULL,
    codigo_tipo_unidade SMALLINT UNSIGNED DEFAULT NULL,
    codigo_municipio    CHAR(6)      COLLATE utf8mb4_unicode_ci NOT NULL,
    municipio           VARCHAR(80)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    uf                  CHAR(2)      COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    logradouro          VARCHAR(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    numero              VARCHAR(20)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    bairro              VARCHAR(80)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    cep                 CHAR(8)      COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    telefone            VARCHAR(30)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    email               VARCHAR(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    latitude            DECIMAL(9,6) DEFAULT NULL,
    longitude           DECIMAL(9,6) DEFAULT NULL,
    fonte               ENUM('CNES_ARQUIVO','DEMONSTRACAO') COLLATE utf8mb4_unicode_ci NOT NULL,
    data_importacao     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (codigo_cnes),
    KEY idx_estab_municipio (codigo_municipio, categoria),
    KEY idx_estab_nome_municipio (uf, municipio)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS conversa (
    id_conversa           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    assunto               VARCHAR(150) COLLATE utf8mb4_unicode_ci NOT NULL,
    id_instituicao        INT UNSIGNED DEFAULT NULL,
    id_crianca            INT UNSIGNED DEFAULT NULL,
    id_usuario_criador    INT UNSIGNED NOT NULL,
    data_criacao          DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_ultima_mensagem  DATETIME     DEFAULT NULL,
    PRIMARY KEY (id_conversa),
    CONSTRAINT fk_conv_instituicao FOREIGN KEY (id_instituicao) REFERENCES instituicao (id_instituicao)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_conv_crianca FOREIGN KEY (id_crianca) REFERENCES crianca (id_crianca)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_conv_criador FOREIGN KEY (id_usuario_criador) REFERENCES usuario (id_usuario)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS conversa_participante (
    id_participante       INT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_conversa           INT UNSIGNED NOT NULL,
    id_usuario            INT UNSIGNED NOT NULL,
    data_entrada          DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_ultima_leitura   DATETIME     DEFAULT NULL,
    PRIMARY KEY (id_participante),
    UNIQUE KEY uk_participante (id_conversa, id_usuario),
    KEY idx_participante_usuario (id_usuario),
    CONSTRAINT fk_part_conversa FOREIGN KEY (id_conversa) REFERENCES conversa (id_conversa)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_part_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS mensagem (
    id_mensagem       BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_conversa       INT UNSIGNED    NOT NULL,
    id_usuario_autor  INT UNSIGNED    NOT NULL,
    conteudo          TEXT            COLLATE utf8mb4_unicode_ci NOT NULL,
    data_envio        DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_mensagem),
    KEY idx_mensagem_conversa (id_conversa, data_envio),
    CONSTRAINT fk_msg_conversa FOREIGN KEY (id_conversa) REFERENCES conversa (id_conversa)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_msg_autor FOREIGN KEY (id_usuario_autor) REFERENCES usuario (id_usuario)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS solicitacao_atendimento (
    id_solicitacao          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_instituicao          INT UNSIGNED NOT NULL,
    id_servico              INT UNSIGNED DEFAULT NULL,
    id_crianca              INT UNSIGNED DEFAULT NULL,
    id_usuario_solicitante  INT UNSIGNED NOT NULL,
    mensagem                VARCHAR(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
    forma_contato           ENUM('MENSAGEM_NA_PLATAFORMA','EMAIL','TELEFONE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MENSAGEM_NA_PLATAFORMA',
    situacao                ENUM('ENVIADA','EM_ANALISE','ACEITA','RECUSADA','CANCELADA','CONCLUIDA') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ENVIADA',
    resposta                VARCHAR(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    id_usuario_resposta     INT UNSIGNED DEFAULT NULL,
    data_resposta           DATETIME     DEFAULT NULL,
    id_conversa             INT UNSIGNED DEFAULT NULL,
    data_criacao            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_solicitacao),
    KEY idx_sol_instituicao (id_instituicao, situacao),
    KEY idx_sol_solicitante (id_usuario_solicitante),
    CONSTRAINT fk_sol_instituicao FOREIGN KEY (id_instituicao) REFERENCES instituicao (id_instituicao)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_sol_servico FOREIGN KEY (id_servico) REFERENCES instituicao_servico (id_servico)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_sol_crianca FOREIGN KEY (id_crianca) REFERENCES crianca (id_crianca)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_sol_solicitante FOREIGN KEY (id_usuario_solicitante) REFERENCES usuario (id_usuario)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_sol_resposta FOREIGN KEY (id_usuario_resposta) REFERENCES usuario (id_usuario)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_sol_conversa FOREIGN KEY (id_conversa) REFERENCES conversa (id_conversa)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT chk_sol_resposta CHECK (situacao NOT IN ('ACEITA','RECUSADA') OR (id_usuario_resposta IS NOT NULL AND data_resposta IS NOT NULL))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Perfil de necessidades da pessoa acompanhada (todas as informações são opcionais)
CREATE TABLE IF NOT EXISTS perfil_necessidades (
    id_crianca                   INT UNSIGNED NOT NULL,
    condicoes_informadas         VARCHAR(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    necessidades_acompanhamento  VARCHAR(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    preferencias_sensoriais      VARCHAR(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    observacoes_sensoriais       VARCHAR(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    comunicacao_preferida        ENUM('ESCRITA','FALADA','VISUAL','COMUNICACAO_ALTERNATIVA','SEM_PREFERENCIA') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SEM_PREFERENCIA',
    necessidades_acessibilidade  VARCHAR(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    observacoes_acompanhamento   TEXT         COLLATE utf8mb4_unicode_ci,
    municipio                    VARCHAR(80)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    uf                           CHAR(2)      COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    somente_gratuito             TINYINT(1)   NOT NULL DEFAULT 0,
    modalidade_preferida         ENUM('PRESENCIAL','ONLINE','DOMICILIAR','SEM_PREFERENCIA') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SEM_PREFERENCIA',
    id_usuario_atualizacao       INT UNSIGNED NOT NULL,
    data_atualizacao             DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_crianca),
    CONSTRAINT fk_pn_crianca FOREIGN KEY (id_crianca) REFERENCES crianca (id_crianca)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_pn_usuario FOREIGN KEY (id_usuario_atualizacao) REFERENCES usuario (id_usuario)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Profissionais autorizados a acompanhar a pessoa (uma pessoa pode ter vários)
CREATE TABLE IF NOT EXISTS crianca_profissional (
    id_crianca_profissional INT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_crianca              INT UNSIGNED NOT NULL,
    id_profissional         INT UNSIGNED NOT NULL,
    funcao                  VARCHAR(80)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    status                  ENUM('ATIVO','ENCERRADO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ATIVO',
    data_inicio             DATE         NOT NULL,
    data_fim                DATE         DEFAULT NULL,
    id_usuario_cadastro     INT UNSIGNED NOT NULL,
    data_cadastro           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_crianca_profissional),
    UNIQUE KEY uk_crianca_profissional (id_crianca, id_profissional),
    KEY idx_cp_profissional (id_profissional, status),
    CONSTRAINT fk_cp_crianca FOREIGN KEY (id_crianca) REFERENCES crianca (id_crianca)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_cp_profissional FOREIGN KEY (id_profissional) REFERENCES profissional (id_profissional)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_cp_usuario FOREIGN KEY (id_usuario_cadastro) REFERENCES usuario (id_usuario)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT chk_cp_datas CHECK (data_fim IS NULL OR data_fim >= data_inicio)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Conta da própria pessoa acompanhada (perfil PESSOA_ACOMPANHADA)
CREATE TABLE IF NOT EXISTS crianca_usuario (
    id_crianca    INT UNSIGNED NOT NULL,
    id_usuario    INT UNSIGNED NOT NULL,
    data_vinculo  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_crianca),
    UNIQUE KEY uk_cu_usuario (id_usuario),
    CONSTRAINT fk_cu_crianca FOREIGN KEY (id_crianca) REFERENCES crianca (id_crianca)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_cu_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Registro estruturado da sessão (1:1 com ATENDIMENTO). Não substitui o relatório:
-- organiza o que foi trabalhado. Não contém diagnóstico gerado pelo sistema.
CREATE TABLE IF NOT EXISTS registro_sessao (
    id_atendimento          INT UNSIGNED NOT NULL,
    tipo_atendimento        VARCHAR(80)  COLLATE utf8mb4_unicode_ci NOT NULL,
    objetivos_trabalhados   TEXT         COLLATE utf8mb4_unicode_ci,
    evolucao_observada      TEXT         COLLATE utf8mb4_unicode_ci,
    dificuldades_observadas TEXT         COLLATE utf8mb4_unicode_ci,
    recomendacoes           TEXT         COLLATE utf8mb4_unicode_ci,
    proximos_passos         TEXT         COLLATE utf8mb4_unicode_ci,
    id_usuario_registro     INT UNSIGNED NOT NULL,
    data_registro           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    id_usuario_atualizacao  INT UNSIGNED DEFAULT NULL,
    data_atualizacao        DATETIME     DEFAULT NULL,
    PRIMARY KEY (id_atendimento),
    CONSTRAINT fk_rs_atendimento FOREIGN KEY (id_atendimento) REFERENCES atendimento (id_atendimento)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_rs_usuario FOREIGN KEY (id_usuario_registro) REFERENCES usuario (id_usuario)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_rs_usuario_atual FOREIGN KEY (id_usuario_atualizacao) REFERENCES usuario (id_usuario)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
