-- =====================================================================
-- V1 - Esquema base do EcoConnect (32 tabelas), extraído de
-- database/EcoConnect_backup_final.sql SEM os comandos destrutivos.
--  * DROP TABLE, CREATE DATABASE/USE e LOCK TABLES foram removidos;
--  * CREATE TABLE virou CREATE TABLE IF NOT EXISTS.
-- Em um banco que já tem as 32 tabelas, o Flyway NÃO executa este arquivo:
-- ele registra a versão 1 como linha de base (baseline) e aplica só V2 em diante.
-- =====================================================================
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS `agendamento` (
  `id_agendamento` int unsigned NOT NULL AUTO_INCREMENT,
  `id_crianca` int unsigned NOT NULL,
  `id_usuario_solicitante` int unsigned NOT NULL,
  `data_hora_inicio_solicitada` datetime NOT NULL,
  `data_hora_fim_solicitada` datetime DEFAULT NULL,
  `observacao_solicitacao` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('SOLICITADO','EM_ANALISE','CONFIRMADO','RECUSADO','CANCELADO','AUSENTE','REALIZADO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SOLICITADO',
  `data_hora_inicio` datetime DEFAULT NULL,
  `data_hora_fim` datetime DEFAULT NULL,
  `id_usuario_confirmacao` int unsigned DEFAULT NULL,
  `data_confirmacao` datetime DEFAULT NULL,
  `data_solicitacao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_agendamento`),
  UNIQUE KEY `id_agendamento` (`id_agendamento`,`status`),
  KEY `fk_ag_crianca` (`id_crianca`),
  KEY `fk_ag_solicitante` (`id_usuario_solicitante`),
  KEY `fk_ag_confirmacao` (`id_usuario_confirmacao`),
  CONSTRAINT `fk_ag_confirmacao` FOREIGN KEY (`id_usuario_confirmacao`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_ag_crianca` FOREIGN KEY (`id_crianca`) REFERENCES `crianca` (`id_crianca`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_ag_solicitante` FOREIGN KEY (`id_usuario_solicitante`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_ag_confirmacao` CHECK (((`status` not in (_utf8mb4'CONFIRMADO',_utf8mb4'AUSENTE',_utf8mb4'REALIZADO')) or ((`data_hora_inicio` is not null) and (`id_usuario_confirmacao` is not null)))),
  CONSTRAINT `chk_ag_horario` CHECK (((`data_hora_fim` is null) or (`data_hora_fim` > `data_hora_inicio`))),
  CONSTRAINT `chk_ag_horario_solicitado` CHECK (((`data_hora_fim_solicitada` is null) or (`data_hora_fim_solicitada` > `data_hora_inicio_solicitada`)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `agendamento_profissional` (
  `id_agendamento` int unsigned NOT NULL,
  `id_profissional` int unsigned NOT NULL,
  `id_usuario_designacao` int unsigned NOT NULL,
  `data_designacao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_agendamento`,`id_profissional`),
  KEY `fk_apg_profissional` (`id_profissional`),
  KEY `fk_apg_usuario` (`id_usuario_designacao`),
  CONSTRAINT `fk_apg_agendamento` FOREIGN KEY (`id_agendamento`) REFERENCES `agendamento` (`id_agendamento`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_apg_profissional` FOREIGN KEY (`id_profissional`) REFERENCES `profissional` (`id_profissional`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_apg_usuario` FOREIGN KEY (`id_usuario_designacao`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `atendimento` (
  `id_atendimento` int unsigned NOT NULL AUTO_INCREMENT,
  `id_agendamento` int unsigned NOT NULL,
  `status_agendamento_ref` enum('REALIZADO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'REALIZADO',
  `data_hora_inicio_real` datetime NOT NULL,
  `data_hora_fim_real` datetime DEFAULT NULL,
  `observacoes_gerais` text COLLATE utf8mb4_unicode_ci,
  `id_usuario_registro` int unsigned NOT NULL,
  `data_registro` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_atendimento`),
  UNIQUE KEY `id_agendamento` (`id_agendamento`),
  KEY `fk_at_agendamento` (`id_agendamento`,`status_agendamento_ref`),
  KEY `fk_at_usuario` (`id_usuario_registro`),
  CONSTRAINT `fk_at_agendamento` FOREIGN KEY (`id_agendamento`, `status_agendamento_ref`) REFERENCES `agendamento` (`id_agendamento`, `status`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_at_usuario` FOREIGN KEY (`id_usuario_registro`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_at_horario` CHECK (((`data_hora_fim_real` is null) or (`data_hora_fim_real` >= `data_hora_inicio_real`)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `atendimento_atividade` (
  `id_atendimento` int unsigned NOT NULL,
  `id_atividade` smallint unsigned NOT NULL,
  `duracao_minutos` smallint unsigned DEFAULT NULL,
  `observacao` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_atendimento`,`id_atividade`),
  KEY `fk_aa_atividade` (`id_atividade`),
  CONSTRAINT `fk_aa_atendimento` FOREIGN KEY (`id_atendimento`) REFERENCES `atendimento` (`id_atendimento`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_aa_atividade` FOREIGN KEY (`id_atividade`) REFERENCES `atividade` (`id_atividade`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_aa_duracao` CHECK (((`duracao_minutos` is null) or (`duracao_minutos` > 0)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `atendimento_profissional` (
  `id_atendimento` int unsigned NOT NULL,
  `id_profissional` int unsigned NOT NULL,
  `funcao_no_atendimento` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_atendimento`,`id_profissional`),
  KEY `fk_ap_profissional` (`id_profissional`),
  CONSTRAINT `fk_ap_atendimento` FOREIGN KEY (`id_atendimento`) REFERENCES `atendimento` (`id_atendimento`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_ap_profissional` FOREIGN KEY (`id_profissional`) REFERENCES `profissional` (`id_profissional`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `atividade` (
  `id_atividade` smallint unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_atividade`),
  UNIQUE KEY `nome` (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `auditoria` (
  `id_auditoria` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int unsigned DEFAULT NULL,
  `id_crianca` int unsigned DEFAULT NULL,
  `acao` enum('LOGIN','LOGIN_FALHA','LOGOUT','CONSULTA','CRIACAO','ATUALIZACAO','EXCLUSAO_LOGICA','VALIDACAO','LIBERACAO') COLLATE utf8mb4_unicode_ci NOT NULL,
  `tabela_afetada` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_registro_afetado` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valores_anteriores` json DEFAULT NULL,
  `valores_novos` json DEFAULT NULL,
  `ip_origem` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_hora` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_auditoria`),
  KEY `fk_aud_usuario` (`id_usuario`),
  KEY `fk_aud_crianca` (`id_crianca`),
  CONSTRAINT `fk_aud_crianca` FOREIGN KEY (`id_crianca`) REFERENCES `crianca` (`id_crianca`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_aud_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `avaliacao_indicador` (
  `id_avaliacao` int unsigned NOT NULL AUTO_INCREMENT,
  `id_objetivo` int unsigned NOT NULL,
  `id_indicador` int unsigned NOT NULL,
  `id_profissional_avaliador` int unsigned NOT NULL,
  `id_atendimento` int unsigned DEFAULT NULL,
  `data_avaliacao` date NOT NULL,
  `valor_numerico` decimal(10,2) DEFAULT NULL,
  `valor_qualitativo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacao` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `situacao` enum('VIGENTE','SUBSTITUIDA') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'VIGENTE',
  `id_avaliacao_substituida` int unsigned DEFAULT NULL,
  `data_registro` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_avaliacao`),
  KEY `idx_ai_serie` (`id_objetivo`,`id_indicador`,`data_avaliacao`),
  KEY `fk_ai_profissional` (`id_profissional_avaliador`),
  KEY `fk_ai_atendimento` (`id_atendimento`),
  KEY `fk_ai_substituida` (`id_avaliacao_substituida`),
  CONSTRAINT `fk_ai_atendimento` FOREIGN KEY (`id_atendimento`) REFERENCES `atendimento` (`id_atendimento`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_ai_objetivo_indicador` FOREIGN KEY (`id_objetivo`, `id_indicador`) REFERENCES `objetivo_indicador` (`id_objetivo`, `id_indicador`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_ai_profissional` FOREIGN KEY (`id_profissional_avaliador`) REFERENCES `profissional` (`id_profissional`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_ai_substituida` FOREIGN KEY (`id_avaliacao_substituida`) REFERENCES `avaliacao_indicador` (`id_avaliacao`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_ai_valor` CHECK (((`valor_numerico` is not null) or (`valor_qualitativo` is not null)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `comunicado` (
  `id_comunicado` int unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario_criador` int unsigned NOT NULL,
  `titulo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensagem` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_comunicado` enum('GERAL','ALTERACAO_ATIVIDADE','OUTRO') COLLATE utf8mb4_unicode_ci NOT NULL,
  `abrangencia` enum('TODOS','GRUPO','ESPECIFICO') COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao_grupo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `situacao` enum('RASCUNHO','PUBLICADO','CANCELADO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'RASCUNHO',
  `data_criacao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_publicacao` datetime DEFAULT NULL,
  PRIMARY KEY (`id_comunicado`),
  KEY `fk_com_usuario` (`id_usuario_criador`),
  CONSTRAINT `fk_com_usuario` FOREIGN KEY (`id_usuario_criador`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `comunicado_destinatario` (
  `id_comunicado` int unsigned NOT NULL,
  `id_responsavel` int unsigned NOT NULL,
  `data_leitura` datetime DEFAULT NULL,
  PRIMARY KEY (`id_comunicado`,`id_responsavel`),
  KEY `fk_cd_responsavel` (`id_responsavel`),
  CONSTRAINT `fk_cd_comunicado` FOREIGN KEY (`id_comunicado`) REFERENCES `comunicado` (`id_comunicado`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_cd_responsavel` FOREIGN KEY (`id_responsavel`) REFERENCES `responsavel` (`id_responsavel`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `condicao_saude` (
  `id_condicao_saude` int unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_condicao_saude`),
  UNIQUE KEY `nome` (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `consentimento` (
  `id_consentimento` int unsigned NOT NULL AUTO_INCREMENT,
  `id_crianca` int unsigned NOT NULL,
  `id_responsavel` int unsigned NOT NULL,
  `finalidade` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `versao_termo` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `situacao_autorizacao` enum('REGISTRADA','REVOGADA','EXPIRADA') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'REGISTRADA',
  `data_autorizacao` datetime NOT NULL,
  `data_revogacao` datetime DEFAULT NULL,
  `data_validade` date DEFAULT NULL,
  `id_documento` int unsigned DEFAULT NULL,
  `base_legal_avaliada` enum('NAO_AVALIADA','CONSENTIMENTO','TUTELA_DA_SAUDE','OBRIGACAO_LEGAL','OUTRA') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NAO_AVALIADA',
  `id_usuario_avaliacao_base` int unsigned DEFAULT NULL,
  `data_avaliacao_base` datetime DEFAULT NULL,
  `id_usuario_registro` int unsigned NOT NULL,
  `data_registro` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_consentimento`),
  KEY `fk_cons_responsavel` (`id_responsavel`),
  KEY `fk_cons_usuario_avaliacao` (`id_usuario_avaliacao_base`),
  KEY `fk_cons_usuario_registro` (`id_usuario_registro`),
  KEY `fk_cons_documento` (`id_crianca`,`id_documento`),
  CONSTRAINT `fk_cons_crianca` FOREIGN KEY (`id_crianca`) REFERENCES `crianca` (`id_crianca`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_cons_documento` FOREIGN KEY (`id_crianca`, `id_documento`) REFERENCES `documento` (`id_crianca`, `id_documento`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_cons_responsavel` FOREIGN KEY (`id_responsavel`) REFERENCES `responsavel` (`id_responsavel`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_cons_usuario_avaliacao` FOREIGN KEY (`id_usuario_avaliacao_base`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_cons_usuario_registro` FOREIGN KEY (`id_usuario_registro`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `consentimento_chk_1` CHECK (((`situacao_autorizacao` <> _utf8mb4'REVOGADA') or (`data_revogacao` is not null))),
  CONSTRAINT `consentimento_chk_2` CHECK (((`base_legal_avaliada` = _utf8mb4'NAO_AVALIADA') or ((`id_usuario_avaliacao_base` is not null) and (`data_avaliacao_base` is not null))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `crianca` (
  `id_crianca` int unsigned NOT NULL AUTO_INCREMENT,
  `nome_completo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_nascimento` date NOT NULL,
  `sexo` enum('F','M','NAO_INFORMADO') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cpf` char(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_ingresso_ecocura` date DEFAULT NULL,
  `situacao_ecocura` enum('EM_ANALISE','AGUARDANDO_VAGA','ATIVA','CICLO_ENCERRADO','INATIVA') COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cadastro` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_atualizacao` datetime NOT NULL,
  PRIMARY KEY (`id_crianca`),
  UNIQUE KEY `cpf` (`cpf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `crianca_condicao` (
  `id_crianca_condicao` int unsigned NOT NULL AUTO_INCREMENT,
  `id_crianca` int unsigned NOT NULL,
  `id_condicao_saude` int unsigned NOT NULL,
  `data_inicio` date DEFAULT NULL,
  `data_fim` date DEFAULT NULL,
  `precisao_data` enum('DIA','MES','ANO','DESCONHECIDA') COLLATE utf8mb4_unicode_ci NOT NULL,
  `origem_informacao` enum('DECLARADO_FAMILIA','DOCUMENTO_ANEXADO','PROFISSIONAL_ECOCURA') COLLATE utf8mb4_unicode_ci NOT NULL,
  `situacao_validacao` enum('DECLARADO','EM_VALIDACAO','VALIDADO','REJEITADO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DECLARADO',
  `id_documento` int unsigned DEFAULT NULL,
  `observacao` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_usuario_registro` int unsigned NOT NULL,
  `data_registro` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario_validacao` int unsigned DEFAULT NULL,
  `data_validacao` datetime DEFAULT NULL,
  PRIMARY KEY (`id_crianca_condicao`),
  KEY `idx_cc_crianca_condicao` (`id_crianca`,`id_condicao_saude`),
  KEY `fk_cc_condicao` (`id_condicao_saude`),
  KEY `fk_cc_usuario_registro` (`id_usuario_registro`),
  KEY `fk_cc_usuario_validacao` (`id_usuario_validacao`),
  KEY `fk_cc_documento` (`id_crianca`,`id_documento`),
  CONSTRAINT `fk_cc_condicao` FOREIGN KEY (`id_condicao_saude`) REFERENCES `condicao_saude` (`id_condicao_saude`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_cc_crianca` FOREIGN KEY (`id_crianca`) REFERENCES `crianca` (`id_crianca`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_cc_documento` FOREIGN KEY (`id_crianca`, `id_documento`) REFERENCES `documento` (`id_crianca`, `id_documento`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_cc_usuario_registro` FOREIGN KEY (`id_usuario_registro`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_cc_usuario_validacao` FOREIGN KEY (`id_usuario_validacao`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_cc_data` CHECK (((`data_fim` is null) or (`data_inicio` is null) or (`data_fim` >= `data_inicio`))),
  CONSTRAINT `chk_cc_validacao` CHECK (((`situacao_validacao` <> _utf8mb4'VALIDADO') or ((`id_usuario_validacao` is not null) and (`data_validacao` is not null))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `crianca_diagnostico` (
  `id_crianca_diagnostico` int unsigned NOT NULL AUTO_INCREMENT,
  `id_crianca` int unsigned NOT NULL,
  `id_diagnostico` int unsigned NOT NULL,
  `data_diagnostico` date DEFAULT NULL,
  `precisao_data` enum('DIA','MES','ANO','DESCONHECIDA') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DIA',
  `profissional_origem` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `origem_informacao` enum('DECLARADO_FAMILIA','DOCUMENTO_ANEXADO','PROFISSIONAL_ECOCURA') COLLATE utf8mb4_unicode_ci NOT NULL,
  `situacao_validacao` enum('DECLARADO','EM_VALIDACAO','VALIDADO','REJEITADO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DECLARADO',
  `id_documento` int unsigned DEFAULT NULL,
  `observacao` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_usuario_registro` int unsigned NOT NULL,
  `data_registro` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario_validacao` int unsigned DEFAULT NULL,
  `data_validacao` datetime DEFAULT NULL,
  PRIMARY KEY (`id_crianca_diagnostico`),
  UNIQUE KEY `id_crianca_diagnostico` (`id_crianca_diagnostico`,`id_crianca`),
  UNIQUE KEY `id_crianca` (`id_crianca`,`id_diagnostico`,`data_diagnostico`),
  KEY `fk_cd_diagnostico` (`id_diagnostico`),
  KEY `fk_cd_usuario_registro` (`id_usuario_registro`),
  KEY `fk_cd_usuario_validacao` (`id_usuario_validacao`),
  KEY `fk_cd_documento` (`id_crianca`,`id_documento`),
  CONSTRAINT `fk_cd_crianca` FOREIGN KEY (`id_crianca`) REFERENCES `crianca` (`id_crianca`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_cd_diagnostico` FOREIGN KEY (`id_diagnostico`) REFERENCES `diagnostico` (`id_diagnostico`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_cd_documento` FOREIGN KEY (`id_crianca`, `id_documento`) REFERENCES `documento` (`id_crianca`, `id_documento`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_cd_usuario_registro` FOREIGN KEY (`id_usuario_registro`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_cd_usuario_validacao` FOREIGN KEY (`id_usuario_validacao`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_cd_validacao` CHECK (((`situacao_validacao` <> _utf8mb4'VALIDADO') or ((`id_usuario_validacao` is not null) and (`data_validacao` is not null))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `crianca_responsavel` (
  `id_crianca_responsavel` int unsigned NOT NULL AUTO_INCREMENT,
  `id_crianca` int unsigned NOT NULL,
  `id_responsavel` int unsigned NOT NULL,
  `parentesco` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `responsavel_principal` tinyint(1) NOT NULL DEFAULT '0',
  `pode_consultar_dados` tinyint(1) NOT NULL DEFAULT '1',
  `pode_solicitar_agendamento` tinyint(1) NOT NULL DEFAULT '1',
  `status` enum('ATIVO','REVOGADO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ATIVO',
  `data_inicio` date NOT NULL,
  `data_fim` date DEFAULT NULL,
  `id_usuario_cadastro` int unsigned NOT NULL,
  PRIMARY KEY (`id_crianca_responsavel`),
  UNIQUE KEY `id_crianca` (`id_crianca`,`id_responsavel`),
  KEY `fk_cr_responsavel` (`id_responsavel`),
  KEY `fk_cr_usuario` (`id_usuario_cadastro`),
  CONSTRAINT `fk_cr_crianca` FOREIGN KEY (`id_crianca`) REFERENCES `crianca` (`id_crianca`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_cr_responsavel` FOREIGN KEY (`id_responsavel`) REFERENCES `responsavel` (`id_responsavel`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_cr_usuario` FOREIGN KEY (`id_usuario_cadastro`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `diagnostico` (
  `id_diagnostico` int unsigned NOT NULL AUTO_INCREMENT,
  `codigo_cid` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nome` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_diagnostico`),
  UNIQUE KEY `codigo_cid` (`codigo_cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `documento` (
  `id_documento` int unsigned NOT NULL AUTO_INCREMENT,
  `id_crianca` int unsigned NOT NULL,
  `tipo_documento` enum('LAUDO','EXAME','RELATORIO_EXTERNO','DECLARACAO','TERMO_ASSINADO','OUTRO') COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_documento` date DEFAULT NULL,
  `nome_arquivo_original` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_mime` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tamanho_bytes` bigint unsigned DEFAULT NULL,
  `hash_sha256` char(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chave_armazenamento` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `origem_informacao` enum('DECLARADO_FAMILIA','DOCUMENTO_ANEXADO','PROFISSIONAL_ECOCURA') COLLATE utf8mb4_unicode_ci NOT NULL,
  `situacao_validacao` enum('NAO_CONFERIDO','CONFERIDO','REJEITADO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NAO_CONFERIDO',
  `situacao_documento` enum('VIGENTE','SUBSTITUIDO','REMOVIDO_LOGICAMENTE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'VIGENTE',
  `id_documento_substituido` int unsigned DEFAULT NULL,
  `id_usuario_upload` int unsigned NOT NULL,
  `data_upload` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_documento`),
  UNIQUE KEY `chave_armazenamento` (`chave_armazenamento`),
  UNIQUE KEY `id_crianca` (`id_crianca`,`id_documento`),
  KEY `fk_doc_substituido` (`id_documento_substituido`),
  KEY `fk_doc_usuario` (`id_usuario_upload`),
  CONSTRAINT `fk_doc_crianca` FOREIGN KEY (`id_crianca`) REFERENCES `crianca` (`id_crianca`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_doc_substituido` FOREIGN KEY (`id_documento_substituido`) REFERENCES `documento` (`id_documento`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_doc_usuario` FOREIGN KEY (`id_usuario_upload`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `especialidade` (
  `id_especialidade` smallint unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_especialidade`),
  UNIQUE KEY `nome` (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `fila_espera` (
  `id_fila_espera` int unsigned NOT NULL AUTO_INCREMENT,
  `id_crianca` int unsigned NOT NULL,
  `id_usuario_solicitante` int unsigned NOT NULL,
  `data_solicitacao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `observacao_solicitacao` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `situacao` enum('SOLICITADA','EM_ANALISE','AGUARDANDO_VAGA','CONVOCADA','INGRESSOU','DESISTENTE','NAO_ACEITA') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SOLICITADA',
  `criterios_institucionais` text COLLATE utf8mb4_unicode_ci,
  `justificativa_decisao` text COLLATE utf8mb4_unicode_ci,
  `nivel_prioridade` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_usuario_analise` int unsigned DEFAULT NULL,
  `data_analise` datetime DEFAULT NULL,
  PRIMARY KEY (`id_fila_espera`),
  KEY `fk_fe_crianca` (`id_crianca`),
  KEY `fk_fe_solicitante` (`id_usuario_solicitante`),
  KEY `fk_fe_analise` (`id_usuario_analise`),
  CONSTRAINT `fk_fe_analise` FOREIGN KEY (`id_usuario_analise`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_fe_crianca` FOREIGN KEY (`id_crianca`) REFERENCES `crianca` (`id_crianca`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_fe_solicitante` FOREIGN KEY (`id_usuario_solicitante`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_fe_analise` CHECK (((`situacao` not in (_utf8mb4'AGUARDANDO_VAGA',_utf8mb4'CONVOCADA',_utf8mb4'NAO_ACEITA')) or ((`id_usuario_analise` is not null) and (`data_analise` is not null) and (`justificativa_decisao` is not null))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `historico_agendamento` (
  `id_historico_agendamento` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_agendamento` int unsigned NOT NULL,
  `status_anterior` enum('SOLICITADO','EM_ANALISE','CONFIRMADO','RECUSADO','CANCELADO','AUSENTE','REALIZADO') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_novo` enum('SOLICITADO','EM_ANALISE','CONFIRMADO','RECUSADO','CANCELADO','AUSENTE','REALIZADO') COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_hora_inicio_anterior` datetime DEFAULT NULL,
  `data_hora_inicio_novo` datetime DEFAULT NULL,
  `motivo` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_usuario` int unsigned NOT NULL,
  `data_hora_alteracao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_historico_agendamento`),
  KEY `fk_ha_agendamento` (`id_agendamento`),
  KEY `fk_ha_usuario` (`id_usuario`),
  CONSTRAINT `fk_ha_agendamento` FOREIGN KEY (`id_agendamento`) REFERENCES `agendamento` (`id_agendamento`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_ha_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `historico_saude` (
  `id_historico_saude` int unsigned NOT NULL AUTO_INCREMENT,
  `id_crianca` int unsigned NOT NULL,
  `tipo_evento` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `data_evento` date NOT NULL,
  `data_evento_fim` date DEFAULT NULL,
  `precisao_data` enum('DIA','MES','ANO','DESCONHECIDA') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DIA',
  `instituicao_origem` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_crianca_diagnostico` int unsigned DEFAULT NULL,
  `id_documento` int unsigned DEFAULT NULL,
  `origem_informacao` enum('DECLARADO_FAMILIA','DOCUMENTO_ANEXADO','PROFISSIONAL_ECOCURA') COLLATE utf8mb4_unicode_ci NOT NULL,
  `situacao_validacao` enum('DECLARADO','EM_VALIDACAO','VALIDADO','REJEITADO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DECLARADO',
  `situacao_registro` enum('ATIVO','SUBSTITUIDO','REMOVIDO_LOGICAMENTE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ATIVO',
  `id_historico_saude_substituido` int unsigned DEFAULT NULL,
  `id_usuario_registro` int unsigned NOT NULL,
  `data_registro` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario_validacao` int unsigned DEFAULT NULL,
  `data_validacao` datetime DEFAULT NULL,
  PRIMARY KEY (`id_historico_saude`),
  KEY `fk_hs_diagnostico` (`id_crianca_diagnostico`,`id_crianca`),
  KEY `fk_hs_substituido` (`id_historico_saude_substituido`),
  KEY `fk_hs_usuario_registro` (`id_usuario_registro`),
  KEY `fk_hs_usuario_validacao` (`id_usuario_validacao`),
  KEY `fk_hs_documento` (`id_crianca`,`id_documento`),
  CONSTRAINT `fk_hs_crianca` FOREIGN KEY (`id_crianca`) REFERENCES `crianca` (`id_crianca`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_hs_diagnostico` FOREIGN KEY (`id_crianca_diagnostico`, `id_crianca`) REFERENCES `crianca_diagnostico` (`id_crianca_diagnostico`, `id_crianca`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_hs_documento` FOREIGN KEY (`id_crianca`, `id_documento`) REFERENCES `documento` (`id_crianca`, `id_documento`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_hs_substituido` FOREIGN KEY (`id_historico_saude_substituido`) REFERENCES `historico_saude` (`id_historico_saude`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_hs_usuario_registro` FOREIGN KEY (`id_usuario_registro`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_hs_usuario_validacao` FOREIGN KEY (`id_usuario_validacao`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `historico_saude_chk_1` CHECK (((`data_evento_fim` is null) or (`data_evento_fim` >= `data_evento`))),
  CONSTRAINT `historico_saude_chk_2` CHECK (((`situacao_validacao` <> _utf8mb4'VALIDADO') or ((`id_usuario_validacao` is not null) and (`data_validacao` is not null))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `indicador` (
  `id_indicador` int unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_medida` enum('NUMERICA','QUALITATIVA') COLLATE utf8mb4_unicode_ci NOT NULL,
  `unidade_medida` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_indicador`),
  UNIQUE KEY `nome` (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `notificacao` (
  `id_notificacao` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario_destinatario` int unsigned NOT NULL,
  `tipo_notificacao` enum('AGENDAMENTO','RELATORIO_LIBERADO','COMUNICADO','FILA_ESPERA','OUTRO') COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensagem` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_comunicado` int unsigned DEFAULT NULL,
  `id_agendamento` int unsigned DEFAULT NULL,
  `id_relatorio` int unsigned DEFAULT NULL,
  `data_criacao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_leitura` datetime DEFAULT NULL,
  PRIMARY KEY (`id_notificacao`),
  KEY `fk_not_usuario` (`id_usuario_destinatario`),
  KEY `fk_not_comunicado` (`id_comunicado`),
  KEY `fk_not_agendamento` (`id_agendamento`),
  KEY `fk_not_relatorio` (`id_relatorio`),
  CONSTRAINT `fk_not_agendamento` FOREIGN KEY (`id_agendamento`) REFERENCES `agendamento` (`id_agendamento`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_not_comunicado` FOREIGN KEY (`id_comunicado`) REFERENCES `comunicado` (`id_comunicado`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_not_relatorio` FOREIGN KEY (`id_relatorio`) REFERENCES `relatorio_atendimento` (`id_relatorio`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_not_usuario` FOREIGN KEY (`id_usuario_destinatario`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_not_origem` CHECK (((((`id_comunicado` is not null) + (`id_agendamento` is not null)) + (`id_relatorio` is not null)) <= 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `objetivo` (
  `id_objetivo` int unsigned NOT NULL AUTO_INCREMENT,
  `id_crianca` int unsigned NOT NULL,
  `id_profissional_definidor` int unsigned NOT NULL,
  `titulo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `data_inicio` date NOT NULL,
  `data_prevista_fim` date DEFAULT NULL,
  `data_encerramento` date DEFAULT NULL,
  `situacao` enum('EM_ANDAMENTO','CICLO_ENCERRADO','CANCELADO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'EM_ANDAMENTO',
  `data_cadastro` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_objetivo`),
  KEY `fk_obj_crianca` (`id_crianca`),
  KEY `fk_obj_profissional` (`id_profissional_definidor`),
  CONSTRAINT `fk_obj_crianca` FOREIGN KEY (`id_crianca`) REFERENCES `crianca` (`id_crianca`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_obj_profissional` FOREIGN KEY (`id_profissional_definidor`) REFERENCES `profissional` (`id_profissional`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_obj_data` CHECK (((`data_prevista_fim` is null) or (`data_prevista_fim` >= `data_inicio`)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `objetivo_indicador` (
  `id_objetivo` int unsigned NOT NULL,
  `id_indicador` int unsigned NOT NULL,
  `valor_referencia_inicial` decimal(10,2) DEFAULT NULL,
  `meta_valor` decimal(10,2) DEFAULT NULL,
  `descricao_meta` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_vinculo` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_objetivo`,`id_indicador`),
  KEY `fk_oi_indicador` (`id_indicador`),
  CONSTRAINT `fk_oi_indicador` FOREIGN KEY (`id_indicador`) REFERENCES `indicador` (`id_indicador`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_oi_objetivo` FOREIGN KEY (`id_objetivo`) REFERENCES `objetivo` (`id_objetivo`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `perfil` (
  `id_perfil` tinyint unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_perfil`),
  UNIQUE KEY `nome` (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `profissional` (
  `id_profissional` int unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int unsigned NOT NULL,
  `conselho_profissional` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registro_profissional` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_profissional`),
  UNIQUE KEY `id_usuario` (`id_usuario`),
  UNIQUE KEY `conselho_profissional` (`conselho_profissional`,`registro_profissional`),
  CONSTRAINT `fk_profissional_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `profissional_especialidade` (
  `id_profissional` int unsigned NOT NULL,
  `id_especialidade` smallint unsigned NOT NULL,
  `principal` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_profissional`,`id_especialidade`),
  KEY `fk_pe_especialidade` (`id_especialidade`),
  CONSTRAINT `fk_pe_especialidade` FOREIGN KEY (`id_especialidade`) REFERENCES `especialidade` (`id_especialidade`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_pe_profissional` FOREIGN KEY (`id_profissional`) REFERENCES `profissional` (`id_profissional`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `relatorio_atendimento` (
  `id_relatorio` int unsigned NOT NULL AUTO_INCREMENT,
  `id_atendimento` int unsigned NOT NULL,
  `id_profissional_autor` int unsigned NOT NULL,
  `titulo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conteudo` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `situacao` enum('RASCUNHO','FINALIZADO','LIBERADO_RESPONSAVEL','SUBSTITUIDO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'RASCUNHO',
  `numero_versao` smallint unsigned NOT NULL DEFAULT '1',
  `id_relatorio_substituido` int unsigned DEFAULT NULL,
  `data_elaboracao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_finalizacao` datetime DEFAULT NULL,
  PRIMARY KEY (`id_relatorio`),
  KEY `fk_ra_participante` (`id_atendimento`,`id_profissional_autor`),
  KEY `fk_ra_substituido` (`id_relatorio_substituido`),
  CONSTRAINT `fk_ra_participante` FOREIGN KEY (`id_atendimento`, `id_profissional_autor`) REFERENCES `atendimento_profissional` (`id_atendimento`, `id_profissional`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_ra_substituido` FOREIGN KEY (`id_relatorio_substituido`) REFERENCES `relatorio_atendimento` (`id_relatorio`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_ra_finalizacao` CHECK (((`situacao` not in (_utf8mb4'FINALIZADO',_utf8mb4'LIBERADO_RESPONSAVEL',_utf8mb4'SUBSTITUIDO')) or (`data_finalizacao` is not null))),
  CONSTRAINT `chk_ra_versao` CHECK ((`numero_versao` >= 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `responsavel` (
  `id_responsavel` int unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int unsigned NOT NULL,
  `cpf` char(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_responsavel`),
  UNIQUE KEY `id_usuario` (`id_usuario`),
  UNIQUE KEY `cpf` (`cpf`),
  CONSTRAINT `fk_responsavel_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `usuario` (
  `id_usuario` int unsigned NOT NULL AUTO_INCREMENT,
  `id_perfil` tinyint unsigned NOT NULL,
  `nome_completo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `senha_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('PENDENTE_ATIVACAO','ATIVO','BLOQUEADO','INATIVO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDENTE_ATIVACAO',
  `data_cadastro` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_ultimo_acesso` datetime DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_usuario_perfil` (`id_perfil`),
  CONSTRAINT `fk_usuario_perfil` FOREIGN KEY (`id_perfil`) REFERENCES `perfil` (`id_perfil`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
