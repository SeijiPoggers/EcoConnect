-- =====================================================================
-- V2 - Autenticação real, preferências de interface e perfis adicionais.
-- Somente acréscimos: nenhuma coluna existente é removida ou renomeada.
-- =====================================================================

-- Troca obrigatória de senha (administrador inicial e senhas redefinidas)
ALTER TABLE usuario
    ADD COLUMN exige_troca_senha TINYINT(1) NOT NULL DEFAULT 0 AFTER status;

-- Sessões de login. Guarda apenas o HASH SHA-256 do token (o token em si
-- fica só no cookie HttpOnly do navegador). Sessões não são apagadas:
-- logout e expiração preenchem data_revogacao/data_expiracao.
CREATE TABLE IF NOT EXISTS sessao_usuario (
    id_sessao       BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_usuario      INT UNSIGNED    NOT NULL,
    token_hash      CHAR(64)        COLLATE utf8mb4_unicode_ci NOT NULL,
    data_criacao    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_expiracao  DATETIME        NOT NULL,
    data_ultimo_uso DATETIME        DEFAULT NULL,
    data_revogacao  DATETIME        DEFAULT NULL,
    ip_origem       VARCHAR(45)     COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    agente_usuario  VARCHAR(255)    COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    PRIMARY KEY (id_sessao),
    UNIQUE KEY uk_sessao_token (token_hash),
    KEY idx_sessao_usuario (id_usuario, data_revogacao),
    CONSTRAINT fk_sessao_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Preferências de acessibilidade da interface, por usuário (WCAG 2.2)
CREATE TABLE IF NOT EXISTS preferencia_interface (
    id_usuario            INT UNSIGNED NOT NULL,
    baixo_estimulo        TINYINT(1)   NOT NULL DEFAULT 0,
    tamanho_fonte         ENUM('PADRAO','GRANDE','MUITO_GRANDE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PADRAO',
    alto_contraste        TINYINT(1)   NOT NULL DEFAULT 0,
    espacamento_leitura   TINYINT(1)   NOT NULL DEFAULT 0,
    reduzir_movimento     TINYINT(1)   NOT NULL DEFAULT 0,
    data_atualizacao      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_usuario),
    CONSTRAINT fk_pref_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Novos tipos de notificação (mensagens e solicitações de atendimento)
ALTER TABLE notificacao
    MODIFY COLUMN tipo_notificacao
        ENUM('AGENDAMENTO','RELATORIO_LIBERADO','COMUNICADO','FILA_ESPERA','OUTRO','MENSAGEM','SOLICITACAO')
        COLLATE utf8mb4_unicode_ci NOT NULL;

-- Perfis de acesso. Os três primeiros são os mesmos criados pela API original
-- (DadosIniciais); só são inseridos se ainda não existirem.
INSERT INTO perfil (nome, descricao)
    SELECT 'ADMINISTRADOR', 'Gestão do sistema e da equipe' FROM DUAL
    WHERE NOT EXISTS (SELECT 1 FROM perfil WHERE nome = 'ADMINISTRADOR');
INSERT INTO perfil (nome, descricao)
    SELECT 'PROFISSIONAL', 'Profissional da equipe Ecocura' FROM DUAL
    WHERE NOT EXISTS (SELECT 1 FROM perfil WHERE nome = 'PROFISSIONAL');
INSERT INTO perfil (nome, descricao)
    SELECT 'RESPONSAVEL', 'Responsável por uma ou mais crianças' FROM DUAL
    WHERE NOT EXISTS (SELECT 1 FROM perfil WHERE nome = 'RESPONSAVEL');
INSERT INTO perfil (nome, descricao)
    SELECT 'ADMIN_INSTITUCIONAL', 'Administra os serviços e as solicitações de uma instituição de apoio' FROM DUAL
    WHERE NOT EXISTS (SELECT 1 FROM perfil WHERE nome = 'ADMIN_INSTITUCIONAL');
INSERT INTO perfil (nome, descricao)
    SELECT 'PESSOA_ACOMPANHADA', 'A própria pessoa acompanhada, com acesso aos seus dados' FROM DUAL
    WHERE NOT EXISTS (SELECT 1 FROM perfil WHERE nome = 'PESSOA_ACOMPANHADA');
