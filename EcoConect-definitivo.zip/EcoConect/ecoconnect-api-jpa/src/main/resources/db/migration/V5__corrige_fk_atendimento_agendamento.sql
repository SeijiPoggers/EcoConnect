-- =====================================================================
-- V5: corrige a FK composta atendimento -> agendamento (RI-10).
-- atendimento.status_agendamento_ref era ENUM('REALIZADO'), enquanto agendamento.status
-- tem sete valores. O InnoDB compara colunas ENUM pela posição interna do valor
-- (1 de um lado, 7 do outro), então a FK recusava TODO atendimento, mesmo de
-- agendamentos REALIZADOS. Os dois ENUMs passam a ter a mesma lista, e um CHECK
-- mantém a regra de que só existe atendimento para agendamento REALIZADO.
-- =====================================================================

ALTER TABLE atendimento DROP FOREIGN KEY fk_at_agendamento;

ALTER TABLE atendimento
    MODIFY status_agendamento_ref
        ENUM('SOLICITADO','EM_ANALISE','CONFIRMADO','RECUSADO','CANCELADO','AUSENTE','REALIZADO')
        COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'REALIZADO';

ALTER TABLE atendimento
    ADD CONSTRAINT chk_at_status_ref CHECK (status_agendamento_ref = 'REALIZADO');

ALTER TABLE atendimento
    ADD CONSTRAINT fk_at_agendamento FOREIGN KEY (id_agendamento, status_agendamento_ref)
        REFERENCES agendamento (id_agendamento, status) ON DELETE RESTRICT ON UPDATE RESTRICT;
