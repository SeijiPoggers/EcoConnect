package br.com.ecoconnect.api.dominio;

import static org.junit.jupiter.api.Assertions.*;

import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.Test;

class LeitorCnesTest {

    @Test
    void leArquivoDoDatasusEmLatin1ComPontoEVirgula() throws Exception {
        String csv = "\"CO_UNIDADE\";\"CO_CNES\";\"NO_RAZAO_SOCIAL\";\"NO_FANTASIA\";\"NO_LOGRADOURO\";\"NU_ENDERECO\";\"NO_BAIRRO\";\"CO_CEP\";\"NU_TELEFONE\";\"NO_EMAIL\";\"TP_UNIDADE\";\"CO_ESTADO_GESTOR\";\"CO_MUNICIPIO_GESTOR\";\"NU_LATITUDE\";\"NU_LONGITUDE\"\n"
                + "\"3552200000001\";\"0000001\";\"PREFEITURA\";\"CAPS INFANTIL EXEMPLO\";\"RUA A\";\"10\";\"CENTRO\";\"18000000\";\"(15) 3000-0000\";\"\";\"70\";\"35\";\"355220\";\"-23,50\";\"-47,45\"\n"
                + "\"3552200000002\";\"0000002\";\"PREFEITURA\";\"UNIDADE BÁSICA EXEMPLO\";\"RUA B\";\"S/N\";\"VILA\";\"18000001\";\"\";\"\";\"02\";\"35\";\"355220\";\"\";\"\"\n"
                + "\"x\";\"\";\"\";\"SEM CODIGO\";\"\";\"\";\"\";\"\";\"\";\"\";\"02\";\"35\";\"355220\";\"\";\"\"\n";
        LeitorCnes.ResultadoLeitura r = LeitorCnes.ler(csv.getBytes(StandardCharsets.ISO_8859_1));
        assertEquals(3, r.linhasLidas());
        assertEquals(1, r.linhasIgnoradas());
        assertEquals(2, r.estabelecimentos().size());
        LeitorCnes.Estabelecimento caps = r.estabelecimentos().get(0);
        assertEquals("0000001", caps.codigoCnes());
        assertEquals("CAPS_INFANTIL", caps.categoria());
        assertEquals("SP", caps.uf());
        assertEquals("355220", caps.codigoMunicipio());
        assertEquals("-23.500000", caps.latitude().toPlainString());
        LeitorCnes.Estabelecimento ubs = r.estabelecimentos().get(1);
        assertEquals("UNIDADE BÁSICA EXEMPLO", ubs.nome());
        assertEquals("UBS", ubs.categoria());
        assertNull(ubs.latitude());
        assertTrue(r.avisos().get(0).contains("nome do município"));
    }

    @Test
    void leExportacaoEstadualComVirgulaENomesEmMinusculas() throws Exception {
        String csv = "cnes,nome_fantasia,codigo_ibge,municipio,uf,tipo_estabelecimento\n"
                + "1234567,\"CER II - Centro, Reabilitação\",5208707,Goiânia,GO,CLINICA/CENTRO DE ESPECIALIDADE\n";
        LeitorCnes.ResultadoLeitura r = LeitorCnes.ler(csv.getBytes(StandardCharsets.UTF_8));
        assertEquals(1, r.estabelecimentos().size());
        LeitorCnes.Estabelecimento e = r.estabelecimentos().get(0);
        assertEquals("CER", e.categoria());
        assertEquals("520870", e.codigoMunicipio());
        assertEquals("Goiânia", e.municipio());
    }

    @Test
    void rejeitaCabecalhoDesconhecido() {
        assertThrows(IllegalArgumentException.class, () -> LeitorCnes.ler("a;b;c\n1;2;3\n".getBytes(StandardCharsets.UTF_8)));
    }

    @Test
    void categorias() {
        assertEquals("CAPS", LeitorCnes.categoria(70, null, "CAPS II MUNICIPAL"));
        assertEquals("CAPS", LeitorCnes.categoria(70, null, "CAPS I SAO JOAO"));
        assertEquals("CAPS_AD", LeitorCnes.categoria(70, null, "CAPS AD III"));
        assertEquals("CAPS_INFANTIL", LeitorCnes.categoria(70, null, "CAPS IJ CENTRO"));
        assertEquals("CAPS_INFANTIL", LeitorCnes.categoria(null, null, "CAPSi Vila Nova"));
        assertEquals("UBS", LeitorCnes.categoria(2, null, "ESF JARDIM"));
        assertEquals("CER", LeitorCnes.categoria(36, null, "CENTRO ESPECIALIZADO EM REABILITACAO"));
        assertEquals("HOSPITAL", LeitorCnes.categoria(5, null, "SANTA CASA"));
        assertEquals("OUTRO", LeitorCnes.categoria(36, null, "CLINICA ORTOPEDICA"));
    }
}
