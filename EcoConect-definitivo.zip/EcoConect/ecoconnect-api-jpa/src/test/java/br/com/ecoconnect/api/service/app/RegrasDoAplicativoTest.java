package br.com.ecoconnect.api.service.app;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import br.com.ecoconnect.api.dominio.PoliticaAcesso;
import br.com.ecoconnect.api.exception.RegraNegocioException;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

/** Regras puras dos serviços do aplicativo (sem banco). */
class RegrasDoAplicativoTest {

    @Test
    void validaCodigosDosVocabulariosDaRede() {
        assertEquals("EQUOTERAPIA", RedeService.validar(" equoterapia ", RedeService.TIPOS_SERVICO, "serviço"));
        assertNull(RedeService.validar("  ", RedeService.TIPOS_SERVICO, "serviço"));
        assertThrows(RegraNegocioException.class, () -> RedeService.validar("MAGIA", RedeService.TIPOS_SERVICO, "serviço"));
    }

    @Test
    void normalizaBooleanosDoMySql() {
        assertTrue(RedeService.bool(1));
        assertTrue(RedeService.bool(Boolean.TRUE));
        assertFalse(RedeService.bool(0));
        assertTrue(RedeService.bool("1"));
        assertNull(RedeService.bool(null));
    }

    @Test
    void rotulosDasSolicitacoes() {
        assertEquals("Em análise", SolicitacaoService.rotulo("EM_ANALISE"));
        assertEquals("Aceita", SolicitacaoService.rotulo("ACEITA"));
        assertEquals("OUTRA", SolicitacaoService.rotulo("OUTRA"));
    }

    @Test
    void guiaDoSusExplicaCadaPortaDeEntrada() {
        SusService s = new SusService(null, null, null);
        Map<String, Object> g = s.guia();
        assertEquals(5, ((List<?>) g.get("portas")).size(), "portas de entrada");
        assertTrue(((List<?>) g.get("caminhos")).size() >= 4, "situações passo a passo");
        assertTrue(String.valueOf(g.get("aviso")).contains("não substituem"), "aviso de que não é orientação clínica");
        assertTrue(String.valueOf(SusService.guiaDaCategoria("CER").get("comoAcessar")).contains("encaminhamento"));
        assertTrue(String.valueOf(SusService.guiaDaCategoria("CAPS_INFANTIL").get("comoAcessar")).contains("sem encaminhamento"));
    }

    @Test
    void rotasNovasNaPoliticaDeAcesso() {
        assertEquals(PoliticaAcesso.Decisao.PUBLICA, PoliticaAcesso.decidir("POST", "/api/auth/cadastro", null));
        assertEquals(PoliticaAcesso.Decisao.PUBLICA, PoliticaAcesso.decidir("GET", "/api/saude", null));
        assertEquals(PoliticaAcesso.Decisao.EXIGE_LOGIN, PoliticaAcesso.decidir("GET", "/api/app/painel", null));
        assertEquals(PoliticaAcesso.Decisao.NEGADA, PoliticaAcesso.decidir("GET", "/api/admin/usuarios", "RESPONSAVEL"));
        assertEquals(PoliticaAcesso.Decisao.NEGADA, PoliticaAcesso.decidir("GET", "/api/relatorios/sessoes", "RESPONSAVEL"));
        assertEquals(PoliticaAcesso.Decisao.NEGADA, PoliticaAcesso.decidir("GET", "/api/fhir/Patient/1", "RESPONSAVEL"));
        assertEquals(PoliticaAcesso.Decisao.PERMITIDA, PoliticaAcesso.decidir("GET", "/api/fhir/Patient/1", "PROFISSIONAL"));
        assertEquals(PoliticaAcesso.Decisao.NEGADA, PoliticaAcesso.decidir("POST", "/api/sus/importacao", "PROFISSIONAL"));
        assertEquals(PoliticaAcesso.Decisao.PERMITIDA, PoliticaAcesso.decidir("POST", "/api/sus/importacao", "ADMINISTRADOR"));
        assertEquals(PoliticaAcesso.Decisao.NEGADA, PoliticaAcesso.decidir("POST", "/api/rede/instituicoes/1/servicos", "RESPONSAVEL"));
        assertEquals(PoliticaAcesso.Decisao.PERMITIDA, PoliticaAcesso.decidir("PATCH", "/api/rede/instituicoes/1/vagas", "ADMIN_INSTITUCIONAL"));
        assertEquals(PoliticaAcesso.Decisao.NEGADA, PoliticaAcesso.decidir("GET", "/api/criancas/1", "ADMIN_INSTITUCIONAL"));
    }
}
