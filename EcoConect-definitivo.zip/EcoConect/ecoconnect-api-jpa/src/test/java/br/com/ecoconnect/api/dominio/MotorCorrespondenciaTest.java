package br.com.ecoconnect.api.dominio;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Test;

class MotorCorrespondenciaTest {

    private static MotorCorrespondencia.Perfil perfil(Integer idade, boolean gratuito) {
        return new MotorCorrespondencia.Perfil(idade, Set.of("TEA"), "São Paulo", "SP", gratuito, "PRESENCIAL",
                Set.of("BAIXO_ESTIMULO"), "ESCRITA", Set.of("SENSIVEL_A_SONS"), Set.of());
    }

    private static MotorCorrespondencia.Candidata inst(long id, String municipio, Integer min, Integer max,
                                                       boolean gratuito, Set<String> condicoes, Set<String> acess) {
        return new MotorCorrespondencia.Candidata(id, "Inst " + id, municipio, "SP", min, max, condicoes,
                Set.of("PRESENCIAL"), acess, gratuito, false, 3, true, true, Set.of("PSICOLOGIA"));
    }

    @Test
    void excluiForaDaFaixaEtaria() {
        assertNull(MotorCorrespondencia.avaliar(perfil(6, false), inst(1, "Sao Paulo", 12, 18, true, Set.of("TEA"), Set.of())));
        assertNotNull(MotorCorrespondencia.avaliar(perfil(6, false), inst(1, "Sao Paulo", 3, 12, true, Set.of("TEA"), Set.of())));
    }

    @Test
    void excluiPagaQuandoPerfilPedeSomenteGratuito() {
        assertNull(MotorCorrespondencia.avaliar(perfil(6, true), inst(1, "Campinas", null, null, false, Set.of("TEA"), Set.of())));
    }

    @Test
    void explicaOsMotivosSemLinguagemClinica() {
        MotorCorrespondencia.Resultado r = MotorCorrespondencia.avaliar(perfil(6, false),
                inst(2, "SAO PAULO", 2, 12, true, Set.of("TEA", "TDAH"), Set.of("BAIXO_ESTIMULO", "COMUNICACAO_ESCRITA")));
        assertNotNull(r);
        String texto = String.join(" ", r.motivos());
        assertTrue(texto.contains("Transtorno do Espectro Autista"), texto);
        assertTrue(texto.contains("mesmo município"), texto);
        assertTrue(texto.contains("mensagem escrita"), texto);
        assertTrue(r.pontuacao() > 70, "pontuação " + r.pontuacao());
        assertFalse(texto.toLowerCase().contains("diagnóstico"));
    }

    @Test
    void ordenaPorPontuacaoELimita() {
        List<MotorCorrespondencia.Resultado> lista = MotorCorrespondencia.recomendar(perfil(6, false), List.of(
                inst(1, "Campinas", null, null, false, Set.of(), Set.of()),
                inst(2, "São Paulo", 2, 12, true, Set.of("TEA"), Set.of("BAIXO_ESTIMULO")),
                inst(3, "Santos", 2, 12, true, Set.of("TEA"), Set.of())), 2);
        assertEquals(2, lista.size());
        assertEquals(2L, lista.get(0).idInstituicao());
    }

    @Test
    void avisaQuandoNaoHaVagas() {
        MotorCorrespondencia.Candidata semVaga = new MotorCorrespondencia.Candidata(9, "X", "São Paulo", "SP", null, null,
                Set.of("TEA"), Set.of(), Set.of(), true, false, 0, false, true, Set.of());
        MotorCorrespondencia.Resultado r = MotorCorrespondencia.avaliar(perfil(6, false), semVaga);
        assertTrue(String.join(" ", r.atencao()).contains("Sem vagas"));
        assertTrue(String.join(" ", r.atencao()).contains("faixa etária"));
    }

    @Test
    void calculaIdade() {
        assertEquals(6, MotorCorrespondencia.idade(LocalDate.of(2020, 5, 10), LocalDate.of(2026, 11, 8)));
        assertEquals(5, MotorCorrespondencia.idade(LocalDate.of(2020, 12, 10), LocalDate.of(2026, 11, 8)));
    }
}
