package br.com.ecoconnect.api.dominio;

import static br.com.ecoconnect.api.dominio.PoliticaAcesso.Decisao.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PoliticaAcessoTest {

    private static PoliticaAcesso.Decisao d(String m, String c, String p) {
        return PoliticaAcesso.decidir(m, c, p);
    }

    @Test
    void rotasPublicasNaoExigemLogin() {
        assertEquals(PUBLICA, d("POST", "/api/auth/login", null));
        assertEquals(PUBLICA, d("GET", "/api/saude", null));
        assertEquals(PUBLICA, d("OPTIONS", "/api/criancas", null));
    }

    @Test
    void semSessaoExigeLogin() {
        assertEquals(EXIGE_LOGIN, d("GET", "/api/criancas", null));
        assertEquals(EXIGE_LOGIN, d("GET", "/api/app/painel", null));
        assertEquals(EXIGE_LOGIN, d("GET", "/api/rota-inexistente", null));
    }

    @Test
    void administradorAcessaRotasAdministrativas() {
        assertEquals(PERMITIDA, d("GET", "/api/usuarios", Papeis.ADMINISTRADOR));
        assertEquals(PERMITIDA, d("PATCH", "/api/usuarios/3/status", Papeis.ADMINISTRADOR));
        assertEquals(PERMITIDA, d("GET", "/api/auditoria", Papeis.ADMINISTRADOR));
        assertEquals(PERMITIDA, d("POST", "/api/sus/importacoes/cnes", Papeis.ADMINISTRADOR));
    }

    @Test
    void responsavelNaoAcessaDadosDeOutrasPessoasPelaApiOriginal() {
        assertEquals(NEGADA, d("GET", "/api/criancas", Papeis.RESPONSAVEL));
        assertEquals(NEGADA, d("GET", "/api/historicos-saude/1", Papeis.RESPONSAVEL));
        assertEquals(NEGADA, d("GET", "/api/usuarios", Papeis.RESPONSAVEL));
        assertEquals(NEGADA, d("GET", "/api/notificacoes", Papeis.RESPONSAVEL));
        assertEquals(NEGADA, d("GET", "/api/auditoria", Papeis.PROFISSIONAL));
    }

    @Test
    void familiaUsaRotasProprias() {
        assertEquals(PERMITIDA, d("GET", "/api/app/pessoas", Papeis.RESPONSAVEL));
        assertEquals(PERMITIDA, d("POST", "/api/agendamentos", Papeis.RESPONSAVEL));
        assertEquals(PERMITIDA, d("PATCH", "/api/agendamentos/7/status", Papeis.RESPONSAVEL));
        assertEquals(NEGADA, d("PUT", "/api/agendamentos/7", Papeis.RESPONSAVEL));
        assertEquals(PERMITIDA, d("GET", "/api/responsaveis/2/relatorios", Papeis.RESPONSAVEL));
        assertEquals(NEGADA, d("GET", "/api/responsaveis/2", Papeis.RESPONSAVEL));
    }

    @Test
    void catalogosSaoLidosPorTodosEAlteradosSoPeloAdministrador() {
        assertEquals(PERMITIDA, d("GET", "/api/atividades", Papeis.PESSOA_ACOMPANHADA));
        assertEquals(PERMITIDA, d("GET", "/api/atividades/3", Papeis.RESPONSAVEL));
        assertEquals(NEGADA, d("POST", "/api/atividades", Papeis.PROFISSIONAL));
        assertEquals(PERMITIDA, d("POST", "/api/atividades", Papeis.ADMINISTRADOR));
    }

    @Test
    void redeDeApoio() {
        assertEquals(PERMITIDA, d("GET", "/api/rede/instituicoes", Papeis.RESPONSAVEL));
        assertEquals(NEGADA, d("POST", "/api/rede/instituicoes", Papeis.RESPONSAVEL));
        assertEquals(PERMITIDA, d("PUT", "/api/rede/instituicoes/4", Papeis.ADMIN_INSTITUCIONAL));
        assertEquals(NEGADA, d("GET", "/api/criancas", Papeis.ADMIN_INSTITUCIONAL));
        assertEquals(PUBLICA, d("GET", "/api/rede/catalogos", null));
    }

    @Test
    void profissionalUsaApiOriginalComEscopo() {
        assertEquals(PERMITIDA, d("GET", "/api/criancas/5", Papeis.PROFISSIONAL));
        assertEquals(PERMITIDA, d("POST", "/api/atendimentos", Papeis.PROFISSIONAL));
        assertEquals(NEGADA, d("POST", "/api/profissionais", Papeis.PROFISSIONAL));
    }

    @Test
    void casamentoDePadroes() {
        assertTrue(PoliticaAcesso.casaPadrao("/api/**", "/api/a/b/c"));
        assertTrue(PoliticaAcesso.casaPadrao("/api/x/**", "/api/x"));
        assertTrue(PoliticaAcesso.casaPadrao("/api/agendamentos/*/status", "/api/agendamentos/10/status"));
        assertFalse(PoliticaAcesso.casaPadrao("/api/agendamentos/*/status", "/api/agendamentos/10/historico"));
        assertEquals("/api/x", PoliticaAcesso.normalizar("/api//x/?a=1"));
    }
}
