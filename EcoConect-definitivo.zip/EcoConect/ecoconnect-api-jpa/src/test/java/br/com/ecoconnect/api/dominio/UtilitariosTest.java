package br.com.ecoconnect.api.dominio;

import static org.junit.jupiter.api.Assertions.*;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

class UtilitariosTest {

    @Test
    void tokensSaoUnicosEHashTemTamanhoFixo() {
        String a = Tokens.novoToken();
        String b = Tokens.novoToken();
        assertNotEquals(a, b);
        assertEquals(43, a.length());
        assertEquals(64, Tokens.sha256Hex(a).length());
        assertEquals(Tokens.sha256Hex(a), Tokens.sha256Hex(a));
        String s = Tokens.senhaTemporaria();
        assertTrue(s.matches(".*[A-Za-z].*") && s.matches(".*\\d.*") && s.length() >= 8);
    }

    @Test
    void limitadorBloqueiaAposCincoFalhasEDesbloqueiaDepoisDaJanela() {
        Instant[] agora = {Instant.parse("2026-11-08T10:00:00Z")};
        Clock relogio = new Clock() {
            public java.time.ZoneId getZone() { return ZoneOffset.UTC; }
            public Clock withZone(java.time.ZoneId z) { return this; }
            public Instant instant() { return agora[0]; }
        };
        LimitadorTentativas l = new LimitadorTentativas(5, Duration.ofMinutes(15), relogio);
        for (int i = 0; i < 4; i++) l.registrarFalha("a@b|1.1.1.1");
        assertFalse(l.bloqueado("a@b|1.1.1.1"));
        l.registrarFalha("a@b|1.1.1.1");
        assertTrue(l.bloqueado("a@b|1.1.1.1"));
        assertFalse(l.bloqueado("outro|1.1.1.1"));
        agora[0] = agora[0].plus(Duration.ofMinutes(16));
        assertFalse(l.bloqueado("a@b|1.1.1.1"));
    }

    @Test
    void conflitoDeHorario() {
        LocalDateTime nove = LocalDateTime.of(2026, 11, 9, 9, 0);
        assertTrue(ConflitoHorario.sobrepoe(nove, nove.plusHours(1), nove.plusMinutes(30), nove.plusMinutes(90)));
        assertFalse(ConflitoHorario.sobrepoe(nove, nove.plusHours(1), nove.plusHours(1), nove.plusHours(2)));
        assertTrue(ConflitoHorario.sobrepoe(nove, null, nove.plusMinutes(40), null));
        assertFalse(ConflitoHorario.sobrepoe(nove, null, nove.plusMinutes(50), null));
    }

    @Test
    void csvProtegeContraFormulasEUsaPontoEVirgula() {
        String csv = new EscritorCsv().linha("Nome", "Obs").linha("=HYPERLINK(1)", "a;b \"c\"").linha(true, null).toString();
        assertTrue(csv.startsWith("\uFEFFNome;Obs\r\n"));
        assertTrue(csv.contains("'=HYPERLINK(1);\"a;b \"\"c\"\"\""));
        assertTrue(csv.contains("sim;\r\n"));
    }

    @Test
    void codigosValidamVocabulario() {
        assertEquals("TEA,TDAH", Codigos.normalizar(" tea, TDAH ,tea", Codigos.CONDICOES, "condições"));
        assertNull(Codigos.normalizar("  ", Codigos.CONDICOES, "condições"));
        assertThrows(IllegalArgumentException.class, () -> Codigos.normalizar("XYZ", Codigos.CONDICOES, "condições"));
    }

    @Test
    void fhirMinimizaDadosDoPaciente() {
        Map<String, Object> semCpf = MapeadorFhir.patient(7, "Pessoa Teste", java.time.LocalDate.of(2020, 1, 2), "F", "12345678901", false);
        assertEquals("Patient", semCpf.get("resourceType"));
        assertEquals("female", semCpf.get("gender"));
        assertEquals(1, ((List<?>) semCpf.get("identifier")).size());
        Map<String, Object> comCpf = MapeadorFhir.patient(7, "Pessoa Teste", null, null, "12345678901", true);
        assertEquals(2, ((List<?>) comCpf.get("identifier")).size());
        assertEquals("unknown", comCpf.get("gender"));
        Map<String, Object> sr = MapeadorFhir.serviceRequest(3, "CANCELADA", 7L, "Organization/inst-1", "Psicologia", "Olá", null);
        assertEquals("revoked", sr.get("status"));
        assertEquals("order", sr.get("intent"));
    }
}
