> **Versão definitiva (EcoConect):** este documento descreve a API original e continua válido para as rotas `/api/...` dos 32 recursos originais. A instalação, a autenticação e os módulos novos estão no [README principal](../README.md) e em [`../docs/`](../docs/). Diferenças importantes: o banco agora é criado e atualizado pelas **migrations do Flyway** (sem rodar o script SQL à mão). Todas as rotas exigem **login** (sessão em cookie ou `Authorization: Bearer <token>` obtido em `POST /api/auth/token`). O cabeçalho `X-Usuario-Id` foi **desativado**. As permissões por perfil e por pessoa são verificadas no servidor.

# EcoConnect API — Spring Data JPA + MySQL

API REST em Java que faz a **ponte** entre o front-end do EcoConnect e o banco MySQL `ecoconnect`.

```
Front-end ──HTTP/JSON──► Controllers ──► Services (regras) ──► Repositories (Spring Data JPA) ──► MySQL
```

- **Banco respeitado à risca:** as 32 tabelas, colunas, tipos, ENUMs, chaves e CHECKs vêm do script `database/EcoConnect_backup_final.sql`. As 32 entidades JPA foram geradas a partir dele, com os mesmos nomes.
- **A API nunca altera a estrutura** (`spring.jpa.hibernate.ddl-auto=none`): só lê e grava dados.
- **Regras da modelagem implementadas:** as do documento *EcoConnect — Modelagem de Dados* (RI-01 a RI-21 e seção E.3), incluindo as que o MySQL não impõe sozinho.

| Item | Versão |
|---|---|
| Java | 17 ou superior |
| Spring Boot | 3.3.5 (Spring Data JPA, Hibernate 6, Bean Validation) |
| MySQL | 8.0.16 ou superior (o script foi gerado no 8.0.46) |
| Maven | 3.8 ou superior (NetBeans, IntelliJ e Eclipse já trazem) |

---

## 1. Como rodar

### 1.1 Banco de dados

No **MySQL Workbench**: *File → Open SQL Script* → `database/EcoConnect_backup_final.sql` → executar (raio ⚡).
Ou no terminal: `mysql -u root -p < database/EcoConnect_backup_final.sql`

> O script começa com `DROP TABLE IF EXISTS`: rodar de novo **apaga os dados** existentes.

### 1.2 Configurar o acesso ao MySQL

O jeito mais simples é preencher `ecoconnect.properties`, na pasta acima deste projeto (o Console usa o mesmo arquivo; veja `LEIA-ME.md`). As variáveis de ambiente abaixo têm prioridade sobre ele (não coloque a senha real no Git):

| Variável | Padrão | Para quê |
|---|---|---|
| `DB_HOST` | `localhost` | servidor MySQL |
| `DB_PORT` | `3306` | porta |
| `DB_NAME` | `ecoconnect` | nome do banco |
| `DB_USER` | `root` | usuário |
| `DB_PASSWORD` | *(vazio)* | senha |
| `PORT` | `8080` | porta da API |
| `ADMIN_EMAIL` / `ADMIN_SENHA` | *(vazio)* | cria o 1º administrador (ATIVO) se o banco não tiver usuários |
| `CORS_ORIGENS` | `*` | endereços do front-end autorizados (ex.: `http://localhost:5173`) |

Como definir:

- **NetBeans:** botão direito no projeto → *Properties* → *Actions* → *Run project* → em *Set Properties* adicione `Env.DB_PASSWORD=suasenha` (uma por linha; idem para `Env.ADMIN_EMAIL` e `Env.ADMIN_SENHA`).
- **IntelliJ:** *Run → Edit Configurations → Environment variables*.
- **Terminal (Windows PowerShell):** `$env:DB_PASSWORD="suasenha"`
- **Terminal (Linux/Mac):** `export DB_PASSWORD=suasenha`

### 1.3 Executar

```bash
mvn spring-boot:run
```

No NetBeans: *File → Open Project* → pasta `ecoconnect-api-jpa` → *Run* (F6). Na primeira vez o Maven baixa as dependências (precisa de internet).

Pronto quando aparecer `Started EcoConnectApiApplication`. Ao subir, a API:

- cria os perfis **ADMINISTRADOR, PROFISSIONAL e RESPONSAVEL** se a tabela `perfil` estiver vazia;
- cria o administrador inicial, se `ADMIN_EMAIL` e `ADMIN_SENHA` estiverem definidos e não houver usuários.

### 1.4 Testar

- **Swagger (pelo navegador):** http://localhost:8080/swagger-ui.html, com todas as rotas e botão *Try it out*.
- **Roteiro pronto:** `testes-api.http` percorre o fluxo completo (usuários → criança → agendamento → atendimento → relatório → evolução → auditoria). Abra no VS Code (extensão *REST Client*) ou no IntelliJ.

---

## 2. Rotas

Todas começam com `/api`. Listagens são paginadas e aceitam filtros pelo nome do campo:

```
GET /api/criancas?nomeCompleto=pedro&situacaoEcocura=ATIVA&page=0&size=20&sort=nomeCompleto,asc
```

Nos filtros, texto é "contém" (sem diferenciar maiúsculas) e os demais tipos comparam igualdade. A resposta vem no formato `{ "conteudo": [...], "pagina", "tamanho", "totalElementos", "totalPaginas" }`.

### Acesso e pessoas

| Recurso | Rotas | DELETE faz |
|---|---|---|
| Login | `POST /auth/login` `{email, senha}` | — |
| Perfis | `GET/POST /perfis`, `GET/PUT/DELETE /perfis/{id}` | exclui (os 3 perfis-base são protegidos) |
| Usuários | `GET/POST /usuarios`, `GET/PUT/DELETE /usuarios/{id}`, `PATCH /usuarios/{id}/status`, `PATCH /usuarios/{id}/senha` | status = INATIVO |
| Responsáveis | `GET/POST /responsaveis`, `GET/PUT/DELETE /responsaveis/{id}`, `GET /responsaveis/{id}/relatorios` | exclui (o banco bloqueia se houver vínculos) |
| Profissionais | `GET/POST /profissionais`, `GET/PUT/DELETE /profissionais/{id}` | ativo = 0 |
| Especialidades do profissional | `GET/POST /profissionais/{id}/especialidades`, `PUT/DELETE .../{idEspecialidade}` | remove o vínculo |
| Especialidades | `GET/POST /especialidades`, `GET/PUT/DELETE /especialidades/{id}` | exclui (se não estiver em uso) |
| Crianças | `GET/POST /criancas`, `GET/PUT/DELETE /criancas/{id}` | situacao_ecocura = INATIVA |
| Vínculos criança–responsável | `GET/POST /criancas-responsaveis`, `GET/PUT/DELETE /criancas-responsaveis/{id}` | status = REVOGADO + data_fim |

### Saúde, documentos e consentimento

| Recurso | Rotas | DELETE |
|---|---|---|
| Diagnósticos / Condições (catálogos) | `/diagnosticos`, `/condicoes-saude` (CRUD) | ativo = 0 |
| Diagnósticos da criança | `GET/POST /criancas-diagnosticos`, `GET/PUT /{id}`, `PATCH /{id}/validacao` | não existe |
| Condições da criança | `GET/POST /criancas-condicoes`, `GET/PUT /{id}`, `PATCH /{id}/validacao` | não existe |
| Histórico de saúde | `GET/POST /historicos-saude`, `GET /{id}`, `POST /{id}/substituicao`, `PATCH /{id}/validacao` | REMOVIDO_LOGICAMENTE |
| Documentos (metadados) | `GET/POST /documentos`, `GET /{id}`, `POST /{id}/substituicao`, `PATCH /{id}/conferencia` | REMOVIDO_LOGICAMENTE |
| Consentimentos | `GET/POST /consentimentos`, `GET /{id}`, `PATCH /{id}/revogacao`, `/expiracao`, `/base-legal` | não existe |

### Agenda e atendimentos

| Recurso | Rotas |
|---|---|
| Agendamentos | `GET/POST /agendamentos`, `GET/PUT /{id}`, `PATCH /{id}/status`, `GET /{id}/historico` |
| Profissionais previstos | `GET/POST /agendamentos/{id}/profissionais`, `DELETE .../{idProfissional}` |
| Histórico de agendamento | `GET /historicos-agendamento`, `GET /{id}` (somente leitura) |
| Atendimentos | `GET/POST /atendimentos`, `GET/PUT /{id}` |
| Participantes do atendimento | `GET/POST /atendimentos/{id}/profissionais`, `POST .../importar-do-agendamento`, `PUT/DELETE .../{idProfissional}` |
| Atividades do atendimento | `GET/POST /atendimentos/{id}/atividades`, `PUT/DELETE .../{idAtividade}` |
| Atividades (catálogo) | `/atividades` (CRUD; DELETE = ativo 0) |
| Relatórios | `GET/POST /relatorios-atendimento`, `GET/PUT /{id}`, `PATCH /{id}/finalizacao`, `PATCH /{id}/liberacao`, `POST /{id}/nova-versao` |

### Evolução, entrada e comunicação

| Recurso | Rotas |
|---|---|
| Objetivos | `/objetivos` (CRUD; DELETE = CANCELADO), `PATCH /objetivos/{id}/encerramento` |
| Indicadores (catálogo) | `/indicadores` (CRUD; DELETE = ativo 0) |
| Indicadores do objetivo | `GET/POST /objetivos/{id}/indicadores`, `PUT/DELETE .../{idIndicador}`, `GET .../{idIndicador}/serie` |
| Avaliações | `GET/POST /avaliacoes-indicador`, `GET /{id}`, `POST /{id}/substituicao` |
| Fila de espera | `GET/POST /fila-espera`, `GET /{id}`, `PATCH /{id}/analise` |
| Comunicados | `/comunicados` (CRUD só em RASCUNHO), `PATCH /{id}/publicacao`, `PATCH /{id}/cancelamento` |
| Destinatários | `GET/POST /comunicados/{id}/destinatarios`, `DELETE .../{idResponsavel}`, `PATCH .../{idResponsavel}/leitura` |
| Notificações | `GET/POST /notificacoes`, `GET /{id}`, `PATCH /{id}/leitura` |
| Auditoria | `GET /auditoria`, `GET /auditoria/{id}`, `POST /auditoria` (somente inserção) |

**Formato dos dados:** datas no formato `aaaa-mm-dd`, data e hora em `aaaa-mm-ddThh:mm:ss`. ENUMs com o valor exato do banco (`"ATIVA"`, `"DECLARADO_FAMILIA"`...). Um valor inválido devolve 400 com a lista dos valores aceitos.

---

## 3. Regras implementadas

| Regra | Como a API aplica |
|---|---|
| Senha nunca em texto puro | BCrypt em `usuario.senha_hash`; o hash nunca aparece no JSON nem pode ser usado como filtro |
| RI-02 / E.3: perfil coerente | `responsavel` só para usuário com perfil RESPONSAVEL, `profissional` só para PROFISSIONAL, nunca os dois; o perfil não pode mudar se houver cadastro complementar |
| E.3: um responsável principal | no máximo um responsável principal ATIVO por criança |
| E.3: quem solicita agendamento | responsável precisa de vínculo ATIVO com `pode_solicitar_agendamento = 1`; a equipe pode solicitar por qualquer criança |
| RI-04: informação de saúde | nasce DECLARADO; validação por alguém da equipe (`PATCH .../validacao`); registro VALIDADO não é editado |
| RI-07: documento da mesma criança | documento citado em diagnóstico, condição, histórico ou consentimento precisa ser da mesma criança |
| RI-08 / RI-09: agendamento | CONFIRMADO exige data/hora e usuário da equipe; **toda** mudança de status ou horário grava HISTORICO_AGENDAMENTO |
| RI-10 / RI-11: atendimento | só para agendamento REALIZADO e no máximo um por agendamento |
| RI-12 / RI-13: relatório | autor precisa ter participado do atendimento; o responsável só vê relatório LIBERADO (`/responsaveis/{id}/relatorios`, equivalente à `VW_RELATORIO_RESPONSAVEL`) |
| RI-14 / RI-15: avaliação | só de indicador vinculado ao objetivo; o valor precisa casar com o tipo do indicador; correção por substituição, nunca UPDATE |
| RI-16: fila de espera | sem pontuação; AGUARDANDO_VAGA, CONVOCADA e NAO_ACEITA exigem analista e justificativa |
| RI-20: sem exclusão física de saúde | DELETE é lógico (ativo, status ou situação) ou inexistente, conforme a tabela (ver seção 2) |
| RI-21 e auditoria | toda criação, alteração, exclusão lógica, validação e liberação grava AUDITORIA com os valores anteriores e os novos em JSON; login grava LOGIN ou LOGIN_FALHA |
| Notificações | a API avisa o responsável quando o agendamento é confirmado, recusado ou cancelado, quando um relatório é liberado, quando a fila muda e quando um comunicado é publicado |

**Quem está agindo:** é o usuário autenticado (sessão ou token). Na versão definitiva, o cabeçalho `X-Usuario-Id` não é mais aceito, porque permitiria agir em nome de outra pessoa.

**Erros:** sempre no formato `{ "dataHora", "status", "erro", "mensagem", "campos" }`. Códigos usados:

- **400:** dados inválidos (`campos` traz o erro de cada campo).
- **401 / 403:** login incorreto, ou conta inativa ou pendente.
- **404:** registro não encontrado.
- **405:** operação não permitida, como DELETE em dado de saúde.
- **409:** e-mail repetido ou registro em uso.
- **422:** regra do EcoConnect ou CHECK do banco, com mensagem em português.
- **503:** MySQL fora do ar.

---

## 4. Organização do código

```
src/main/java/br/com/ecoconnect/api
├── EcoConnectApiApplication.java   classe principal
├── config/        CORS, BCrypt e dados iniciais (perfis e admin)
├── controller/    rotas REST (base/, catalogo/, pessoa/, saude/, agenda/, evolucao/, comunicacao/)
├── service/       regras de negócio (mesmas pastas) + AuditoriaService, Verificacoes, UsuarioAtual
├── repository/    32 interfaces Spring Data JPA (consultas derivadas e JPQL)
├── model/entity/  32 entidades + 6 classes de chave composta (@IdClass)
├── model/enums/   24 enums com os mesmos valores dos ENUMs do MySQL
├── dto/           objetos de entrada e saída que não são tabelas (login, mudança de status...)
└── exception/     erros padronizados e tradução das mensagens do MySQL
```

**Decisões de mapeamento:**

- **Chaves estrangeiras como campos de id** (`idCrianca`, `idUsuarioRegistro`...), e não como objetos `@ManyToOne`. O banco tem várias FKs compostas que reaproveitam colunas, como `(id_crianca, id_documento)`. Com campos de id elas são respeitadas sem gambiarras, o JSON fica simples e não há erro de carregamento preguiçoso (lazy).
- **Tipos:** `INT UNSIGNED` vira `Long`, `SMALLINT`/`TINYINT UNSIGNED` viram `Integer`, `TINYINT(1)` vira `Boolean`, `DECIMAL` vira `BigDecimal`, `DATE` vira `LocalDate` e `DATETIME` vira `LocalDateTime`.
- **Valores padrão** (`DEFAULT CURRENT_TIMESTAMP`, status iniciais) são preenchidos em `@PrePersist`, iguais aos do banco.

---

## 5. Divergências encontradas entre os arquivos

1. **RELATORIO_ATENDIMENTO:** o documento de modelagem cita `id_usuario_liberacao` e `data_liberacao`, mas essas colunas **não existem** no script do banco. A API segue o banco. Quem liberou e quando fica registrado na AUDITORIA (ação LIBERACAO).
2. **VW_RELATORIO_RESPONSAVEL:** a view do documento não está no script e usa `data_liberacao`, que não existe. A API oferece a mesma consulta em `GET /api/responsaveis/{id}/relatorios`, sem criar a view.
3. **Pontos "pendentes de validação" no documento:** a API adotou uma proposta para cada um, e cada um pode ser ajustado na classe indicada:
   - fluxo de status do agendamento: `AgendamentoService`;
   - quem valida diagnósticos (qualquer usuário da equipe): `Verificacoes.usuarioDaEquipe`;
   - grupo de comunicado (texto livre em `descricao_grupo`).

## 6. Limitações (próximos passos)

- **Autenticação:** resolvida na versão definitiva (sessões no banco com cookie HttpOnly, tokens para clientes de API, proteção CSRF, bloqueio por tentativas e troca obrigatória de senha).
- **Documentos:** a API grava só os metadados e a `chave_armazenamento`. O arquivo em si deve ir para um armazenamento seguro, como pede a modelagem.
- **Teste em ambiente real:** a API ainda não foi executada contra um MySQL real. O código foi compilado em Java 17 e as consultas foram conferidas contra as entidades, mas faça o roteiro de `testes-api.http` antes de usar.

## 7. Erros comuns

| Mensagem | Causa / solução |
|---|---|
| `Communications link failure` | MySQL desligado ou `DB_HOST`/`DB_PORT` errados |
| `Access denied for user` | `DB_USER`/`DB_PASSWORD` incorretos |
| `Unknown database 'ecoconnect'` | importe `database/EcoConnect_backup_final.sql` |
| `Table 'ecoconnect.xxx' doesn't exist` | script incompleto; importe de novo |
| `Port 8080 was already in use` | outra aplicação na porta: defina `PORT=8081` |
| Login responde "Conta pendente de ativação" | usuário novo nasce PENDENTE_ATIVACAO: `PATCH /api/usuarios/{id}/status` com `{"status":"ATIVO"}` |
