# Relatório de testes: EcoConect

## 1. Ambiente em que o pacote foi construído (leia antes)

O pacote foi produzido em um ambiente **sem Maven, sem internet, sem MySQL, sem navegador e sem PowerShell**. Por isso:

- tudo o que pôde ser executado aqui foi executado, e os resultados reais estão na seção 2;
- os testes que dependem do sistema completo em execução (Spring Boot + MySQL + navegador) **não foram executados aqui**. Eles estão automatizados e prontos para rodar na máquina de destino (seção 3).

Nenhum resultado abaixo foi estimado ou inventado.

## 2. Executado neste ambiente

| Verificação | Como | Resultado |
|---|---|---|
| Compilação da API (269 arquivos Java) | `javac` (JDK 21, alvo Java 17) contra bibliotecas substitutas das APIs do Spring, JPA, Jakarta e Jackson, porque não havia Maven | **0 erros** |
| Testes unitários (JUnit 5) | 30 testes: política de acesso, recomendação, leitura do CNES, FHIR, tokens, limitador de tentativas, conflito de horário, CSV, vocabulários, guia do SUS e rotas novas | **30 de 30 passaram** |
| Entidades × migrations | `ferramentas/verificacao/verificar_backend.py`: 46 entidades, todas as `@Column` existem nas tabelas criadas pelas migrations V1–V4 (49 tabelas, 435 colunas) | **0 erros** |
| Consultas derivadas dos repositórios | 53 métodos `findBy…`/`existsBy…`, cujas propriedades existem nas entidades | **0 erros** |
| SQL escrito à mão | 258 trechos de SQL (tabelas, `alias.coluna`, colunas de `INSERT` e `UPDATE`) conferidos com o esquema | **0 erros** |
| Ciclos entre componentes Spring | Grafo de 98 beans (o Spring Boot 3 recusa ciclos) | **0 ciclos** |
| Autoteste do verificador | 3 erros colocados de propósito (coluna de entidade, propriedade de repositório e coluna em SQL) | **3 de 3 detectados** |
| Contrato front-end × API | `verificar_contrato.py`: as 93 chamadas distintas do front-end existem entre as 251 rotas da API, com o mesmo método HTTP | **0 divergências** |
| Matriz de permissões | Classe real `PoliticaAcesso` × 5 perfis × 93 chamadas | Nenhuma chamada bloqueada para todos os perfis |
| Mapeamentos e nomes | Rotas ambíguas (inclusive o CRUD herdado) e beans com nome repetido | **Nenhum** |
| Sintaxe do front-end | `node --check` nos 16 arquivos JavaScript | **OK** |
| Funções da interface | `testar_interface.mjs`: formatação de datas, rótulos e booleanos do MySQL | **9 de 9 passaram** |
| Scripts Linux | `bash -n` e execução de `healthcheck.sh` e `stop.sh` (sem MySQL e sem API) | Mensagens corretas: Java encontrado, MySQL ausente e API parada |
| Teste ponta a ponta | `TesteFimAFim.java` compilado e executado contra uma porta fechada | Falha controlada (6 verificações falharam, como esperado, com saída de erro). **O sistema real não foi testado aqui** |
| Console Java | Compilação com substituto do jBCrypt | **0 erros** |

Para repetir as verificações estáticas: `ferramentas/verificacao/verificar_tudo.sh` (requer Python 3 e Node.js).

## 3. Não executado aqui: execute na máquina de destino

| O que falta testar | Como executar |
|---|---|
| Compilação com as bibliotecas reais e testes unitários pelo Maven (Surefire) | `setup.bat` (executa `mvn package` com os testes) |
| Subida do Spring Boot, migrations Flyway no MySQL, carga dos catálogos e dos dados de demonstração | `start.bat`. A tela "EcoConect em execução" mostra a versão das migrations |
| API, banco, permissões e fluxos completos | `healthcheck.bat -Completo` (Linux: `./healthcheck.sh --completo`) |
| Scripts do Windows (PowerShell), Docker e navegador | Uso normal e o roteiro manual da seção 4 |

O **teste ponta a ponta** (`ferramentas/teste/TesteFimAFim.java`) faz cerca de 50 verificações com as contas fictícias:

- **Sistema e login:** saúde da API e do banco, página publicada, 401 sem login e senha errada.
- **Segurança:** recusa de gravação sem o cabeçalho anti-CSRF e busca com tentativa de SQL injection.
- **Escopo de cada perfil:** o profissional não vê pessoa de fora; a família não vê outra família nem o histórico de alterações, a administração, os relatórios gerenciais e o FHIR. A instituição não vê sessões nem CPF e não usa a API original de prontuário.
- **Fluxos de acompanhamento:** agendamento confirmado, **conflito de horário recusado**, cancelamento com histórico e registro de sessão, com o texto guardado como dado.
- **Integrações e dados:** relatório CSV, FHIR Patient mínimo, recomendações explicadas, estabelecimentos do SUS, token para a API original com escopo e exportação LGPD.
- **Fluxos entre perfis:** solicitação, duplicidade recusada, mensagem, recebimento pela instituição, recusa sem motivo bloqueada, resposta, notificação à família e logout. A pessoa acompanhada vê só o próprio cadastro.

Ele grava poucos registros com o prefixo `[TESTE]` e só roda quando o banco tem os dados de demonstração (use um banco de teste). Para testar também a administração, defina `ECO_TESTE_ADMIN_EMAIL` e `ECO_TESTE_ADMIN_SENHA`.

## 4. Roteiro manual (navegador)

1. **Primeiro acesso:** entre com `admin@ecoconnect.com` / `Admin1234`. Confirme que a troca de senha é exigida antes de qualquer tela.
2. **Administração:** em *Usuários*, crie um profissional e confira a senha temporária e a troca obrigatória dele. Ative uma conta criada pelo cadastro público.
3. **Profissional (Ana):** registre uma sessão a partir da agenda, crie um objetivo com indicador e avaliação e veja o gráfico. Libere um relatório para a família.
4. **Família (Mariana):** peça um horário, veja o relatório liberado e preencha o perfil de necessidades. Abra *Rede de apoio > Recomendações*, envie uma solicitação e troque mensagens.
5. **Instituição (Roberta):** responda à solicitação, atualize as vagas e veja as pessoas vinculadas.
6. **Acessibilidade:** em *Minha conta > Acessibilidade*, ative o baixo estímulo, a fonte maior e o alto contraste. Use só o teclado (Tab, Enter, setas nas abas) e confira o foco visível. Reduza a janela para a largura de um celular.
7. **SUS:** em *Administração > Integrações*, importe o CSV do CNES da sua UF. Busque UBS, CAPS e CER em *Caminhos no SUS*.
8. **Persistência:** execute `restart.bat` e confirme que os dados continuam lá.

## 5. Resultado esperado e registro

Anote o resultado do `healthcheck -Completo` (número de verificações, sucesso e falhas) neste documento depois da primeira execução na máquina da equipe. Se algo falhar, a saída indica a verificação, o código HTTP e a mensagem da API, e o registro completo fica em `logs/ecoconect-api.log`.
