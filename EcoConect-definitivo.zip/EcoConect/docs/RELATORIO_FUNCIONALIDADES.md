# Relatório de funcionalidades: EcoConect

Legenda: **Implementado** (código, rota e tela) · **Parcial** (implementado com limitação descrita).

## Módulos

| Módulo (seção do pedido) | Situação | Onde |
|---|---|---|
| 5.1 Painel | Implementado | Tela *Painel*. Indicadores calculados no banco a cada acesso e filtrados pelo escopo do perfil: pessoas, em acompanhamento, sessões (total e do mês), próximas sessões, pedidos de horário, solicitações (total e pendentes), instituições, profissionais ativos, contas aguardando ativação, pedidos LGPD, atividades recentes, avisos e gráfico de sessões por mês. Painel próprio para família e para instituição (`GET /api/app/painel`) |
| 5.2 Cadastro e perfil da pessoa | Implementado | *Pessoas* → cadastro (equipe ou responsável, com consentimento LGPD), dados básicos, responsáveis (permissões de consulta e de pedido de horário), perfil de necessidades (condições informadas, sensorial, comunicação, acessibilidade, local, gratuidade), vários profissionais autorizados, instituições vinculadas, histórico de alterações (auditoria). CPF e dados sensíveis são opcionais |
| 5.3 Acompanhamento terapêutico | Implementado | *Registrar sessão*: data e hora, profissionais, tipo, atividades, objetivos trabalhados, evolução, dificuldades, recomendações, próximos passos, anotações internas e relatório opcional com liberação à família. A *linha do tempo* reúne agendamentos, sessões, relatórios e histórico de saúde. *Objetivos e indicadores* têm meta, avaliações e gráfico. Autor, data e alterações ficam registrados. Não há diagnóstico automático |
| 5.4 Agenda | Implementado | Visão de 14 dias, pedido de horário pela família, agendamento pela equipe, confirmação, remarcação, cancelamento, recusa, ausência, "registrar sessão" a partir do agendamento e histórico de cada agendamento. **Conflito de horário** verificado para a pessoa e para os profissionais. As notificações são internas |
| 5.5 Profissionais | Implementado | *Profissionais*: área e registro, especialidades, instituições, situação da conta, pessoas acompanhadas, agenda e atividades recentes. Cadastro e níveis de permissão em *Administração > Usuários* |
| 5.6 Gestão institucional | Implementado | *Minha instituição*: dados, contato, endereço, serviços (com gratuidade), público e faixa etária, condições atendidas, modalidades, acessibilidade, vagas, recebimento de solicitações, pessoas vinculadas, profissionais e membros. A instituição vê só o perfil e as necessidades, nunca sessões ou dados de saúde |
| 5.7 Busca e correspondência | Implementado | *Rede de apoio*: filtros (condição, idade, local, serviço, tipo, gratuidade, SUS, modalidade, acessibilidade, vagas). *Recomendações* a partir do perfil de necessidades, com a lista "Por que foi recomendada" e "Pontos de atenção" e o aviso de que não é diagnóstico nem garantia |
| 5.8 Comunicação | Implementado | *Mensagens*: conversas, histórico, situação de leitura ("lida") e contador no topo. Contatos limitados pelos vínculos. *Solicitações de atendimento* abrem uma conversa com a instituição. Toda operação tem confirmação visual |
| 5.9 Integração com o SUS | Parcial | Busca de UBS, CAPS (infantojuvenil, II e AD), CER e policlínicas por município, guia em linguagem simples ("o que é", "quando procurar", "como acessar", situações passo a passo) e importação do arquivo oficial do CNES. Recursos FHIR R4 (`Patient` mínimo, `Organization`, `Location`, `HealthcareService`, `ServiceRequest` e pacote). **RNDS:** adaptador com teste de autenticação mTLS, desligado sem credenciamento. Não envia dados clínicos |
| 5.10 Relatórios | Implementado | CSV (Excel/LibreOffice): sessões, agendamentos, histórico de uma pessoa, solicitações, atividade das instituições e indicadores administrativos por mês. Respeita o escopo e fica registrado na auditoria |

## Usuários e permissões (seção 6)

| Perfil | Pode |
|---|---|
| Administrador geral | Tudo. Contas (criar com senha temporária, ativar, bloquear, redefinir senha), instituições e membros, auditoria, pedidos LGPD, importação do CNES, RNDS |
| Administrador institucional | Painel da própria instituição, serviços, vagas, solicitações recebidas, pessoas vinculadas (dados mínimos), mensagens e relatórios da instituição |
| Profissional | Pessoas que acompanha (autorização ou designação), sessões, agenda, objetivos e avaliações, relatórios da equipe e FHIR das suas pessoas |
| Responsável / família | Pessoas da família (vínculo ativo com permissão), pedidos de horário, cadastro de pessoa, perfil de necessidades, rede de apoio, solicitações, mensagens, relatórios liberados, privacidade |
| Pessoa acompanhada | O próprio acompanhamento, agenda, rede de apoio, solicitações, mensagens e privacidade |

A verificação acontece no servidor, em três camadas: rota (`PoliticaAcesso`), registro (`EscopoAcesso`) e regra do serviço. A interface só esconde o que o perfil não usa.

## Design e acessibilidade (seção 7)

- **Identidade:** verdes do protótipo original, sem dependências externas e com layout previsível (menu lateral fixo e cabeçalho de página padrão).
- **Ajustes do usuário (Minha conta > Acessibilidade):** modo de **baixo estímulo**, **tamanho da fonte** (3 níveis), **alto contraste**, **leitura facilitada** (espaçamento para dislexia) e **reduzir movimento**. Os ajustes ficam salvos na conta.
- **Recursos da interface:**
  - Navegação por teclado, link "Pular para o conteúdo", foco visível e abas acessíveis com as setas.
  - Janelas nativas `<dialog>` e avisos anunciados por `aria-live`.
  - Rótulos em todos os campos e mensagens de erro em português perto do campo.
  - Tabelas que viram cartões no celular.
  - Comunicação escrita como padrão: mensagens em vez de telefone.

## LGPD e segurança (seção 8)

- **Consentimento:** registrado no cadastro pela família e revogável em *Minha conta*.
- **Direitos do titular:** coleta mínima (CPF opcional) e exportação dos dados do titular em JSON. Pedidos de acesso, correção, exclusão e portabilidade são atendidos pelo administrador, com **anonimização** da conta. O histórico de saúde é guardado (dever de guarda, regra RI-20).
- **Auditoria:** login, falhas de login, logout, consultas a dados sensíveis (FHIR, exportações, relatórios), criações, alterações, exclusões lógicas, validações e liberações. Valores antes e depois ficam em JSON.
- **Senhas e acesso:** senhas em BCrypt, bloqueio por tentativas e sessões revogáveis. Logout e troca de senha encerram as outras sessões.
- **Proteções contra ataques:**
  - **SQL injection:** consultas parametrizadas.
  - **XSS:** `textContent` e CSP sem scripts inline.
  - **CSRF:** cabeçalho obrigatório nas gravações com cookie.
  - **Arquivos CSV:** fórmulas do Excel são neutralizadas.

## Execução local (seções 9 e 13)

Setup e inicialização automáticos:
- **Ambiente:** verificam o Java (com instalação via winget), baixam o Maven com conferência SHA-512 e pedem a senha do MySQL uma única vez.
- **Banco:** verificam a porta do MySQL. Se ela estiver fechada, tentam iniciar o serviço e, sem MySQL, sobem o Docker. Criam o banco e aplicam as migrations.
- **Aplicação:** compilam, rodam os testes automatizados, iniciam a API em segundo plano, aguardam a verificação de saúde e abrem o navegador.
- **Arquivos:** `stop`, `restart`, `healthcheck` (com teste ponta a ponta opcional) e `console`. Configuração em `ecoconnect.properties` (com exemplo), credenciais iniciais documentadas e troca obrigatória da senha do administrador.
