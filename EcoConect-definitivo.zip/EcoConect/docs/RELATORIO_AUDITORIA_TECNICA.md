# Relatório de auditoria técnica: EcoConect

## 1. Material analisado

| Material | Conteúdo encontrado |
|---|---|
| `EcoConnect (1).zip` | API REST Spring Boot (`ecoconnect-api-jpa`), Console Java (`EcoConect-Console`), dump MySQL (`EcoConnect_backup_final.sql`), `ecoconnect.properties`, `LEIA-ME.md` |
| `EcoConnect_backup-main.zip` | Protótipo navegável em HTML/CSS/JS (1.490 linhas): dados fixos no próprio arquivo, sem chamadas à API e sem `localStorage` |
| `EcoConect-landingpage-main.zip` | Landing page estática (HTML/CSS) |
| PDFs | Documentação do projeto, artigo científico, AC2 e relatório de validação da persona real (contexto Equocura / Intercura) |
| `ThinkCODE.png` | Pôster da Mostra de Projetos: equipe, telas e identidade visual |

Todos os arquivos dos três ZIPs foram lidos. O material do repositório original foi preservado sem alterações em `legado/`.

## 2. Mapa técnico do que existia

| Item | Situação encontrada |
|---|---|
| Linguagens | Java 17 (API e Console), SQL (MySQL 8), HTML/CSS/JS (protótipos) |
| Frameworks | Spring Boot 3.3.5 (Web, Data JPA, Validation), Hibernate 6, springdoc-openapi 2.6, spring-security-crypto (somente BCrypt) |
| Banco | MySQL 8, banco `ecoconnect`, **32 tabelas** com FKs compostas, CHECKs e ENUMs. **O dump não traz dados** e começa com `DROP TABLE` (destrutivo) |
| API | 46 controllers e 78 mapeamentos explícitos, mais o CRUD herdado de `CrudController`/`LeituraController`. Regras RI-01 a RI-21 da modelagem e auditoria de gravações |
| Autenticação | **Inexistente.** O login conferia a senha, mas as rotas não exigiam sessão. O autor era o cabeçalho `X-Usuario-Id`, que qualquer cliente podia falsificar. CORS `*` |
| Console | CRUD genérico por metadados JDBC sobre as 32 tabelas, no mesmo banco. Senha com jBCrypt |
| Configuração | `ecoconnect.properties`, compartilhado por API e Console, com prioridade para variáveis de ambiente. Porta 8080 (API) e 3306 (MySQL) |
| Execução | Manual: importar o SQL no Workbench, abrir os projetos no NetBeans e executar cada um |
| Testes | Nenhum teste automatizado. O README da API declarava que ela nunca tinha sido executada contra um MySQL real |

### Funcionalidades encontradas

- **Implementadas na API original:** usuários, perfis, crianças, responsáveis e vínculos; profissionais e especialidades; agendamentos com histórico; atendimentos, participantes e atividades; relatórios com versões e liberação à família; objetivos, indicadores e avaliações; histórico de saúde, diagnósticos, condições, documentos (metadados) e consentimentos; fila de espera, comunicados, notificações e auditoria.
- **Ausentes:**
  - Autenticação e autorização.
  - Instituições de apoio, busca e recomendação, integração com o SUS/CNES e FHIR.
  - Mensagens entre usuários.
  - Painel, relatórios exportáveis e direitos do titular (LGPD).
  - Interface conectada à API.
  - Inicialização automatizada e testes.

## 3. Problemas encontrados e tratamento

| # | Problema | Gravidade | Tratamento |
|---|---|---|---|
| 1 | Rotas sem autenticação; autor falsificável por `X-Usuario-Id` | Crítica | Sessões no banco (hash SHA-256 do token), cookie HttpOnly e SameSite, token Bearer para clientes de API. Cabeçalho legado desativado |
| 2 | Qualquer usuário via dados de qualquer criança | Crítica | Política por rota (`PoliticaAcesso`) e escopo por pessoa (`EscopoAcesso`) aplicados no servidor, inclusive nas rotas originais (`CrudService`, `EscopoInterceptor`) |
| 3 | Campos de autoria (`idUsuarioRegistro`...) vinham do cliente | Alta | `AutorDaRequisicaoAdvice` substitui esses campos pelo usuário autenticado |
| 4 | CORS liberado para qualquer origem com credenciais | Alta | CORS desligado por padrão: a aplicação é servida na mesma origem da API |
| 5 | Script SQL com `DROP TABLE` como forma de instalação | Alta | Migrations Flyway (`V1` = esquema original sem comandos destrutivos). Banco existente é preservado por *baseline* |
| 6 | Senhas sem regra de troca; admin inicial com senha conhecida | Média | Troca obrigatória no primeiro acesso e após senha temporária. Bloqueio após 5 tentativas em 15 min |
| 7 | Front-ends sem integração | Alta | Nova aplicação web servida pelo Spring Boot, consumindo a API real. Landing page original adaptada como página inicial |
| 8 | Ausência da Frente B (rede de apoio e SUS) | Alta | Novos módulos e tabelas (V3/V4), descritos no relatório de funcionalidades |
| 9 | Instalação manual em várias ferramentas | Média | `setup`/`start`/`stop`/`restart`/`healthcheck`/`console` (`.bat` com PowerShell e `.sh`) |

## 4. Decisões técnicas

- **Arquitetura preservada.** A API continua Spring Boot + JPA + MySQL e o Console continua Java/JDBC no mesmo banco. As 32 entidades e as regras originais foram mantidas. As mudanças nos serviços originais são acréscimos (escopo, conflito de horário, autoria).
- **Banco versionado.** Quatro migrations aditivas:
  - **V1:** esquema original.
  - **V2:** sessões, troca de senha, preferências e novos perfis `ADMIN_INSTITUCIONAL` e `PESSOA_ACOMPANHADA`.
  - **V3:** rede de apoio, SUS, conversas, solicitações, perfil de necessidades, profissionais autorizados e registro estruturado de sessão.
  - **V4:** vínculo pessoa–instituição, pedidos do titular e registro dos dados de demonstração.

  O banco é criado automaticamente (`createDatabaseIfNotExist`).
- **API do aplicativo (`/api/app/...`).** Rotas orientadas às telas, com consultas SQL de leitura via `JdbcTemplate` e gravações pelos serviços originais quando eles existem (histórico, auditoria e notificações continuam valendo).
- **Segurança sem o Spring Security completo.** A dependência original (somente `spring-security-crypto`) foi mantida. A autenticação é um filtro próprio com a política em uma classe pura, testada isoladamente. CSP sem scripts inline e cabeçalhos de segurança em todas as respostas.
- **Front-end sem etapa de build.** HTML, CSS e JavaScript (módulos ES) servidos pelo próprio Spring Boot, sem bibliotecas externas. Todo dado entra na tela por `textContent` (proteção contra XSS). As preferências de acessibilidade ficam no banco, e o `localStorage` só guarda uma cópia visual.
- **Docker apenas como alternativa.** O ambiente da equipe (NetBeans + MySQL local) é o caminho principal. O `docker-compose.yml` sobe só o MySQL, e só quando não há MySQL local.
- **SUS sem conexão falsa.** O catálogo vem do arquivo oficial do CNES (importação pelo administrador). Os recursos FHIR R4 são somente leitura. O adaptador da RNDS fica desligado sem credenciamento e certificado ICP-Brasil e não envia dados clínicos.
- **Dados fictícios separados.** Os dados de demonstração usam o domínio `demo.ecoconect.local`, estão listados em `registro_demonstracao`, aparecem com a etiqueta "Fictício" e só são carregados em banco vazio.

## 5. Arquitetura final

```
Navegador ── /  (landing page) ── /app/ (aplicação web, módulos ES)
     │  HTTPS/HTTP mesma origem, cookie HttpOnly + X-Requested-With
     ▼
Spring Boot 3.3 (porta 8080, 127.0.0.1)
  CabecalhosSeguranca → FiltroAutenticacao (PoliticaAcesso) → EscopoInterceptor
  Controllers: originais (/api/...) + aplicativo (/api/app, /api/rede, /api/sus, /api/fhir, /api/rnds, /api/relatorios, /api/admin)
  Serviços: originais (regras RI-xx, auditoria) + app (escopo, consultas, recomendação, LGPD)
  Flyway (db/migration V1–V4) · DadosIniciais · DadosDemonstracao
     ▼
MySQL 8 (banco ecoconnect, 49 tabelas)  ◄── Console Java (JDBC, mesmo banco)
```

## 6. Limitações conhecidas

- A integração bidirecional com a RNDS depende de credenciamento do estabelecimento e de modelo de informação homologado. Está preparada (adaptador, FHIR), mas não ativa.
- O catálogo do SUS só tem dados reais depois da importação do arquivo do CNES (os estabelecimentos de demonstração são fictícios).
- Os documentos clínicos continuam só com metadados (como na API original). O armazenamento dos arquivos não foi implementado.
- Este pacote foi produzido em um ambiente sem Maven, sem internet e sem MySQL. O que foi e o que não foi executado está descrito em `RELATORIO_TESTES.md`.
